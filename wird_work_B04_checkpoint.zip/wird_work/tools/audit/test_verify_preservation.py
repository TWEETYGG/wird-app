#!/usr/bin/env python3
"""Self-test for verify_preservation.py: builds scratch copies of the project, applies one mutation each and checks
that the verifier reports exactly the expected verdict.  Never touches the real tree.
usage:  python3 -I tools/audit/test_verify_preservation.py"""
import os, re, sys, shutil, tempfile, subprocess

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))
VERIFY = os.path.join(ROOT, 'tools', 'audit', 'verify_preservation.py')
results = []


def run(tree, *extra):
    p = subprocess.run([sys.executable, '-I', os.path.join(tree, 'tools', 'audit', 'verify_preservation.py'), *extra],
                       capture_output=True, text=True)
    return p.returncode, p.stdout + p.stderr


def case(name, mutate, expect_fail, must_contain=None, extra=()):
    tmp = tempfile.mkdtemp(prefix='wird-vp-')
    tree = os.path.join(tmp, 'p')
    shutil.copytree(ROOT, tree, ignore=shutil.ignore_patterns('.git', '__pycache__', 'node_modules'))
    try:
        mutate(tree)
        rc, out = run(tree, *extra)
        ok = (rc != 0) == expect_fail and (must_contain is None or must_contain in out)
        results.append((ok, name, rc, must_contain))
        if not ok: print(out)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def edit(rel, fn, enc='utf-8'):
    def m(tree):
        p = os.path.join(tree, rel); s = open(p, encoding=enc).read(); t = fn(s)
        assert t != s, 'mutation did not change %s' % rel
        open(p, 'w', encoding=enc).write(t)
    return m


def add_block(tag, ident, body):
    def m(tree):
        p = os.path.join(tree, 'index.html'); s = open(p, encoding='utf-8').read()
        blk = '\n<%s id="%s">%s</%s>\n' % (tag, ident, body, tag)
        anchor = '<script id="wird-offline">'
        assert anchor in s
        open(p, 'w', encoding='utf-8').write(s.replace(anchor, blk + anchor, 1))
    return m


case('untouched copy passes', lambda t: None, False, 'PASS')
case('sw.js one byte changed -> FAIL', edit('sw.js', lambda s: s.replace('use strict', 'use  strict', 1)), True, 'sw.js')
case('SHELL_VERSION bump -> FAIL (needs approval)', edit('sw.js', lambda s: s.replace('SHELL_VERSION = 5;', 'SHELL_VERSION = 6;', 1)), True, 'SHELL_VERSION')
case('wird-update block changed -> FAIL', edit('index.html', lambda s: s.replace('<script id="wird-update">', '<script id="wird-update">/*x*/', 1)), True, 'FROZEN block changed (len 8319')
case('ls-main (minified lesson engine) changed -> FAIL', edit('index.html', lambda s: s.replace('<script id="ls-main">"use strict";', '<script id="ls-main">"use strict";;', 1)), True, 'script:ls-main')
case('manifest changed -> FAIL', edit('manifest.webmanifest', lambda s: s + ' '), True, 'manifest.webmanifest')
case('existing test file changed -> FAIL', edit('tests/update.test.js', lambda s: s + '\n//x'), True, 'tests/update.test.js')
case('legacy build script changed -> FAIL', edit('tools/patch/build.py', lambda s: s + '\n#x'), True, 'tools/patch/build.py')
case('existing file deleted -> FAIL', lambda t: os.remove(os.path.join(t, 'icon-192.png')), True, 'MISSING')
case('main inline app script changed, no allow -> FAIL', edit('index.html', lambda s: s.replace('const HK=\'wird_habits_v1\';', 'const HK=\'wird_habits_v1\';/*hook*/', 1)), True, 'GUARDED block changed without')
case('main inline app script changed, --allow-guarded script:#2 -> PASS', edit('index.html', lambda s: s.replace('const HK=\'wird_habits_v1\';', 'const HK=\'wird_habits_v1\';/*hook*/', 1)), False, 'GUARDED', extra=('--allow-guarded', 'script:#2'))
case('body markup changed, no allow -> FAIL', edit('index.html', lambda s: s.replace('<body>', '<body><div id="x"></div>', 1)), True, 'markup')
case('README appended -> PASS (append-only)', edit('README-OFFLINE-AR.txt', lambda s: s + '\n\nextra section'), False, 'PASS')
case('README original text altered -> FAIL', edit('README-OFFLINE-AR.txt', lambda s: 'X' + s[1:]), True, 'original text was altered')
case('new wird-tasks block inserted before wird-offline -> PASS', add_block('script', 'wird-tasks', 'window.WirdTasks={};'), False, 'script:wird-tasks')
case('new wird-quiz css block -> PASS', add_block('style', 'wird-quiz-css', '.q{}'), False, 'style:wird-quiz-css')
case('unexpected new block id -> FAIL', add_block('script', 'my-other', 'var a=1;'), True, 'UNEXPECTED new block')
case('new block calls deleteDatabase -> FAIL', add_block('script', 'wird-quiz', 'indexedDB.deleteDatabase("x")'), True, 'deletes a database')
case('new block opens another IDB -> FAIL', add_block('script', 'wird-quiz', 'indexedDB.open("wird_study_db",3)'), True, 'other than wird_quiz_db')
case('new block opens wird_quiz_db -> PASS', add_block('script', 'wird-quiz', 'indexedDB.open("wird_quiz_db",1)'), False, 'PASS')
case('new block writes foreign localStorage key -> FAIL', add_block('script', 'wird-tasks', 'localStorage.setItem("wird_habits_v1","{}")'), True, 'outside wird_tasks')
case('new block writes wird_tasks_v1 -> PASS', add_block('script', 'wird-tasks', 'localStorage.setItem("wird_tasks_v1","{}")'), False, 'PASS')
case('new block touches serviceWorker -> FAIL', add_block('script', 'wird-tasks', 'navigator.serviceWorker.getRegistrations()'), True, 'service worker')
case('new block touches caches -> FAIL', add_block('script', 'wird-quiz', 'caches.keys()'), True, 'Cache Storage')
case('new block localStorage.clear -> FAIL', add_block('script', 'wird-quiz', 'localStorage.clear()'), True, 'clears web storage')
case('new block .clear() -> WARN only', add_block('script', 'wird-quiz', 'new Map().clear()'), False, 'WARN')


def reorder(s):
    a = re.search(r'<script id="wird-offline">.*?</script>', s, re.S).group(0)
    b = re.search(r'<script id="wird-update">.*?</script>', s, re.S).group(0)
    return s.replace(a, '\x01A\x01').replace(b, '\x01B\x01').replace('\x01A\x01', b).replace('\x01B\x01', a)


case('two baseline blocks swapped -> FAIL (order)', edit('index.html', reorder), True, 'ORDER CHANGED')

bad = [r for r in results if not r[0]]
for ok, name, rc, mc in results:
    print('%s %s' % ('PASS' if ok else 'FAIL', name))
print('\n%d/%d verifier self-tests passed' % (len(results) - len(bad), len(results)))
sys.exit(1 if bad else 0)
