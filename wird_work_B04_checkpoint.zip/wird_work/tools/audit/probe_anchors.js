// Task 0.2 evidence probe — READ-ONLY with respect to the project (serves it, never writes into it except --out).
// Opens the real app in Chromium (390×844, Arabic, service worker blocked, no external network) and records the facts the
// roadmap depends on: helper globals, habit-row/quick-task/wizard anchors, lesson-header anchors, KaTeX loading, repo API,
// resource-type validation, storage footprint.
// usage:  NODE_PATH=$(npm root -g) node tools/audit/probe_anchors.js [--out docs/spike-evidence]
const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
const ROOT = path.resolve(__dirname, '..', '..');
const OUT = path.resolve(ROOT, (process.argv.includes('--out') ? process.argv[process.argv.indexOf('--out') + 1] : 'docs/spike-evidence'));
fs.mkdirSync(OUT, { recursive: true });
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };
const server = http.createServer((req, res) => { const u = decodeURIComponent(req.url.split('?')[0]); const f = u === '/' ? path.join(ROOT, 'index.html') : path.join(ROOT, u);
  if (!f.startsWith(ROOT)) { res.writeHead(403); return res.end(); }
  fs.readFile(f, (e, d) => { if (e) { res.writeHead(404); return res.end(); } res.writeHead(200, { 'content-type': MIME[path.extname(f)] || 'application/octet-stream' }); res.end(d); }); });
const sleep = ms => new Promise(r => setTimeout(r, ms));
const out = { probe: 'Task 0.2', when: new Date().toISOString(), viewport: '390x844', sections: {}, errors: [] };
const sec = async (name, fn) => { try { out.sections[name] = await fn(); } catch (e) { out.sections[name] = { PROBE_ERROR: String(e && e.message || e).split('\n')[0] }; } };
(async () => {
  await new Promise(r => server.listen(0, '127.0.0.1', r)); const BASE = 'http://127.0.0.1:' + server.address().port;
  const browser = await chromium.launch({ args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, locale: 'ar-EG', timezoneId: 'Africa/Cairo', serviceWorkers: 'block' });
  const p = await ctx.newPage(); p.on('pageerror', e => out.errors.push('pageerror: ' + e)); p.on('console', m => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) out.errors.push('console: ' + m.text()) });
  await p.route(/^https?:\/\/(?!127\.0\.0\.1)/, r => r.abort());
  await p.goto(BASE + '/index.html'); await sleep(700);

  await sec('a0_globals_available_to_a_classic_script_module', () => p.evaluate(() => { const o = {}; ['H', 'hSave', 'hRender', 'hModal', 'hUid', 'hTasks', 'hSheet', 'hSettings', 'hWizard', 'showToast', 'showConfirm', 'escapeHtml', 'toArabicNum', 'todayISO', 'el', 'dbPut', 'pmChime', 'pmAudio', 'PM', 'HT'].forEach(n => { try { o[n] = typeof eval(n) } catch (e) { o[n] = 'MISSING' } }); o.katexBeforeLessonsOpen = typeof globalThis.katex; o.hFabIsElement = !!document.getElementById('hFab'); return o; }));

  // ---------- habits: today list, quick task, wizard ----------
  await p.click('.tab[data-view="view-habits"]'); await sleep(500);
  await sec('b1_habits_top_bar', () => p.evaluate(() => [...document.querySelectorAll('#habitsRoot .hb-top button')].map(b => (b.dataset.v || '') + '|' + b.textContent.trim())));
  await sec('b2_quick_task_modal_and_row', async () => {
    await p.evaluate(() => document.getElementById('hFab').click()); await sleep(250);
    const modal = await p.evaluate(() => { const m = document.querySelector('.modal-overlay.open .modal'); return m ? { ids: [...m.querySelectorAll('[id]')].map(e => e.id), h3: m.querySelector('h3') && m.querySelector('h3').textContent, buttons: [...m.querySelectorAll('button')].map(b => b.id + '|' + b.textContent.trim()) } : null });
    await p.fill('#qn', 'مهمة تجريبية للمسبار'); await p.click('#hok'); await sleep(400);
    const row = await p.evaluate(() => { const r = document.querySelector('.hb-task[data-id^="o_"]'); if (!r) return null; return { html: r.outerHTML.slice(0, 700), dataId: r.dataset.id }; });
    const before = await p.evaluate(() => document.querySelectorAll('.modal-overlay.open').length);
    await p.evaluate(() => document.querySelector('.hb-task[data-id^="o_"] .hb-n').click()); await sleep(250);
    const after = await p.evaluate(() => document.querySelectorAll('.modal-overlay.open').length);
    const oneoff = await p.evaluate(() => { const d = todayISO(); return H.oneoffs[d]; });
    await p.screenshot({ path: path.join(OUT, '01-habits-today-with-quick-task.png') });
    return { modal, row, tapOnQuickTaskNameOpensSomething: after > before, oneoffShape: oneoff };
  });
  await sec('b3_wizard_step2_chip_layout', async () => {
    await p.evaluate(() => document.querySelector('#habitsRoot .hb-top [data-v="new"]').click()); await sleep(300);
    await p.fill('#wn', 'عادة المسبار'); await p.click('#wx'); await sleep(250);
    const r = await p.evaluate(() => { const c = document.getElementById('wt'); if (!c) return null; const cr = c.getBoundingClientRect(); const chips = [...c.querySelectorAll('button')].map(b => { const r = b.getBoundingClientRect(); return { t: b.textContent.trim(), x: Math.round(r.left), y: Math.round(r.top), w: Math.round(r.width), h: Math.round(r.height) } }); return { container: { x: Math.round(cr.left), y: Math.round(cr.top), w: Math.round(cr.width) }, chips, title: document.querySelector('.modal-overlay.open .modal h3').textContent }; });
    if (r) { const rows = {}; r.chips.forEach(c => (rows[c.y] = rows[c.y] || []).push(c)); r.rows = Object.keys(rows).map(y => ({ y: +y, chips: rows[y].map(c => c.t), leftEdge: Math.min(...rows[y].map(c => c.x)), rightEdge: Math.max(...rows[y].map(c => c.x + c.w)) })); const last = r.rows[r.rows.length - 1]; r.freeSlotInLastRow = { fromX: r.container.x, toX: last.leftEdge, width: last.leftEdge - r.container.x, fitsAnotherChip: (last.leftEdge - r.container.x) > 120 }; }
    await p.screenshot({ path: path.join(OUT, '02-wizard-step2-chips.png') });
    await p.evaluate(() => document.querySelector('.modal-overlay.open').remove());
    return r;
  });
  await sec('b4_habit_settings_entry', async () => { await p.evaluate(() => document.querySelector('#habitsRoot .hb-top [data-v="set"]').click()); await sleep(250); const r = await p.evaluate(() => { const m = document.querySelector('.modal-overlay.open .modal'); return m ? { h3: m.querySelector('h3') && m.querySelector('h3').textContent, headings: [...m.querySelectorAll('h3,.field-label')].slice(0, 8).map(e => e.textContent.trim().slice(0, 40)) } : null }); await p.evaluate(() => { const o = document.querySelector('.modal-overlay.open'); o && o.remove() }); return r; });

  // ---------- lessons workspace ----------
  await p.click('.tab[data-view="view-lessons"]'); await p.waitForFunction(() => window.__WIRD_STUDY_APP__ && __WIRD_STUDY_APP__.isOpen, null, { timeout: 15000 }); await sleep(700);
  const ids = await p.evaluate(async () => { const a = __WIRD_STUDY_APP__, r = a.repo; await a.init(); const s = await r.createSubject('فيزياء'), u = await r.createUnit(s.id, 'الحركة'), l = await r.createLesson({ subjectId: s.id, unitId: u.id, title: 'الدرس الأول' }); return { s: s.id, u: u.id, l: l.id } });
  await sleep(500);
  await p.evaluate(() => { const a = __WIRD_STUDY_APP__; a.tree.subjects.forEach(x => a.sidebar.setExpanded(x.id, true)); a.tree.units.forEach(x => a.sidebar.setExpanded(x.id, true)); a.sidebar.render(); a.root.classList.add('side-open'); }); await sleep(400);
  await sec('c1_sidebar_row_buttons_(add-new-sheet-candidates)', async () => { await p.screenshot({ path: path.join(OUT, '03-sidebar-rows.png') }); return p.evaluate(() => [...document.querySelectorAll('.ls-row')].map(r => ({ row: r.textContent.trim().replace(/\s+/g, ' ').slice(0, 30), cls: (r.className + '').slice(0, 50), buttons: [...r.querySelectorAll('button')].map(b => ({ aria: b.getAttribute('aria-label'), text: b.textContent.trim(), cls: (b.className + '') })) }))); });
  await sec('c2_patch_free_sidebar_hook (window.__wirdRow wrapper)', async () => p.evaluate(() => { const orig = window.__wirdRow; if (typeof orig !== 'function') return { hook: typeof orig }; let calls = 0; window.__wirdRow = (row, el) => { orig(row, el); calls++; if (row && row.kind === 'unit' && !el.querySelector('.probe-mark')) { const s = document.createElement('span'); s.className = 'probe-mark'; el.appendChild(s) } }; __WIRD_STUDY_APP__.sidebar.render(); const marks = document.querySelectorAll('.probe-mark').length; window.__wirdRow = orig; __WIRD_STUDY_APP__.sidebar.render(); return { hook: 'function', wrapperCalledDuringRender: calls, unitRowsMarked: marks, restored: document.querySelectorAll('.probe-mark').length === 0 }; }));
  await p.evaluate(() => { const row = [...document.querySelectorAll('.ls-row')].find(r => r.textContent.includes('الدرس الأول')); row && row.click(); });
  await p.waitForSelector('.wr[data-lesson]'); await sleep(900); await p.evaluate(() => __WIRD_STUDY_APP__.root.classList.remove('side-open')); await sleep(300);
  await sec('c3_lesson_header_structure', async () => { await p.screenshot({ path: path.join(OUT, '04-lesson-view.png') }); return p.evaluate(() => { const wr = document.querySelector('.wr[data-lesson]'); const kids = el => [...el.children].map(c => c.tagName.toLowerCase() + (c.id ? '#' + c.id : '') + '.' + (c.className + '').trim().replace(/\s+/g, '.')); return { wrParentClass: wr.parentElement.className, parentChildren: kids(wr.parentElement), wrChildren: kids(wr), wrFootChildren: kids(wr.querySelector('.wr-foot')), tabs: [...wr.querySelectorAll('#wrTabs button')].map(b => b.textContent.trim()), topBar: [...document.querySelectorAll('.ls-ws button')].filter(b => b.offsetParent && b.getBoundingClientRect().top < 40).map(b => (b.getAttribute('aria-label') || '') + '|' + b.textContent.trim()) } }); });
  await sec('c4_which_anchor_survives_header_rerender', async () => {
    await p.evaluate(() => { const wr = document.querySelector('.wr[data-lesson]'); const a = document.createElement('span'); a.id = 'probeSibling'; wr.querySelector('#wrHead').after(a); const b = document.createElement('span'); b.id = 'probeInFoot'; wr.querySelector('.wr-foot').appendChild(b); const c = document.createElement('span'); c.id = 'probeAfterTabs'; wr.querySelector('#wrTabs').after(c); });
    await p.evaluate(async lid => { await __WIRD_STUDY_APP__.repo.saveResource({ id: 'res_probe_link', lessonId: lid, type: 'link', title: 'رابط المسبار', order: 1, status: 'todo', link: { url: 'https://example.com/' } }); }, ids.l); await sleep(900);
    return p.evaluate(() => ({ siblingAfterHeadSurvives: !!document.getElementById('probeSibling'), insideWrFootSurvives: !!document.getElementById('probeInFoot'), afterTabsSurvives: !!document.getElementById('probeAfterTabs') }));
  });
  await sec('d1_katex_mhchem_and_loader_pattern', async () => p.evaluate(() => { const r = { katexAfterLessonOpen: typeof katex, version: window.katex && katex.version }; try { r.frac = katex.renderToString('\\frac{a}{b}+\\sqrt{x}+\\alpha_1^2', { throwOnError: true, strict: 'ignore', trust: false }).length > 100; r.ce = !katex.renderToString('\\ce{2H2 + O2 -> 2H2O}', { throwOnError: true }).includes('katex-error'); r.lessonMacroNames = 'vect unit abs norm dd deriv pderiv R N Z Q (defined in ls-main var hr)'; } catch (e) { r.err = String(e).slice(0, 120) } r.assets = ['ls-asset-katex', 'ls-asset-mhchem', 'ls-asset-katex-css'].map(id => id + ':' + (document.getElementById(id) ? document.getElementById(id).textContent.length : 'MISSING')); r.styleInjectedId = !!document.getElementById('ls-katex-style'); return r; }));
  await sec('d2_katex_loads_without_opening_a_lesson (fresh page, own loader)', async () => {
    const q = await ctx.newPage(); await q.route(/^https?:\/\/(?!127\.0\.0\.1)/, r => r.abort()); await q.goto(BASE + '/index.html'); await sleep(600);
    const r = await q.evaluate(async () => { const pre = typeof katex; const run = id => { const t = document.getElementById(id); if (!t) return false; const s = document.createElement('script'); s.textContent = t.textContent || ''; document.head.appendChild(s); s.remove(); return true }; if (!document.getElementById('ls-katex-style')) { const c = document.getElementById('ls-asset-katex-css'); const st = document.createElement('style'); st.id = 'ls-katex-style'; st.textContent = c.textContent; document.head.appendChild(st) } const t0 = performance.now(); const ok = run('ls-asset-katex') && run('ls-asset-mhchem'); const ms = Math.round(performance.now() - t0); return { before: pre, loaded: ok, after: typeof katex, ms, ce: !katex.renderToString('\\ce{H2O}', { throwOnError: true }).includes('katex-error') } });
    await q.close(); return r;
  });
  await sec('e1_repo_mistakes_api', async () => p.evaluate(async lid => { const r = __WIRD_STUDY_APP__.repo; const m = await r.saveMistake({ lessonId: lid, errorDescription: 'خطأ تجريبي', rootCause: 'تجربة', correctionRule: 'قاعدة' }); const list = await r.listMistakes({ lessonId: lid }); await r.setMistakeStatus(m.id, 'mastered'); const after = (await r.listMistakes({ lessonId: lid })).find(x => x.id === m.id); await r.deleteMistake(m.id).catch(() => {}); return { savedRecordKeys: Object.keys(m), statusInitial: m.status, statusAfterSet: after && after.status, listLen: list.length, methods: ['saveMistake', 'listMistakes', 'setMistakeStatus', 'reseeMistake', 'deleteMistake'].map(k => k + ':' + typeof r[k]) } }, ids.l));
  await sec('e2_resource_type_quiz_validation', async () => p.evaluate(async lid => { const r = __WIRD_STUDY_APP__.repo; try { await r.saveResource({ id: 'res_probe_quiz', lessonId: lid, type: 'quiz', title: 'اختبار', order: 1, status: 'todo', quiz: { sessionId: 'q1' } }); return 'ACCEPTED' } catch (e) { return 'REJECTED: ' + String(e && e.message || e) } }, ids.l));
  await sec('f1_storage_footprint_after_probe', async () => p.evaluate(async () => ({ localStorageKeys: Object.keys(localStorage).sort(), indexedDBs: (await indexedDB.databases()).map(d => d.name + '@v' + d.version).sort(), hasQuizDb: (await indexedDB.databases()).some(d => d.name === 'wird_quiz_db') })));
  await sec('f2_pointer_and_viewport_notes', async () => p.evaluate(() => ({ innerWidth, innerHeight, dir: document.documentElement.dir, lang: document.documentElement.lang, vv: !!window.visualViewport, vibrate: typeof navigator.vibrate, share: typeof navigator.share, clipboard: !!(navigator.clipboard && navigator.clipboard.writeText), persist: !!(navigator.storage && navigator.storage.persist) })));
  fs.writeFileSync(path.join(OUT, 'probe-output.json'), JSON.stringify(out, null, 1));
  console.log(JSON.stringify(out.sections, null, 1).slice(0, 12000)); console.log('ERRORS', JSON.stringify(out.errors));
  await browser.close(); server.close();
})().catch(e => { console.error('PROBE FATAL', e); process.exit(1); });
