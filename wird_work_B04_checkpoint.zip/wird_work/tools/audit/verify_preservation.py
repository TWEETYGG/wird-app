#!/usr/bin/env python3
"""Wird preservation verifier  (Task 0.1)

Proves that the existing application, its update system and its data-safety guarantees are untouched
while the Task-Atomization / Focus-Quiz features are added.   Python stdlib only.

usage (run from the project root, or anywhere):
    python3 -I tools/audit/verify_preservation.py                    # verify the current tree against the baseline
    python3 -I tools/audit/verify_preservation.py --json             # same, machine readable
    python3 -I tools/audit/verify_preservation.py --allow-guarded script:#2,style:#0   # approved hook patches only
    python3 -I tools/audit/verify_preservation.py --write-baseline   # create the baseline (refuses if one exists)
    (the baseline in this project was written ONCE from the pristine upload:  --root <pristine dir> --baseline docs/PRESERVATION-BASELINE.json --write-baseline)

Exit code 0 = no FAIL.  Anything else = do not ship.

TIERS
  FROZEN       must stay byte-identical forever  (sw.js, manifest, icons, tools/**, tests/**, every <script>/<style> block of
               index.html except the guarded ones: update system, offline, lesson engine, KaTeX, courses, resources, unified, ...)
  GUARDED      may change ONLY through an approved, exact-match hook patch  (the main inline app <script> / <style> and the
               markup outside the blocks).  A change is reported as FAIL unless the block key is passed to --allow-guarded.
  APPEND-ONLY  existing text must stay a byte-for-byte prefix  (README-OFFLINE-AR.txt, docs/*.md that existed at baseline)
  NEW          anything not in the baseline.  New files are fine.  New index.html blocks are fine only if their id starts with
               one of --allow-added-prefix (default: wird-tasks, wird-quiz), and are scanned for forbidden APIs.
"""
import re, sys, os, json, hashlib, argparse, datetime

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))
BASELINE = os.path.join(ROOT, 'docs', 'PRESERVATION-BASELINE.json')
INDEX = 'index.html'
BLOCK_RE = re.compile(r'<(script|style)\b([^>]*)>(.*?)</\1>', re.S)

GUARDED_BLOCKS = {'script:#2', 'style:#0', 'markup'}          # main inline app script, main stylesheet, body markup
APPEND_ONLY = {'README-OFFLINE-AR.txt', 'docs/RESOURCES-DEV-NOTES.md', 'docs/UNIFIED-DEV-NOTES.md', 'docs/UPDATE-GUIDE.md'}
# whole-file counters that may never go UP (destructive / update-system APIs)
TRIPWIRES = ['deleteDatabase', 'localStorage.clear', 'sessionStorage.clear', 'caches.delete', 'serviceWorker']
# forbidden in NEW blocks (regex, message, severity)
NEW_CODE_RULES = [
    (r'deleteDatabase', 'deletes a database', 'FAIL'),
    (r'localStorage\s*\.\s*clear|sessionStorage\s*\.\s*clear', 'clears web storage', 'FAIL'),
    (r'\bcaches\s*\.', 'touches Cache Storage (owned by sw.js)', 'FAIL'),
    (r'serviceWorker', 'touches the service worker / update system', 'FAIL'),
    (r'indexedDB\s*\.\s*open\(\s*(?![\'"]wird_quiz_db[\'"])', 'opens an IndexedDB other than wird_quiz_db', 'FAIL'),
    (r'(?:localStorage|sessionStorage)\s*\.\s*(?:set|remove)Item\(\s*[\'"`](?!wird_(?:tasks|taskprefs|quiz))', 'writes a storage key outside wird_tasks*/wird_taskprefs*/wird_quiz*', 'FAIL'),
    (r'\.clear\(\)', '.clear() call — review that it is not wiping foreign data', 'WARN'),
]


def sha(b):
    return hashlib.sha256(b if isinstance(b, bytes) else b.encode('utf-8')).hexdigest()


def parse_index(text):
    """-> (ordered list of (key, attrs, body, line), markup_text_without_blocks)"""
    blocks, counters = [], {}
    for m in BLOCK_RE.finditer(text):
        tag, attrs, body = m.group(1), m.group(2), m.group(3)
        idm = re.search(r'\bid="([^"]+)"', attrs)
        if idm:
            key = '%s:%s' % (tag, idm.group(1))
        else:
            n = counters.get(tag, 0); counters[tag] = n + 1
            key = '%s:#%d' % (tag, n)
        blocks.append((key, attrs, body, text.count('\n', 0, m.start()) + 1))
    return blocks


def markup_of(text, drop_keys):
    """Text outside <script>/<style> blocks.  Added (allowed) blocks are removed entirely and whitespace is collapsed,
    so inserting a block (plus its newlines) never changes the fingerprint, while any real markup change does."""
    out, last, counters = [], 0, {}
    for m in BLOCK_RE.finditer(text):
        tag, attrs = m.group(1), m.group(2)
        idm = re.search(r'\bid="([^"]+)"', attrs)
        if idm:
            key = '%s:%s' % (tag, idm.group(1))
        else:
            n = counters.get(tag, 0); counters[tag] = n + 1; key = '%s:#%d' % (tag, n)
        out.append(text[last:m.start()])
        out.append('\x00BLOCK\x00' if key not in drop_keys else '')
        last = m.end()
    out.append(text[last:])
    return re.sub(r'\s+', ' ', ''.join(out)).strip()


def block_hash(attrs, body):
    return sha(attrs + '\x00' + body)


def all_files():
    res = []
    for d, dirs, fs in os.walk(ROOT):
        dirs[:] = [x for x in dirs if x not in ('.git', 'node_modules', '__pycache__')]
        for f in fs:
            p = os.path.relpath(os.path.join(d, f), ROOT).replace(os.sep, '/')
            res.append(p)
    return sorted(res)


def file_tier(p):
    if p in APPEND_ONLY: return 'append-only'
    if p == INDEX: return 'blocks'
    return 'frozen'


def shell_version():
    try:
        m = re.search(r'^const SHELL_VERSION = (\d+);', open(os.path.join(ROOT, 'sw.js'), encoding='utf-8').read(), re.M)
        return int(m.group(1)) if m else None
    except Exception:
        return None


def write_baseline(force):
    if os.path.exists(BASELINE) and not force:
        sys.exit('REFUSED: %s already exists. The baseline is the "before" state and must not be regenerated without approval (use --force).' % os.path.relpath(BASELINE, ROOT))
    text = open(os.path.join(ROOT, INDEX), encoding='utf-8').read()
    blocks = parse_index(text)
    files = {}
    for p in all_files():
        if p == 'docs/PRESERVATION-BASELINE.json': continue
        b = open(os.path.join(ROOT, p), 'rb').read()
        files[p] = {'sha256': sha(b), 'size': len(b), 'tier': file_tier(p)}
    bl = {
        'schema': 1,
        'created_utc': datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),
        'note': 'Frozen "before" state of the uploaded wird_work_updated.zip. Never regenerate without explicit approval.',
        'sw_shell_version': shell_version(),
        'files': files,
        'index_html': {
            'order': [k for k, *_ in blocks],
            'blocks': {k: {'sha256': block_hash(a, b), 'len': len(b), 'line': ln,
                           'tier': 'guarded' if k in GUARDED_BLOCKS else 'frozen'} for k, a, b, ln in blocks},
            'markup_sha256': sha(markup_of(text, set())),
            'tripwires': {t: text.count(t) for t in TRIPWIRES},
        },
    }
    os.makedirs(os.path.dirname(BASELINE), exist_ok=True)
    json.dump(bl, open(BASELINE, 'w', encoding='utf-8'), indent=1, sort_keys=True, ensure_ascii=False)
    print('baseline written: %s  (%d files, %d index.html blocks)' % (BASELINE, len(files), len(blocks)))


def verify(args):
    if not os.path.exists(BASELINE):
        sys.exit('no baseline: docs/PRESERVATION-BASELINE.json is missing')
    bl = json.load(open(BASELINE, encoding='utf-8'))
    allow_g = set(x for x in args.allow_guarded.split(',') if x)
    prefixes = tuple(x for x in args.allow_added_prefix.split(',') if x)
    rows = []        # (status, area, name, detail)
    def add(st, area, name, detail=''): rows.append((st, area, name, detail))

    # ---- files ---------------------------------------------------------------------------------------------------
    cur = set(all_files()); base_files = bl['files']
    for p, meta in sorted(base_files.items()):
        if p not in cur:
            add('FAIL', 'file', p, 'MISSING (existing file removed)'); continue
        data = open(os.path.join(ROOT, p), 'rb').read()
        tier = meta['tier']
        if tier == 'blocks': continue
        if tier == 'append-only':
            if len(data) < meta['size'] or sha(data[:meta['size']]) != meta['sha256']:
                add('FAIL', 'file', p, 'append-only file: original text was altered')
            else:
                add('OK', 'file', p, 'unchanged' if len(data) == meta['size'] else 'appended +%d bytes (original text intact)' % (len(data) - meta['size']))
        else:
            if sha(data) != meta['sha256']: add('FAIL', 'file', p, 'FROZEN file changed')
            else: add('OK', 'file', p, 'identical')
    new_files = sorted(p for p in cur if p not in base_files and p != 'docs/PRESERVATION-BASELINE.json')
    for p in new_files: add('NEW', 'file', p, 'new file')

    # ---- sw.js shell version ---------------------------------------------------------------------------------------
    sv = shell_version()
    add('OK' if sv == bl['sw_shell_version'] else 'FAIL', 'sw', 'SHELL_VERSION', '%s (baseline %s)' % (sv, bl['sw_shell_version']))

    # ---- index.html blocks -----------------------------------------------------------------------------------------
    text = open(os.path.join(ROOT, INDEX), encoding='utf-8').read()
    blocks = parse_index(text); cur_map = {k: (a, b, ln) for k, a, b, ln in blocks}
    ib = bl['index_html']
    for k in ib['order']:
        meta = ib['blocks'][k]
        if k not in cur_map:
            add('FAIL', 'block', k, 'REMOVED'); continue
        a, b, ln = cur_map[k]
        if block_hash(a, b) == meta['sha256']:
            add('OK', 'block', k, 'identical [%s]' % meta['tier']); continue
        if meta['tier'] == 'guarded':
            if k in allow_g: add('GUARDED', 'block', k, 'changed — allowed by --allow-guarded (must be an approved hook patch)')
            else: add('FAIL', 'block', k, 'GUARDED block changed without --allow-guarded')
        else:
            add('FAIL', 'block', k, 'FROZEN block changed (len %d -> %d)' % (meta['len'], len(b)))
    added = [k for k in cur_map if k not in ib['blocks']]
    for k in added:
        ident = k.split(':', 1)[1]
        add('NEW' if ident.startswith(prefixes) else 'FAIL', 'block', k, 'new block' if ident.startswith(prefixes) else 'UNEXPECTED new block (id must start with %s)' % '/'.join(prefixes))
    kept = [k for k, *_ in blocks if k in ib['blocks']]
    base_order = [k for k in ib['order'] if k in cur_map]
    add('OK' if kept == base_order else 'FAIL', 'block', 'relative order', 'baseline blocks keep their relative order' if kept == base_order else 'ORDER CHANGED')
    mk = sha(markup_of(text, set(added)))
    if mk == ib['markup_sha256']: add('OK', 'block', 'markup', 'identical outside blocks [guarded]')
    elif 'markup' in allow_g: add('GUARDED', 'block', 'markup', 'markup changed — allowed by --allow-guarded')
    else: add('FAIL', 'block', 'markup', 'GUARDED markup changed without --allow-guarded')

    # ---- tripwires ---------------------------------------------------------------------------------------------------
    for t, n0 in sorted(ib['tripwires'].items()):
        n = text.count(t)
        add('OK' if n <= n0 else 'FAIL', 'tripwire', t, '%d (baseline %d)' % (n, n0))
    # ---- scan new blocks for forbidden APIs ----------------------------------------------------------------------
    for k in added:
        if not k.split(':', 1)[1].startswith(prefixes): continue
        a, b, ln = cur_map[k]
        for rx, msg, sev in NEW_CODE_RULES:
            hits = [m for m in re.finditer(rx, b)]
            if hits:
                first = b.count('\n', 0, hits[0].start()) + 1
                add(sev, 'new-code', k, '%s  (%d hit(s), first at block line %d)' % (msg, len(hits), first))
    rows.append(('', '', '', ''))
    fails = [r for r in rows if r[0] == 'FAIL']
    if args.json:
        print(json.dumps({'ok': not fails, 'rows': [dict(zip(('status', 'area', 'name', 'detail'), r)) for r in rows if r[0]]}, ensure_ascii=False, indent=1))
    else:
        order = {'FAIL': 0, 'WARN': 1, 'GUARDED': 2, 'NEW': 3, 'OK': 4}
        shown = [r for r in rows if r[0]]
        if not args.verbose:
            shown = [r for r in shown if r[0] != 'OK']
        for st, area, name, detail in sorted(shown, key=lambda r: (order.get(r[0], 9), r[1], r[2])):
            print('%-8s %-9s %-34s %s' % (st, area, name[:34], detail))
        cnt = {}
        for r in rows:
            if r[0]: cnt[r[0]] = cnt.get(r[0], 0) + 1
        print('-' * 78)
        print('SUMMARY  ' + '  '.join('%s=%d' % (k, cnt[k]) for k in ('OK', 'NEW', 'GUARDED', 'WARN', 'FAIL') if k in cnt))
        print('RESULT   ' + ('PASS — preservation intact' if not fails else 'FAIL — %d violation(s)' % len(fails)))
    return 1 if fails else 0


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--write-baseline', action='store_true'); ap.add_argument('--force', action='store_true')
    ap.add_argument('--json', action='store_true'); ap.add_argument('-v', '--verbose', action='store_true', help='also list OK rows')
    ap.add_argument('--allow-guarded', default='', help='comma list of guarded keys approved to differ, e.g. script:#2,markup')
    ap.add_argument('--allow-added-prefix', default='wird-tasks,wird-quiz', help='ids of new blocks that are permitted')
    ap.add_argument('--root', default=None, help='scan another project root (used once to baseline the pristine upload)')
    ap.add_argument('--baseline', default=None, help='baseline path (default: <root>/docs/PRESERVATION-BASELINE.json)')
    a = ap.parse_args()
    if a.root: ROOT = os.path.abspath(a.root)
    BASELINE = os.path.abspath(a.baseline) if a.baseline else os.path.join(ROOT, 'docs', 'PRESERVATION-BASELINE.json')
    if a.write_baseline: write_baseline(a.force)
    else: sys.exit(verify(a))
