#!/usr/bin/env python3
"""Rebuilds the project's index.html from the pristine original, deterministically.
usage: python3 -I build.py <orig dir> <out dir>
Steps: 1) bundle patches (bundle_patches.py)  2) courses-module patches  3) hub patches
       4) inject resources.css + resources.js  5) rename دروسي -> منهجي (index.html, README, tests)  6) sw cache bump
"""
import subprocess, sys, os, shutil, re, tempfile

orig, out = sys.argv[1], sys.argv[2]
here = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.join(here, '..', 'src')
os.makedirs(out, exist_ok=True)
tmp = os.path.join(tempfile.mkdtemp(prefix='wird-build-'), 'index.stage1.html')
subprocess.check_call([sys.executable, '-I', os.path.join(here, 'bundle_patches.py'), os.path.join(orig, 'index.html'), tmp], stdout=subprocess.DEVNULL)
s = open(tmp, encoding='utf-8').read()
shutil.rmtree(os.path.dirname(tmp), ignore_errors=True)


def rep(label, old, new, count=1):
    global s
    n = s.count(old)
    if n != count:
        sys.exit(f'BUILD PATCH FAILED [{label}]: expected {count} match(es), found {n}')
    s = s.replace(old, new)
    print('ok', label)


# ------------------------------------------------ courses-module: share the progress step + export player primitives
rep('C1 tick uses applyStep',
    "  const prev=P.prevT,st=trackStep(prev,t,wall,rate);P.prevT=t;\n"
    "  v.lastPos=t;v.lastPlayedAt=now;\n"
    "  if(st.add){v.iv=mergeIv((v.iv||[]).concat([st.add]));v.watched=ivLen(v.iv);v.furthest=Math.max(v.furthest||0,st.add[1])}\n"
    "  if(st.active>0){v.active=(v.active||0)+st.active;addSession(c.id,st.active)}\n",
    "  const prev=P.prevT,st=applyStep(v,prev,t,wall,rate,now);P.prevT=t;\n"
    "  if(st.active>0) addSession(c.id,st.active);\n")
rep('C2 define applyStep + pausePlayer',
    "// قراءة دورية أثناء التشغيل: تقدّم طبيعي ⇒ مشاهدة؛ قفزة ⇒ بس بنحدّث آخر موضع.",
    "// خطوة تقدّم واحدة على سجل الفيديو (مصدر الحقيقة الوحيد لموضع الفيديو ومشاهدته). بتستخدمها الكورسات وكمان مصادر الدروس في «منهجي».\n"
    "function applyStep(v,prev,t,wall,rate,now){\n"
    "  const st=trackStep(prev,t,wall,rate);\n"
    "  v.lastPos=t;v.lastPlayedAt=now;\n"
    "  if(st.add){v.iv=mergeIv((v.iv||[]).concat([st.add]));v.watched=ivLen(v.iv);v.furthest=Math.max(v.furthest||0,st.add[1])}\n"
    "  if(st.active>0) v.active=(v.active||0)+st.active;\n"
    "  return st;\n"
    "}\n"
    "// بيوقّف مشغّل الكورسات (لو شغّال) — مشغّل واحد بس في المرة\n"
    "function pausePlayer(){if(P.player&&P.state===1){try{P.player.pauseVideo()}catch(e){}}stopTimer();flush()}\n"
    "// قراءة دورية أثناء التشغيل: تقدّم طبيعي ⇒ مشاهدة؛ قفزة ⇒ بس بنحدّث آخر موضع.")
rep('C3 exports',
    "  get C(){return C},get V(){return V},get P(){return P},reload(){C=norm(JSON.parse(localStorage.getItem(CK)||'{}'))},save,flush};",
    "  loadYT,ytLink,saveSoon,applyStep,pausePlayer,\n"
    "  get C(){return C},get V(){return V},get P(){return P},reload(){C=norm(JSON.parse(localStorage.getItem(CK)||'{}'))},save,flush};")

# ------------------------------------------------ learning hub: continue card + unified search include lesson resources
rep('H1 open action',
    "  addVideo:()=>{go('view-courses');WC().addVideo()}\n};",
    "  addVideo:()=>{go('view-courses');WC().addVideo()},\n"
    "  lres:id=>{try{window.WirdResources.openResource(id)}catch(e){}}\n};")
rep('H2 search',
    "  return out.slice(0,25);\n}\nfunction renderResults(){",
    "  try{out.push(...window.WirdResources.hubSearch(k))}catch(e){}   // عناوين مصادر الدروس (فيديو/كتاب/رابط)\n"
    "  return out.slice(0,25);\n}\nfunction renderResults(){")
rep('H3 continue card',
    "  nb.forEach(v=>it.push(v));\n",
    "  nb.forEach(v=>it.push(v));\n"
    "  try{const lc=window.WirdResources.hubContinue();if(lc){const r=lc.res,ic={video:'🎬',book:'📚',link:'🔗'}[r.type],rec=r.type==='video'?(WC().C.videos||{})[r.video.youtubeVideoId]:null;\n"
    "    it.push({ts:Math.max(r.updatedAt||0,(rec&&rec.lastPlayedAt)||0),i:'📖',t:lc.title,s:'التالي: '+ic+' '+(r.title||'مصدر'),p:lc.pct,a:'lres',id:r.id,cta:'كمّل المذاكرة'})}}catch(e){}\n")
rep('H4 search placeholder',
    'placeholder="ابحث في الكتب والمذاكرة والكورسات…"',
    'placeholder="ابحث في الكتب والمذاكرة والكورسات ومصادر الدروس…"')
rep('H5 search hint',
    "(البحث بيغطي الكتب والمذاكرة والكورسات؛ ملاحظات «الدروس» ليها بحث خاص جوه قسمها.)",
    "(البحث بيغطي الكتب والمذاكرة والكورسات وعناوين مصادر الدروس؛ نص ملاحظات «الدروس» ليه بحث خاص جوه قسمها.)")

# ------------------------------------------------ inject css + module (after the notebook-recall styles, before the quran-font block)
css = open(os.path.join(src_dir, 'resources.css'), encoding='utf-8').read()
js = open(os.path.join(src_dir, 'resources.js'), encoding='utf-8').read()
rep('I1 inject module',
    '<style id="wird-quran-font">',
    '<style id="wird-resources-css">\n' + css + '</style>\n<script id="wird-resources">\n' + js + '</script>\n<style id="wird-quran-font">')

# ------------------------------------------------ rename: دروسي -> منهجي
before = s.count('دروسي')
s = s.replace('دروسي', 'منهجي')
print('rename: index.html occurrences replaced =', before)
open(os.path.join(out, 'index.html'), 'w', encoding='utf-8').write(s)

for name in ['README-OFFLINE-AR.txt', 'sw.js', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png']:
    shutil.copy(os.path.join(orig, name), os.path.join(out, name))
r = open(os.path.join(out, 'README-OFFLINE-AR.txt'), encoding='utf-8').read().replace('دروسي', 'منهجي')
r = r.rstrip('\n') + '\n' + open(os.path.join(src_dir, 'README-resources-AR.txt'), encoding='utf-8').read()
open(os.path.join(out, 'README-OFFLINE-AR.txt'), 'w', encoding='utf-8').write(r)
sw = open(os.path.join(out, 'sw.js'), encoding='utf-8').read()
assert "const V='wird-v2'" in sw
open(os.path.join(out, 'sw.js'), 'w', encoding='utf-8').write(sw.replace("const V='wird-v2'", "const V='wird-v3'"))
print('built', out)
