#!/usr/bin/env python3
"""Block-level diff of two index.html builds: which <script>/<style> blocks changed, and by how many lines.
usage: python3 -I tools/patch/audit_blocks.py <before.html> <after.html>"""
import re, sys, difflib
def blocks(path):
    h = open(path, encoding='utf8').read(); out = []; last = 0
    for m in re.finditer(r'<(script|style)\b([^>]*)>(.*?)</\1>', h, re.S):
        idm = re.search(r'id="([^"]+)"', m.group(2)); n = len([b for b in out if b[0].startswith(m.group(1))])
        out.append((m.group(1) + ':' + (idm.group(1) if idm else '#%d' % n), m.group(3)))
        last = m.end()
    markup = re.sub(r'<(script|style)\b[^>]*>.*?</\1>', '<\\1/>', h, flags=re.S)
    out.append(('markup', markup)); return dict(out)
a, b = blocks(sys.argv[1]), blocks(sys.argv[2])
print('%-34s %10s %10s  %s' % ('block', 'before', 'after', 'status'))
for k in list(a) + [k for k in b if k not in a]:
    x, y = a.get(k), b.get(k)
    if x is None: st = 'ADDED'
    elif y is None: st = 'REMOVED'
    elif x == y: st = 'identical'
    else:
        d = [l for l in difflib.unified_diff(x.split('\n'), y.split('\n'), lineterm='', n=0) if l[:1] in '+-' and l[:3] not in ('+++', '---')]
        st = 'CHANGED (%d lines differ)' % len(d)
    print('%-34s %10s %10s  %s' % (k[:34], len(x) if x is not None else '-', len(y) if y is not None else '-', st))
