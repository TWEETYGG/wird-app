#!/usr/bin/env python3
"""Unify Manhaji: one tree (Subject > Unit > Lesson > Items). Exact-match, must-match-once patches.
usage: python3 -I tools/patch/unify.py <in-index.html> <out-dir>
input  = the resources-phase build (tools/phase2/: index.html + sw.js + README-OFFLINE-AR.txt, i.e. build.py's output)
output = index.html, sw.js (cache wird-v3 -> wird-v4), README-OFFLINE-AR.txt (stale hub/tab sections replaced)"""
import re, sys, os, json
src, out = sys.argv[1], sys.argv[2]
here = os.path.dirname(os.path.abspath(__file__)); root = os.path.dirname(os.path.dirname(here))
s = open(src, encoding='utf8').read()
log = []
def rep(old, new, label, n=1):
    global s
    c = s.count(old)
    if c != n: raise SystemExit('PATCH FAILED %s: expected %d match(es), found %d' % (label, n, c))
    s = s.replace(old, new); log.append(label)

# ---- data layer (resources store widened: notebook | course | text) ----
rep('wirdResTypes=["video","book","link"]', 'wirdResTypes=["video","book","link","course","text","notebook"]', 'D1 types')
rep(r'''else{let s=z(o.link)?o.link:{};if(!/^https?:\/\/[^\s]+$/i.test(E(s.url)))return null;n.link={url:s.url}}return n}''',
    r'''else if(n.type==="course"){let s=z(o.course)?o.course:{};if(!E(s.courseId))return null;n.course={courseId:s.courseId}}else if(n.type==="text"){let s=z(o.text)?o.text:{};if(!E(s.sessionId))return null;n.text={sessionId:s.sessionId,subject:E(s.subject).slice(0,200)}}else if(n.type==="notebook"){let s=z(o.notebook)?o.notebook:{};if(!E(s.key))return null;n.notebook={key:s.key}}else{let s=z(o.link)?o.link:{};if(!/^https?:\/\/[^\s]+$/i.test(E(s.url)))return null;n.link={url:s.url}}return n}''', 'D2 norm')

# ---- sidebar: item rows, menus, click, search ----
rep('for(let c of l)s.push({kind:"lesson",id:c.id,unitId:a.id,subjectId:i.id,name:c.title||u.untitled})}}return s}render(){',
    'for(let c of l){s.push({kind:"lesson",id:c.id,unitId:a.id,subjectId:i.id,name:c.title||u.untitled});if(globalThis.__wirdItems)for(let q of globalThis.__wirdItems(c.id))s.push({kind:"item",id:q.id,lessonId:c.id,unitId:a.id,subjectId:i.id,name:q.name,itype:q.type})}}}return s}render(){', 'S1 computeRows')
rep('n.draggable=!0;let s=t.kind==="subject"?0:t.kind==="unit"?1:2;if(n.style.paddingInlineStart=`${8+s*18}px`,t.kind!=="lesson"){let i=this.expanded(t.id)',
    'n.draggable=t.kind!=="item";let s=t.kind==="subject"?0:t.kind==="unit"?1:t.kind==="item"?3:2;n.setAttribute("aria-level",s+1);if(n.style.paddingInlineStart=`${8+s*18}px`,t.kind!=="lesson"&&t.kind!=="item"){let i=this.expanded(t.id)', 'S2 rowEl depth/chevron + aria-level')
rep('t.kind==="unit"?"📁":"📄"', 't.kind==="unit"?"📁":t.kind==="item"?globalThis.__wirdIcon(t):"📄"', 'S3 row icon')
rep('n.append(h("span","ls-row-name",t.name)),t.kind!=="lesson"){let i=h("button","ls-row-btn","＋"', 'n.append(h("span","ls-row-name",t.name)),t.kind!=="lesson"&&t.kind!=="item"){let i=h("button","ls-row-btn","＋"', 'S4 no add on item')
rep('s=e.dataset.id;if(n==="empty")return;let i=t.target.closest("[data-act]")?.dataset.act;if(i==="menu"){',
    's=e.dataset.id;if(n==="empty")return;let i=t.target.closest("[data-act]")?.dataset.act;if(n==="item"){if(i==="menu"){let r=t.target.getBoundingClientRect();Un(r.left,r.bottom+4,this.menuFor("item",s))}else globalThis.__wirdOpen(s);return}if(i==="menu"){', 'S5 onClick item')
rep('menuFor(t,e){let n=[];return t==="subject"?', 'menuFor(t,e){if(t==="item")return globalThis.__wirdMenu(e);let n=[];return t==="subject"?', 'S6 menuFor item')
rep(':n.push({label:u.print,icon:"🖨",', ':n.push(...(globalThis.__wirdAddMenu?globalThis.__wirdAddMenu(e):[]),{label:u.print,icon:"🖨",', 'S7 lesson add menu')
rep('d=y=>{let v=r[y];v&&(p(),o.go({kind:"lesson",id:v.id,sid:v.sid}))}', 'd=y=>{let v=r[y];v&&(p(),v.item?globalThis.__wirdOpen(v.item):o.go({kind:"lesson",id:v.id,sid:v.sid}))}', 'S8 palette open')
rep('r.push({id:v.id,sid:v.sectionSid});let T=h("button","ls-palette-item",void 0,{type:"button",role:"option"}),g=h("b","",k.title||u.untitled)',
    'r.push({id:v.id,sid:v.sectionSid,item:v.itemId});let T=h("button","ls-palette-item",void 0,{type:"button",role:"option"}),g=h("b","",v.itemName||k.title||u.untitled)', 'S9 palette item title')
rep('let k=await o.search.search(y,{limit:30}).catch(()=>[]);v===l&&b(k)', 'let k=await o.search.search(y,{limit:30}).catch(()=>[]);k=(globalThis.__wirdSearch?globalThis.__wirdSearch(y):[]).concat(k);v===l&&b(k)', 'S10 palette search items')

# ---- main script hooks (new data appears in the tree right away) ----
rep("ST.subjects.push(subject);\n  stSave(); return id;", "ST.subjects.push(subject);\n  stSave(); globalThis.__wirdDirty&&globalThis.__wirdDirty(); return id;", 'M1 text created')
rep("booksState.list.unshift(book);\n    renderBooksList();", "booksState.list.unshift(book);\n    renderBooksList(); globalThis.__wirdDirty&&globalThis.__wirdDirty();", 'M2 book added')

# ---- resources module: new tabs / cards / forms / upload in context ----
rep("const TYPES={video:{ic:'🎬',n:'فيديو'},book:{ic:'📚',n:'كتاب'},link:{ic:'🔗',n:'رابط'}};", "const TYPES={video:{ic:'🎬',n:'فيديو'},book:{ic:'📚',n:'كتاب'},link:{ic:'🔗',n:'رابط'},course:{ic:'🎓',n:'كورس'},text:{ic:'📓',n:'نص'},notebook:{ic:'🗒',n:'نوت'}};", 'R1 TYPES')
rep("if(r.type==='book'){ if(CACHE.bookIds==null) return false; return !CACHE.bookIds.has(r.book&&r.book.bookId) }",
    "if(r.type==='book'){ if(CACHE.bookIds==null) return false; return !CACHE.bookIds.has(r.book&&r.book.bookId) }\n  try{ if(r.type==='course') return !WC().C.courses.some(c=>c.id===(r.course&&r.course.courseId)); if(r.type==='text') return !ST.sessions[r.text&&r.text.sessionId] }catch(e){}", 'R2 isMissing')
rep("['link','🔗','روابط',cnt('link')]];", "['link','🔗','روابط',cnt('link')],['course','🎓','كورس',cnt('course')],['text','📓','نص',cnt('text')]];", 'R3 tabs')
rep("card=t==='video'?videoCard:t==='book'?bookCard:linkCard;", "card=t==='video'?videoCard:t==='book'?bookCard:t==='link'?linkCard:globalThis.__wirdCard;", 'R4a card')
rep("link:'＋ إضافة رابط'}[t];", "link:'＋ إضافة رابط',course:'＋ إضافة كورس',text:'＋ إضافة نص مذاكرة'}[t];", 'R4b addLbl')
rep("link:'لسه مفيش روابط. أضِف رابط مقال أو مرجع خارجي.'}[t];", "link:'لسه مفيش روابط. أضِف رابط مقال أو مرجع خارجي.',course:'لسه مفيش كورسات في الدرس ده. أنشئ كورس أو اربط واحد موجود.',text:'لسه مفيش نصوص مذاكرة. أضِف نصًا للحفظ والتسميع.'}[t];", 'R4c empty')
rep("const f=formEl(); if(!f) return; const ed=!!res;", "const f=formEl(); if(!f) return; const ed=!!res;\n    if(globalThis.__wirdCreate&&globalThis.__wirdCreate(kind,lessonId,f,res)) return;", 'R5 openForm')
rep("${ed?'تعديل مصدر الكتاب':'إضافة كتاب من المكتبة'}</h4>", "${ed?'تعديل مصدر الكتاب':'إضافة كتاب'}</h4>${ed?'':'<button type=\"button\" class=\"ls-btn\" data-wu=\"upload\">📄 رفع PDF جديد</button>'}", 'R6a book upload')
rep("مفيش كتب في مكتبتك لسه. أضِف كتاب PDF من قسم «الكتب» الأول وارجع هنا.</p><div class=\"wr-act\">", "مفيش كتب لسه. ارفع أول كتاب PDF من هنا.</p><div class=\"wr-act\"><button type=\"button\" class=\"ls-btn ls-btn-primary\" data-wu=\"upload\">📄 رفع PDF</button>", 'R6b empty library')
rep("const c={video:0,book:0,link:0}; l.forEach(r=>{c[r.type]++});", "const c={video:0,book:0,link:0,course:0,text:0,notebook:0}; l.forEach(r=>{c[r.type]++});", 'R7a counts')
rep("txt=['video','book','link'].filter(k=>c[k])", "txt=['video','book','link','course','text','notebook'].filter(k=>c[k])", 'R7b badge')

# ---- remove legacy screens / hub ----
m = re.search(r'<script id="learning-hub">.*?</script>', s, re.S); assert m, 'hub script'
hub_len = len(m.group(0))
s = s[:m.start()] + '<script id="wird-learning-shim">window.WirdLearning={go(v){const t=document.querySelector(\'.tab[data-view="\'+v+\'"]\');if(t&&!t.classList.contains("active"))t.click()},get last(){return"view-lessons"},search(){return[]},renderHub(){}};</script>' + s[m.end():]; log.append('X1 hub script removed (%d chars)' % hub_len)
rep('<div class="lrn-nav" id="lrnNav" hidden></div>', '', 'X2 section bar')
rep('<section class="view" id="view-lrn"><div id="lrnRoot"></div></section>', '', 'X3 hub view')
m = re.search(r'<!-- ---------- BOOKS VIEW ---------- -->.*?</section>', s, re.S); assert m, 'books view'
s = s[:m.start()] + '<!-- مكتبتي القديمة: حاويات خاملة بس (القارئ والإضافة بيستخدموها) — مفيش شاشة ولا أزرار دخول -->\n    <section class="view" id="view-books" hidden><div id="cuReminderBanner"></div><div id="booksList"></div><button id="addBookBtn" hidden aria-hidden="true" tabindex="-1"></button><button id="cuOpenBtn" hidden aria-hidden="true" tabindex="-1"></button></section>' + s[m.end():]; log.append('X4 books screen -> inert stubs')
for v in ('view-books', 'view-study', 'view-courses'):
    m = re.search(r'\s*<button class="tab" data-view="%s" hidden>[^<]*</button>' % v, s); assert m, 'tab '+v
    s = s[:m.start()] + s[m.end():]; log.append('X5 hidden tab '+v)
# dead CSS of the hub
css_removed = 0
def strip(mo):
    global css_removed; css_removed += 1; return ''
s = re.sub(r'(?m)^[ \t]*(?:\.lrn-nav|\.lh-|#lrnNav|#view-lrn|#lrnRoot)[^{}\n]*\{[^{}]*\}[ \t]*\n?', strip, s); log.append('X6 hub css rules removed: %d' % css_removed)

# ---- inject module ----
css = open(os.path.join(root, 'tools/src/unified.css'), encoding='utf8').read()
js = open(os.path.join(root, 'tools/src/unified.js'), encoding='utf8').read()
rep('<style id="wird-quran-font">', '<style id="wird-unified-css">\n' + css + '</style>\n<style id="wird-quran-font">', 'I1 css')
rep('<style id="wird-quran-font-js">', '<style id="wird-quran-font-js">', 'noop-guard') if False else None
i = s.find('<script id="wird-quran-font-js">'); assert i > 0
s = s[:i] + '<script id="wird-unified">\n' + js + '</script>\n' + s[i:]; log.append('I2 module injected')

os.makedirs(out, exist_ok=True)
open(os.path.join(out, 'index.html'), 'w', encoding='utf8').write(s)
base = os.path.dirname(os.path.abspath(src))
# ---- service worker: the base is already wird-v3 (resources phase) => bump to v4 so installed PWAs drop the old shell
sw = open(os.path.join(base, 'sw.js'), encoding='utf8').read()
assert sw.count("V='wird-v3'") == 1, 'sw base must be wird-v3'
open(os.path.join(out, 'sw.js'), 'w', encoding='utf8').write(sw.replace("V='wird-v3'", "V='wird-v4'")); log.append('SW cache wird-v3 -> wird-v4')

# ---- README: replace stale sections (hub bar, courses tab, tab list, dev commands) -- exact-match, must-match-once
rd = open(os.path.join(base, 'README-OFFLINE-AR.txt'), encoding='utf8').read()
def rrep(old, new, label):
    global rd
    c = rd.count(old)
    if c != 1: raise SystemExit('README PATCH FAILED %s: expected 1 match, found %d' % (label, c))
    rd = rd.replace(old, new); log.append('README ' + label)
rrep('- تبويب جديد «كورسات»: كورس ← موديول (اختياري) ← درس. الدرس = فيديو كامل | فصل | فترة زمنية مخصصة.',
     '- «الكورس»: كورس ← موديول (اختياري) ← درس. الدرس = فيديو كامل | فصل | فترة زمنية مخصصة. بقى عنصر «🎓 كورس» جوه درس في «منهجي» (مفيش تبويب كورسات مستقل).', 'R-courses intro')
a = rd.index('================ مركز التعلّم (داخل «منهجي») ================'); b = rd.index('================ منهجي: مصادر الدرس')
assert 0 < a < b and rd.count('================ مركز التعلّم') == 1
sec = open(os.path.join(root, 'tools/src/README-unified-AR.txt'), encoding='utf8').read().rstrip('\n')
rd = rd[:a] + sec + '\n\n\n' + rd[b:]; log.append('README R-hub section -> unified tree section')
rrep('📝 الملخص | 🎬 فيديو | 📚 كتاب | 🔗 روابط (بعدّاد لكل نوع)', '📝 الملخص | 🎬 فيديو | 📚 كتاب | 🔗 روابط | 🎓 كورس | 📓 نص (بعدّاد لكل نوع؛ والنوت 🗒 بتتفتح من عنصرها في الشجرة)', 'R-tabs')
rrep('- اللوحة الرئيسية: «كمّل المذاكرة» (آخر درس + أول مصدر لسه مخلصش) + البحث الموحّد بيلاقي عناوين المصادر.',
     '- الرجوع للمذاكرة: «منهجي» بيفتح آخر عنصر كنت فاتحه ومكان تمرير الشريط الجانبي؛ والبحث (Ctrl+K أو زر البحث في الشريط الجانبي) بيلاقي الدروس وعناوين كل العناصر.', 'R-continue')
rrep('(+ tests/courses.test.js)', '(+ tests/courses.test.js + tests/unified.test.js)', 'R-tests')
rrep('- إعادة البناء من النسخة الأصلية: python3 -I tools/patch/build.py tools/orig <مجلد-الخرج>  (التفاصيل في docs/RESOURCES-DEV-NOTES.md).',
     '- إعادة البناء من النسخة الأصلية (خطوتين): python3 -I tools/patch/build.py tools/orig <مجلد-1>  ثم  python3 -I tools/patch/unify.py <مجلد-1>/index.html <مجلد-الخرج>\n  (tools/phase2 = ناتج الخطوة الأولى محفوظ؛ التفاصيل في docs/RESOURCES-DEV-NOTES.md و docs/UNIFIED-DEV-NOTES.md).', 'R-rebuild')
assert 'دروسي' not in rd
open(os.path.join(out, 'README-OFFLINE-AR.txt'), 'w', encoding='utf8').write(rd)
print('\n'.join(log)); print('OK', len(s))
