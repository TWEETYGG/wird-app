#!/usr/bin/env python3
"""Applies the minimal, guarded patches to the minified Lessons bundle (<script id="ls-main">) in index.html.
Every patch is an exact-match replacement that must match exactly once, otherwise the script aborts.
Usage: python3 -I bundle_patches.py <in index.html> <out index.html>
"""
import sys

src_path, out_path = sys.argv[1], sys.argv[2]
src = open(src_path, encoding='utf-8').read()
PATCHES = []


def patch(label, old, new):
    PATCHES.append((label, old, new))


# ---------------------------------------------------------------- P1/P2: DB v1 -> v2, new `resources` store
patch('P1 db version 1->2',
      'var io="wird_study_db",oo=1;',
      'var io="wird_study_db",oo=2;')
patch('P2 store list + indexes',
      '"templates","kv","index"],gs={units:["subjectId"],lessons:["subjectId","unitId"],vmeta:["lessonId"],sectionTrash:["lessonId"],mistakes:["lessonId","subjectId"],blobs:["mediaId"]}',
      '"templates","kv","index","resources"],gs={units:["subjectId"],lessons:["subjectId","unitId"],vmeta:["lessonId"],sectionTrash:["lessonId"],mistakes:["lessonId","subjectId"],blobs:["mediaId"],resources:["lessonId","subjectId"]}')

# ---------------------------------------------------------------- P4: repository resource API (before `async must`)
REPO = r'''async listResources(t){return(await this.backend.getByIndex("resources","lessonId",t)).filter(n=>!n.deletedAt).sort((n,s)=>n.order-s.order||n.createdAt-s.createdAt)}
async listAllResources(){return(await this.backend.getAll("resources")).filter(t=>!t.deletedAt)}
async getResource(t){let e=await this.backend.get("resources",t);return e&&!e.deletedAt?e:void 0}
async saveResource(t,e={}){return this.mu.run(async()=>{let n=await this.backend.get("lessons",t.lessonId);if(!n||n.deletedAt)throw new ut(`Lesson ${t.lessonId}`);let s=await this.backend.get("resources",t.id);if(s&&s.deletedAt)throw new ut(`Resource ${t.id}`);if(s&&e.expectedRev!==void 0&&!e.force&&s.rev!==e.expectedRev)throw new Et(t.lessonId,s.rev);let i=this.clock(),r=wirdResNorm({...t,subjectId:n.subjectId,createdAt:s?s.createdAt:i,updatedAt:i,rev:s?s.rev+1:1,deletedAt:null,deleteBatch:null,order:s?s.order:(await this.backend.getByIndex("resources","lessonId",t.lessonId)).reduce((a,l)=>Math.max(a,l.order+1),0)},null);if(!r)throw new Error("Invalid resource");return await this.backend.batch([x("resources",r)]),this.emit({type:"resources",lessonId:r.lessonId}),r})}
async removeResource(t){return this.mu.run(async()=>{let e=await this.backend.get("resources",t);return e?(await this.backend.batch([J("resources",t)]),this.emit({type:"resources",lessonId:e.lessonId}),e):null})}
async putResourceRaw(t){return this.mu.run(async()=>{let e=wirdResNorm(t,null);if(!e)throw new Error("Invalid resource");return await this.backend.batch([x("resources",e)]),this.emit({type:"resources",lessonId:e.lessonId}),e})}
'''
patch('P4 repo resource methods',
      'async must(t,e){let n=await this.backend.get(t,e);if(!n)throw new ut(`${t}/${e}`);return n}',
      REPO + 'async must(t,e){let n=await this.backend.get(t,e);if(!n)throw new ut(`${t}/${e}`);return n}')

# ---------------------------------------------------------------- P5: soft-delete cascade (same transaction)
patch('P5 softDelete cascade',
      'for(let l of r)i.push(J("index",l));return await this.backend.batch(i),this.emit({type:"tree"},{type:"trash"},{type:"mistakes"},...r.map(l=>({type:"index-remove",id:l}))),e})}',
      'for(let l of r)i.push(J("index",l));for(let l of r)for(let c of await this.backend.getByIndex("resources","lessonId",l))c.deletedAt||i.push(x("resources",s(c)));return await this.backend.batch(i),this.emit({type:"tree"},{type:"trash"},{type:"mistakes"},{type:"resources"},...r.map(l=>({type:"index-remove",id:l}))),e})}')

# ---------------------------------------------------------------- P6: restore cascade
patch('P6 restoreBatch cascade',
      'let f=[{type:"tree"},{type:"trash"},{type:"mistakes"}];for(let y of c){let v=await this.backend.get("docs",y.id);if(v){let k=Nt(y,v.doc);l.push(x("index",k)),f.push({type:"index-upsert",entry:k})}}await this.backend.batch(l),this.emit(...f)})}',
      'let f=[{type:"tree"},{type:"trash"},{type:"mistakes"},{type:"resources"}];for(let y of c){let v=await this.backend.get("docs",y.id);if(v){let k=Nt(y,v.doc);l.push(x("index",k)),f.push({type:"index-upsert",entry:k})}}for(let y of await this.backend.getAll("resources"))y.deletedAt&&y.deleteBatch===t&&l.push(x("resources",a(y)));await this.backend.batch(l),this.emit(...f)})}')

# ---------------------------------------------------------------- P7: purge cascade
patch('P7 purgeWhere cascade',
      'for(let l of await this.backend.getByIndex("mistakes","lessonId",a.id))i.push(J("mistakes",l.id))}return i.length&&await this.backend.batch(i),this.emit({type:"trash"},{type:"mistakes"}),r.length}',
      'for(let l of await this.backend.getByIndex("mistakes","lessonId",a.id))i.push(J("mistakes",l.id));for(let l of await this.backend.getByIndex("resources","lessonId",a.id))i.push(J("resources",l.id))}return i.length&&await this.backend.batch(i),this.emit({type:"trash"},{type:"mistakes"},{type:"resources"}),r.length}')

# ---------------------------------------------------------------- P8: keep denormalised subjectId in sync on move (same pattern as mistakes)
patch('P8a moveUnit -> resources.subjectId',
      'for(let f of await this.backend.getByIndex("mistakes","lessonId",m.id))c.push(x("mistakes",{...f,subjectId:e}))}p.push({type:"mistakes"})}await this.backend.batch(c),this.emit(...p)})}async moveLesson(t,e,n){',
      'for(let f of await this.backend.getByIndex("mistakes","lessonId",m.id))c.push(x("mistakes",{...f,subjectId:e}));for(let f of await this.backend.getByIndex("resources","lessonId",m.id))c.push(x("resources",{...f,subjectId:e}))}p.push({type:"mistakes"},{type:"resources"})}await this.backend.batch(c),this.emit(...p)})}async moveLesson(t,e,n){')
patch('P8b moveLesson -> resources.subjectId',
      'for(let m of await this.backend.getByIndex("mistakes","lessonId",t))c.push(x("mistakes",{...m,unitId:e,subjectId:i.subjectId}));p.push({type:"mistakes"})}await this.backend.batch(c),this.emit(...p)})}async deleteSubject(t){',
      'for(let m of await this.backend.getByIndex("mistakes","lessonId",t))c.push(x("mistakes",{...m,unitId:e,subjectId:i.subjectId}));for(let m of await this.backend.getByIndex("resources","lessonId",t))c.push(x("resources",{...m,subjectId:i.subjectId}));p.push({type:"mistakes"},{type:"resources"})}await this.backend.batch(c),this.emit(...p)})}async deleteSubject(t){')

# ---------------------------------------------------------------- P9: dump / import
patch('P9a dump',
      'sectionTrash:d,media:m}}async dumpMeta(){',
      'sectionTrash:d,media:m,resources:await n.getAll("resources")}}async dumpMeta(){')
patch('P9b dumpMeta',
      'versions:[],sectionTrash:l,media:c}}async applyImport(t,e){',
      'versions:[],sectionTrash:l,media:c,resources:await t.getAll("resources")}}async applyImport(t,e){')
patch('P9c import replace: clear',
      '"sectionTrash","mistakes","concepts","templates","index"])i.push({kind:"clear",store:w});',
      '"sectionTrash","mistakes","concepts","templates","index","resources"])i.push({kind:"clear",store:w});')
patch('P9d import replace: put',
      'for(let w of t.media)i.push(x("media",w));return t.settings&&i.push(x("kv",{id:"settings",value:t.settings})),',
      'for(let w of t.media)i.push(x("media",w));for(let w of t.resources||[])i.push(x("resources",w));return t.settings&&i.push(x("kv",{id:"settings",value:t.settings})),')
patch('P9e import merge: newer updatedAt wins, never deletes',
      'for(let w of t.media)$.has(w.id)||i.push(x("media",w));return await this.backend.batch(i),this.emit(...r,...a.map(',
      'for(let w of t.media)$.has(w.id)||i.push(x("media",w));{let w0=new Map((await this.backend.getAll("resources")).map(w=>[w.id,w]));for(let w of t.resources||[]){let R=w0.get(w.id);(!R||w.updatedAt>R.updatedAt)&&i.push(x("resources",w))}}return await this.backend.batch(i),this.emit(...r,{type:"resources"},...a.map(')

# ---------------------------------------------------------------- P10: backup archive (write / read / validate / copy-mode remap)
patch('P10a backup write',
      'o.addText("data/media.json",JSON.stringify(t.media))}function $e(o,t,e){',
      'o.addText("data/media.json",JSON.stringify(t.media)),o.addText("data/resources.json",JSON.stringify(t.resources||[]))}function $e(o,t,e){')
patch('P10b backup manifest counts',
      'media:o.media.length}}}function Rn(o){',
      'media:o.media.length,resources:(o.resources||[]).length}}}function Rn(o){')
patch('P10c backup read list',
      'for(let v of["subjects","units","lessons","mistakes","concepts","templates","settings","sectionTrash","media"])s[v]=await Oe(e,`data/${v}.json`,!1);',
      'for(let v of["subjects","units","lessons","mistakes","concepts","templates","settings","sectionTrash","media","resources"])s[v]=await Oe(e,`data/${v}.json`,!1);')
patch('P10d backup validate resources',
      '{data:c,warnings:p}=Cs(l.raw),d=[],m=new Set;for(let v of e.names()){',
      '{data:c,warnings:p}=Cs(l.raw),d=[],m=new Set;c.resources=wirdResAll(l.raw.resources,c.lessons,p);for(let v of e.names()){')
patch('P10e copy-mode: register ids + remap anchors',
      'if(i.type==="ref"&&z(i.attrs)&&typeof i.attrs.targetId=="string"){let[a,...l]=i.attrs.targetId.split("#"),c=t.get(a);c&&(r.attrs={...i.attrs,targetId:[c,...l].join("#")})}return r};for(let i of[...o.subjects,...o.units,...o.lessons,...o.concepts])e(i.id);',
      'if(i.type==="ref"&&z(i.attrs)&&typeof i.attrs.targetId=="string"){let[a,...l]=i.attrs.targetId.split("#"),c=t.get(a);c&&(r.attrs={...i.attrs,targetId:[c,...l].join("#")})}if(i.type==="link"&&z(i.attrs)&&typeof i.attrs.href=="string"&&i.attrs.href.startsWith("wird-res://")){let a=i.attrs.href.slice(11).split(/[?#]/)[0],c=t.get(a);c&&(r.attrs={...i.attrs,href:"wird-res://"+c+i.attrs.href.slice(11+a.length)})}return r};for(let i of[...o.subjects,...o.units,...o.lessons,...o.concepts,...o.resources||[]])e(i.id);')
patch('P10f copy-mode: remap resources',
      'sectionTrash:o.sectionTrash.map(i=>({...i,id:e(i.id),lessonId:e(i.lessonId)})),media:o.media}}var Os=',
      'sectionTrash:o.sectionTrash.map(i=>({...i,id:e(i.id),lessonId:e(i.lessonId)})),media:o.media,resources:(o.resources||[]).map(i=>({...i,id:e(i.id),lessonId:e(i.lessonId),subjectId:e(i.subjectId)}))}}var Os=')

# ---------------------------------------------------------------- P3: validation helpers (module scope, before `var Os=`; applied last because it edits the anchor the P10f patch matches)
HELPERS = r'''var wirdResTypes=["video","book","link"],wirdResStatus=["todo","doing","done"];
function wirdResInt(o,t){return typeof o=="number"&&Number.isFinite(o)&&o>=t?Math.floor(o):void 0}
function wirdResNorm(o,t){if(!z(o)||!E(o.id)||!E(o.lessonId)||!wirdResTypes.includes(o.type))return null;if(t&&!t.has(o.lessonId))return null;let n={id:E(o.id),lessonId:E(o.lessonId),subjectId:E(o.subjectId),type:o.type,title:E(o.title).slice(0,300),order:K(o.order,0),status:wirdResStatus.includes(o.status)?o.status:"todo",completedAt:typeof o.completedAt=="number"?o.completedAt:null,createdAt:K(o.createdAt,Date.now()),updatedAt:K(o.updatedAt,Date.now()),rev:Math.max(1,Math.floor(K(o.rev,1))),deletedAt:typeof o.deletedAt=="number"?o.deletedAt:null,deleteBatch:typeof o.deleteBatch=="string"?o.deleteBatch:null};if(n.type==="video"){let s=z(o.video)?o.video:{};if(!/^[A-Za-z0-9_-]{11}$/.test(E(s.youtubeVideoId)))return null;let i=typeof s.startSec=="number"&&Number.isFinite(s.startSec)&&s.startSec>=0?s.startSec:void 0,r=typeof s.endSec=="number"&&Number.isFinite(s.endSec)&&s.endSec>0&&(i===void 0||s.endSec>i)?s.endSec:void 0;n.video={youtubeVideoId:s.youtubeVideoId,metadataStatus:E(s.metadataStatus,"none").slice(0,20)};i!==void 0&&(n.video.startSec=i);r!==void 0&&(n.video.endSec=r)}else if(n.type==="book"){let s=z(o.book)?o.book:{};if(!E(s.bookId))return null;let i=wirdResInt(s.pageStart,1),r=wirdResInt(s.pageEnd,1);r!==void 0&&i!==void 0&&r<i&&(r=void 0);n.book={bookId:s.bookId};i!==void 0&&(n.book.pageStart=i);r!==void 0&&(n.book.pageEnd=r)}else{let s=z(o.link)?o.link:{};if(!/^https?:\/\/[^\s]+$/i.test(E(s.url)))return null;n.link={url:s.url}}return n}
function wirdResAll(o,t,e){let n=new Set(ot(t).map(i=>i.id)),s=[],i=0;for(let r of ot(o)){let a=wirdResNorm(r,n);a?s.push(a):i++}return i&&e.push(`Skipped ${i} resource(s) that were invalid or whose lesson is missing`),s}
'''
patch('P3 resource validation helpers',
      'var Os=30*864e5;function _t(o)',
      HELPERS + 'var Os=30*864e5;function _t(o)')

# ---------------------------------------------------------------- P12: sidebar row decoration hook (badges + progress), one call in rowEl
patch('P12 sidebar row hook',
      'return n.append(h("button","ls-row-btn","⋯",{type:"button","data-act":"menu",title:u.more,"aria-label":u.more,tabindex:"-1"})),n}setActive(t){',
      'return n.append(h("button","ls-row-btn","⋯",{type:"button","data-act":"menu",title:u.more,"aria-label":u.more,tabindex:"-1"})),globalThis.__wirdRow&&globalThis.__wirdRow(t,n),n}setActive(t){')

# ---------------------------------------------------------------- P11: rename دروسي -> منهجي (bundle strings)
patch('P11 rename strings',
      'u={tabName:"📖 دروسي",appTitle:"دروسي",landingTitle:"دروسي — قاعدة معرفتك للمذاكرة"',
      'u={tabName:"📖 منهجي",appTitle:"منهجي",landingTitle:"منهجي — قاعدة معرفتك للمذاكرة"')

out = src
for label, old, new in PATCHES:
    n = out.count(old)
    if n != 1:
        sys.exit(f'PATCH FAILED [{label}]: expected exactly 1 match, found {n}')
    out = out.replace(old, new)
    print('ok', label)

open(out_path, 'w', encoding='utf-8').write(out)
print('written', out_path, len(out) - len(src), 'bytes added')
