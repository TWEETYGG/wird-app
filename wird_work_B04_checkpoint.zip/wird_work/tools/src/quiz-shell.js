/* ==========================================================================================================
   quiz-shell.js — module shell of the "focus quiz and self-grading" feature (B2 / TASK 0.3).
   Exposes ONLY window.WirdQuiz. No DOM changes, no observers, no listeners and no storage access at load,
   and the IndexedDB wird_quiz_db is NOT created here (it is created on first quiz use, through WirdKit).
   Later batches ADD files named quiz-*.js (concatenated after this shell; quiz-core*.js first).
   ========================================================================================================== */
(function () {
  'use strict';
  if (window.WirdQuiz) return;                        // a re-evaluated block must never replace live module state
  window.WirdQuiz = {
    version: 1,
    kit: window.WirdKit,
    ext: {}                     // extension point: later files attach their public API here
  };
})();
