/* ==========================================================================================================
   tasks-shell.js — module shell of the "dynamic task atomization" feature (B2 / TASK 0.3).
   Exposes ONLY window.WirdTasks. No DOM changes, no observers, no listeners and no storage access at load.
   Later batches ADD files named tasks-*.js (the injector concatenates them after this shell) and attach
   themselves to the extension points below; the injector itself is never edited.
   ========================================================================================================== */
(function () {
  'use strict';
  if (window.WirdTasks) return;                       // a re-evaluated block must never replace live module state
  /* Habits state is read ONLY through the bare lexical name H (amendment A7: typeof window.H is undefined) and
     only when a caller asks for it, never at load. Bare-name access may throw before the main script finished
     initialising, hence the guard. */
  function readHabits() {
    try { return (typeof H !== 'undefined') ? H : null; } catch (e) { return null; }
  }
  window.WirdTasks = {
    version: 1,
    kit: window.WirdKit,
    ext: {},                    // extension point: later files attach their public API here (e.g. ext.planner, ext.runner)
    readHabits: readHabits
  };
})();
