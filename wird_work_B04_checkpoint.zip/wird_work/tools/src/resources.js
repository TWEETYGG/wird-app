/* =========================================================================
   مصادر الدرس (منهجي) — كل درس بقى حاوية تعلّم: ملخّصه + فيديوهات يوتيوب (كامل أو مدى زمني) + كتب من المكتبة (مدى صفحات) + روابط.
   الأساس:
   • مرجع مش نسخة: المصدر بيحفظ معرّفات ومديات بس. موضع الفيديو والمشاهدة محفوظين في سجل الفيديو بتاع WirdCourses (مصدر الحقيقة الوحيد)،
     وموضع الكتاب في سجل الكتاب.
   • التخزين: متجر `resources` جوه قاعدة wird_study_db (إصدار 2) — بيتحدّث مع الدرس (حذف/استرجاع/تصدير/استيراد) من نفس معاملات المستودع.
   • التثبيت في الملخّص: رابط (link mark) بعنوان wird-res://<resourceId>?t=<ثواني> أو ?p=<صفحة> — بيظهر كشريحة تقفز للفيديو/الكتاب.
   • مشغّل يوتيوب الرسمي (IFrame API) بس، عبر loadYT بتاع الكورسات، وخطوة التقدّم نفسها (applyStep). مفيش تحميل ولا استخراج ولا تغطية للمشغّل.
   ========================================================================= */
(()=>{
'use strict';
const ap=()=>window.__WIRD_STUDY_APP__;
const WC=()=>window.WirdCourses;
const esc=s=>escapeHtml(String(s==null?'':s));
const ar=n=>String(n).replace(/\d/g,d=>'٠١٢٣٤٥٦٧٨٩'[d]);
const clamp=(x,a,b)=>Math.min(b,Math.max(a,x));
const toast=m=>{try{showToast(m)}catch(e){}};
const SCHEME='wird-res://';
const uid=()=>'res_'+Date.now().toString(36)+Math.random().toString(36).slice(2,8);
const TYPES={video:{ic:'🎬',n:'فيديو'},book:{ic:'📚',n:'كتاب'},link:{ic:'🔗',n:'رابط'}};
const STATUS_N={todo:'لم يبدأ',doing:'جاري',done:'مكتمل'};
const LESSON_ST={none:'لم يبدأ',doing:'جاري',review:'مراجعة',mastered:'متقن'};
const SUGGEST_AT=0.9;

/* ============================ دوال نقية (قابلة للاختبار) ============================ */
function anchorHref(id,o){o=o||{};return SCHEME+id+(o.p!=null?'?p='+Math.max(1,Math.floor(o.p)):'?t='+Math.max(0,Math.floor(o.t||0)))}
function parseAnchor(href){
  const m=/^wird-res:\/\/([^?#\s]+)(?:\?(.*))?$/.exec(String(href==null?'':href)); if(!m) return null;
  const q=new URLSearchParams(m[2]||''),out={id:m[1]};
  if(q.has('p')){const p=parseInt(q.get('p'),10);if(p>=1)out.p=p}
  else if(q.has('t')){const t=parseInt(q.get('t'),10);if(t>=0)out.t=t}
  return out;
}
// جاهزية الدرس = المصادر المكتملة ÷ المصادر المؤهَّلة (المصدر المفقود مش مؤهَّل). null لو مفيش مصادر مؤهَّلة.
function lessonProgress(list,isMissing){
  isMissing=isMissing||(()=>false);
  const live=(list||[]).filter(r=>!r.deletedAt),missing=live.filter(isMissing),el=live.filter(r=>!isMissing(r));
  const done=el.filter(r=>r.status==='done').length,doing=el.filter(r=>r.status==='doing').length;
  return {total:live.length,eligible:el.length,done,doing,missing:missing.length,frac:el.length?done/el.length:null,pct:el.length?Math.round(done/el.length*100):null};
}
// الوحدة/المادة = متوسط جاهزية الدروس اللي فيها مصادر مؤهَّلة (كل درس بوزن واحد)
function rollup(progs){
  const w=(progs||[]).filter(p=>p&&p.frac!=null);
  if(!w.length) return {pct:null,lessons:0,done:0};
  const avg=w.reduce((s,p)=>s+p.frac,0)/w.length;
  return {pct:Math.round(avg*100),lessons:w.length,done:w.filter(p=>p.frac===1).length};
}
// حالة الدرس: لم يبدأ / جاري / مراجعة (كل المصادر خلصت وفيه أخطاء مفتوحة في المتتبّع) / متقن (خلصت ومفيش أخطاء مفتوحة)
function lessonStatus(p,openMistakes){
  if(!p||p.eligible===0) return null;
  if(p.done===p.eligible) return openMistakes>0?'review':'mastered';
  return p.done>0||p.doing>0?'doing':'none';
}
// مدى الفيديو + نسبة المشاهدة، بنفس دوال الكورسات (lessonRange/lessonCoverage) على «درس افتراضي»
const pseudo=r=>{const v=r.video||{},has=v.startSec!=null||v.endSec!=null;return {vid:v.youtubeVideoId,type:has?'range':'video',start:v.startSec||0,end:v.endSec||0}};
const vrec=id=>{try{return WC().C.videos[id]||null}catch(e){return null}};
const vRange=r=>WC().lessonRange(pseudo(r),WC().C.videos);
const vCover=r=>WC().lessonCoverage(pseudo(r),WC().C.videos);
function resumeAt(r){
  const [a,b]=vRange(r),v=vrec(r.video.youtubeVideoId),p=v&&v.lastPos>0?v.lastPos:a;
  return p>=a&&(b==null||p<b-2)?p:a;
}
// «١٢:٣٠» أو «١:٣٠:٠٠» أو «٩٠» → ثواني | null لو فاضي | NaN لو غير صالح
function timeField(s){s=String(s==null?'':s).trim();if(!s)return null;const t=WC().parseTime(s);return t==null?NaN:t}
function validateRange(start,end,dur){
  const isN=x=>typeof x==='number'&&isFinite(x),e=[];
  if(Number.isNaN(start)) e.push('وقت البداية غير صالح (اكتبه مثل ٠٥:٣٠ أو ١:٠٠:٠٠)');
  if(Number.isNaN(end)) e.push('وقت النهاية غير صالح (اكتبه مثل ١٢:٠٠)');
  if(isN(start)&&start<0) e.push('البداية لازم تكون صفر أو أكتر');
  if(isN(start)&&isN(end)&&end<=start) e.push('النهاية لازم تكون بعد البداية');
  if(end!=null&&isN(end)&&start==null&&end<=0) e.push('النهاية لازم تكون أكبر من صفر');
  if(dur>0){
    if(isN(end)&&end>dur+0.5) e.push('النهاية بعد مدة الفيديو ('+WC().fmt(dur)+')');
    if(isN(start)&&start>=dur) e.push('البداية بعد نهاية الفيديو');
  }
  return e;
}
function validatePages(a,b,total){
  const e=[];
  if(a!=null&&!(a>=1)) e.push('أول صفحة لازم تكون ١ أو أكتر');
  if(b!=null&&!(b>=1)) e.push('آخر صفحة لازم تكون ١ أو أكتر');
  if(a!=null&&b!=null&&b<a) e.push('آخر صفحة لازم تكون بعد أول صفحة');
  if(total>0){ if(a!=null&&a>total) e.push('أول صفحة بعد آخر صفحة في الكتاب ('+ar(total)+')'); if(b!=null&&b>total) e.push('آخر صفحة بعد نهاية الكتاب ('+ar(total)+')'); }
  return e;
}
function intField(s){s=String(s==null?'':s).trim().replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d));if(!s)return null;return /^\d+$/.test(s)?parseInt(s,10):NaN}
function parseHttpUrl(s){
  s=String(s==null?'':s).trim(); if(!s) return {ok:false,reason:'empty'};
  if(/\s/.test(s)) return {ok:false,reason:'malformed'};
  if(/^[a-z][a-z0-9+.-]*:(?!\/\/)(?!\d+(?:[\/?#]|$))/i.test(s)) return {ok:false,reason:'scheme'};   // javascript: / data: / mailto: … (مش host:port)
  if(!/^[a-z][a-z0-9+.-]*:\/\//i.test(s)) s='https://'+s;
  let u; try{u=new URL(s)}catch(e){return {ok:false,reason:'malformed'}}
  if(u.protocol!=='https:'&&u.protocol!=='http:') return {ok:false,reason:'scheme'};
  if(!u.hostname||!u.hostname.includes('.')) return {ok:false,reason:'malformed'};
  return {ok:true,url:u.href,host:u.hostname.replace(/^www\./,'')};
}
const URL_ERR={empty:'الصق الرابط الأول.',malformed:'الرابط مش مكتوب صح — لازم يكون رابط كامل.',domain:'الرابط ده مش من يوتيوب.',noid:'ماقدرتش ألاقي معرّف الفيديو في الرابط.',scheme:'المسموح روابط http أو https بس.',yt:'ده رابط يوتيوب — أضِفه من تبويب «فيديو» عشان يتشغّل ويتتبّع تقدّمه.'};

/* ============================ ذاكرة مؤقتة (للشريط الجانبي واللوحة الرئيسية) ============================ */
const CACHE={byLesson:new Map(),bookIds:null,ready:false,listeners:new Set()};
const bookList=()=>{try{return booksState.list||[]}catch(e){return[]}};
const bookById=id=>bookList().find(b=>b.id===id)||null;
function isMissing(r){
  if(r.type==='book'){ if(CACHE.bookIds==null) return false; return !CACHE.bookIds.has(r.book&&r.book.bookId) }
  return false;
}
async function refreshBooks(){try{const bs=await dbGetAll('books');CACHE.bookIds=new Set(bs.map(b=>b.id))}catch(e){CACHE.bookIds=null}}
async function loadCache(){
  const a=ap(); if(!a||!a.repo) return;
  try{
    await refreshBooks();
    const all=await a.repo.listAllResources(),m=new Map();
    all.forEach(r=>{(m.get(r.lessonId)||m.set(r.lessonId,[]).get(r.lessonId)).push(r)});
    m.forEach(l=>l.sort((x,y)=>x.order-y.order||x.createdAt-y.createdAt));
    CACHE.byLesson=m;CACHE.ready=true;
  }catch(e){console.error('wird-resources cache',e)}
  CACHE.listeners.forEach(f=>{try{f()}catch(e){}});
}
const progOf=lid=>lessonProgress(CACHE.byLesson.get(lid)||[],isMissing);
function treeProgress(kind,id){
  const a=ap(); if(!a||!a.tree) return {pct:null};
  const ls=a.tree.lessons.filter(l=>kind==='subject'?l.subjectId===id:l.unitId===id);
  return rollup(ls.map(l=>progOf(l.id)));
}
// الشريط الجانبي: شارات 🎬 ٢ 📚 ١ للدرس، ونسبة التقدّم للمادة/الوحدة. بيتنادى من rowEl (نقطة حقن واحدة في الـ bundle).
window.__wirdRow=(row,el)=>{
  try{
    if(!CACHE.ready||!row) return;
    const nm=el.querySelector('.ls-row-name'); if(!nm) return;
    let txt='',label='';
    if(row.kind==='lesson'){
      const l=CACHE.byLesson.get(row.id)||[]; if(!l.length) return;
      const c={video:0,book:0,link:0}; l.forEach(r=>{c[r.type]++});
      txt=['video','book','link'].filter(k=>c[k]).map(k=>TYPES[k].ic+' '+ar(c[k])).join(' ');
      const p=progOf(row.id); label=l.length+' مصادر'+(p.pct!=null?'، جاهزية '+p.pct+'٪':'');
    }else if(row.kind==='subject'||row.kind==='unit'){
      const r=treeProgress(row.kind,row.id); if(r.pct==null) return;
      txt=ar(r.pct)+'٪'; label='تقدّم '+row.name+' '+r.pct+'٪';
    }else return;
    const b=document.createElement('span'); b.className='wr-bdg'+(row.kind==='lesson'?'':' wr-bdg-pct'); b.textContent=txt;
    b.setAttribute('role','img'); b.setAttribute('aria-label',label);
    nm.after(b);
  }catch(e){}
};
function repaintSidebar(){try{const a=ap();a&&a.sidebar&&a.sidebar.render()}catch(e){}}

/* ============================ شاشة الدرس ============================ */
let PENDING=null;                       // {lessonId,resId,tab} — لو جينا من اللوحة الرئيسية «كمّل»
const ATTACHED=new Set();

function attach(view){
  const a=ap(),repo=a.repo,lessonId=view.id;
  boot();
  if(!view.title||!view.statsEl||!view.root) return;
  const editorWrap=view.root.parentElement;
  const wrap=document.createElement('section'); wrap.className='wr'; wrap.dataset.lesson=lessonId;
  wrap.setAttribute('aria-label','مصادر الدرس');
  wrap.innerHTML=`<div class="wr-head" id="wrHead"></div><div class="wr-tabs" role="tablist" aria-label="أقسام الدرس" id="wrTabs"></div><div class="wr-panel" id="wrPanel" role="tabpanel" hidden></div>`;
  view.statsEl.after(wrap);
  const q=s=>wrap.querySelector(s);
  const S={tab:'note',res:[],mist:0,playing:null,disposed:false,books:[]};
  const PL={player:null,timer:null,tickMs:1000,ready:false,state:-1,prevT:null,lastTick:0,token:0,endHit:false,suggested:false,resId:null,marked:false};
  const byId=id=>S.res.find(r=>r.id===id);
  const stamp=()=>Date.now();

  /* ---------- تحميل ---------- */
  async function reload(){
    try{
      const [list,mist]=await Promise.all([repo.listResources(lessonId),repo.listMistakes({lessonId}).catch(()=>[]),refreshBooks()]);
      if(S.disposed) return;
      S.res=list; S.mist=(mist||[]).filter(m=>m.status!=='mastered').length;
      S.books=await dbGetAll('books').catch(()=>[]);
      CACHE.byLesson.set(lessonId,list.slice()); if(!list.length) CACHE.byLesson.delete(lessonId);
      renderHead();renderTabs();
      if(S.tab==='video'&&S.playing){ if(!byId(S.playing)) stopPlayer(true); else renderPlayerInfo() }
      else if(S.tab!=='note') renderList();
      repaintSidebar();
    }catch(e){console.error('wird-resources reload',e)}
  }
  const unsub=repo.subscribe(ev=>{ if(ev.type==='resources'&&(!ev.lessonId||ev.lessonId===lessonId)) reload(); else if(ev.type==='mistakes') reload() });

  /* ---------- الرأس: الحالة + الجاهزية ---------- */
  const prog=()=>lessonProgress(S.res,isMissing);
  function renderHead(){
    const p=prog(),st=lessonStatus(p,S.mist),h=q('#wrHead'); if(!h) return;
    h.innerHTML=p.eligible===0
      ?`<p class="wr-hint">${p.total?'كل المصادر مفقودة — مفيش حاجة تتحسب.':'أضِف فيديو أو كتاب أو رابط لتتبّع جاهزية الدرس.'}</p>`
      :`<div class="wr-st"><span class="wr-chip wr-s-${st}">${LESSON_ST[st]}</span><span class="wr-pct">جاهزية الدرس <b>${ar(p.pct)}٪</b> <small>(${ar(p.done)} من ${ar(p.eligible)})</small></span></div>
        <div class="wr-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${p.pct}" aria-label="جاهزية الدرس ${p.pct} بالمئة"><i style="width:${p.pct}%"></i></div>`;
    h.innerHTML+=`<div class="wr-foot"><details class="wr-help"><summary>كيف يُحسب التقدّم؟</summary><ul>
      <li>جاهزية الدرس = المصادر المكتملة ÷ المصادر المؤهَّلة. الإكتمال بيتعلّم بإيدك دايمًا.</li>
      <li>الفيديو بيقترح الإكتمال لما تشاهد ٩٠٪ من مداه تقريبًا، بس مبيكمّلش لوحده.</li>
      <li>المصدر المفقود (كتاب اتحذف من المكتبة مثلًا) مش بيتحسب، ومبيتحذفش منك.</li>
      <li>الوحدة والمادة = متوسط جاهزية الدروس اللي فيها مصادر (كل درس بوزن واحد).</li>
      <li>«متقن» = كل المصادر خلصت ومفيش أخطاء مفتوحة للدرس في دفتر الأخطاء، و«مراجعة» = خلصت وفيه أخطاء مفتوحة.</li>
      <li>التقدّم ده منفصل عن إحصائيات العادات.</li></ul></details><button type="button" class="ls-btn wr-sched" data-a="sched" aria-label="جدولة الدرس كمهمة">📅 جدولة</button></div>`;
  }

  /* ---------- التبويبات ---------- */
  const cnt=t=>S.res.filter(r=>r.type===t).length;
  function renderTabs(){
    const t=q('#wrTabs'); if(!t) return;
    const defs=[['note','📝','الملخص',null],['video','🎬','فيديو',cnt('video')],['book','📚','كتاب',cnt('book')],['link','🔗','روابط',cnt('link')]];
    t.innerHTML=defs.map(d=>`<button type="button" role="tab" id="wrt-${d[0]}" aria-selected="${S.tab===d[0]}" aria-controls="wrPanel" data-tab="${d[0]}" class="${S.tab===d[0]?'on':''}"><span aria-hidden="true">${d[1]}</span> ${d[2]}${d[3]!=null?` <b class="wr-n" aria-label="${ar(d[3])} مصدر">${ar(d[3])}</b>`:''}</button>`).join('');
  }
  function select(tab,opts){
    opts=opts||{};
    if(S.tab===tab&&!opts.force) return;
    if(S.tab==='video'&&tab!=='video') stopPlayer(true);
    S.tab=tab;
    const p=q('#wrPanel');
    editorWrap.classList.toggle('wr-hidden',tab!=='note');
    p.hidden=tab==='note';
    renderTabs();
    if(tab==='note') return;
    p.innerHTML=`<div id="wrForm"></div><div id="wrList"></div>`;
    renderList();
  }

  /* ---------- القوائم ---------- */
  const rangeText=r=>{
    const v=r.video,lg=(vrec(v.youtubeVideoId)||{}).duration>=3600;
    if(v.startSec==null&&v.endSec==null) return 'الفيديو كامل';
    return 'من <bdi dir="ltr">'+ar(WC().fmt(v.startSec||0,lg))+'</bdi> إلى '+(v.endSec!=null?'<bdi dir="ltr">'+ar(WC().fmt(v.endSec,lg))+'</bdi>':'النهاية');
  };
  const bar=(pct,label)=>`<div class="wr-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${pct}" aria-label="${esc(label)}"><i style="width:${pct}%"></i></div>`;
  const actBtns=(r,main)=>`<div class="wr-act">${main}<button type="button" class="ls-btn ${r.status==='done'?'':'wr-ok'}" data-a="done">${r.status==='done'?'↩ إلغاء الإكتمال':'✓ تم'}</button><button type="button" class="ls-btn" data-a="edit" aria-label="تعديل">✎</button><button type="button" class="ls-btn ls-btn-danger" data-a="del" aria-label="حذف المصدر">🗑</button></div>`;
  function videoCard(r){
    const v=r.video,rec=vrec(v.youtubeVideoId)||{},cov=vCover(r),pct=cov==null?null:Math.round(cov*100),title=r.title||rec.title||'فيديو يوتيوب';
    const th=rec.thumb?`<img src="${esc(rec.thumb)}" alt="" loading="lazy" onerror="this.remove()">`:'';
    const resume=rec.lastPos>0&&resumeAt(r)>(vRange(r)[0]+3);
    return `<article class="wr-card" data-id="${esc(r.id)}"><div class="wr-card-top"><div class="wr-thumb" aria-hidden="true"><span>🎬</span>${th}</div><div class="wr-body"><b class="wr-title">${esc(title)}</b>
      <small>${esc(rec.channel||'')}${rec.channel?' · ':''}${rangeText(r)}</small>
      <span class="wr-chip wr-r-${r.status}">${STATUS_N[r.status]}</span>${rec.unavailable?' <span class="wr-chip wr-r-bad">غير متاح للتضمين</span>':''}
      ${pct!=null?bar(pct,'مشاهدة تقريبية '+pct+' بالمئة')+`<small class="wr-meta">مشاهدة تقريبية ${ar(pct)}٪</small>`:''}</div></div>
      ${actBtns(r,`<button type="button" class="ls-btn ls-btn-primary" data-a="play">${resume?'▶ كمّل':'▶ شغّل'}</button>`)}</article>`;
  }
  function bookCard(r){
    const b=bookById(r.book.bookId)||S.books.find(x=>x.id===r.book.bookId),miss=!b&&CACHE.bookIds!=null&&!CACHE.bookIds.has(r.book.bookId);
    const a=r.book.pageStart,z=r.book.pageEnd,cur=b?(b.currentPage||1):null;
    let pct=null; if(b&&a!=null&&z!=null&&z>=a) pct=Math.round(clamp((cur-a+1)/(z-a+1),0,1)*100);
    const range=a==null&&z==null?'الكتاب كله':'ص '+ar(a==null?1:a)+' – '+(z==null?'النهاية':ar(z));
    return `<article class="wr-card ${miss?'wr-missing':''}" data-id="${esc(r.id)}"><div class="wr-card-top"><div class="wr-thumb wr-thumb-b" aria-hidden="true"><span>📚</span></div><div class="wr-body"><b class="wr-title">${esc(r.title||(b&&b.title)||'كتاب')}</b>
      <small>${miss?'':esc(b?b.title+' · ':'')}${range}${cur!=null?' · أنت في ص '+ar(cur):''}</small>
      ${miss?'<span class="wr-chip wr-r-bad">مصدر مفقود</span><small class="wr-meta">الكتاب مش موجود في المكتبة. المرجع محفوظ، وتقدر تحذفه أو تضيف الكتاب تاني.</small>':`<span class="wr-chip wr-r-${r.status}">${STATUS_N[r.status]}</span>`}
      ${pct!=null?bar(pct,'التقدّم في المدى '+pct+' بالمئة')+`<small class="wr-meta">${ar(pct)}٪ من المدى</small>`:''}</div></div>
      ${actBtns(r,miss?'':`<button type="button" class="ls-btn ls-btn-primary" data-a="open">📖 افتح</button><button type="button" class="ls-btn" data-a="pinp">📍 ثبّت الصفحة</button>`)}</article>`;
  }
  function linkCard(r){
    const host=(parseHttpUrl(r.link.url)||{}).host||'';
    return `<article class="wr-card" data-id="${esc(r.id)}"><div class="wr-card-top"><div class="wr-thumb wr-thumb-l" aria-hidden="true"><span>🔗</span></div><div class="wr-body"><b class="wr-title">${esc(r.title||host)}</b>
      <small dir="ltr" class="wr-host">${esc(host)}</small><span class="wr-chip wr-r-${r.status}">${STATUS_N[r.status]}</span></div></div>
      ${actBtns(r,`<a class="ls-btn ls-btn-primary" data-a="visit" href="${esc(r.link.url)}" target="_blank" rel="noopener noreferrer">↗ افتح الرابط</a>`)}</article>`;
  }
  function renderList(){
    const box=q('#wrList'); if(!box) return;
    const t=S.tab,list=S.res.filter(r=>r.type===t),card=t==='video'?videoCard:t==='book'?bookCard:linkCard;
    const addLbl={video:'＋ إضافة فيديو',book:'＋ إضافة كتاب',link:'＋ إضافة رابط'}[t];
    const empty={video:'لسه مفيش فيديوهات في الدرس ده. أضِف فيديو يوتيوب كامل أو جزء منه.',book:'لسه مفيش كتب. اربط كتابًا من مكتبتك بمدى صفحات.',link:'لسه مفيش روابط. أضِف رابط مقال أو مرجع خارجي.'}[t];
    const formOpen=!!q('#wrForm')&&q('#wrForm').innerHTML.trim();
    box.innerHTML=`${formOpen?'':`<div class="wr-add"><button type="button" class="ls-btn ls-btn-primary" data-a="add">${addLbl}</button></div>`}`+(list.length?list.map(card).join(''):`<p class="wr-empty">${empty}</p>`);
  }

  /* ---------- نماذج الإضافة/التعديل ---------- */
  const fld=(id,label,ph,val,extra)=>`<label class="wr-f" for="${id}"><span>${label}</span><input class="ls-input" id="${id}" value="${esc(val==null?'':val)}" placeholder="${esc(ph||'')}" ${extra||''}></label>`;
  const formEl=()=>q('#wrForm');
  function openForm(kind,res){
    const f=formEl(); if(!f) return; const ed=!!res;
    let html='';
    if(kind==='video'){
      const v=res&&res.video;
      html=`<form class="wr-form" data-kind="video" ${ed?`data-edit="${esc(res.id)}"`:''} novalidate><h4>${ed?'تعديل الفيديو':'إضافة فيديو يوتيوب'}</h4>
        ${ed?'':fld('wrfUrl','رابط الفيديو','https://www.youtube.com/watch?v=…','','inputmode="url" dir="ltr" autocomplete="off"')}
        ${fld('wrfTitle',ed?'العنوان':'العنوان (اختياري — بيتجاب تلقائي)','',ed?res.title:'', 'maxlength="300"')}
        <div class="wr-2">${fld('wrfStart','من (اختياري)','٠٥:٣٠',v&&v.startSec!=null?WC().fmt(v.startSec):'','inputmode="text" dir="ltr"')}${fld('wrfEnd','إلى (اختياري)','١٢:٠٠',v&&v.endSec!=null?WC().fmt(v.endSec):'','inputmode="text" dir="ltr"')}</div>
        <p class="wr-hint">سيبهم فاضيين لو عايز الفيديو كله. التوقيتات بصيغة دقائق:ثواني أو ساعة:دقائق:ثواني.</p>
        <div id="wrfMsg" class="wr-msg" role="alert"></div>
        <div class="wr-act"><button type="submit" class="ls-btn ls-btn-primary" data-a="submit">${ed?'حفظ':'إضافة'}</button><button type="button" class="ls-btn" data-a="manual" hidden>أضِفه يدويًا بالعنوان</button><button type="button" class="ls-btn" data-a="cancel">إلغاء</button></div></form>`;
    }else if(kind==='book'){
      const bs=S.books.length?S.books:bookList(),b=res&&res.book;
      html=bs.length?`<form class="wr-form" data-kind="book" ${ed?`data-edit="${esc(res.id)}"`:''} novalidate><h4>${ed?'تعديل مصدر الكتاب':'إضافة كتاب من المكتبة'}</h4>
        <label class="wr-f" for="wrfBook"><span>الكتاب</span><select class="ls-input" id="wrfBook">${bs.map(x=>`<option value="${esc(x.id)}" ${b&&b.bookId===x.id?'selected':''}>${esc(x.title)}${x.totalPages?' ('+ar(x.totalPages)+' ص)':''}</option>`).join('')}</select></label>
        <div class="wr-2">${fld('wrfFrom','من صفحة (اختياري)','١',b&&b.pageStart!=null?b.pageStart:'','inputmode="numeric"')}${fld('wrfTo','إلى صفحة (اختياري)','٣٠',b&&b.pageEnd!=null?b.pageEnd:'','inputmode="numeric"')}</div>
        ${fld('wrfTitle','عنوان المصدر (اختياري)','',ed?res.title:'','maxlength="300"')}
        <div id="wrfMsg" class="wr-msg" role="alert"></div>
        <div class="wr-act"><button type="submit" class="ls-btn ls-btn-primary" data-a="submit">${ed?'حفظ':'إضافة'}</button><button type="button" class="ls-btn" data-a="cancel">إلغاء</button></div></form>`
      :`<div class="wr-form"><h4>إضافة كتاب</h4><p class="wr-hint">مفيش كتب في مكتبتك لسه. أضِف كتاب PDF من قسم «الكتب» الأول وارجع هنا.</p><div class="wr-act"><button type="button" class="ls-btn" data-a="cancel">تمام</button></div></div>`;
    }else{
      const l=res&&res.link;
      html=`<form class="wr-form" data-kind="link" ${ed?`data-edit="${esc(res.id)}"`:''} novalidate><h4>${ed?'تعديل الرابط':'إضافة رابط'}</h4>
        ${fld('wrfUrl','الرابط','https://…',l?l.url:'','inputmode="url" dir="ltr" autocomplete="off"')}
        ${fld('wrfTitle','العنوان (اختياري)','',ed?res.title:'','maxlength="300"')}
        <div id="wrfMsg" class="wr-msg" role="alert"></div>
        <div class="wr-act"><button type="submit" class="ls-btn ls-btn-primary" data-a="submit">${ed?'حفظ':'إضافة'}</button><button type="button" class="ls-btn" data-a="cancel">إلغاء</button></div></form>`;
    }
    f.innerHTML=html; renderList();
    const first=f.querySelector('input,select'); if(first) try{first.focus({preventScroll:false})}catch(e){}
  }
  function closeForm(){const f=formEl();if(f)f.innerHTML='';renderList()}
  const msg=(h,kind)=>{const m=q('#wrfMsg');if(m){m.className='wr-msg'+(kind?' '+kind:'');m.innerHTML=h||''}};
  const val=id=>{const e=q('#'+id);return e?e.value:''};
  const busy=on=>{const b=q('.wr-form [data-a="submit"]');if(b){b.disabled=!!on;b.textContent=on?'…بنجهّز':(q('.wr-form').dataset.edit?'حفظ':'إضافة')}};

  async function save(rec,opts){
    try{return await repo.saveResource(rec,opts)}
    catch(e){
      if(e&&e.name==='ConflictError'){toast('المصدر ده اتغيّر من مكان تاني — حدّثناه، جرّب تاني');await reload();return null}
      if(e&&e.name==='NotFoundError'){toast('الدرس أو المصدر مبقاش موجود');await reload();return null}
      console.error(e);toast('تعذّر الحفظ');return null;
    }
  }
  const base=(type,extra)=>Object.assign({id:uid(),lessonId,subjectId:'',type,title:'',order:0,status:'todo',completedAt:null,createdAt:stamp(),updatedAt:stamp()},extra);

  async function submitVideo(form,manual){
    const editId=form.dataset.edit;
    const sRaw=timeField(val('wrfStart')),eRaw=timeField(val('wrfEnd'));
    if(editId){
      const r=byId(editId); if(!r) return closeForm();
      const rec=vrec(r.video.youtubeVideoId),errs=validateRange(sRaw,eRaw,rec&&rec.duration||0);
      if(errs.length) return msg(errs.map(esc).join('<br>'),'err');
      const v={...r.video}; delete v.startSec; delete v.endSec;
      if(sRaw!=null) v.startSec=sRaw; if(eRaw!=null) v.endSec=eRaw;
      const out=await save({...r,title:val('wrfTitle').trim()||r.title,video:v},{expectedRev:r.rev}); if(out){closeForm();toast('اتحفظت التعديلات')}
      return;
    }
    const p=WC().parseYouTubeUrl(val('wrfUrl'));
    if(!p.ok) return msg(esc(URL_ERR[p.reason]||URL_ERR.malformed),'err');
    const start=sRaw!=null?sRaw:(p.start!=null&&val('wrfStart').trim()===''?null:null);
    const errs0=validateRange(sRaw,eRaw,0); if(errs0.length) return msg(errs0.map(esc).join('<br>'),'err');
    let title=val('wrfTitle').trim(),status='none';
    busy(true);
    try{
      if(manual){
        if(!title){busy(false);return msg('اكتب عنوان للفيديو الأول.','err')}
        WC().upsertVideo({id:p.id,title,metaStatus:'manual'});status='manual';
      }else{
        const m=await WC().fetchMeta(p.id);
        if(!m.ok){
          busy(false);
          const why={unavailable:'الفيديو ده خاص أو محذوف أو ممنوع تشغيله خارج يوتيوب.',offline:'مفيش اتصال بالإنترنت دلوقتي.',error:'تعذّر جلب بيانات الفيديو.'}[m.reason]||'تعذّر جلب بيانات الفيديو.';
          const mb=q('.wr-form [data-a="manual"]');if(mb)mb.hidden=false;
          return msg(esc(why)+' تقدر تضيفه يدويًا بكتابة عنوانه.','err');
        }
        WC().upsertVideo(m.meta);status=m.meta.metaStatus||'oembed';
        if(!title) title=m.meta.title||'';
      }
      WC().save();
      const rec=vrec(p.id),errs=validateRange(sRaw,eRaw,rec&&rec.duration||0);
      if(errs.length){busy(false);return msg(errs.map(esc).join('<br>'),'err')}
      const dup=S.res.find(r=>r.type==='video'&&r.video.youtubeVideoId===p.id&&(r.video.startSec==null?null:r.video.startSec)===(sRaw==null?null:sRaw)&&(r.video.endSec==null?null:r.video.endSec)===(eRaw==null?null:eRaw));
      if(dup){busy(false);return msg('الفيديو ده (بنفس المدى) مضاف بالفعل في الدرس.','err')}
      const v={youtubeVideoId:p.id,metadataStatus:status}; if(sRaw!=null)v.startSec=sRaw; if(eRaw!=null)v.endSec=eRaw;
      const out=await save(base('video',{title:title||'فيديو يوتيوب',video:v}));
      busy(false);
      if(out){closeForm();toast('اتضاف الفيديو للدرس')}
    }catch(e){busy(false);console.error(e);msg('حصلت مشكلة. جرّب تاني.','err')}
  }
  async function submitBook(form){
    const editId=form.dataset.edit,bid=val('wrfBook'),b=bookById(bid)||S.books.find(x=>x.id===bid);
    if(!b) return msg('اختار كتاب من القائمة.','err');
    const from=intField(val('wrfFrom')),to=intField(val('wrfTo'));
    const errs=validatePages(Number.isNaN(from)?0:from,Number.isNaN(to)?0:to,b.totalPages||0).concat(Number.isNaN(from)||Number.isNaN(to)?['اكتب أرقام صفحات صحيحة']:[]);
    if(errs.length) return msg(errs.map(esc).join('<br>'),'err');
    const bk={bookId:bid}; if(from!=null)bk.pageStart=from; if(to!=null)bk.pageEnd=to;
    const title=val('wrfTitle').trim()||b.title;
    if(editId){const r=byId(editId);if(!r)return closeForm();const out=await save({...r,title,book:bk},{expectedRev:r.rev});if(out){closeForm();toast('اتحفظت التعديلات')}return}
    if(S.res.some(r=>r.type==='book'&&r.book.bookId===bid&&r.book.pageStart===bk.pageStart&&r.book.pageEnd===bk.pageEnd)) return msg('الكتاب ده (بنفس المدى) مضاف بالفعل في الدرس.','err');
    const out=await save(base('book',{title,book:bk})); if(out){closeForm();toast('اتضاف الكتاب للدرس')}
  }
  async function submitLink(form){
    const editId=form.dataset.edit,p=parseHttpUrl(val('wrfUrl'));
    if(!p.ok) return msg(esc(URL_ERR[p.reason]||URL_ERR.malformed),'err');
    if(WC().parseYouTubeUrl(p.url).ok) return msg(esc(URL_ERR.yt),'err');
    const title=val('wrfTitle').trim()||p.host;
    if(editId){const r=byId(editId);if(!r)return closeForm();const out=await save({...r,title,link:{url:p.url}},{expectedRev:r.rev});if(out){closeForm();toast('اتحفظت التعديلات')}return}
    if(S.res.some(r=>r.type==='link'&&r.link.url===p.url)) return msg('الرابط ده مضاف بالفعل في الدرس.','err');
    const out=await save(base('link',{title,link:{url:p.url}})); if(out){closeForm();toast('اتضاف الرابط للدرس')}
  }

  /* ---------- إكتمال / حذف ---------- */
  async function setDone(r,on){
    const cov=r.type==='video'?vCover(r):null;
    const nx=on?{status:'done',completedAt:stamp()}:{status:(cov||0)>0?'doing':'todo',completedAt:null};
    return save({...r,...nx},{expectedRev:r.rev});
  }
  function confirmDelete(r){
    const nm=r.title||TYPES[r.type].n;
    showConfirm('حذف المصدر','حذف «'+nm+'» من الدرس؟ ده بيشيل المرجع بس — '+(r.type==='video'?'تقدّم مشاهدة الفيديو':r.type==='book'?'الكتاب وموضع قراءتك':'الرابط')+' و ملخّص الدرس مش هيتأثروا.',async()=>{
      if(S.playing===r.id) stopPlayer(true);
      const out=await repo.removeResource(r.id); if(out) toast('اتحذف المصدر من الدرس');
    });
  }

  /* ---------- ملخّص الدرس: إضافة سطر مثبّت (شريحة) ---------- */
  function appendNote(inline){
    const ed=view.editor; if(!ed||view.disposed) return false;
    try{
      const doc=structuredClone(ed.getDoc()),last=doc.content[doc.content.length-1],p={type:'paragraph',content:inline};
      if(last&&last.type==='paragraph'&&!(last.content&&last.content.length)) doc.content.splice(doc.content.length-1,1,p,{type:'paragraph'});
      else doc.content.push(p,{type:'paragraph'});
      ed.load(doc,ed.getToggleState()); view.onChange();
      Promise.resolve(view.flush&&view.flush()).catch(()=>{});
      return true;
    }catch(e){console.error('wird-resources note',e);return false}
  }
  const chip=(text,href)=>({type:'text',text,marks:[{type:'link',attrs:{href}}]});
  function pinTime(r,noteText){
    const t=PL.player&&PL.ready?nowT():null;
    const rec=vrec(r.video.youtubeVideoId),sec=Math.floor(t!=null?t:(rec&&rec.lastPos)||0);
    const inline=[chip('▶ '+WC().fmt(sec,(rec&&rec.duration||0)>=3600),anchorHref(r.id,{t:sec}))];
    if(noteText) inline.push({type:'text',text:' '+noteText});
    if(appendNote(inline)) toast('اتثبّت الوقت '+WC().fmt(sec)+' في الملخّص');
    else toast('تعذّر الإضافة للملخّص');
  }
  function pinPage(r){
    const b=bookById(r.book.bookId); if(!b) return toast('الكتاب مش موجود في المكتبة');
    const pg=b.currentPage||1;
    if(appendNote([chip('📖 ص '+pg,anchorHref(r.id,{p:pg}))])) toast('اتثبّتت صفحة '+ar(pg)+' في الملخّص'); else toast('تعذّر الإضافة للملخّص');
  }

  /* ---------- الكتب ---------- */
  async function openBook(r,page){
    const b=bookById(r.book.bookId);
    if(!b){toast('الكتاب مش موجود في المكتبة (مصدر مفقود)');return}
    const a=r.book.pageStart,z=r.book.pageEnd,cur=b.currentPage||1;
    const target=page!=null?page:((a==null||(cur>=a&&(z==null||cur<=z)))?cur:a);
    try{
      await openBookReader(b.id);
      if(target!==bookReaderState.currentPage) await renderBookPage(target);
      if(r.status==='todo') save({...r,status:'doing'},{expectedRev:r.rev});
    }catch(e){console.error(e)}
  }

  /* ---------- المشغّل (يوتيوب الرسمي فقط) ---------- */
  const ytLink=(id,t)=>'https://www.youtube.com/watch?v='+id+(t>0?'&t='+Math.floor(t)+'s':'');
  const setStat=h=>{const e=q('#wrStat');if(e)e.innerHTML=h||''};
  const nowT=()=>{try{return PL.player.getCurrentTime()}catch(e){return null}};
  function buildPlayerShell(r){
    const p=q('#wrPanel'),v=r.video,rec=vrec(v.youtubeVideoId)||{};
    p.innerHTML=`<div class="wr-player"><div class="wr-top"><button type="button" class="ls-btn" data-a="pback">→ الفيديوهات</button><a class="ls-btn" id="wrYtLink" href="${esc(ytLink(v.youtubeVideoId,vRange(r)[0]))}" target="_blank" rel="noopener noreferrer">▶ افتح في يوتيوب</a></div>
      <div class="wr-ytw"><div id="wrYt"></div></div><div id="wrStat" role="status" aria-live="polite"></div><div id="wrPrompt"></div><div id="wrInfo"></div></div>`;
    setStat('<p class="wr-hint">⏳ بنحمّل مشغّل يوتيوب…</p>');
  }
  function liveHtml(r){
    const v=r.video,rec=vrec(v.youtubeVideoId)||{},cov=vCover(r),lg=(rec.duration||0)>=3600,t=rec.lastPos||0;
    return `<div class="wr-meta">⏱ الموضع: <bdi dir="ltr">${ar(WC().fmt(t,lg))}</bdi> · ${rangeText(r)} · مشاهدة تقريبية: ${cov==null?'—':ar(Math.round(cov*100))+'٪'}${r.status==='done'?' · ✓ مكتمل':''}</div>${cov!=null?bar(Math.round(cov*100),'نسبة مشاهدة المصدر (تقريبية)'):''}`;
  }
  function renderPlayerInfo(){
    const r=byId(S.playing),box=q('#wrInfo'); if(!r||!box) return;
    const rec=vrec(r.video.youtubeVideoId)||{};
    if(!box.querySelector('.wr-pin')){
      box.innerHTML=`<div class="wr-card wr-pcard"><b class="wr-title">${esc(r.title||rec.title||'فيديو')}</b><small>${esc(rec.channel||'')}</small><div id="wrLive"></div>
        <div class="wr-act"><button type="button" class="ls-btn ls-btn-primary" data-a="presume">▶ كمّل من آخر موضع</button><button type="button" class="ls-btn wr-ok" data-a="pdone"></button></div>
        <div class="wr-pin"><label class="wr-f" for="wrPinTxt"><span>ملاحظة قصيرة على اللحظة (اختياري)</span><input class="ls-input" id="wrPinTxt" maxlength="200" placeholder="اكتب ملاحظتك…"></label>
        <button type="button" class="ls-btn" data-a="pin">📍 ثبّت الوقت</button></div></div>
        <p class="wr-hint wr-yt-note">المشغّل الرسمي من يوتيوب — العنوان والقناة والإعلانات وأدوات التحكم كما هي. <a href="${esc(ytLink(r.video.youtubeVideoId,0))}" target="_blank" rel="noopener noreferrer">الفيديو الأصلي</a></p>`;
    }
    const l=q('#wrLive'); if(l) l.innerHTML=liveHtml(r);
    const d=q('[data-a="pdone"]'); if(d) d.textContent=r.status==='done'?'↩ إلغاء الإكتمال':'✓ علّمه مكتمل';
  }
  function showSuggest(r){
    const box=q('#wrPrompt'); if(!box||PL.suggested||r.status==='done') return; PL.suggested=true;
    box.innerHTML=`<div class="wr-prompt" role="status"><b>🎯 شاهدت حوالي ٩٠٪ من المصدر ده</b><small>تعلّمه مكتمل؟ (اقتراح بس — مفيش حاجة بتتكمّل لوحدها.)</small><div class="wr-act"><button type="button" class="ls-btn ls-btn-primary" data-a="psugg-yes">✓ علّمه مكتمل</button><button type="button" class="ls-btn" data-a="psugg-no">لاحقًا</button></div></div>`;
  }
  function showEnd(r){
    const box=q('#wrPrompt'); if(!box) return;
    box.innerHTML=`<div class="wr-prompt" role="status"><b>⏸ وقّفنا عند نهاية المدى</b><small>خلّصت الجزء ده. علّمه مكتمل لو فعلًا خلّصته.</small><div class="wr-act">${r.status==='done'?'':'<button type="button" class="ls-btn ls-btn-primary" data-a="psugg-yes">✓ علّمه مكتمل</button>'}<button type="button" class="ls-btn" data-a="psugg-no">تمام</button></div></div>`;
  }
  async function startPlayer(r,o){
    o=o||{};
    stopPlayer(false);
    S.playing=r.id; PL.resId=r.id; PL.endHit=false; PL.suggested=false; PL.marked=false; const tok=++PL.token;
    try{WC().pausePlayer()}catch(e){}
    WC().upsertVideo({id:r.video.youtubeVideoId});
    select('video',{force:true}); buildPlayerShell(r); renderPlayerInfo();
    let API; try{API=await WC().loadYT()}catch(e){
      if(tok!==PL.token) return;
      return setStat(`<p class="wr-err" role="alert">مقدرناش نحمّل مشغّل يوتيوب (غالبًا مفيش اتصال). تقدّمك والدرس محفوظين.</p><a class="ls-btn ls-btn-primary" href="${esc(ytLink(r.video.youtubeVideoId,resumeAt(r)))}" target="_blank" rel="noopener noreferrer">افتح الفيديو في يوتيوب</a>`);
    }
    if(tok!==PL.token||!q('#wrYt')) return;
    setStat('');
    const at=Math.floor(o.at!=null?o.at:(o.resume?resumeAt(r):vRange(r)[0])),pv={playsinline:1,rel:0,enablejsapi:1,start:at};
    if(/^https?:$/.test(location.protocol)) pv.origin=location.origin;
    PL.player=new API.Player('wrYt',{videoId:r.video.youtubeVideoId,width:'100%',height:'100%',playerVars:pv,events:{
      onReady:()=>{ if(tok!==PL.token) return; PL.ready=true; syncDuration(); seekTo(at,false); if(o.play) try{PL.player.playVideo()}catch(e){} },
      onStateChange:e=>tok===PL.token&&onState(e),onError:e=>tok===PL.token&&onError(e)}});
  }
  function syncDuration(){
    const r=byId(PL.resId),p=PL.player; if(!r||!p||!p.getDuration) return;
    const rec=vrec(r.video.youtubeVideoId); if(!rec) return;
    let d=0,vd=null; try{d=p.getDuration();vd=p.getVideoData&&p.getVideoData()}catch(e){}
    let ch=false;
    if(d>0&&(!rec.duration||Math.abs(rec.duration-d)>2)){rec.duration=Math.round(d);ch=true}
    if(vd){if(!rec.title&&vd.title){rec.title=vd.title;ch=true}if(!rec.channel&&vd.author){rec.channel=vd.author;ch=true}}
    if(ch){rec.metaStatus=rec.metaStatus||'player';WC().save();renderPlayerInfo()}
  }
  function seekTo(t,play){
    if(!PL.player||!PL.ready) return;
    try{PL.player.seekTo(Math.max(0,t),true);if(play)PL.player.playVideo()}catch(e){}
    PL.prevT=null;PL.endHit=false;
  }
  const ERR={2:'رابط الفيديو غير صالح.',5:'حصلت مشكلة في مشغّل الفيديو.',100:'الفيديو محذوف أو خاص.',101:'صاحب الفيديو منع تشغيله خارج يوتيوب.',150:'صاحب الفيديو منع تشغيله خارج يوتيوب.',153:'يوتيوب رفض تشغيل الفيديو هنا.'};
  function onError(e){
    const r=byId(PL.resId); if(!r) return; const rec=vrec(r.video.youtubeVideoId); if(rec){rec.unavailable=true;WC().save()}
    stopTimer();
    setStat(`<p class="wr-err" role="alert">${esc(ERR[e.data]||'الفيديو مش متاح للتشغيل جوه التطبيق.')} المصدر وتقدّمك محفوظين.</p><a class="ls-btn ls-btn-primary" href="${esc(ytLink(r.video.youtubeVideoId,resumeAt(r)))}" target="_blank" rel="noopener noreferrer">▶ افتح في يوتيوب</a>`);
  }
  function onState(e){
    PL.state=e.data;
    const r=byId(PL.resId);
    if(e.data===1){
      if(PL.endHit){PL.endHit=false;const b=q('#wrPrompt');if(b)b.innerHTML=''}
      syncDuration();startTimer();
      if(r&&r.status==='todo'&&!PL.marked){PL.marked=true;save({...r,status:'doing'},{expectedRev:r.rev})}   // بدأ = جاري (مش إكتمال)
    }else if(e.data===3){ if(!PL.timer) startTimer() }
    else{ if(e.data===2||e.data===0) tick(); stopTimer(); PL.prevT=null; try{WC().flush()}catch(_){} }
  }
  function startTimer(){stopTimer();PL.prevT=nowT();PL.lastTick=Date.now();PL.tickMs=1000;PL.timer=setInterval(tick,1000)}
  function setTickMs(ms){if(!PL.timer||PL.tickMs===ms)return;clearInterval(PL.timer);PL.tickMs=ms;PL.timer=setInterval(tick,ms)}
  function stopTimer(){if(PL.timer){clearInterval(PL.timer);PL.timer=null}}
  function tick(){
    if(!PL.player||!PL.ready) return;
    const r=byId(PL.resId); if(!r) return;
    const rec=vrec(r.video.youtubeVideoId); if(!rec) return;
    const t=nowT(); if(t==null) return;
    const now=Date.now(),wall=Math.min(10,(now-PL.lastTick)/1000); PL.lastTick=now;
    let rate=1; try{rate=PL.player.getPlaybackRate()||1}catch(e){}
    const prev=PL.prevT,st=WC().applyStep(rec,prev,t,wall,rate,now); PL.prevT=t;
    WC().saveSoon();
    const [,end]=vRange(r),hasEnd=r.video.endSec!=null&&end!=null;
    if(hasEnd&&!PL.endHit&&st.add&&prev<end-0.1&&t>=end-0.1){PL.endHit=true;try{PL.player.pauseVideo()}catch(e){}showEnd(r)}
    const cov=vCover(r); if(cov!=null&&cov>=SUGGEST_AT) showSuggest(r);
    setTickMs(hasEnd&&!PL.endHit&&end-t<=1.6*rate+0.5&&end-t>-1?200:1000);
    const l=q('#wrLive'); if(l) l.innerHTML=liveHtml(r);
  }
  function stopPlayer(rerender){
    if(PL.player){try{tick()}catch(e){}try{PL.player.destroy()}catch(e){}}
    stopTimer(); PL.player=null; PL.ready=false; PL.state=-1; PL.prevT=null; PL.token++;
    try{WC().flush()}catch(e){}
    if(S.playing){S.playing=null; if(rerender&&S.tab==='video'&&!S.disposed){const p=q('#wrPanel');if(p){p.innerHTML=`<div id="wrForm"></div><div id="wrList"></div>`;renderList()}}}
  }

  /* ---------- جدولة الدرس كمهمة في نظام العادات ---------- */
  function schedule(resId){
    const L=a.lesson(lessonId); if(!L) return;
    const res=window.WirdResources.scheduleLesson(lessonId,resId); if(res.dup) toast('الدرس ده مجدول النهارده بالفعل'); else if(res.ok) toast('اتضافت مهمة «'+L.title+'» لجدول النهارده'); else toast('تعذّرت الجدولة');
  }

  /* ---------- الأحداث ---------- */
  wrap.addEventListener('click',e=>{
    const tb=e.target.closest('[data-tab]'); if(tb&&wrap.contains(tb)){select(tb.dataset.tab);return}
    const b=e.target.closest('[data-a]'); if(!b||!wrap.contains(b)) return;
    const act=b.dataset.a,row=b.closest('[data-id]'),r=row&&byId(row.dataset.id);
    switch(act){
      case 'add': openForm(S.tab); break;
      case 'cancel': closeForm(); break;
      case 'manual': { const f=b.closest('form'); submitVideo(f,true); break }
      case 'play': if(r) startPlayer(r,{resume:true,play:true}); break;
      case 'pback': stopPlayer(true); break;
      case 'presume': { const x=byId(S.playing); if(x) seekTo(resumeAt(x),true); break }
      case 'pdone': { const x=byId(S.playing); if(x) setDone(x,x.status!=='done'); break }
      case 'pin': { const x=byId(S.playing),i=q('#wrPinTxt'); if(x){pinTime(x,i&&i.value.trim());if(i)i.value=''} break }
      case 'psugg-yes': { const x=byId(S.playing); if(x) setDone(x,true); const p=q('#wrPrompt'); if(p)p.innerHTML=''; break }
      case 'psugg-no': { const p=q('#wrPrompt'); if(p)p.innerHTML=''; break }
      case 'done': if(r) setDone(r,r.status!=='done'); break;
      case 'edit': if(r) openForm(r.type,r); break;
      case 'del': if(r) confirmDelete(r); break;
      case 'open': if(r) openBook(r); break;
      case 'pinp': if(r) pinPage(r); break;
      case 'sched': schedule(); break;
      case 'visit': if(r&&r.status==='todo') save({...r,status:'doing'},{expectedRev:r.rev}); break;     // الرابط بيتفتح في تبويب جديد بـ noopener
    }
  });
  wrap.addEventListener('submit',e=>{
    const f=e.target.closest('form.wr-form'); if(!f) return; e.preventDefault();
    if(f.dataset.kind==='video') submitVideo(f,false); else if(f.dataset.kind==='book') submitBook(f); else submitLink(f);
  });

  /* شرائح الملخّص (wird-res://…) بتقفز للمصدر */
  async function goAnchor(href){
    const an=parseAnchor(href); if(!an) return;
    let r=byId(an.id)||await repo.getResource(an.id);
    if(!r||r.lessonId!==lessonId){
      const other=r&&r.lessonId!==lessonId?r:null;
      if(!other){toast('المصدر المرتبط بالشريحة دي اتحذف أو مفقود');return}
      toast('المصدر ده تابع لدرس تاني');return;
    }
    if(r.type==='video'){ select('video',{force:true}); await startPlayer(r,{at:an.t!=null?an.t:undefined,resume:an.t==null,play:true}) }
    else if(r.type==='book'){ select('book',{force:true}); openBook(r,an.p) }
    else { select('link',{force:true}) }
  }
  const onChipClick=e=>{
    const a1=e.target.closest&&e.target.closest('a[href^="wird-res://"]'); if(!a1) return;
    e.preventDefault(); e.stopPropagation(); goAnchor(a1.getAttribute('href'));
  };
  view.root.addEventListener('click',onChipClick,true);

  /* ---------- تنظيف ---------- */
  const onWirdView=()=>{ if(PL.player&&PL.state===1){try{PL.player.pauseVideo()}catch(e){}} stopTimer(); try{WC().flush()}catch(e){} };
  const onVis=()=>{ if(!PL.player) return; if(document.hidden){tick();stopTimer();PL.prevT=null;try{WC().flush()}catch(e){}} else if(PL.state===1) startTimer() };
  const onHide=()=>{try{if(PL.player)tick()}catch(e){}try{WC().flush()}catch(e){}};
  document.addEventListener('wird:view',onWirdView); document.addEventListener('visibilitychange',onVis); window.addEventListener('pagehide',onHide);
  const bro=document.getElementById('bookReaderOverlay'); let mo=null;
  if(bro){ mo=new MutationObserver(()=>{ if(!bro.classList.contains('open')) { S.tab==='book'&&!S.disposed&&(refreshBooks().then(()=>dbGetAll('books')).then(b=>{S.books=b;renderList()}).catch(()=>{})) } }); mo.observe(bro,{attributes:true,attributeFilter:['class']}) }
  view.unsubs.push(()=>{
    S.disposed=true; stopPlayer(false); unsub();
    document.removeEventListener('wird:view',onWirdView); document.removeEventListener('visibilitychange',onVis); window.removeEventListener('pagehide',onHide);
    view.root&&view.root.removeEventListener('click',onChipClick,true); mo&&mo.disconnect(); ATTACHED.delete(view);
  });
  ATTACHED.add(view);
  view.resApi={select,startPlayer:id=>{const r=byId(id);return r&&startPlayer(r,{resume:true,play:true})},get state(){return S}};
  renderHead();renderTabs();
  reload().then(()=>{
    if(PENDING&&PENDING.lessonId===lessonId){
      const p=PENDING;PENDING=null;const r=p.resId&&byId(p.resId);
      if(r){ if(r.type==='video') startPlayer(r,{resume:true,play:true}); else select(r.type,{force:true}) }
    }
  });
}

/* ============================ ربط بالـ hook الموجود (__ctxLesson) ============================ */
(function hook(){
  const prev=window.__ctxLesson;
  window.__ctxLesson=(view,slots,dirSel)=>{
    let r=false; try{r=prev?prev(view,slots,dirSel):false}catch(e){}
    try{attach(view)}catch(e){console.error('wird-resources attach',e)}
    return r;
  };
})();

/* ============================ جدولة (مهمة في نظام العادات، مرجع الدرس بس) ============================ */
function scheduleLesson(lessonId,resourceId,date){
  try{
    const d=date||todayISO(),L=ap().lesson(lessonId); if(!L) return {ok:false};
    H.oneoffs[d]=H.oneoffs[d]||[];
    if(H.oneoffs[d].some(o=>o.lessonRef&&o.lessonRef.lessonId===lessonId&&(o.lessonRef.resourceId||null)===(resourceId||null))) return {ok:false,dup:true};
    const one={id:'o_'+Date.now()+Math.random().toString(36).slice(2,5),name:'📖 ذاكر: '+L.title,s:0,cat:'other',done:false,lessonRef:{lessonId,resourceId:resourceId||null}};
    H.oneoffs[d].push(one); hSave(); try{hRender()}catch(e){}
    return {ok:true,id:one.id};
  }catch(e){console.error(e);return {ok:false}}
}
// الاسم بيفضل مطابق لعنوان الدرس الحالي (من غير ما نلمس حالة الإنجاز)
function syncLessonTasks(over){
  try{
    const a=ap(); if(!a||!a.tree) return; let ch=false;
    Object.values(H.oneoffs||{}).forEach(arr=>(arr||[]).forEach(o=>{
      if(!o.lessonRef) return; const id=o.lessonRef.lessonId,L=a.lesson(id),title=(over&&over[id])||(L&&L.title); if(!title) return;
      const nm='📖 ذاكر: '+title; if(o.name!==nm){o.name=nm;ch=true}
    }));
    if(ch){hSave();try{hRender()}catch(e){}}
  }catch(e){}
}

/* ============================ اللوحة الرئيسية: «كمّل» + البحث ============================ */
function nextResource(lessonId){
  const l=(CACHE.byLesson.get(lessonId)||[]).filter(r=>!isMissing(r)&&r.status!=='done');
  return l.find(r=>r.status==='doing')||l[0]||null;
}
function hubContinue(){
  const a=ap(); if(!a||!a.settings||!CACHE.ready) return null;
  const id=a.settings.lastLessonId,L=id&&a.lesson&&a.lesson(id); if(!L) return null;
  const n=nextResource(id); if(!n) return null;
  return {lessonId:id,title:L.title||'درس',res:n,pct:progOf(id).pct};
}
function hubSearch(k){
  const a=ap(),out=[]; if(!a||!a.tree||!CACHE.ready||k.length<2) return out;
  const m=s=>(s||'').toLowerCase().includes(k);
  CACHE.byLesson.forEach((list,lid)=>{
    const L=a.lesson(lid); if(!L) return;
    list.forEach(r=>{
      const rec=r.type==='video'?vrec(r.video.youtubeVideoId):null,host=r.type==='link'?(parseHttpUrl(r.link.url)||{}).host:'';
      if(m(r.title)||(rec&&(m(rec.title)||m(rec.channel)))||m(host)) out.push({i:TYPES[r.type].ic,t:r.title||(rec&&rec.title)||host||TYPES[r.type].n,s:'مصدر في درس «'+(L.title||'بدون عنوان')+'»',a:'lres',id:r.id});
    });
  });
  return out;
}
async function openResource(resId){
  const a=ap(); if(!a) return; let r=null;
  CACHE.byLesson.forEach(l=>l.forEach(x=>{if(x.id===resId)r=x}));
  if(!r) r=await a.repo.getResource(resId); if(!r) return;
  PENDING={lessonId:r.lessonId,resId:r.id};
  try{window.WirdLearning&&window.WirdLearning.go('view-lessons')}catch(e){}
  await a.open({kind:'lesson',id:r.lessonId});
}
async function openLesson(lessonId,resId){
  const a=ap(); if(!a) return;
  PENDING=resId?{lessonId,resId}:null;
  try{window.WirdLearning&&window.WirdLearning.go('view-lessons')}catch(e){}
  await a.open({kind:'lesson',id:lessonId});
}

/* ============================ تشغيل ============================ */
const API={
  helpers:{anchorHref,parseAnchor,lessonProgress,rollup,lessonStatus,validateRange,validatePages,parseHttpUrl,timeField,intField},
  cache:CACHE,progOf,treeProgress,hubContinue,hubSearch,openResource,openLesson,scheduleLesson,syncLessonTasks,reloadCache:loadCache,
  get attached(){return ATTACHED.size}
};
window.WirdResources=API;
let started=false;
async function boot(){
  if(started) return; started=true;
  const a=ap(); if(!a) return;
  try{ await a.init() }catch(e){ return }
  await loadCache(); syncLessonTasks();
  a.onTree(()=>syncLessonTasks());   // بعد ما التطبيق يعيد تحميل الشجرة (إعادة تسمية/نقل/استرجاع…)
  a.repo.subscribe(ev=>{
    if(ev.type==='resources'||ev.type==='reset') loadCache().then(repaintSidebar);
    else if(ev.type==='lesson'&&ev.id) a.repo.getLessonMeta(ev.id).then(m=>{ if(m&&!m.deletedAt) syncLessonTasks({[m.id]:m.title}) }).catch(()=>{});   // تعديل العنوان من المحرر
  });
  CACHE.listeners.add(()=>{try{window.WirdLearning&&window.WirdLearning.last==='view-lrn'&&window.WirdLearning.renderHub()}catch(e){}});
  repaintSidebar();
}
// بنبدأ التحميل لما التطبيق يتفتح أول مرة (من تبويب «منهجي»)، مش في بداية تشغيل الصفحة
const tabBtn=document.querySelector('[data-view="view-lessons"]');
tabBtn&&tabBtn.addEventListener('click',()=>{boot()});
if(document.readyState!=='loading') setTimeout(()=>{ if(ap()&&ap().initPromise) boot() },0);
})();
