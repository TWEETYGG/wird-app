/* wird-unified — شجرة واحدة: مادة › وحدة › درس › عناصر. الشجرة هي المتصفّح الوحيد.
   العنصر = سجل في مخزن resources (نوع + مرجع للمصدر الأصلي). المصادر الأصلية (كتب/كورسات/نصوص/نوت) ما بتتنقلش ولا بتتمسح:
   الترحيل بيربطها بالشجرة بس (غير مدمِّر + idempotent)، وأي حاجة من غير أب بتروح تحت مادة «غير مصنّف». */
(()=>{
'use strict';
const MK='wird_mig_v3',UNC='غير مصنّف',SCK='wird_wu_scroll',LASTK='wird_wu_last';
const $=id=>document.getElementById(id),esc=s=>escapeHtml(String(s==null?'':s)),ar=n=>String(n).replace(/\d/g,d=>'٠١٢٣٤٥٦٧٨٩'[d]);
const ap=()=>window.__WIRD_STUDY_APP__,WR=()=>window.WirdResources,WC=()=>window.WirdCourses;
const lsGet=(k,d)=>{try{const v=JSON.parse(localStorage.getItem(k));return v==null?d:v}catch(e){return d}};
const lsSet=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}};
const TY={video:['🎬','فيديو'],book:['📚','كتاب'],link:['🔗','رابط'],course:['🎓','كورس'],text:['📓','نص مذاكرة'],notebook:['🗒','نوت']};
const UN={book:'كتب',course:'كورسات',text:'المذاكرة',notebook:'دفاتر'};
const st=()=>lsGet(MK,{}),stSet=o=>lsSet(MK,o);
const uid=()=>'res_'+Date.now().toString(36)+Math.random().toString(36).slice(2,8);
const ms=v=>typeof v==='number'?v:(Date.parse(v)||Date.now());

/* ---------------------------- مكوّنات مشتركة: sheet / menu / toast ---------------------------- */
function sheet(title,html,btns){
  const d=document.createElement('div');d.className='wu-ov';
  d.innerHTML=`<div class="wu-sheet" role="dialog" aria-modal="true" aria-label="${esc(title)}"><div class="wu-hd"><h3>${esc(title)}</h3><button type="button" class="wu-x" aria-label="إغلاق">✕</button></div><div class="wu-body">${html}</div><div class="wu-act"></div></div>`;
  const opener=document.activeElement;
  const close=()=>{d.remove();document.removeEventListener('keydown',kd,true);if(opener&&opener.isConnected&&opener.focus)opener.focus()};
  const kd=e=>{
    if(e.key==='Escape'){e.stopPropagation();close()}
    else if(e.key==='Enter'&&e.target.tagName==='INPUT'){const p=d.querySelector('.wu-act .ls-btn-primary');if(p){e.preventDefault();p.click()}}
    else if(e.key==='Tab'){const f=[...d.querySelectorAll('button,input,select,textarea')].filter(x=>!x.disabled&&x.offsetParent!==null);if(!f.length)return;const a=f[0],z=f[f.length-1];
      if(e.shiftKey&&document.activeElement===a){e.preventDefault();z.focus()}else if(!e.shiftKey&&document.activeElement===z){e.preventDefault();a.focus()}else if(!d.contains(document.activeElement)){e.preventDefault();a.focus()}}};
  document.addEventListener('keydown',kd,true);
  d.querySelector('.wu-x').onclick=close;d.addEventListener('mousedown',e=>{if(e.target===d)close()});
  (btns||[]).forEach(b=>{const x=document.createElement('button');x.type='button';x.className='ls-btn '+(b.cls||'');x.textContent=b.l;x.onclick=async()=>{if(await b.fn(d)!==false)close()};d.querySelector('.wu-act').append(x)});
  document.body.append(d);const f=d.querySelector('input,select,textarea,.wu-act button');f&&f.focus();return d;
}
function toast(msg,undo){
  const t=document.createElement('div');t.className='wu-toast';t.setAttribute('role','status');t.textContent=msg;
  if(undo){const b=document.createElement('button');b.type='button';b.textContent='تراجع';b.onclick=()=>{undo();t.remove()};t.append(b)}
  document.body.append(t);setTimeout(()=>t.remove(),undo?7000:2800);
}
function menu(x,y,items){
  document.querySelectorAll('.wu-menu').forEach(m=>m.remove());
  const from=document.activeElement;
  const m=document.createElement('div');m.className='wu-menu';m.setAttribute('role','menu');
  const back=()=>{if(from&&from.isConnected&&from.focus)from.focus()};
  items.forEach(i=>{if(i.sep){const s=document.createElement('hr');s.setAttribute('role','separator');m.append(s);return}const b=document.createElement('button');b.type='button';b.setAttribute('role','menuitem');b.className=i.danger?'danger':'';b.textContent=(i.icon?i.icon+' ':'')+i.label;b.onclick=()=>{m.remove();back();i.run()};m.append(b)});
  document.body.append(m);const r=m.getBoundingClientRect();
  m.style.left=Math.max(8,Math.min(x,innerWidth-r.width-8))+'px';m.style.top=Math.max(8,Math.min(y,innerHeight-r.height-8))+'px';
  const bs=[...m.querySelectorAll('button')],go=n=>bs.length&&bs[(n+bs.length)%bs.length].focus();
  m.addEventListener('keydown',e=>{const n=bs.indexOf(document.activeElement);
    if(e.key==='ArrowDown'){e.preventDefault();go(n+1)}else if(e.key==='ArrowUp'){e.preventDefault();go(n-1)}
    else if(e.key==='Home'){e.preventDefault();go(0)}else if(e.key==='End'){e.preventDefault();go(-1)}
    else if(e.key==='Escape'){e.preventDefault();e.stopPropagation();m.remove();back()}else if(e.key==='Tab'){m.remove()}});
  go(0);
  setTimeout(()=>document.addEventListener('click',()=>m.remove(),{once:true}),0);
}

/* ---------------------------- قراءة المصادر الأصلية ---------------------------- */
const nbState=()=>new Promise(r=>{try{const q=indexedDB.open('wird_fnb_m',1);q.onupgradeneeded=()=>q.result.createObjectStore('m');q.onerror=()=>r(null);
  q.onsuccess=()=>{try{const g=q.result.transaction('m').objectStore('m').get('__S');g.onsuccess=()=>{q.result.close();r(g.result||null)};g.onerror=()=>r(null)}catch(e){r(null)}}}catch(e){r(null)}});
async function sources(){
  const repo=ap().repo,books=await dbGetAll('books').catch(()=>[]);
  const C=(WC()&&WC().C)||{},nb=await nbState();
  const nbKeys=nb&&nb.books?Object.keys(nb.books).filter(k=>(nb.books[k].n||[]).some(p=>p.it&&p.it.length)):[];
  return{books,courses:C.courses||[],texts:Object.values((typeof ST!=='undefined'&&ST.sessions)||{}),nbKeys,res:await repo.listAllResources(),C,nb};
}
const refsOf=res=>{const R={book:new Set(),course:new Set(),text:new Set(),notebook:new Set()};
  res.forEach(r=>{const x=r[r.type];if(!x)return;if(r.type==='book')R.book.add(x.bookId);else if(r.type==='course')R.course.add(x.courseId);else if(r.type==='text')R.text.add(x.sessionId);else if(r.type==='notebook')R.notebook.add(x.key)});return R};
const countsOf=S=>({books:S.books.length,courses:S.courses.length,notebooks:S.nbKeys.length,texts:S.texts.length,resources:S.res.length});

/* ---------------------------- نسخة احتياطية ---------------------------- */
function bkDb(){return new Promise(r=>{try{const q=indexedDB.open('wird_mig_db',1);q.onupgradeneeded=()=>q.result.createObjectStore('b',{keyPath:'id'});q.onsuccess=()=>r(q.result);q.onerror=()=>r(null)}catch(e){r(null)}})}
async function backup(){
  const a=ap(),S=await sources(),ls={};
  for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k&&k.startsWith('wird'))ls[k]=localStorage.getItem(k)}
  const ann=await dbGetAll('annotations').catch(()=>[]);
  const data={app:'wird',kind:'pre-v3-backup',ts:Date.now(),note:'بيانات وصفية فقط؛ ملفات PDF والصور والوسائط ما اتمسّتش ولا اتنسخت.',ls,books:S.books,annotations:ann,resources:S.res,courses:S.C,study:typeof ST!=='undefined'?ST:null,notebooks:S.nb,tree:{subjects:a.tree.subjects,units:a.tree.units,lessons:a.tree.lessons}};
  const db=await bkDb();if(db){await new Promise(r=>{const t=db.transaction('b','readwrite');t.objectStore('b').put({id:'pre-v3',ts:data.ts,json:JSON.stringify(data)});t.oncomplete=()=>r();t.onerror=()=>r()});db.close()}
  return data;
}
async function backupJson(){const db=await bkDb();if(!db)return null;return new Promise(r=>{const g=db.transaction('b').objectStore('b').get('pre-v3');g.onsuccess=()=>{db.close();r(g.result&&g.result.json)};g.onerror=()=>r(null)})}
async function downloadBackup(){
  const j=await backupJson();if(!j)return toast('مفيش نسخة محفوظة');
  const u=URL.createObjectURL(new Blob([j],{type:'application/json'})),a=document.createElement('a');
  a.href=u;a.download='wird-backup-pre-v3-'+new Date().toISOString().slice(0,10)+'.json';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),4000);
}

/* ---------------------------- الترحيل / الربط (idempotent) ---------------------------- */
let chain=Promise.resolve(),ctx=null,pend=false;const flush=()=>{if(pend){pend=false;report()}};
const reconcile=c=>chain=chain.then(()=>rec(c)).catch(e=>{console.error('wird-unified reconcile',e);return null});
async function rec(c){
  const a=ap();if(!a||!a.repo)return null;await a.init();const repo=a.repo,s0=st();if(s0.off)return null;
  await WR().reloadCache();const first=!s0.ts,S=await sources(),R=refsOf(S.res),T=a.tree;
  if(first){await backup();s0.before=countsOf(S);s0.ts=Date.now();s0.v=3;s0.created={subject:null,units:[],lessons:[],items:[]};stSet(s0)}
  const cr=s0.created||(s0.created={subject:null,units:[],lessons:[],items:[]}),SC={},LC={};
  const subj=async()=>{if(SC.s)return SC.s;let s=T.subjects.find(x=>x.name===UNC);if(!s){s=await repo.createSubject(UNC);cr.subject=s.id}return SC.s=s};
  const unit=async t=>{if(SC[t])return SC[t];const s=await subj();let u=T.units.find(x=>x.subjectId===s.id&&x.name===UN[t]);if(!u){u=await repo.createUnit(s.id,UN[t]);cr.units.push(u.id)}return SC[t]=u};
  const lesson=async(t,title)=>{const k=t+'|'+title;if(LC[k])return LC[k];const u=await unit(t);let l=T.lessons.find(x=>x.unitId===u.id&&x.title===title);if(!l){l=await repo.createLesson({subjectId:u.subjectId,unitId:u.id,title});cr.lessons.push(l.id)}return LC[k]=l};
  const ctxL=c&&T.lessons.find(l=>l.id===c.lessonId);
  const jobs=[];
  S.books.forEach(b=>R.book.has(b.id)||jobs.push({t:'book',lt:b.title||'كتاب',title:b.title,at:ms(b.addedDate),st:(b.currentPage||1)>1?'doing':'todo',p:{book:{bookId:b.id}}}));
  S.courses.forEach(x=>R.course.has(x.id)||jobs.push({t:'course',lt:x.title||'كورس',title:x.title,at:ms(x.createdAt),p:{course:{courseId:x.id}}}));
  S.texts.forEach(x=>R.text.has(x.sessionId)||jobs.push({t:'text',lt:x.subject||'نصوص',title:((x.rawText||'').trim().slice(0,40)||x.subject),at:ms(x.createdAt),st:x.completedAt?'done':'todo',p:{text:{sessionId:x.sessionId,subject:x.subject||''}}}));
  S.nbKeys.forEach(k=>{if(R.notebook.has(k))return;const lid=k[0]==='L'&&k.slice(1),own=lid&&T.lessons.find(l=>l.id===lid);jobs.push({t:'notebook',own,lt:k==='G'?'النوت العام':'نوت قديم',title:'نوت',at:Date.now(),p:{notebook:{key:k}}})});
  let n=0;
  for(const j of jobs){
    const L=j.own||(ctxL&&j.t!=='notebook'?ctxL:await lesson(j.t,j.lt));
    const sib=(WR().cache.byLesson.get(L.id)||[]).length+n++;
    const rid=uid();
    await repo.putResourceRaw({id:rid,lessonId:L.id,subjectId:L.subjectId,type:j.t,title:(j.title||'').slice(0,300),order:sib,status:j.st||'todo',completedAt:j.st==='done'?Date.now():null,createdAt:j.at,updatedAt:Date.now(),rev:1,deletedAt:null,deleteBatch:null,...j.p}).then(()=>cr.items.push(rid)).catch(e=>console.error('wird-unified item',j.t,e));
  }
  cr.items=cr.items.filter(Boolean);
  const S2=await sources(),R2=refsOf(S2.res);
  const ok=x=>x.length;
  if(first||!s0.after)s0.after={books:S2.books.filter(b=>R2.book.has(b.id)).length,courses:S2.courses.filter(x=>R2.course.has(x.id)).length,notebooks:S2.nbKeys.filter(k=>R2.notebook.has(k)).length,texts:S2.texts.filter(x=>R2.text.has(x.sessionId)).length,resources:S2.res.length};
  s0.now=countsOf(S2);s0.created=cr;stSet(Object.assign(st(),s0));
  if(jobs.length){await WR().reloadCache();await new Promise(r=>setTimeout(r,150));a.sidebar&&a.sidebar.render();}
  if(first&&cr.items.length&&!s0.reported){pend=true;if($('view-lessons').classList.contains('active'))setTimeout(flush,900)}
  return{jobs:jobs.length};
}

/* مدخل دائم لتقرير الترحيل / الرجوع / إعادة الربط على شاشة «منهجي» الرئيسية (مش بس نافذة لمرة واحدة) */
/* «مناهجي الدراسية» (خطط الكتب + بانر مهام اليوم): كان مدخلها على شاشة «مكتبتي» المشالة — بنرجّعه من الرئيسية من غير حذف ولا تغيير في منطقها:
   بانر التذكير الأصلي (#cuReminderBanner) بيتنقل لهنا (نفس العقدة ⇒ نفس المعالجات) وزر الفتح بيشغّل المعالج الأصلي. */
let cuNode=null;
function mountCurricula(h){
  if(h.querySelector('.wu-cu'))return;cuNode=cuNode||$('cuReminderBanner');
  const w=document.createElement('div');w.className='wu-cu';if(cuNode)w.append(cuNode);
  const b=document.createElement('button');b.type='button';b.className='ls-btn';b.dataset.wu='curricula';b.textContent='🗓 مناهجي الدراسية';w.append(b);h.append(w);
  try{if(typeof renderCuReminderBanner==='function')renderCuReminderBanner()}catch(e){}
}
function dressHome(root){
  const h=root.matches&&root.matches('.ls-home')?root:root.querySelector&&root.querySelector('.ls-home');if(!h)return;
  mountCurricula(h);if(h.querySelector('.wu-rep'))return;
  const s=st();if(!s.ts&&!s.off)return;const b=document.createElement('button');b.type='button';b.className='ls-btn wu-rep';
  if(s.off){b.dataset.wu='remigrate';b.textContent='↻ إعادة ربط البيانات القديمة'}else{b.dataset.wu='report';b.textContent='📋 تقرير الترحيل'}h.append(b);
}
const refreshHome=()=>{document.querySelectorAll('.ls-home .wu-rep').forEach(b=>b.remove());document.querySelectorAll('.ls-home').forEach(dressHome)};

/* ---------------------------- التقرير + الرجوع ---------------------------- */
function report(){
  const s=st(),b=s.before||{},f=s.after||{},now=s.now||{};
  const row=(l,x,y)=>`<tr><td>${l}</td><td>${ar(x==null?0:x)}</td><td>${ar(y==null?0:y)}</td><td aria-label="${x===y?'مطابق':'اختلاف'}">${x===y?'✓':'⚠'}</td></tr>`;
  const rows=row('كتب',b.books,f.books)+row('كورسات',b.courses,f.courses)+row('دفاتر نوت',b.notebooks,f.notebooks)+row('نصوص مذاكرة',b.texts,f.texts)+`<tr><td>مصادر الدروس</td><td>${ar(b.resources||0)}</td><td>${ar(now.resources||0)}</td><td>＋${ar((s.created&&s.created.items.length)||0)}</td></tr>`;
  const bad=['books','courses','notebooks','texts'].some(k=>b[k]!==f[k]);
  s.reported=true;stSet(s);
  sheet('تقرير الترحيل',`<p class="wu-hint">${bad?'⚠ في اختلاف في الأعداد — راجع النسخة الاحتياطية أو ارجع للوضع السابق.':'✓ كل بياناتك القديمة بقت ظاهرة في الشجرة. المصادر الأصلية ما اتمسّتش، والتقدّم وأرقام الصفحات والتواريخ محفوظة.'}</p><table class="wu-tbl"><thead><tr><th></th><th>قبل</th><th>بعد</th><th></th></tr></thead><tbody>${rows}</tbody></table><p class="wu-hint">اللي ملوش أب اتحط تحت مادة «${UNC}» بوحدات حسب النوع.</p>`,
    [{l:'تنزيل النسخة الاحتياطية',fn:()=>{downloadBackup();return false}},{l:'رجوع للوضع السابق',cls:'ls-btn-danger',fn:()=>{sheet('تأكيد الرجوع','<p class="wu-hint">هيتشال ربط الكتب والكورسات والنصوص والنوت بالشجرة، ومادة «'+UNC+'» هتروح سلة المحذوفات. بياناتك الأصلية ما بتتمسحش، وتقدر ترجّع الربط بزر «إعادة ربط البيانات القديمة».</p>',[{l:'تأكيد الرجوع',cls:'ls-btn-danger',fn:async()=>{await rollback();return true}},{l:'إلغاء',fn:()=>true}]);return true}},{l:'تمام',cls:'ls-btn-primary',fn:()=>true}]);
}
async function rollback(){
  const a=ap(),repo=a.repo,s=st(),cr=s.created||{items:[],lessons:[],units:[],subject:null};
  for(const id of cr.items)await repo.removeResource(id).catch(()=>{});
  if(cr.subject)await repo.softDelete({subjectId:cr.subject}).catch(()=>{});
  else{for(const id of cr.lessons)await repo.softDelete({lessonId:id}).catch(()=>{});for(const id of cr.units)await repo.softDelete({unitId:id}).catch(()=>{})}
  stSet({v:2,off:true,rolledBack:Date.now(),before:s.before,created:{subject:null,units:[],lessons:[],items:[]}});
  await WR().reloadCache();setTimeout(()=>{a.sidebar&&a.sidebar.render()},200);refreshHome();
  toast('اتشالت روابط الشجرة. بياناتك الأصلية سليمة.');
}
async function remigrate(){const s=st();delete s.off;delete s.ts;s.reported=false;stSet(s);const r=await reconcile();refreshHome();return r}

/* ---------------------------- نموذج العنصر ---------------------------- */
const itemOf=id=>{let r=null;const c=WR()&&WR().cache;c&&c.byLesson.forEach(l=>l.forEach(x=>{if(x.id===id)r=x}));return r};
function nameOf(r){
  try{
    if(r.type==='book'){const b=booksState.list.find(x=>x.id===r.book.bookId);if(b)return b.title}
    else if(r.type==='course'){const c=WC().C.courses.find(x=>x.id===r.course.courseId);if(c)return c.title}
  }catch(e){}
  return r.title||TY[r.type][1];
}
window.__wirdItems=lid=>{const l=WR()&&WR().cache&&WR().cache.byLesson.get(lid);return l?l.map(r=>({id:r.id,type:r.type,name:nameOf(r)})):[]};
window.__wirdIcon=t=>(TY[t.itype]||['•'])[0];
window.__wirdSearch=q=>{
  const k=q.trim().toLowerCase(),out=[];if(k.length<2||!WR())return out;
  WR().cache.byLesson.forEach((l,lid)=>l.forEach(r=>{const n=nameOf(r);if(out.length<12&&(n.toLowerCase().includes(k)||TY[r.type][1].includes(k)))out.push({id:lid,itemId:r.id,itemName:TY[r.type][0]+' '+n,titleMatch:false,snippet:'',ranges:[]})}));
  return out;
};
window.__wirdCard=r=>{
  let meta='';
  try{if(r.type==='course'){const c=WC().C.courses.find(x=>x.id===r.course.courseId);meta=c?ar((c.lessons||[]).length)+' درس':'الكورس مفقود'}
    else if(r.type==='text'){const s=ST.sessions[r.text.sessionId];meta=s?ar((s.units||[]).length)+' مقطع':'النص مفقود'}else meta='نوت الدرس'}catch(e){}
  const done=r.status==='done';
  return `<article class="wr-card wu-card" data-id="${esc(r.id)}"><div class="wr-card-top"><div class="wr-thumb" aria-hidden="true">${TY[r.type][0]}</div><div class="wr-card-info"><b>${esc(nameOf(r))}</b><small>${esc(meta)}</small></div></div><div class="wr-act"><button type="button" class="ls-btn ls-btn-primary" data-wu="open" data-id="${esc(r.id)}">فتح</button><button type="button" class="ls-btn ${done?'':'wr-ok'}" data-a="done">${done?'↩ إلغاء الإكتمال':'✓ تم'}</button><button type="button" class="ls-btn" data-a="edit" aria-label="تعديل">✎</button><button type="button" class="ls-btn ls-btn-danger" data-a="del" aria-label="حذف">🗑</button></div></article>`;
};

/* ---------------------------- فتح العناصر ---------------------------- */
function lessonOf(id){return ap().tree.lessons.find(l=>l.id===id)}
async function openItem(id){
  const r=itemOf(id),a=ap();if(!r)return;lsSet(LASTK,{lessonId:r.lessonId,resId:id});
  if(r.type==='notebook'){try{window.__nbNew&&window.__nbNew(r.lessonId)}catch(e){}await a.go({kind:'lesson',id:r.lessonId});return}
  await WR().openResource(id);
}
window.__wirdOpen=openItem;
async function openType(r){
  if(r.type==='book'){try{await openBookReader(r.book.bookId)}catch(e){toast('تعذّر فتح الكتاب')}}
  else if(r.type==='course'){openHost(r)}
  else if(r.type==='text'){const s=ST.sessions[r.text.sessionId];if(!s)return toast('النص مفقود');stOpen();stSubjectScreen(s.subject)}
}

/* لوحة الكورس: نفس شاشة الكورسات الأصلية لكن داخل مساحة العمل (مش تبويب مستقل) */
let host=null,hostCtx=null;
function openHost(r,create){
  const a=ap();hostCtx=r||null;
  if(!host){host=document.createElement('div');host.className='wu-host';host.innerHTML='<div class="wu-hhd"><button type="button" class="wu-back" aria-label="رجوع">›</button><div class="wu-crumb"></div><button type="button" class="wu-more" data-wu="hmenu" aria-label="المزيد">⋯</button></div><div class="wu-hbody"></div>';document.body.append(host);host.querySelector('.wu-hbody').append($('view-courses'));host.querySelector('.wu-back').onclick=closeHost}
  const L=r&&lessonOf(r.lessonId)||(ctx&&lessonOf(ctx.lessonId));
  host.querySelector('.wu-crumb').innerHTML=`<small>${esc(L?a.crumb(L.id):'')}</small><b>${esc(r?nameOf(r):'كورس جديد')}</b>`;
  host.hidden=false;$('view-courses').classList.add('active');host.querySelector('.wu-back').focus();
  document.dispatchEvent(new CustomEvent('wird:view',{detail:{view:'view-courses'}}));
  if(create)WC().newCourse();else if(r)WC().open(r.course.courseId);
}
function closeHost(){
  if(!host)return;host.hidden=true;$('view-courses').classList.remove('active');
  document.dispatchEvent(new CustomEvent('wird:view',{detail:{view:'view-lessons'}}));
  reconcile(ctx&&Date.now()-ctx.t<6e5?ctx:null);
}

/* ---------------------------- ⋯ قائمة العنصر (نفس القائمة في الشجرة والكارت) ---------------------------- */
function lessonPicker(cur){const a=ap();return `<label class="wr-f"><span>الدرس</span><select class="ls-input" id="wuLes">${a.tree.lessons.map(l=>`<option value="${esc(l.id)}" ${l.id===cur?'selected':''}>${esc(a.crumb(l.id))}</option>`).join('')}</select></label>`}
function itemMenu(id){
  const r=itemOf(id);if(!r)return[];const repo=ap().repo;
  return[
    {label:'فتح',icon:'↗',run:()=>openItem(id)},
    {label:'إعادة تسمية',icon:'✎',run:()=>sheet('إعادة تسمية',`<label class="wr-f"><span>الاسم</span><input class="ls-input" id="wuNm" value="${esc(nameOf(r))}" maxlength="300"></label>`,[{l:'حفظ',cls:'ls-btn-primary',fn:async d=>{const v=d.querySelector('#wuNm').value.trim();if(!v)return false;await repo.putResourceRaw({...r,title:v,rev:r.rev+1,updatedAt:Date.now()})}},{l:'إلغاء',fn:()=>true}])},
    {label:'نقل لدرس تاني',icon:'⇄',run:()=>sheet('نقل',lessonPicker(r.lessonId),[{l:'نقل',cls:'ls-btn-primary',fn:async d=>{const L=lessonOf(d.querySelector('#wuLes').value);if(!L)return false;await repo.putResourceRaw({...r,lessonId:L.id,subjectId:L.subjectId,rev:r.rev+1,updatedAt:Date.now()});toast('اتنقل ✓')}},{l:'إلغاء',fn:()=>true}])},
    {label:'إعدادات',icon:'⚙',run:async()=>{if(r.type==='notebook')return openItem(id);await openItem(id);setTimeout(()=>{const b=document.querySelector(`.wr-card[data-id="${CSS.escape(id)}"] [data-a="edit"]`);b&&b.click()},350)}},
    {sep:true,label:''},
    {label:r.type==='video'||r.type==='link'?'حذف':'إزالة من الدرس',icon:r.type==='video'||r.type==='link'?'🗑':'➖',danger:r.type==='video'||r.type==='link',run:async()=>{
      const copy={...r};await repo.removeResource(id);
      const own=r.type==='video'||r.type==='link';
      toast(own?'اتحذف':'اتشال من الدرس — المصدر الأصلي محفوظ في «'+UNC+'»',()=>repo.putResourceRaw(copy).then(()=>toast('اتسترجع ✓')));
      if(!own)setTimeout(()=>reconcile(),7500);
    }},
    r.type==='book'?{label:'حذف الكتاب نهائيًا',icon:'⛔',danger:true,run:()=>{
      const bid=r.book.bookId,b=booksState.list.find(x=>x.id===bid);
      /* نفس حذف مكتبتي الأصلي (تأكيد ← حذف الكتاب وملفه ← تحديث القائمة): كان زره على شاشة «مكتبتي» المشالة */
      showConfirm('حذف الكتاب','هيتحذف كتاب "'+(b?b.title:'')+'" وملفه وتقدمك فيه نهائياً. متأكد؟',async()=>{
        try{await dbDelete('books',bid);await dbDelete('files',bid);booksState.list=booksState.list.filter(x=>x.id!==bid);try{renderBooksList()}catch(e){}
          await repo.removeResource(id);toast('اتحذف الكتاب')}catch(err){console.error('wird-unified delete book',err);toast('تعذّر حذف الكتاب')}});
    }}:null
  ].filter(Boolean);
}
window.__wirdMenu=itemMenu;

/* قائمة «إضافة» داخل سياق الدرس (⋯ على صف الدرس) — أقصى حاجة: لمستين */
window.__wirdAddMenu=lid=>['book','course','video','text','link','notebook'].map(t=>({label:'＋ '+TY[t][1],icon:TY[t][0],run:()=>addIn(lid,t)})).concat([{sep:true,label:''}]);
async function addIn(lid,t){
  const a=ap();ctx={lessonId:lid,t:Date.now()};
  if(t==='notebook')return createNotebook(lid);
  await a.go({kind:'lesson',id:lid});
  setTimeout(()=>{const tab=$('wrt-'+t);tab&&tab.click();setTimeout(()=>{const b=document.querySelector('.wr [data-a="add"]');b&&b.click()},60)},120);
}
async function createNotebook(lid){
  const exists=[...(WR().cache.byLesson.get(lid)||[])].some(r=>r.type==='notebook');
  if(!exists){const L=lessonOf(lid);await ap().repo.putResourceRaw({id:uid(),lessonId:lid,subjectId:L.subjectId,type:'notebook',title:'نوت',order:99,status:'todo',completedAt:null,createdAt:Date.now(),updatedAt:Date.now(),rev:1,deletedAt:null,deleteBatch:null,notebook:{key:'L'+lid}})}
  try{window.__nbNew&&window.__nbNew(lid)}catch(e){}await ap().go({kind:'lesson',id:lid});
}

/* نماذج الإنشاء داخل لوحة الدرس (بتتنادى من openForm في وحدة المصادر) */
window.__wirdCreate=(kind,lid,f,res)=>{
  if(kind!=='course'&&kind!=='text')return false;
  const repo=ap().repo,L=lessonOf(lid);ctx={lessonId:lid,t:Date.now()};
  if(res){f.innerHTML=`<form class="wr-form" novalidate><h4>تعديل</h4><label class="wr-f"><span>الاسم</span><input class="ls-input" id="wuNm2" value="${esc(nameOf(res))}" maxlength="300"></label><div class="wr-act"><button type="submit" class="ls-btn ls-btn-primary">حفظ</button><button type="button" class="ls-btn" data-a="cancel">إلغاء</button></div></form>`;
    f.querySelector('form').onsubmit=async e=>{e.preventDefault();const v=f.querySelector('#wuNm2').value.trim();if(v)await repo.putResourceRaw({...res,title:v,rev:res.rev+1,updatedAt:Date.now()})};return true}
  if(kind==='course'){
    const have=new Set((WR().cache.byLesson.get(lid)||[]).filter(r=>r.type==='course').map(r=>r.course.courseId)),cs=(WC().C.courses||[]).filter(c=>!have.has(c.id));
    f.innerHTML=`<div class="wr-form"><h4>إضافة كورس</h4><div class="wr-act"><button type="button" class="ls-btn ls-btn-primary" data-wu="newcourse">＋ كورس جديد</button></div>${cs.length?`<label class="wr-f"><span>أو اربط كورس موجود</span><select class="ls-input" id="wuCs">${cs.map(c=>`<option value="${esc(c.id)}">${esc(c.title)}</option>`).join('')}</select></label><div class="wr-act"><button type="button" class="ls-btn" data-wu="linkcourse">ربط</button></div>`:''}<div class="wr-act"><button type="button" class="ls-btn" data-a="cancel">إلغاء</button></div></div>`;
    return true}
  f.innerHTML=`<form class="wr-form" novalidate><h4>إضافة نص مذاكرة</h4><label class="wr-f"><span>العنوان</span><input class="ls-input" id="wuTs" value="${esc(L?L.title:'')}" maxlength="200"></label><label class="wr-f"><span>النص (الأجزاء اللي بين [أقواس] بتتحمي)</span><textarea class="ls-input" id="wuTx" rows="6" dir="auto"></textarea></label><div id="wrfMsg" class="wr-msg" role="alert"></div><div class="wr-act"><button type="submit" class="ls-btn ls-btn-primary">إضافة</button><button type="button" class="ls-btn" data-a="cancel">إلغاء</button></div></form>`;
  f.querySelector('form').onsubmit=async e=>{e.preventDefault();const s=f.querySelector('#wuTs').value.trim()||'نص',x=f.querySelector('#wuTx').value.trim(),m=f.querySelector('#wrfMsg');
    if(!x){m.textContent='اكتب النص الأول.';return}
    const sid=stCreate(s,x,'auto');if(!sid){m.textContent='النص ما اتقسّمش لمقاطع — جرّب نص أطول.';return}
    await reconcile(ctx)};
  return true;
};

/* ---------------------------- ربط الأحداث (مرة واحدة) ---------------------------- */
let dt=0;
window.__wirdDirty=()=>{clearTimeout(dt);dt=setTimeout(()=>reconcile(ctx&&Date.now()-ctx.t<6e5?ctx:null),400)};
if(!window.__wirdBound){window.__wirdBound=1;
  document.addEventListener('click',e=>{
    const b=e.target.closest&&e.target.closest('[data-wu]');
    if(b){const k=b.dataset.wu,id=b.dataset.id,lid=(b.closest('.wr')||{dataset:{}}).dataset.lesson;
      if(k==='open'){const r=itemOf(id);r&&openType(r)}
      else if(k==='upload'){ctx={lessonId:lid,t:Date.now()};const x=$('addBookBtn');x&&x.click()}
      else if(k==='newcourse'){ctx={lessonId:lid,t:Date.now()};openHost(null,true)}
      else if(k==='linkcourse'){const v=document.querySelector('#wuCs');const L=lessonOf(lid);if(v&&L)ap().repo.putResourceRaw({id:uid(),lessonId:lid,subjectId:L.subjectId,type:'course',title:'',order:99,status:'todo',completedAt:null,createdAt:Date.now(),updatedAt:Date.now(),rev:1,deletedAt:null,deleteBatch:null,course:{courseId:v.value}})}
      else if(k==='curricula'){const x=$('cuOpenBtn');x&&x.click()}
      else if(k==='report'){report()}
      else if(k==='remigrate'){remigrate().then(()=>toast('اتربطت البيانات القديمة بالشجرة'))}
      else if(k==='menu'){const r=b.getBoundingClientRect();menu(r.left,r.bottom+4,itemMenu(id||(b.closest('.wr-card')||{dataset:{}}).dataset.id))}
      else if(k==='hmenu'&&hostCtx){const r=b.getBoundingClientRect();menu(r.left,r.bottom+4,itemMenu(hostCtx.id))}
      return;
    }
  });
  /* نفس الرأس + ⋯ على كل كارت عنصر (فيديو/كتاب/رابط/كورس/نص) */
  const dress=root=>root.querySelectorAll&&root.querySelectorAll('.wr-card').forEach(c=>{const top=c.querySelector('.wr-card-top');if(top&&!top.querySelector('.wu-more')){const b=document.createElement('button');b.type='button';b.className='wu-more';b.dataset.wu='menu';b.dataset.id=c.dataset.id;b.setAttribute('aria-label','المزيد');b.textContent='⋯';top.append(b)}});
  /* مدخل دائم لتقرير الترحيل / الرجوع (على شاشة «منهجي» الرئيسية) — مش بس نافذة لمرة واحدة */
  new MutationObserver(ms=>{for(const m of ms)m.addedNodes.forEach(n=>{if(n.nodeType!==1)return;dress(n.matches&&n.matches('.wr-card')?n.parentNode:n);dressHome(n)})}).observe(document.body,{childList:true,subtree:true});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&host&&!host.hidden&&!document.querySelector('.wu-ov,.wu-menu,.modal-overlay.open'))closeHost()});
  /* أحداث العرض (المشغّل بيوقّف الفيديو لما نسيب كورسات) + فتح مساحة العمل مباشرة من تبويب «منهجي» */
  document.querySelectorAll('.tab').forEach(t=>t.addEventListener('click',()=>{
    document.dispatchEvent(new CustomEvent('wird:view',{detail:{view:t.dataset.view}}));
    if(t.dataset.view==='view-lessons'){boot();setTimeout(openWs,60);setTimeout(flush,1000)}
  }));
}
function openWs(){
  const a=ap();if(!a||a.isOpen)return;const b=document.querySelector('#lessonsRoot .ls-landing-open');if(!b)return;b.click();
  setTimeout(()=>{const sc=a.sidebar&&a.sidebar.scroller;if(!sc||sc.__wu)return;sc.__wu=1;sc.scrollTop=lsGet(SCK,0);let t=0;sc.addEventListener('scroll',()=>{clearTimeout(t);t=setTimeout(()=>lsSet(SCK,sc.scrollTop),250)},{passive:true});
    const l=lsGet(LASTK,null);if(l&&l.resId&&itemOf(l.resId)&&a.route&&(a.route.kind==='home'?(a.settings&&a.settings.lastLessonId===l.lessonId):(a.route.kind==='lesson'&&a.route.id===l.lessonId)))openItem(l.resId)},700);
}
/* نقطة تشغيل واحدة بعد ما تطبيق الدروس يجهز */
let booted=false;
function boot(){if(booted)return;booted=true;(async()=>{try{const a=ap();if(!a)return;await a.init();await reconcile()}catch(e){console.error('wird-unified boot',e)}})()}
if($('view-lessons')&&$('view-lessons').classList.contains('active'))boot();
window.WirdUnified={__host:()=>openHost(null,false),reconcile,report,rollback,remigrate,downloadBackup,state:st,counts:async()=>countsOf(await sources())};
})();
