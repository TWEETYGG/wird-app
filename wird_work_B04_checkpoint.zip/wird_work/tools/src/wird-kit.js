/* ==========================================================================================================
   WirdKit — shared helper kit for the task-atomization and focus-quiz modules (batch B2 / TASK 0.3).
   This file is prepended to BOTH generated blocks (wird-tasks and wird-quiz). Only one instance is ever
   created (window.WirdKit is guarded by its version field), so the second copy is a no-op.

   Contract: everything here is LAZY. Nothing runs, listens, stores, plays a sound, loads a library or opens
   a database at load time. The functions below are called by later batches, on demand.
   Safety contract: new code may write only the namespaces below (verifier rule A8) and may open only the
   IndexedDB named wird_quiz_db. The kit enforces both (defence in depth), it does not rely on callers.
   ========================================================================================================== */
(function () {
  'use strict';
  var KIT_VERSION = 1;
  var root = typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : {});
  if (root.WirdKit && root.WirdKit.version >= KIT_VERSION) return;

  var WRITABLE_KEY = /^wird_(?:tasks|taskprefs|quiz)/;   // the only localStorage namespaces new code may write
  var QUIZ_DB = 'wird_quiz_db';                           // the only IndexedDB new code may open

  function errInfo(e) {
    var o = e || {};
    return {
      name: String(o.name || 'Error'),
      message: String(o.message || e || ''),
      quota: o.name === 'QuotaExceededError' || o.name === 'NS_ERROR_DOM_QUOTA_REACHED' || o.code === 22 || o.code === 1014
    };
  }

  /* ---------------------------------------------------------------------------------------------- storage */
  function lsHandle() {                       // merely touching localStorage can throw (blocked storage, sandboxed frame)
    try { return root.localStorage || null; } catch (e) { return null; }
  }
  var ls = {
    lastError: null,
    available: function () { return !!lsHandle(); },
    isQuotaError: function (e) { return errInfo(e).quota; },
    isWritableKey: function (key) { return typeof key === 'string' && WRITABLE_KEY.test(key); },
    /* never throws: string or null */
    get: function (key) {
      try { var s = lsHandle(); return s ? s.getItem(key) : null; }
      catch (e) { ls.lastError = errInfo(e); return null; }
    },
    getJson: function (key, fallback) {
      var raw = ls.get(key);
      if (raw === null || raw === undefined) return fallback;
      try { return JSON.parse(raw); } catch (e) { ls.lastError = errInfo(e); return fallback; }
    },
    /* never throws: {ok:true} or {ok:false, error:{name,message,quota}} */
    set: function (key, value) {
      if (!ls.isWritableKey(key)) { var bad = { name: 'KeyNotAllowed', message: 'wird kit may only write wird_tasks*, wird_taskprefs*, wird_quiz*', quota: false }; ls.lastError = bad; return { ok: false, error: bad }; }
      try {
        var s = lsHandle(); if (!s) throw new Error('localStorage unavailable');
        s.setItem(key, String(value)); return { ok: true };
      } catch (e) { var info = errInfo(e); ls.lastError = info; return { ok: false, error: info }; }
    },
    setJson: function (key, value) {
      var text;
      try { text = JSON.stringify(value); } catch (e) { var info = errInfo(e); ls.lastError = info; return { ok: false, error: info }; }
      return ls.set(key, text);
    },
    /* Raw adapter {getItem, setItem} for engines that do their own error handling: unlike the helpers above
       it lets storage exceptions propagate (the engine catches them and enters its degraded state). */
    adapter: function () {
      return {
        getItem: function (key) { var s = lsHandle(); if (!s) throw new Error('localStorage unavailable'); return s.getItem(key); },
        setItem: function (key, value) {
          if (!ls.isWritableKey(key)) { var e = new Error('key not allowed: ' + key); e.name = 'KeyNotAllowed'; throw e; }
          var s = lsHandle(); if (!s) throw new Error('localStorage unavailable'); s.setItem(key, String(value));
        }
      };
    }
  };

  /* --------------------------------------------------------------------------------------------------- uid */
  var uidCounter = 0;
  function uid(prefix) {
    var p = String(prefix === undefined || prefix === null ? 'id' : prefix).replace(/[^A-Za-z0-9]/g, '') || 'id';
    uidCounter = (uidCounter + 1) % 1679616;                       // 36^4, keeps ids unique even inside one millisecond
    var rnd = '';
    try { if (root.crypto && root.crypto.getRandomValues) { var a = new Uint32Array(1); root.crypto.getRandomValues(a); rnd = a[0].toString(36); } } catch (e) { rnd = ''; }
    if (!rnd) rnd = Math.random().toString(36).slice(2);
    return p + '_' + Date.now().toString(36) + '_' + uidCounter.toString(36) + rnd.slice(0, 6);
  }

  /* ------------------------------------------------------------------------------------------------- audio */
  /* Own AudioContext (NOT pmAudio/pmChime: those are Pomodoro-coupled). Created lazily on the first call that
     needs it; browsers only let it run after a user gesture, so call unlockOnFirstTap() from a later batch. */
  var audio = {
    ctx: null,
    context: function () {
      if (audio.ctx) return audio.ctx;
      var C = root.AudioContext || root.webkitAudioContext;
      if (!C) return null;
      try { audio.ctx = new C(); } catch (e) { audio.ctx = null; }
      return audio.ctx;
    },
    unlock: function () {
      var c = audio.context();
      if (!c) return false;
      try { if (c.state === 'suspended' && c.resume) { var p = c.resume(); if (p && p.catch) p.catch(function () {}); } } catch (e) { /* ignore */ }
      return true;
    },
    /* Opt-in: registers one-shot listeners that unlock audio on the first tap. Returns a cancel function.
       NOT called at load; a later batch calls it when the user enables sound. */
    unlockOnFirstTap: function () {
      var doc = root.document; if (!doc || !doc.addEventListener) return function () {};
      var names = ['pointerdown', 'touchend', 'keydown'], done = false;
      function off() { if (done) return; done = true; names.forEach(function (n) { doc.removeEventListener(n, on, true); }); }
      function on() { audio.unlock(); off(); }
      names.forEach(function (n) { doc.addEventListener(n, on, true); });
      return off;
    },
    /* A short soft tone. Returns true when a tone was scheduled. Never throws. */
    blip: function (opts) {
      try {
        var o = opts || {}, c = audio.context(); if (!c) return false;
        audio.unlock();
        var freq = o.freq > 0 ? o.freq : 880, ms = o.ms > 0 ? o.ms : 90, vol = o.gain >= 0 ? Math.min(o.gain, 0.3) : 0.05;
        var t0 = c.currentTime, osc = c.createOscillator(), g = c.createGain();
        osc.type = o.type || 'sine'; osc.frequency.value = freq;
        g.gain.setValueAtTime(0.0001, t0);
        g.gain.exponentialRampToValueAtTime(Math.max(vol, 0.0002), t0 + 0.01);
        g.gain.exponentialRampToValueAtTime(0.0001, t0 + ms / 1000);
        osc.connect(g); g.connect(c.destination);
        osc.start(t0); osc.stop(t0 + ms / 1000 + 0.02);
        return true;
      } catch (e) { return false; }
    }
  };

  /* ---------------------------------------------------------------------------------------------- vibrate */
  function vibrate(pattern) {
    try {
      var n = root.navigator;
      if (n && typeof n.vibrate === 'function') return !!n.vibrate(pattern === undefined || pattern === null ? 15 : pattern);
    } catch (e) { /* ignore */ }
    return false;
  }

  /* ------------------------------------------------------------------------------------------------ IndexedDB */
  /* Generic opener, memoised per (name, version), NEVER called at load. The quiz stores are defined by the
     upgrade function a later batch passes in (B6). It refuses any database except wird_quiz_db. Because the
     database is created by its first open, callers must not open it before the first quiz feature is used;
     quizDbExists() answers "has it been created yet?" without creating it. */
  var dbMemo = Object.create(null);
  function openDb(name, version, upgrade) {
    if (name !== QUIZ_DB) { var e = new Error('openDb: only ' + QUIZ_DB + ' may be opened by new code'); e.name = 'DbNameNotAllowed'; return Promise.reject(e); }
    var v = version > 0 ? Math.floor(version) : 1, k = name + '@' + v;
    if (dbMemo[k]) return dbMemo[k];
    var p = new Promise(function (resolve, reject) {
      if (!root.indexedDB) { reject(new Error('IndexedDB unavailable')); return; }
      var req;
      try { req = root.indexedDB.open('wird_quiz_db', v); } catch (err) { reject(err); return; }
      req.onupgradeneeded = function (ev) {
        try { if (typeof upgrade === 'function') upgrade(req.result, ev, req.transaction); }
        catch (err) { try { req.transaction.abort(); } catch (err2) { /* ignore */ } }
      };
      req.onsuccess = function () {
        var db = req.result;
        db.onversionchange = function () { try { db.close(); } catch (err) { /* ignore */ } delete dbMemo[k]; };
        resolve(db);
      };
      req.onerror = function () { reject(req.error || new Error('IndexedDB open failed')); };
      req.onblocked = function () { /* an older connection in another tab holds the database; the request stays pending */ };
    });
    dbMemo[k] = p;
    p.then(null, function () { if (dbMemo[k] === p) delete dbMemo[k]; });
    return p;
  }
  function openQuizDb(upgrade, version) { return openDb(QUIZ_DB, version || 1, upgrade); }
  /* true / false, or null when the browser cannot list databases. Never creates the database. */
  function quizDbExists() {
    try {
      if (!root.indexedDB || typeof root.indexedDB.databases !== 'function') return Promise.resolve(null);
      return root.indexedDB.databases().then(function (list) {
        return (list || []).some(function (d) { return d && d.name === QUIZ_DB; });
      }, function () { return null; });
    } catch (e) { return Promise.resolve(null); }
  }

  /* ------------------------------------------------------------------------------------------------- KaTeX */
  /* Mirrors the loader of the lessons bundle (ls-main): the same three embedded assets, the same style id and
     the same evaluation method (a temporary script element), so that both loaders share state and KaTeX is never
     evaluated twice by this loader: (1) it returns at once when katex is already defined, (2) all concurrent
     callers share one promise, (3) evaluation is deferred by one timer tick and re-checked inside the callback,
     so a lesson-bundle load that was requested first always wins. The only unavoidable race is the reverse
     order (this call first, the bundle's own call within the same tick): the bundle re-evaluates once, the
     result stays consistent; it cannot be prevented without patching frozen code. */
  var KATEX_MACROS = {
    '\\vect': '\\vec{\\mathbf{#1}}', '\\unit': '\\,\\mathrm{#1}', '\\abs': '\\left|#1\\right|', '\\norm': '\\left\\|#1\\right\\|',
    '\\dd': '\\mathrm{d}', '\\deriv': '\\frac{\\mathrm{d}#1}{\\mathrm{d}#2}', '\\pderiv': '\\frac{\\partial #1}{\\partial #2}',
    '\\R': '\\mathbb{R}', '\\N': '\\mathbb{N}', '\\Z': '\\mathbb{Z}', '\\Q': '\\mathbb{Q}'
  };
  function katexOptions(displayMode) {              // a fresh object each call: KaTeX may mutate the macros it is given
    var m = {}; for (var k in KATEX_MACROS) m[k] = KATEX_MACROS[k];
    return { displayMode: !!displayMode, throwOnError: true, strict: 'ignore', trust: false, output: 'htmlAndMathml', maxExpand: 1000, macros: m };
  }
  function katexDefined() { return typeof root.katex !== 'undefined'; }
  function mhchemLoaded() {
    try { root.katex.renderToString('\\ce{H}', { throwOnError: true }); return true; } catch (e) { return false; }
  }
  function evalAsset(id) {                          // same method as ls-main: run the text/plain asset through a temporary script
    var doc = root.document, src = doc && doc.getElementById(id);
    if (!src) return false;
    var s = doc.createElement('script');
    s.textContent = src.textContent || '';
    doc.head.appendChild(s); s.parentNode && s.parentNode.removeChild(s);
    return true;
  }
  function ensureKatexStyle() {
    var doc = root.document; if (!doc || doc.getElementById('ls-katex-style')) return;
    var css = doc.getElementById('ls-asset-katex-css'); if (!css) return;
    var st = doc.createElement('style'); st.id = 'ls-katex-style'; st.textContent = css.textContent || '';
    doc.head.appendChild(st);
  }
  var katexPromise = null;
  /* Resolves with window.katex (mhchem registered) or null when the assets are missing. Never rejects. */
  function ensureKatex() {
    if (katexDefined()) { try { ensureKatexStyle(); } catch (e) { /* ignore */ } return Promise.resolve(root.katex); }
    if (katexPromise) return katexPromise;
    var p = new Promise(function (resolve) {
      root.setTimeout(function () {
        try {
          ensureKatexStyle();
          if (!katexDefined()) evalAsset('ls-asset-katex');                  // re-check: the lesson bundle may have loaded it meanwhile
          if (katexDefined() && !mhchemLoaded()) evalAsset('ls-asset-mhchem');
          resolve(katexDefined() ? root.katex : null);
        } catch (e) { resolve(null); }
      }, 0);
    });
    katexPromise = p;
    p.then(function (k) { if (!k && katexPromise === p) katexPromise = null; });   // a failed attempt may be retried
    return p;
  }

  /* ------------------------------------------------------------------------------------------- DOM builder */
  var FORBIDDEN_TAGS = /^(?:script|style|iframe|frame|frameset|object|embed|base|meta|link|template)$/i;
  var URL_ATTRS = /^(?:href|src|action|formaction|poster|xlink:href)$/i;
  function isNode(x) { return !!x && typeof x === 'object' && typeof x.nodeType === 'number' && typeof x.nodeName === 'string'; }
  function safeUrl(v) {
    var s = String(v).replace(/[\u0000-\u0020\u007F-\u009F\u200B-\u200F\u2028\u2029\uFEFF]/g, '').toLowerCase();
    return !/^(?:javascript|vbscript|livescript):/.test(s) && !/^data:(?!image\/(?:png|jpe?g|gif|webp|bmp|avif);)/.test(s);
  }
  function appendChildren(el, kids) {
    if (kids === null || kids === undefined || kids === false || kids === true) return;
    if (Array.isArray(kids)) { for (var i = 0; i < kids.length; i++) appendChildren(el, kids[i]); return; }
    if (isNode(kids)) { el.appendChild(kids); return; }
    el.appendChild(el.ownerDocument.createTextNode(String(kids)));        // strings and numbers are always text, never markup
  }
  function applyAttrs(el, attrs) {
    Object.keys(attrs).forEach(function (k) {
      var v = attrs[k];
      if (v === null || v === undefined || v === false) return;
      var lk = k.toLowerCase();
      if (lk === 'innerhtml' || lk === 'outerhtml' || lk === 'html' || lk === 'srcdoc' || lk === 'insertadjacenthtml') return;   // never markup
      if (lk === 'class' || lk === 'classname') { el.className = String(v); return; }
      if (lk === 'text' || lk === 'textcontent') { el.textContent = String(v); return; }
      if (lk === 'style') {
        if (typeof v === 'string') el.setAttribute('style', v);
        else if (typeof v === 'object') Object.keys(v).forEach(function (p) { if (p.indexOf('-') >= 0) el.style.setProperty(p, String(v[p])); else el.style[p] = String(v[p]); });
        return;
      }
      if (lk === 'dataset') { if (typeof v === 'object') Object.keys(v).forEach(function (p) { el.dataset[p] = String(v[p]); }); return; }
      if (lk.slice(0, 2) === 'on') { if (typeof v === 'function') el.addEventListener(lk.slice(2), v); return; }   // handlers must be functions, never strings
      if (URL_ATTRS.test(k) && !safeUrl(v)) return;
      el.setAttribute(k, v === true ? '' : String(v));
    });
  }
  /* h(tag, attrs?, children?) — builds elements with createElement/textContent only. h('p','text') and h('div',[...]) work too. */
  function h(tag, attrs, children) {
    var doc = root.document;
    var name = String(tag === undefined || tag === null || tag === '' ? 'div' : tag);
    if (!/^[A-Za-z][A-Za-z0-9-]*$/.test(name) || FORBIDDEN_TAGS.test(name)) throw new TypeError('WirdKit.h: tag not allowed: ' + name);
    var el = doc.createElement(name);
    if (attrs !== null && typeof attrs === 'object' && !Array.isArray(attrs) && !isNode(attrs)) applyAttrs(el, attrs);
    else if (attrs !== undefined && children === undefined) children = attrs;
    appendChildren(el, children);
    return el;
  }
  function emptyNode(el) { while (el && el.firstChild) el.removeChild(el.firstChild); return el; }

  root.WirdKit = {
    version: KIT_VERSION,
    ls: ls,
    uid: uid,
    audio: audio,
    vibrate: vibrate,
    openDb: openDb,
    openQuizDb: openQuizDb,
    quizDbExists: quizDbExists,
    katex: { ensure: ensureKatex, options: katexOptions, macros: function () { return katexOptions(false).macros; } },
    ensureKatex: ensureKatex,
    h: h,
    dom: { h: h, empty: emptyNode }
  };
})();
