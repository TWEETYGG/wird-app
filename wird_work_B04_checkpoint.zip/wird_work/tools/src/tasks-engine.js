/* ==========================================================================================================
   tasks-engine.js — task engine & persistence (B2 / TASK 1.1). PURE LOGIC: no DOM, no timers, no listeners.
   Dual environment: Node `require()` (unit tests) and, in the browser, attached to WirdTasks.engine.
   Nothing here runs at load. The browser block creates no engine and touches no storage until a later
   batch calls WirdTasks.getEngine().

   Model:  DAY -> TASK -> STEP   (ids are stable; edits and deletes keep history)
   Task status:  not_started | in_progress | paused | completed | skipped | partial
   Step state:   not_started | in_progress | completed | skipped
   The CURRENT step of a task is derived: the first unresolved live step in plan order. Resolutions are
   append-only events with unique keys; the active resolution of every step is derived from those events.
   Full description: docs/TASKS-ENGINE.md
   ========================================================================================================== */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module && module.exports) module.exports = api;
  if (root && typeof root.WirdTasks === 'object' && root.WirdTasks) { root.WirdTasks.engine = api; root.WirdTasks.getEngine = api.getEngine; }   // lazy singleton; nothing is created here
})(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this), function () {
  'use strict';

  var GLOBAL = typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : {});

  /* ------------------------------------------------------------------------------------------ constants */
  var SCHEMA_VERSION = 1;
  var STORAGE_KEY = 'wird_tasks_v1';
  var PREFS_KEY = 'wird_taskprefs_v1';
  var UNDO_WINDOW_MS = 8000;                       // interpretation I3: the brief only says "brief"; adjustable via deps.undoWindowMs
  var LIMITS = { title: 120, step: 300, stepsPerTask: 100, tasksPerDay: 100 };
  var LINK_RE = /^o_[A-Za-z0-9]{1,64}$/;           // quick-task ids look like o_<digits/base36>
  var EVENT_TYPES = ['start', 'complete', 'skip', 'undo', 'back', 'pause', 'resume',
                     'step_edit', 'step_delete', 'task_edit', 'task_delete', 'task_move', 'link_set'];
  var EVENT_FIELDS = ['key', 'seq', 'at', 'type', 'taskId', 'stepId', 'dayKey', 'voids', 'of', 'n',
                      'stepText', 'taskTitle', 'from', 'to', 'state', 'linkCleared', 'oneoffId', 'elapsedMs'];

  /* Preferences. Minimal defaults (brief: "Defaults are Minimal"). Every key is validated against this table.
     ASSUMED DEFAULT: endOfDayPrompt is on (non-intrusive, disableable, never forces navigation); every other
     optional feature (skip, edit during execution, timer, progress, sound, haptic, micro-interactions) is off. */
  var PREF_SPEC = {
    displayMode:         { type: 'enum', values: ['one'], def: 'one' },
    autoTransition:      { type: 'bool', def: true },
    backNavigation:      { type: 'bool', def: true },
    skipStep:            { type: 'bool', def: false },
    editDuringExecution: { type: 'bool', def: false },
    timer:               { type: 'bool', def: false },
    progress:            { type: 'enum', values: ['hidden', 'subtle', 'detailed'], def: 'hidden' },
    completionAnimation: { type: 'enum', values: ['off', 'subtle'], def: 'subtle' },
    sound:               { type: 'bool', def: false },
    haptic:              { type: 'bool', def: false },
    microInteractions:   { type: 'bool', def: false },
    endOfDayPrompt:      { type: 'bool', def: true }
  };

  /* ------------------------------------------------------------------------------------------- utilities */
  function isObj(x) { return x !== null && typeof x === 'object' && !Array.isArray(x); }
  function isStr(x) { return typeof x === 'string' && x.length > 0; }
  function isInt(n) { return typeof n === 'number' && isFinite(n) && Math.floor(n) === n; }
  function isTime(n) { return typeof n === 'number' && isFinite(n) && n >= 0; }
  function has(o, k) { return Object.prototype.hasOwnProperty.call(o, k); }
  function clone(x) { return x === undefined ? undefined : JSON.parse(JSON.stringify(x)); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function uniq(list) { var seen = Object.create(null), out = []; list.forEach(function (x) { if (!seen[x]) { seen[x] = 1; out.push(x); } }); return out; }

  function isDayKey(s) {
    if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
    var y = +s.slice(0, 4), m = +s.slice(5, 7), d = +s.slice(8, 10), t = new Date(Date.UTC(y, m - 1, d));
    return t.getUTCFullYear() === y && t.getUTCMonth() === m - 1 && t.getUTCDate() === d;
  }
  function addDays(key, n) {                         // pure calendar arithmetic on a day key; null for bad input
    if (!isDayKey(key) || !isInt(n)) return null;
    var t = new Date(Date.UTC(+key.slice(0, 4), +key.slice(5, 7) - 1, +key.slice(8, 10) + n));
    return t.getUTCFullYear() + '-' + pad(t.getUTCMonth() + 1) + '-' + pad(t.getUTCDate());
  }
  function dayKeyOf(ms) {                            // local calendar day, same convention as the app's todayISO()
    var d = new Date(ms);
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }
  /* trims, turns every whitespace run (incl. newlines) into one space, drops control characters */
  function cleanText(s, max) {
    if (typeof s !== 'string') return { err: 'invalid_argument' };
    var t = s.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '').replace(/\s+/g, ' ').trim();
    if (!t) return { err: 'empty_text' };
    if (t.length > max) return { err: 'too_long', max: max };
    return { text: t };
  }
  function errInfo(e) {
    var o = e || {};
    return { name: String(o.name || 'Error'), message: String(o.message || e || ''), quota: o.name === 'QuotaExceededError' || o.name === 'NS_ERROR_DOM_QUOTA_REACHED' || o.code === 22 || o.code === 1014 };
  }
  function makeMemoryStorage(initial) {
    var m = Object.create(null);
    if (isObj(initial)) Object.keys(initial).forEach(function (k) { m[k] = String(initial[k]); });
    return {
      getItem: function (k) { return k in m ? m[k] : null; },
      setItem: function (k, v) { m[k] = String(v); },
      dump: function () { var o = {}; Object.keys(m).forEach(function (k) { o[k] = m[k]; }); return o; }
    };
  }
  function makeIdGen() {
    var n = 0;
    return function (prefix) {
      n = (n + 1) % 1679616;
      return String(prefix || 'id') + '_' + Date.now().toString(36) + '_' + n.toString(36) + Math.random().toString(36).slice(2, 7);
    };
  }

  /* ------------------------------------------------------------------------------------------ preferences */
  function defaultPrefs() { var o = {}; Object.keys(PREF_SPEC).forEach(function (k) { o[k] = PREF_SPEC[k].def; }); return o; }
  function prefValueOk(spec, v) { return spec.type === 'bool' ? typeof v === 'boolean' : spec.values.indexOf(v) >= 0; }
  /* full, valid preference object: anything missing, unknown or invalid falls back to the default */
  function sanitizePrefs(raw) {
    var o = defaultPrefs();
    if (isObj(raw)) Object.keys(PREF_SPEC).forEach(function (k) { if (has(raw, k) && prefValueOk(PREF_SPEC[k], raw[k])) o[k] = raw[k]; });
    return o;
  }
  /* splits a patch into valid assignments and rejected keys */
  function splitPrefsPatch(patch) {
    var applied = {}, rejected = [];
    if (!isObj(patch)) return { applied: applied, rejected: ['*'] };
    Object.keys(patch).forEach(function (k) {
      if (has(PREF_SPEC, k) && prefValueOk(PREF_SPEC[k], patch[k])) applied[k] = patch[k]; else rejected.push(k);
    });
    return { applied: applied, rejected: rejected };
  }

  /* --------------------------------------------------------------------------------------- state / sanitize */
  function emptyState() { return { schemaVersion: SCHEMA_VERSION, savedAt: 0, seq: 0, days: {}, tasks: {}, steps: {}, exec: {}, events: [] }; }
  function newExec() { return { started: false, paused: false, startedAt: null, pausedAt: null, prefs: null, linkDoneAt: null }; }

  /* Turns an untrusted parsed object into a clean, internally consistent state. Never throws.
     Returns { state, repairs } where repairs counts every dropped / fixed element. */
  function sanitizeState(raw) {
    var rep = 0, s = emptyState();
    function section(v) { if (v === undefined) return {}; if (isObj(v)) return v; rep++; return {}; }
    if (!isObj(raw)) return { state: s, repairs: 1 };
    s.seq = isInt(raw.seq) && raw.seq >= 0 ? raw.seq : 0;
    s.savedAt = isTime(raw.savedAt) ? raw.savedAt : 0;

    var rt = section(raw.tasks);
    Object.keys(rt).forEach(function (id) {
      var t = rt[id];
      if (!isObj(t) || t.id !== id || typeof t.title !== 'string' || !t.title.trim() || !isDayKey(t.dayKey)) { rep++; return; }
      var task = {
        id: id, dayKey: t.dayKey, title: t.title, linkedOneoffId: null, linkedDay: null,
        stepOrder: Array.isArray(t.stepOrder) ? t.stepOrder.filter(isStr) : [],
        createdAt: isTime(t.createdAt) ? t.createdAt : 0, updatedAt: isTime(t.updatedAt) ? t.updatedAt : 0,
        deletedAt: isTime(t.deletedAt) ? t.deletedAt : null
      };
      if (typeof t.linkedOneoffId === 'string' && LINK_RE.test(t.linkedOneoffId) && isDayKey(t.linkedDay)) { task.linkedOneoffId = t.linkedOneoffId; task.linkedDay = t.linkedDay; }
      else if (t.linkedOneoffId) rep++;
      s.tasks[id] = task;
    });

    var rs = section(raw.steps);
    Object.keys(rs).forEach(function (id) {
      var st = rs[id];
      if (!isObj(st) || st.id !== id || !isStr(st.taskId) || !s.tasks[st.taskId] || typeof st.text !== 'string' || !st.text.trim()) { rep++; return; }
      s.steps[id] = {
        id: id, taskId: st.taskId, text: st.text,
        createdAt: isTime(st.createdAt) ? st.createdAt : 0, updatedAt: isTime(st.updatedAt) ? st.updatedAt : 0,
        deletedAt: isTime(st.deletedAt) ? st.deletedAt : null, rev: isInt(st.rev) && st.rev >= 1 ? st.rev : 1
      };
    });

    /* per-task step order: only live steps of that task, no duplicates; live steps missing from the order are re-appended */
    Object.keys(s.tasks).forEach(function (tid) {
      var task = s.tasks[tid], seen = Object.create(null), order = [];
      task.stepOrder.forEach(function (sid) {
        var st = s.steps[sid];
        if (st && st.taskId === tid && !st.deletedAt && !seen[sid]) { seen[sid] = 1; order.push(sid); } else rep++;
      });
      var missing = Object.keys(s.steps).filter(function (sid) { var st = s.steps[sid]; return st.taskId === tid && !st.deletedAt && !seen[sid]; });
      if (missing.length) {
        rep += missing.length;
        missing.sort(function (a, b) { return (s.steps[a].createdAt - s.steps[b].createdAt) || (a < b ? -1 : 1); });
        order = order.concat(missing);
      }
      task.stepOrder = order;
    });

    /* day groups: live tasks only, each in the day it belongs to; missing live tasks are re-appended */
    var rd = section(raw.days);
    Object.keys(rd).forEach(function (key) {
      if (!isDayKey(key) || !isObj(rd[key])) { rep++; return; }
      var seen = Object.create(null), order = [];
      (Array.isArray(rd[key].taskOrder) ? rd[key].taskOrder : []).forEach(function (tid) {
        var t = s.tasks[tid];
        if (t && !t.deletedAt && t.dayKey === key && !seen[tid]) { seen[tid] = 1; order.push(tid); } else rep++;
      });
      s.days[key] = { key: key, taskOrder: order };
    });
    Object.keys(s.tasks).forEach(function (tid) {
      var t = s.tasks[tid]; if (t.deletedAt) return;
      var day = s.days[t.dayKey] || (s.days[t.dayKey] = { key: t.dayKey, taskOrder: [] });
      if (day.taskOrder.indexOf(tid) < 0) { day.taskOrder.push(tid); rep++; }
    });

    /* execution state */
    var rx = section(raw.exec);
    Object.keys(s.tasks).forEach(function (tid) {
      var x = isObj(rx[tid]) ? rx[tid] : null, e = newExec();
      if (x) {
        e.started = x.started === true; e.paused = x.paused === true;
        e.startedAt = isTime(x.startedAt) ? x.startedAt : null; e.pausedAt = isTime(x.pausedAt) ? x.pausedAt : null;
        e.prefs = isObj(x.prefs) ? sanitizePrefs(x.prefs) : null;
        e.linkDoneAt = isTime(x.linkDoneAt) ? x.linkDoneAt : null;
      } else if (rx[tid] !== undefined) rep++;
      s.exec[tid] = e;
    });

    /* append-only event log: unique keys, known types, whitelisted fields */
    var seenKeys = Object.create(null), maxSeq = s.seq;
    (Array.isArray(raw.events) ? raw.events : (raw.events === undefined ? [] : (rep++, []))).forEach(function (ev) {
      if (!isObj(ev) || !isStr(ev.key) || seenKeys[ev.key] || EVENT_TYPES.indexOf(ev.type) < 0 || !isTime(ev.at) || !isStr(ev.taskId) || !s.tasks[ev.taskId]) { rep++; return; }
      var o = {};
      EVENT_FIELDS.forEach(function (f) { if (has(ev, f)) { var v = ev[f]; if (v === null || typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean') o[f] = v; } });
      if (!isInt(o.seq)) o.seq = ++maxSeq; else if (o.seq > maxSeq) maxSeq = o.seq;
      seenKeys[ev.key] = 1; s.events.push(o);
    });
    s.seq = Math.max(s.seq, maxSeq);
    /* a started flag is implied by any resolution event */
    s.events.forEach(function (ev) { if ((ev.type === 'complete' || ev.type === 'skip' || ev.type === 'start') && s.exec[ev.taskId] && !s.exec[ev.taskId].started) { s.exec[ev.taskId].started = true; rep++; } });
    Object.keys(s.exec).forEach(function (tid) { if (!s.exec[tid].started && s.exec[tid].paused) { s.exec[tid].paused = false; rep++; } });
    return { state: s, repairs: rep };
  }

  /* ================================================================================================= engine */
  function createEngine(deps) {
    deps = deps || {};
    var storage = (deps.storage && typeof deps.storage.getItem === 'function' && typeof deps.storage.setItem === 'function') ? deps.storage : makeMemoryStorage();
    var clock = typeof deps.clock === 'function' ? deps.clock : function () { return Date.now(); };
    var idGen = typeof deps.idGen === 'function' ? deps.idGen : makeIdGen();
    var habits = (deps.habits && typeof deps.habits.markOneoffDone === 'function') ? deps.habits : { markOneoffDone: function () {} };   // B2: no-op, nothing is ever written to wird_habits_v1
    var undoWindowMs = isTime(deps.undoWindowMs) ? deps.undoWindowMs : UNDO_WINDOW_MS;

    var S, C, P;                                     // S persisted state, C derived cache (never saved), P preferences { values }
    var listeners = [];
    var corruptRaw = null;
    var pendingBackups = {};                         // storage key -> raw text that was loaded but could not be fully understood
    var meta = {
      loadedFrom: 'empty', degraded: false, readOnly: false, readOnlyReason: null, foundSchemaVersion: null,
      lastError: null, repairs: 0, recovered: null, prefsLoadedFrom: 'defaults', prefsReadOnly: false, backups: []
    };

    /* ----- errors, results ------------------------------------------------------------------------------ */
    function setError(code, e) { var i = errInfo(e); meta.lastError = { code: code, name: i.name, message: i.message, quota: i.quota, at: clock() }; }
    function ok(extra) { var r = { ok: true }; if (extra) Object.keys(extra).forEach(function (k) { r[k] = extra[k]; }); return r; }
    function fail(reason, extra) { var r = { ok: false, reason: reason }; if (extra) Object.keys(extra).forEach(function (k) { r[k] = extra[k]; }); return r; }
    function guarded(fn) {
      return function () {
        try { return fn.apply(null, arguments); }
        catch (e) { setError('internal_error', e); return fail('internal_error', { message: String(e && e.message || e) }); }
      };
    }
    function mutating(fn) {
      return guarded(function () {
        if (meta.readOnly) return fail('read_only', { readOnlyReason: meta.readOnlyReason });
        return fn.apply(null, arguments);
      });
    }
    function emit(ev) { listeners.slice().forEach(function (fn) { try { fn(ev); } catch (e) { /* a listener must never break the engine */ } }); }
    function todayKey() { return dayKeyOf(clock()); }

    /* ----- load / save ---------------------------------------------------------------------------------- */
    function loadState() {
      corruptRaw = null; delete pendingBackups[STORAGE_KEY]; meta.readOnly = false; meta.readOnlyReason = null; meta.foundSchemaVersion = null; meta.repairs = 0; meta.recovered = null; meta.degraded = false;
      var raw;
      try { raw = storage.getItem(STORAGE_KEY); }
      catch (e) { setError('storage_unavailable', e); meta.loadedFrom = 'unavailable'; meta.degraded = true; S = emptyState(); return; }
      if (raw === null || raw === undefined || raw === '') { meta.loadedFrom = 'empty'; S = emptyState(); return; }
      function recover(code, detail) {
        corruptRaw = typeof raw === 'string' ? raw : String(raw);
        pendingBackups[STORAGE_KEY] = corruptRaw;
        meta.loadedFrom = 'recovered'; meta.recovered = { code: code, rawLength: corruptRaw.length };
        setError(code, detail || { name: 'CorruptStorage', message: code }); S = emptyState();
      }
      var parsed;
      try { parsed = JSON.parse(raw); } catch (e) { recover('corrupt_json', e); return; }
      if (!isObj(parsed) || !isInt(parsed.schemaVersion) || parsed.schemaVersion < 1) { recover('invalid_schema', { name: 'CorruptStorage', message: 'missing or invalid schemaVersion' }); return; }
      if (parsed.schemaVersion > SCHEMA_VERSION) {                       // written by a NEWER app: open read-only, never overwrite
        meta.loadedFrom = 'newer_schema'; meta.readOnly = true; meta.readOnlyReason = 'newer_schema'; meta.foundSchemaVersion = parsed.schemaVersion;
        setError('newer_schema', { name: 'NewerSchema', message: 'stored schemaVersion ' + parsed.schemaVersion + ' > ' + SCHEMA_VERSION }); S = emptyState(); return;
      }
      var r = sanitizeState(parsed);
      S = r.state; meta.repairs = r.repairs; meta.loadedFrom = r.repairs ? 'repaired' : 'storage';
      if (r.repairs) pendingBackups[STORAGE_KEY] = typeof raw === 'string' ? raw : String(raw);
      if (r.repairs) setError('repaired', { name: 'Repaired', message: r.repairs + ' element(s) dropped or fixed while loading' });
    }
    function loadPrefs() {
      meta.prefsReadOnly = false; meta.prefsLoadedFrom = 'defaults'; delete pendingBackups[PREFS_KEY];
      var raw;
      try { raw = storage.getItem(PREFS_KEY); } catch (e) { setError('prefs_unavailable', e); P = { values: defaultPrefs() }; return; }
      if (raw === null || raw === undefined || raw === '') { P = { values: defaultPrefs() }; return; }
      var parsed;
      try { parsed = JSON.parse(raw); } catch (e) { pendingBackups[PREFS_KEY] = String(raw); setError('prefs_corrupt', e); P = { values: defaultPrefs() }; meta.prefsLoadedFrom = 'recovered'; return; }
      if (!isObj(parsed) || !isInt(parsed.schemaVersion) || parsed.schemaVersion < 1) { pendingBackups[PREFS_KEY] = String(raw); setError('prefs_corrupt', { name: 'CorruptStorage', message: 'invalid prefs schema' }); P = { values: defaultPrefs() }; meta.prefsLoadedFrom = 'recovered'; return; }
      if (parsed.schemaVersion > SCHEMA_VERSION) { meta.prefsReadOnly = true; meta.prefsLoadedFrom = 'newer_schema'; setError('prefs_newer_schema', { name: 'NewerSchema', message: 'prefs schemaVersion ' + parsed.schemaVersion }); P = { values: defaultPrefs() }; return; }
      P = { values: sanitizePrefs(parsed.values) }; meta.prefsLoadedFrom = 'storage';
    }
    /* Data that could not be fully understood (unparseable, wrong schema, elements dropped while repairing) is never
       overwritten before a byte-exact copy of it is stored under a sibling key (wird_tasks_v1_recovered_<ms>, which the
       kit's write whitelist allows). If the copy cannot be written, nothing is overwritten: the session stays in memory
       and the result reports persisted:false with lastError.code 'backup_failed'. */
    function backupFirst(key) {
      var raw = pendingBackups[key]; if (raw === undefined) return true;
      var bk = key + '_recovered_' + clock();
      try { storage.setItem(bk, raw); } catch (e) { setError('backup_failed', e); return false; }
      delete pendingBackups[key]; meta.backups.push(bk);
      return true;
    }
    function saveState() {
      if (meta.readOnly) return false;
      if (!backupFirst(STORAGE_KEY)) { meta.degraded = true; return false; }
      var text;
      try { S.savedAt = clock(); text = JSON.stringify(S); }
      catch (e) { setError('serialize_failed', e); meta.degraded = true; return false; }
      try { storage.setItem(STORAGE_KEY, text); meta.degraded = false; return true; }
      catch (e) { setError('save_failed', e); meta.degraded = true; return false; }
    }
    function savePrefs() {
      if (meta.prefsReadOnly) return false;
      if (!backupFirst(PREFS_KEY)) return false;
      try { storage.setItem(PREFS_KEY, JSON.stringify({ schemaVersion: SCHEMA_VERSION, values: P.values })); return true; }
      catch (e) { setError('prefs_save_failed', e); return false; }
    }

    /* ----- derived cache -------------------------------------------------------------------------------- */
    function buildCache() {
      C = { keys: Object.create(null), voided: Object.create(null), counts: Object.create(null), res: Object.create(null), info: Object.create(null), lastExec: Object.create(null) };
      S.events.slice().sort(function (a, b) { return a.seq - b.seq; }).forEach(indexEvent);
      S.events.forEach(function (e) {
        if ((e.type === 'complete' || e.type === 'skip') && !C.voided[e.key] && isStr(e.stepId) && S.steps[e.stepId] && !S.steps[e.stepId].deletedAt && S.steps[e.stepId].taskId === e.taskId) {
          (C.res[e.taskId] || (C.res[e.taskId] = Object.create(null)))[e.stepId] = { state: e.type === 'complete' ? 'completed' : 'skipped', key: e.key, at: e.at };
        }
      });
      Object.keys(S.tasks).forEach(function (tid) { recompute(S.tasks[tid]); });
    }
    /* status + current step of one task, from its live steps and active resolutions */
    function recompute(task) {
      var ex = S.exec[task.id] || (S.exec[task.id] = newExec()), res = C.res[task.id] || {}, nC = 0, nS = 0, first = null;
      task.stepOrder.forEach(function (sid) {
        var r = res[sid];
        if (!r) { if (first === null) first = sid; } else if (r.state === 'completed') nC++; else nS++;
      });
      var total = task.stepOrder.length, status;
      if (total === 0) status = 'not_started';
      else if (first === null) status = nS === 0 ? 'completed' : (nC === 0 ? 'skipped' : 'partial');
      else status = ex.paused ? 'paused' : (ex.started ? 'in_progress' : 'not_started');
      if (first === null && total > 0 && ex.paused) ex.paused = false;     // a finished task cannot stay paused
      var prev = C.info[task.id] ? C.info[task.id].status : null;
      C.info[task.id] = { status: status, current: first, total: total, completed: nC, skipped: nS, remaining: total - nC - nS };
      return { prev: prev, status: status };
    }
    var EXEC_TYPES = ['start', 'complete', 'skip', 'undo', 'back', 'pause', 'resume'];
    function indexEvent(e) {
      C.keys[e.key] = e;
      if (e.voids) C.voided[e.voids] = e.key;
      if (e.type === 'complete' || e.type === 'skip') { var ck = e.type + ':' + e.stepId; C.counts[ck] = (C.counts[ck] || 0) + 1; }
      if (EXEC_TYPES.indexOf(e.type) >= 0) C.lastExec[e.taskId] = e;          // events are indexed in seq order, so the last one wins
    }
    function appendEvent(type, taskId, fields, key) {
      S.seq += 1;
      var ev = { key: key || (type + ':' + S.seq), seq: S.seq, at: clock(), type: type, taskId: taskId };
      if (fields) Object.keys(fields).forEach(function (f) { if (fields[f] !== undefined) ev[f] = fields[f]; });
      S.events.push(ev); indexEvent(ev);
      return ev;
    }
    function setResolution(task, step, type, ev) {
      (C.res[task.id] || (C.res[task.id] = Object.create(null)))[step.id] = { state: type === 'complete' ? 'completed' : 'skipped', key: ev.key, at: ev.at };
    }
    function clearResolution(taskId, stepId) { if (C.res[taskId]) delete C.res[taskId][stepId]; }

    /* ----- lookups / views ------------------------------------------------------------------------------ */
    function liveTask(id) {
      if (!isStr(id)) return { err: fail('invalid_argument') };
      var t = S.tasks[id];
      if (!t) return { err: fail('not_found') };
      if (t.deletedAt) return { err: fail('deleted') };
      return { task: t };
    }
    function liveStep(id) {
      if (!isStr(id)) return { err: fail('invalid_argument') };
      var st = S.steps[id];
      if (!st) return { err: fail('not_found') };
      var t = S.tasks[st.taskId];
      if (st.deletedAt || !t || t.deletedAt) return { err: fail('deleted') };
      return { step: st, task: t };
    }
    function stepView(task, sid, index) {
      var st = S.steps[sid], r = C.res[task.id] && C.res[task.id][sid], ex = S.exec[task.id], info = C.info[task.id];
      var state = r ? r.state : ((sid === info.current && ex.started) ? 'in_progress' : 'not_started');
      return { id: sid, text: st.text, state: state, index: index };
    }
    function taskView(task) {
      var info = C.info[task.id], ex = S.exec[task.id];
      return {
        id: task.id, dayKey: task.dayKey, title: task.title, status: info.status, started: ex.started, paused: ex.paused,
        currentStepId: info.current,
        counts: { total: info.total, completed: info.completed, skipped: info.skipped, remaining: info.remaining },
        steps: task.stepOrder.map(function (sid, i) { return stepView(task, sid, i); }),
        linkedOneoffId: task.linkedOneoffId, linkedDay: task.linkedDay,
        createdAt: task.createdAt, updatedAt: task.updatedAt, deleted: !!task.deletedAt
      };
    }
    function newId(prefix, map) {
      for (var i = 0; i < 8; i++) { var id = idGen(prefix); if (isStr(id) && !map[id]) return id; }
      throw new Error('id generator produced no unique id');
    }
    function dayOf(key, create) {
      var d = S.days[key];
      if (!d && create) d = S.days[key] = { key: key, taskOrder: [] };
      return d || null;
    }
    function touch(task) { task.updatedAt = clock(); }
    function commit(name, taskId, res) {
      res.persisted = saveState();
      emit({ type: 'change', action: name, taskId: taskId || null });
      return res;
    }
    function current(task) { var info = C.info[task.id]; return info.current ? { id: info.current, text: S.steps[info.current].text } : null; }
    function resolutionResult(task, extra) {
      var info = C.info[task.id], r = { status: info.status, current: current(task), finished: info.status === 'completed' || info.status === 'partial' || info.status === 'skipped' };
      if (extra) Object.keys(extra).forEach(function (k) { r[k] = extra[k]; });
      return r;
    }
    /* once, when a LINKED quick task's plan becomes fully completed (not partial, not skipped) */
    function maybeMarkLinked(task, prevStatus, newStatus) {
      if (newStatus !== 'completed' || prevStatus === 'completed') return;
      var ex = S.exec[task.id];
      if (!task.linkedOneoffId || ex.linkDoneAt) return;
      try { habits.markOneoffDone(task.linkedOneoffId, task.linkedDay); ex.linkDoneAt = clock(); }
      catch (e) { setError('link_failed', e); }
    }

    /* ======================================================================================== tasks / days */
    var createTask = mutating(function (dayKey, title, opts) {
      opts = isObj(opts) ? opts : {};
      if (!isDayKey(dayKey)) return fail('bad_day');
      var t = cleanText(title, LIMITS.title); if (t.err) return fail(t.err, { field: 'title', max: t.max });
      var texts = [];
      if (opts.steps !== undefined) {
        if (!Array.isArray(opts.steps)) return fail('invalid_argument', { field: 'steps' });
        if (opts.steps.length > LIMITS.stepsPerTask) return fail('limit_steps');
        for (var i = 0; i < opts.steps.length; i++) {
          var c = cleanText(opts.steps[i], LIMITS.step); if (c.err) return fail(c.err, { field: 'steps', index: i, max: c.max });
          texts.push(c.text);
        }
      }
      var day = dayOf(dayKey, false);
      if (day && day.taskOrder.length >= LIMITS.tasksPerDay) return fail('limit_tasks');
      var link = null;
      if (opts.linkedOneoffId !== undefined && opts.linkedOneoffId !== null) {
        if (typeof opts.linkedOneoffId !== 'string' || !LINK_RE.test(opts.linkedOneoffId)) return fail('bad_link');
        if (dayKey !== todayKey()) return fail('link_today_only');         // D8: only TODAY's quick tasks can be linked
        link = opts.linkedOneoffId;
      }
      var now = clock(), id = newId('t', S.tasks);
      var task = { id: id, dayKey: dayKey, title: t.text, linkedOneoffId: link, linkedDay: link ? dayKey : null, stepOrder: [], createdAt: now, updatedAt: now, deletedAt: null };
      S.tasks[id] = task; S.exec[id] = newExec();
      texts.forEach(function (tx) {
        var sid = newId('s', S.steps);
        S.steps[sid] = { id: sid, taskId: id, text: tx, createdAt: now, updatedAt: now, deletedAt: null, rev: 1 };
        task.stepOrder.push(sid);
      });
      dayOf(dayKey, true).taskOrder.push(id);
      recompute(task);
      return commit('createTask', id, ok({ task: taskView(task) }));
    });

    var editTask = mutating(function (taskId, patch) {
      var lt = liveTask(taskId); if (lt.err) return lt.err;
      if (!isObj(patch) || !has(patch, 'title')) return fail('invalid_argument');
      var t = cleanText(patch.title, LIMITS.title); if (t.err) return fail(t.err, { field: 'title', max: t.max });
      var task = lt.task;
      if (t.text === task.title) return ok({ noop: true, task: taskView(task), persisted: !meta.degraded });
      appendEvent('task_edit', task.id, { from: task.title, to: t.text });
      task.title = t.text; touch(task);
      return commit('editTask', task.id, ok({ task: taskView(task) }));
    });

    var deleteTask = mutating(function (taskId) {
      if (!isStr(taskId)) return fail('invalid_argument');
      var task = S.tasks[taskId]; if (!task) return fail('not_found');
      if (task.deletedAt) return ok({ noop: true, duplicate: true, persisted: !meta.degraded });
      appendEvent('task_delete', task.id, { taskTitle: task.title, dayKey: task.dayKey, state: C.info[task.id].status });
      task.deletedAt = clock();
      var day = dayOf(task.dayKey, false); if (day) day.taskOrder = day.taskOrder.filter(function (x) { return x !== taskId; });
      return commit('deleteTask', taskId, ok({ deleted: taskId }));
    });

    /* Moves an UNFINISHED task to another day (or to another position of its own day).
       Same day without an index = move to the end. */
    var moveTask = mutating(function (taskId, toDayKey, index) {
      var lt = liveTask(taskId); if (lt.err) return lt.err;
      if (!isDayKey(toDayKey)) return fail('bad_day');
      var task = lt.task, info = C.info[task.id];
      if (info.status === 'completed' || info.status === 'partial' || info.status === 'skipped') return fail('task_finished');
      var from = task.dayKey, same = from === toDayKey;
      var srcDay = dayOf(from, false), srcOrder = (srcDay ? srcDay.taskOrder : []).filter(function (x) { return x !== taskId; });
      var dstOrder;
      if (same) dstOrder = srcOrder;
      else { var dd = dayOf(toDayKey, false); dstOrder = dd ? dd.taskOrder.slice() : []; if (dstOrder.length >= LIMITS.tasksPerDay) return fail('limit_tasks'); }
      var pos = dstOrder.length;
      if (index !== undefined && index !== null) { if (!isInt(index) || index < 0 || index > dstOrder.length) return fail('bad_index'); pos = index; }
      if (same) {
        var curPos = srcDay ? srcDay.taskOrder.indexOf(taskId) : -1;
        if (curPos === pos) return ok({ noop: true, task: taskView(task), persisted: !meta.degraded });
        dstOrder.splice(pos, 0, taskId); dayOf(from, true).taskOrder = dstOrder; touch(task);
        return commit('moveTask', taskId, ok({ task: taskView(task), linkCleared: false }));
      }
      dstOrder.splice(pos, 0, taskId);
      if (srcDay) srcDay.taskOrder = srcOrder;
      dayOf(toDayKey, true).taskOrder = dstOrder; task.dayKey = toDayKey;
      var linkCleared = false;
      if (task.linkedOneoffId) { task.linkedOneoffId = null; task.linkedDay = null; linkCleared = true; }   // a quick-task link only makes sense on its own day
      appendEvent('task_move', task.id, { from: from, to: toDayKey, linkCleared: linkCleared ? true : undefined });
      touch(task);
      return commit('moveTask', taskId, ok({ task: taskView(task), linkCleared: linkCleared }));
    });

    var reorderTasks = mutating(function (dayKey, orderedIds) {
      if (!isDayKey(dayKey)) return fail('bad_day');
      var day = dayOf(dayKey, false), cur = day ? day.taskOrder : [];
      if (!Array.isArray(orderedIds) || orderedIds.length !== cur.length) return fail('bad_order');
      var set = Object.create(null); cur.forEach(function (x) { set[x] = 1; });
      for (var i = 0; i < orderedIds.length; i++) { if (!set[orderedIds[i]]) return fail('bad_order'); delete set[orderedIds[i]]; }
      if (orderedIds.every(function (x, i) { return x === cur[i]; })) return ok({ noop: true, persisted: !meta.degraded });
      day.taskOrder = orderedIds.slice();
      return commit('reorderTasks', null, ok({ order: day.taskOrder.slice() }));
    });

    var setLink = mutating(function (taskId, oneoffId) {
      var lt = liveTask(taskId); if (lt.err) return lt.err;
      var task = lt.task;
      if (oneoffId === null || oneoffId === undefined) {
        if (!task.linkedOneoffId) return ok({ noop: true, persisted: !meta.degraded });
        appendEvent('link_set', task.id, { oneoffId: null, from: task.linkedOneoffId });
        task.linkedOneoffId = null; task.linkedDay = null; touch(task);
        return commit('setLink', task.id, ok({ task: taskView(task) }));
      }
      if (typeof oneoffId !== 'string' || !LINK_RE.test(oneoffId)) return fail('bad_link');
      if (task.dayKey !== todayKey()) return fail('link_today_only');
      if (task.linkedOneoffId === oneoffId) return ok({ noop: true, persisted: !meta.degraded });
      appendEvent('link_set', task.id, { oneoffId: oneoffId, from: task.linkedOneoffId || null });
      task.linkedOneoffId = oneoffId; task.linkedDay = task.dayKey; S.exec[task.id].linkDoneAt = null; touch(task);
      return commit('setLink', task.id, ok({ task: taskView(task) }));
    });

    /* ============================================================================================== steps */
    var addStep = mutating(function (taskId, text, opts) {
      var lt = liveTask(taskId); if (lt.err) return lt.err;
      opts = isObj(opts) ? opts : {};
      var task = lt.task, c = cleanText(text, LIMITS.step); if (c.err) return fail(c.err, { field: 'text', max: c.max });
      if (task.stepOrder.length >= LIMITS.stepsPerTask) return fail('limit_steps');
      var pos = task.stepOrder.length;
      if (opts.afterStepId !== undefined && opts.afterStepId !== null) {
        var at = task.stepOrder.indexOf(opts.afterStepId); if (at < 0) return fail('not_found', { field: 'afterStepId' });
        pos = at + 1;
      } else if (opts.index !== undefined && opts.index !== null) {
        if (!isInt(opts.index) || opts.index < 0 || opts.index > task.stepOrder.length) return fail('bad_index');
        pos = opts.index;
      }
      var now = clock(), sid = newId('s', S.steps);
      S.steps[sid] = { id: sid, taskId: task.id, text: c.text, createdAt: now, updatedAt: now, deletedAt: null, rev: 1 };
      task.stepOrder.splice(pos, 0, sid); touch(task);
      var before = recompute(task);
      var res = ok({ step: stepView(task, sid, pos), status: C.info[task.id].status, current: current(task), reopened: before.prev !== null && ['completed', 'partial', 'skipped'].indexOf(before.prev) >= 0 && C.info[task.id].status === 'in_progress' });
      return commit('addStep', task.id, res);
    });
    var insertStep = mutating(function (taskId, index, text) { return addStep(taskId, text, { index: index }); });

    var editStep = mutating(function (stepId, text) {
      var ls = liveStep(stepId); if (ls.err) return ls.err;
      var c = cleanText(text, LIMITS.step); if (c.err) return fail(c.err, { field: 'text', max: c.max });
      var st = ls.step, task = ls.task;
      if (c.text === st.text) return ok({ noop: true, persisted: !meta.degraded });
      appendEvent('step_edit', task.id, { stepId: st.id, from: st.text, to: c.text });
      st.text = c.text; st.rev += 1; st.updatedAt = clock(); touch(task);
      return commit('editStep', task.id, ok({ step: stepView(task, st.id, task.stepOrder.indexOf(st.id)), current: current(task) }));
    });

    var deleteStep = mutating(function (stepId) {
      if (!isStr(stepId)) return fail('invalid_argument');
      var st = S.steps[stepId]; if (!st) return fail('not_found');
      if (st.deletedAt) return ok({ noop: true, duplicate: true, persisted: !meta.degraded });
      var task = S.tasks[st.taskId]; if (!task || task.deletedAt) return fail('deleted');
      var r = C.res[task.id] && C.res[task.id][stepId], wasCurrent = C.info[task.id].current === stepId;
      appendEvent('step_delete', task.id, { stepId: stepId, stepText: st.text, state: r ? r.state : 'not_started' });
      st.deletedAt = clock(); touch(task);
      task.stepOrder = task.stepOrder.filter(function (x) { return x !== stepId; });
      clearResolution(task.id, stepId);
      var before = recompute(task);
      maybeMarkLinked(task, before.prev, before.status);
      return commit('deleteStep', task.id, ok(resolutionResult(task, { deleted: stepId, wasCurrent: wasCurrent })));
    });

    var reorderSteps = mutating(function (taskId, orderedIds) {
      var lt = liveTask(taskId); if (lt.err) return lt.err;
      var task = lt.task, cur = task.stepOrder;
      if (!Array.isArray(orderedIds) || orderedIds.length !== cur.length) return fail('bad_order');
      var set = Object.create(null); cur.forEach(function (x) { set[x] = 1; });
      for (var i = 0; i < orderedIds.length; i++) { if (!set[orderedIds[i]]) return fail('bad_order'); delete set[orderedIds[i]]; }
      if (orderedIds.every(function (x, i) { return x === cur[i]; })) return ok({ noop: true, persisted: !meta.degraded });
      task.stepOrder = orderedIds.slice(); touch(task);
      recompute(task);
      return commit('reorderSteps', task.id, ok(resolutionResult(task, { order: task.stepOrder.slice() })));
    });
    var moveStep = mutating(function (stepId, toIndex) {
      var ls = liveStep(stepId); if (ls.err) return ls.err;
      var task = ls.task, rest = task.stepOrder.filter(function (x) { return x !== stepId; });
      if (!isInt(toIndex) || toIndex < 0 || toIndex > rest.length) return fail('bad_index');
      var next = rest.slice(); next.splice(toIndex, 0, stepId);
      return reorderSteps(task.id, next);
    });

    /* ================================================================================== execution actions */
    var start = mutating(function (taskId, opts) {
      var lt = liveTask(taskId); if (lt.err) return lt.err;
      var task = lt.task, ex = S.exec[task.id], info = C.info[task.id];
      if (info.status === 'in_progress') return ok(resolutionResult(task, { noop: true, persisted: !meta.degraded }));
      if (info.status === 'paused') return fail('paused');
      if (info.status === 'completed' || info.status === 'partial' || info.status === 'skipped') return fail('finished');
      if (info.total === 0) return fail('no_steps');
      var patch = isObj(opts) && isObj(opts.prefs) ? splitPrefsPatch(opts.prefs).applied : {};
      var snap = defaultPrefs(); Object.keys(P.values).forEach(function (k) { snap[k] = P.values[k]; }); Object.keys(patch).forEach(function (k) { snap[k] = patch[k]; });
      ex.started = true; ex.paused = false; ex.startedAt = clock(); ex.prefs = snap;       // per-session snapshot: later setPrefs() never alters it
      var ev = appendEvent('start', task.id, { dayKey: task.dayKey });
      touch(task); recompute(task);
      return commit('start', task.id, ok(resolutionResult(task, { event: clone(ev) })));
    });

    /* B4 (additive, TASK 1.3): an optional per-step stopwatch reading. complete(stepId, {elapsedMs}) / skip(stepId, {elapsedMs}) store it
       on the new event as `elapsedMs` (integer ms, 0 .. 24 h). Anything else is ignored; it never changes whether the action succeeds,
       and the duplicate/no-op paths write nothing. Old data without the field is valid; an engine that does not know the field drops it on load. */
    var MAX_ELAPSED_MS = 86400000;
    function elapsedOf(opts) { return isObj(opts) && isInt(opts.elapsedMs) && opts.elapsedMs >= 0 && opts.elapsedMs <= MAX_ELAPSED_MS ? opts.elapsedMs : undefined; }
    function resolve(type, stepId, opts) {      // shared by complete() and skip()
      var ls = liveStep(stepId); if (ls.err) return ls.err;
      var step = ls.step, task = ls.task, ex = S.exec[task.id], info = C.info[task.id];
      var act = C.res[task.id] && C.res[task.id][stepId];
      if (act) {
        if ((type === 'complete') === (act.state === 'completed')) return ok(resolutionResult(task, { noop: true, duplicate: true, record: clone(C.keys[act.key]), persisted: !meta.degraded }));   // the same resolution is never recorded twice
        return fail('already_resolved', { state: act.state });
      }
      if (!ex.started || info.status === 'not_started') return fail('not_started');
      if (info.status === 'paused') return fail('paused');
      if (info.status !== 'in_progress' || info.current !== stepId) return fail('not_current', { currentStepId: info.current });
      var n = (C.counts[type + ':' + stepId] || 0) + 1, key = (type === 'complete' ? 'done:' : 'skip:') + stepId + ':' + n;
      if (C.keys[key]) return ok(resolutionResult(task, { noop: true, duplicate: true, record: clone(C.keys[key]), persisted: !meta.degraded }));
      var ev = appendEvent(type, task.id, { stepId: stepId, dayKey: task.dayKey, n: n, stepText: step.text, taskTitle: task.title, elapsedMs: elapsedOf(opts) }, key);
      setResolution(task, step, type, ev); touch(task);
      var before = recompute(task);
      maybeMarkLinked(task, before.prev, before.status);
      return commit(type, task.id, ok(resolutionResult(task, { record: clone(ev), undoUntil: ev.at + undoWindowMs })));
    }
    var complete = mutating(function (stepId, opts) { return resolve('complete', stepId, opts); });
    var skip = mutating(function (stepId, opts) { return resolve('skip', stepId, opts); });

    /* Reverts the last completion/skip of a task, only inside the undo window, and only while it is still the task's
       most recent execution event (after a back / pause / resume / another completion there is nothing to undo).
       opts.key (the record key returned by complete()/skip()) makes a repeated tap harmless. */
    var undo = mutating(function (taskId, opts) {
      var lt = liveTask(taskId); if (lt.err) return lt.err;
      var task = lt.task, ex = S.exec[task.id], key = isObj(opts) && isStr(opts.key) ? opts.key : null;
      if (key && C.voided[key]) return ok({ noop: true, duplicate: true, persisted: !meta.degraded });
      if (ex.paused) return fail('paused');
      var last = C.lastExec[task.id];
      if (!last || (last.type !== 'complete' && last.type !== 'skip') || C.voided[last.key]) return fail('nothing_to_undo');
      var act = C.res[task.id] && C.res[task.id][last.stepId];
      if (!act || act.key !== last.key) return fail('nothing_to_undo');                // the step was deleted meanwhile
      if (key && last.key !== key) return fail('not_latest');
      if (clock() - last.at > undoWindowMs) return fail('window_expired', { undoWindowMs: undoWindowMs });
      var ev = appendEvent('undo', task.id, { stepId: last.stepId, voids: last.key, of: last.type }, 'undo:' + last.key);
      clearResolution(task.id, last.stepId); touch(task);
      recompute(task);
      return commit('undo', task.id, ok(resolutionResult(task, { undone: { key: last.key, stepId: last.stepId, type: last.type }, event: clone(ev) })));
    });

    /* Re-opens the previous step (the one right before the current step); no time limit. Its earlier
       completion/skip is voided, not deleted: the history keeps both events. */
    var back = mutating(function (taskId) {
      var lt = liveTask(taskId); if (lt.err) return lt.err;
      var task = lt.task, ex = S.exec[task.id], info = C.info[task.id];
      if (!ex.started || info.status === 'not_started') return fail('not_started');
      if (info.status === 'paused') return fail('paused');
      var ci = info.current ? task.stepOrder.indexOf(info.current) : task.stepOrder.length;
      if (ci <= 0) return fail('at_first_step');
      var sid = task.stepOrder[ci - 1], r = C.res[task.id] && C.res[task.id][sid];
      if (!r) return fail('at_first_step');                 // cannot happen (everything before the first unresolved step is resolved); defensive
      var ev = appendEvent('back', task.id, { stepId: sid, voids: r.key, of: C.keys[r.key].type }, 'back:' + r.key);
      clearResolution(task.id, sid); touch(task);
      recompute(task);
      return commit('back', task.id, ok(resolutionResult(task, { reopened: sid, event: clone(ev) })));
    });

    var pause = mutating(function (taskId) {
      var lt = liveTask(taskId); if (lt.err) return lt.err;
      var task = lt.task, ex = S.exec[task.id], info = C.info[task.id];
      if (info.status === 'paused') return ok(resolutionResult(task, { noop: true, persisted: !meta.degraded }));
      if (info.status === 'not_started') return fail('not_started');
      if (info.status !== 'in_progress') return fail('finished');
      ex.paused = true; ex.pausedAt = clock();
      var ev = appendEvent('pause', task.id, {}); touch(task); recompute(task);
      return commit('pause', task.id, ok(resolutionResult(task, { event: clone(ev) })));
    });
    var resume = mutating(function (taskId) {
      var lt = liveTask(taskId); if (lt.err) return lt.err;
      var task = lt.task, ex = S.exec[task.id], info = C.info[task.id];
      if (info.status === 'in_progress') return ok(resolutionResult(task, { noop: true, persisted: !meta.degraded }));
      if (info.status !== 'paused') return fail(info.status === 'not_started' ? 'not_started' : 'finished');
      ex.paused = false; ex.pausedAt = null;
      var ev = appendEvent('resume', task.id, {}); touch(task); recompute(task);
      return commit('resume', task.id, ok(resolutionResult(task, { event: clone(ev) })));
    });

    /* ==================================================================================== preferences */
    var setPrefs = guarded(function (patch) {
      if (meta.prefsReadOnly) return fail('read_only', { readOnlyReason: 'newer_schema' });
      var sp = splitPrefsPatch(patch);
      if (!Object.keys(sp.applied).length) return fail('invalid_argument', { rejected: sp.rejected });
      Object.keys(sp.applied).forEach(function (k) { P.values[k] = sp.applied[k]; });
      var saved = savePrefs();
      emit({ type: 'prefs', action: 'setPrefs' });
      return ok({ applied: sp.applied, rejected: sp.rejected, prefs: clone(P.values), persisted: saved });   // active sessions keep their snapshot
    });
    var resetPrefs = guarded(function () {
      if (meta.prefsReadOnly) return fail('read_only', { readOnlyReason: 'newer_schema' });
      P.values = defaultPrefs(); var saved = savePrefs(); emit({ type: 'prefs', action: 'resetPrefs' });
      return ok({ prefs: clone(P.values), persisted: saved });
    });
    /* changes the snapshot of an ACTIVE session only; the saved defaults stay as they are */
    var setSessionPrefs = mutating(function (taskId, patch) {
      var lt = liveTask(taskId); if (lt.err) return lt.err;
      var task = lt.task, ex = S.exec[task.id], st = C.info[task.id].status;
      if (st !== 'in_progress' && st !== 'paused') return fail('not_started');
      var sp = splitPrefsPatch(patch); if (!Object.keys(sp.applied).length) return fail('invalid_argument', { rejected: sp.rejected });
      var snap = sanitizePrefs(ex.prefs); Object.keys(sp.applied).forEach(function (k) { snap[k] = sp.applied[k]; });
      ex.prefs = snap; touch(task);
      return commit('setSessionPrefs', task.id, ok({ applied: sp.applied, rejected: sp.rejected, prefs: clone(snap) }));
    });
    function getSessionPrefs(taskId) {
      var t = isStr(taskId) ? S.tasks[taskId] : null, ex = t ? S.exec[t.id] : null;
      return clone(ex && ex.prefs ? ex.prefs : P.values);
    }

    /* ======================================================================================== queries */
    function getTask(taskId, opts) {
      var t = isStr(taskId) ? S.tasks[taskId] : null;
      if (!t || (t.deletedAt && !(opts && opts.includeDeleted))) return null;
      return taskView(t);
    }
    function getCurrent(taskId) {
      var t = isStr(taskId) ? S.tasks[taskId] : null; if (!t || t.deletedAt) return null;
      var info = C.info[t.id]; if (!info.current) return null;
      var sid = info.current;
      return { taskId: t.id, taskTitle: t.title, status: info.status, step: { id: sid, text: S.steps[sid].text, index: t.stepOrder.indexOf(sid) }, counts: { total: info.total, completed: info.completed, skipped: info.skipped, remaining: info.remaining } };
    }
    function listTasks(dayKey) {
      var d = isDayKey(dayKey) ? S.days[dayKey] : null; if (!d) return [];
      return d.taskOrder.map(function (id) { return taskView(S.tasks[id]); });
    }
    function getDay(dayKey) {
      if (!isDayKey(dayKey)) return null;
      var tasks = listTasks(dayKey), done = tasks.filter(function (t) { return t.status === 'completed' || t.status === 'partial' || t.status === 'skipped'; }).length;
      return { key: dayKey, tasks: tasks, counts: { tasks: tasks.length, finished: done, unfinished: tasks.length - done }, allFinished: tasks.length > 0 && done === tasks.length };
    }
    function listDays() {
      return Object.keys(S.days).filter(function (k) { return S.days[k].taskOrder.length > 0; }).sort().map(function (k) { return getDay(k); });
    }
    function getTaskByLink(oneoffId) {
      var found = null;
      Object.keys(S.tasks).forEach(function (id) { var t = S.tasks[id]; if (!t.deletedAt && t.linkedOneoffId === oneoffId && oneoffId) found = taskView(t); });
      return found;
    }
    /* the unfinished started task the user touched last (resume target), or null */
    function getActiveTask() {
      var best = null, bestAt = -1;
      Object.keys(S.tasks).forEach(function (id) {
        var t = S.tasks[id]; if (t.deletedAt) return;
        var st = C.info[id].status; if (st !== 'in_progress' && st !== 'paused') return;
        var at = C.lastExec[id] ? C.lastExec[id].at : 0; if (at >= bestAt) { best = id; bestAt = at; }
      });
      return best ? taskView(S.tasks[best]) : null;
    }
    function getEvents(filter) {
      var f = isObj(filter) ? filter : {};
      return S.events.filter(function (e) {
        return (!f.taskId || e.taskId === f.taskId) && (!f.stepId || e.stepId === f.stepId) && (!f.type || e.type === f.type) && (!f.dayKey || e.dayKey === f.dayKey);
      }).map(clone);
    }
    /* active completion records (not undone, not reopened); kept even after the step or task was edited/deleted */
    function getCompletions(filter) {
      var f = isObj(filter) ? filter : {};
      return S.events.filter(function (e) {
        return e.type === 'complete' && !C.voided[e.key] && (!f.taskId || e.taskId === f.taskId) && (!f.dayKey || e.dayKey === f.dayKey) && (!isTime(f.since) || e.at >= f.since) && (!isTime(f.until) || e.at <= f.until);
      }).map(clone);
    }
    function getPrefs() { return clone(P.values); }
    function getState() { return clone(S); }
    function status() {
      return {
        loadedFrom: meta.loadedFrom, degraded: meta.degraded, readOnly: meta.readOnly, readOnlyReason: meta.readOnlyReason,
        foundSchemaVersion: meta.foundSchemaVersion, lastError: meta.lastError ? clone(meta.lastError) : null, repairs: meta.repairs,
        recovered: meta.recovered ? clone(meta.recovered) : null, prefsLoadedFrom: meta.prefsLoadedFrom, prefsReadOnly: meta.prefsReadOnly,
        schemaVersion: SCHEMA_VERSION, undoWindowMs: undoWindowMs, backups: meta.backups.slice()
      };
    }
    function getRecoveredRaw() { return corruptRaw; }
    function subscribe(fn) {
      if (typeof fn !== 'function') return function () {};
      listeners.push(fn);
      return function () { var i = listeners.indexOf(fn); if (i >= 0) listeners.splice(i, 1); };
    }
    /* re-reads both keys from storage (e.g. after a storage event from another tab) */
    function reload() { loadState(); loadPrefs(); buildCache(); emit({ type: 'reload' }); return status(); }

    loadState(); loadPrefs(); buildCache();

    return {
      createTask: createTask, editTask: editTask, deleteTask: deleteTask, moveTask: moveTask, reorderTasks: reorderTasks, setLink: setLink,
      addStep: addStep, insertStep: insertStep, editStep: editStep, deleteStep: deleteStep, reorderSteps: reorderSteps, moveStep: moveStep,
      start: start, complete: complete, skip: skip, undo: undo, back: back, pause: pause, resume: resume,
      getPrefs: getPrefs, setPrefs: setPrefs, resetPrefs: resetPrefs, getSessionPrefs: getSessionPrefs, setSessionPrefs: setSessionPrefs,
      getTask: getTask, getCurrent: getCurrent, listTasks: listTasks, getDay: getDay, listDays: listDays, getTaskByLink: getTaskByLink, getActiveTask: getActiveTask,
      getEvents: getEvents, getCompletions: getCompletions, getState: getState, status: status, getRecoveredRaw: getRecoveredRaw,
      subscribe: subscribe, reload: reload, todayKey: todayKey
    };
  }

  /* browser helpers (lazy: nothing below runs at load) */
  function defaultDeps() {
    var kit = GLOBAL.WirdKit;
    if (!kit || !kit.ls || typeof kit.ls.adapter !== 'function') throw new Error('WirdTasks engine needs WirdKit');
    return { storage: kit.ls.adapter(), clock: function () { return Date.now(); }, idGen: kit.uid };
  }
  var singleton = null;
  function getEngine() { if (!singleton) singleton = createEngine(defaultDeps()); return singleton; }

  return {
    version: 1,
    SCHEMA_VERSION: SCHEMA_VERSION, STORAGE_KEY: STORAGE_KEY, PREFS_KEY: PREFS_KEY, UNDO_WINDOW_MS: UNDO_WINDOW_MS,
    LIMITS: clone(LIMITS), PREF_SPEC: clone(PREF_SPEC), DEFAULT_PREFS: defaultPrefs(),
    createEngine: createEngine, defaultDeps: defaultDeps, getEngine: getEngine,
    sanitizeState: sanitizeState, sanitizePrefs: sanitizePrefs, isDayKey: isDayKey, addDays: addDays, dayKeyOf: dayKeyOf, makeMemoryStorage: makeMemoryStorage
  };
});
