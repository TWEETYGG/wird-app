/* ==========================================================================================================
   tasks-ui.js — planning UI & entry points (B3 / TASK 1.2).   Public API: window.WirdTasks.ui
   PLANNING ONLY: create / edit / delete / insert / reorder steps; DAY -> TASKS -> STEPS; move a task to another day.
   The execution screen is tasks-exec.js (B4): this file only offers «ابدأ» / «متابعة»; the settings sheet arrives in B5.

   Entry points (decision D1 default (a), ASSUMED DEFAULT; patch-free per amendment A2; the habit wizard is untouched):
     (i)  tapping the NAME of a quick-task row  .hb-task[data-id^="o_"] .hb-n  -> action sheet
          capture-phase delegation on #habitsRoot (hRender() rewrites the root, the root element itself stays).
     (ii) two chips inside the quick-task modal opened by #hFab, injected by a click listener on #hFab.
          (#hFab.onclick is the only code path that creates that modal, and the app's own handler is registered
          before ours, so the modal already exists when our listener runs. No MutationObserver is needed there.)
   Linking (D7/D8, ASSUMED DEFAULT): a plan may link to one of TODAY'S quick tasks (engine linkedOneoffId); standalone plans
   and future days live only in wird_tasks_v1; habits are never link targets; nothing is written to wird_habits_v1.

   Load-time footprint (kept identical to the pristine page on purpose): two element-level listeners (#habitsRoot, #hFab)
   and nothing else. No observer, no interval, no window/document/body listener, no storage write, no engine instance.
   A MutationObserver on #habitsRoot (childList only, O(1) early return) exists ONLY after the user has created a plan
   (it draws the small badge on rows that HAVE a plan). The planner adds a document keydown listener only while it is open.

   Everything goes through WirdKit.h (no innerHTML) and the engine API (WirdTasks.getEngine()); both are looked up at call time.
   Every hook is wrapped in try/catch: quick-task creation never depends on this file.
   ========================================================================================================== */
(function () {
  'use strict';
  var T = window.WirdTasks, K = window.WirdKit;
  if (!T || !K) return;
  if (T.ui && T.ui.version >= 1) return;               // a re-evaluated block must never replace live UI state

  /* ----------------------------------------------------------------------------------------------- strings */
  var L = {
    plannerTitle: '\uD83E\uDDE9 خطوات المهام',
    split: '\uD83E\uDDE9 قسّمها لخطوات',
    editSteps: 'تعديل الخطوات',
    start: '\u25B6 ابدأ', resume: '\u25B6 متابعة',
    close: 'إغلاق',
    rowHint: 'اختياري — المهمة السريعة بتفضل زي ما هي.',
    chipAfter: '\uD83E\uDDE9 قسّمها لخطوات بعد الحفظ',
    chipSolo: '\uD83E\uDDE9 خطّة بخطوات (بدون مهمة سريعة)',
    today: 'اليوم', tomorrow: 'غدًا', other: 'يوم آخر', pickDay: 'اختيار اليوم', pickDate: 'اختيار تاريخ',
    taskName: 'اسم المهمة', newTaskPh: 'اسم مهمة جديدة', addTask: '＋ إضافة',
    noTasks: 'لسه مفيش مهام في اليوم ده. اكتب اسم مهمة وقسّمها لخطوات.',
    pastDay: 'اليوم ده فات. تقدر تنقل مهامه اللي ما خلصتش.',
    overdue: 'مهام من أيام فاتت لسه ما خلصتش', moveToToday: 'نقل لليوم', overdueMore: 'وفيه مهام كمان من أيام أقدم.',
    steps: 'الخطوات', stepPh: 'خطوة جديدة…', addStep: '＋ إضافة', noSteps: 'لسه مفيش خطوات. اكتب أول خطوة وهتتحفظ تلقائي.',
    insertPh: 'خطوة جديدة هنا…', insertDo: 'إضافة', insertCancel: 'تم',
    linked: '\uD83D\uDD17 مربوطة بمهمة سريعة النهارده', back: '\u203A',
    up: 'للأعلى', down: 'للأسفل', del: 'حذف', move: 'نقل ليوم…', moveDo: 'نقل', cancel: 'إلغاء', delTask: '\uD83D\uDDD1 حذف المهمة',
    moveTitle: 'نقل المهمة', moveTo: 'انقلها لأي يوم؟',
    confirmTitle: 'حذف المهمة', deleted: 'اتحذفت', saved: 'اتحفظ',
    needTitle: 'اكتب اسم المهمة الأول.', emptyStep: 'اكتب نص الخطوة الأول. ولو عايز تمسحها دوس ✕.',
    err: 'حصلت مشكلة. جرّب تاني.', notSaved: '\u26A0\uFE0F التعديل ده لسه ما اتحفظش على الجهاز (ممكن المساحة مليانة).',
    readOnly: 'الخطط دي اتحفظت بنسخة أحدث من التطبيق، فمينفعش تتعدّل هنا.',
    st_not_started: 'لسه ما بدأتش', st_in_progress: 'شغّالة', st_paused: 'موقوفة', st_completed: 'خلصت \u2713', st_skipped: 'اتخطّت', st_partial: 'خلصت جزئيًا',
    noSteps0: 'من غير خطوات', sameDay: 'المهمة أصلاً في اليوم ده.', pastMove: 'اختار النهارده أو يوم جاي.', finishedMove: 'المهمة دي خلصت، مينفعش تتنقل.',
    badgeLabel: 'فيها خطة بخطوات'
  };

  var LIM = (T.engine && T.engine.LIMITS) || { title: 120, step: 300, stepsPerTask: 100, tasksPerDay: 100 };
  var S = null;                                         // the open sheet (null when closed)
  var hooks = { root: null, fab: null, observer: null, unsub: null };
  var linkCache = null;                                 // { oneoffId: taskView } for TODAY'S plans; dropped on every engine change
  var lastError = null;
  var origin = null;                                    // { taskId, view, day }: where «ابدأ» / «متابعة» was pressed; consumed once by takeOrigin()

  /* -------------------------------------------------------------------------------------------- utilities */
  function report(e) { lastError = e; try { if (window.console && window.console.warn) window.console.warn('[wird-tasks-ui]', e && e.message ? e.message : e); } catch (x) { /* ignore */ } }
  function h() { return K.h.apply(K, arguments); }
  function eng() { return T.getEngine(); }
  function an(n) { try { return typeof toArabicNum === 'function' ? toArabicNum(n) : String(n); } catch (e) { return String(n); } }
  function todayKey() { try { return eng().todayKey(); } catch (e) { try { return todayISO(); } catch (x) { return ''; } } }
  function addDays(k, n) { return T.engine.addDays(k, n); }
  function isDay(k) { return typeof k === 'string' && T.engine.isDayKey(k); }
  function habits() { return T.readHabits(); }
  function isFinished(st) { return st === 'completed' || st === 'partial' || st === 'skipped'; }
  function toast(m) { try { if (typeof showToast === 'function') showToast(m); } catch (e) { /* ignore */ } }
  function canStart(t) { return !!(T.exec && typeof T.exec.open === 'function' && t && t.counts.total > 0 && !isFinished(t.status)); }   // feature detection: the execution screen arrives in B4

  function fmtDay(key, withYear) {
    try {
      var p = key.split('-'), d = new Date(Date.UTC(+p[0], +p[1] - 1, +p[2], 12));
      var o = { weekday: 'long', day: 'numeric', month: 'long', timeZone: 'UTC' };
      if (withYear) o.year = 'numeric';
      return new Intl.DateTimeFormat('ar-EG', o).format(d);
    } catch (e) { return key; }
  }
  function dayName(key) {
    var t = todayKey();
    if (key === t) return L.today;
    if (key === addDays(t, 1)) return L.tomorrow;
    return fmtDay(key, key.slice(0, 4) !== t.slice(0, 4));
  }
  function stepsLabel(n) {
    if (!n) return L.noSteps0;
    if (n === 1) return 'خطوة واحدة';
    if (n === 2) return 'خطوتين';
    return an(n) + (n <= 10 ? ' خطوات' : ' خطوة');
  }
  function statusText(t) {
    var c = t.counts, parts = [stepsLabel(c.total)];
    if (!c.total) return parts[0];
    if (t.status === 'completed') parts.push(L.st_completed);
    else if (t.status === 'skipped') parts.push(L.st_skipped);
    else if (t.status === 'partial') parts.push(L.st_partial);
    else if (t.status === 'in_progress' || t.status === 'paused') parts.push((t.status === 'paused' ? L.st_paused : L.st_in_progress) + ' · ' + an(c.completed) + ' من ' + an(c.total));
    else parts.push(L.st_not_started);
    return parts.join(' · ');
  }
  function reasonText(r) {
    var why = r && r.reason;
    if (why === 'empty_text') return r.field === 'title' ? L.needTitle : L.emptyStep;
    if (why === 'too_long') return 'النص طويل (الحد الأقصى ' + an(r.max || (r.field === 'title' ? LIM.title : LIM.step)) + ' حرف).';
    if (why === 'limit_steps') return 'وصلت للحد الأقصى: ' + an(LIM.stepsPerTask) + ' خطوة في المهمة.';
    if (why === 'limit_tasks') return 'وصلت للحد الأقصى: ' + an(LIM.tasksPerDay) + ' مهمة في اليوم.';
    if (why === 'read_only') return L.readOnly;
    if (why === 'task_finished') return L.finishedMove;
    if (why === 'bad_day') return L.pastMove;
    return L.err;
  }

  /* one engine call; the busy flag lets the sheet ignore the change event of its own action */
  function call(name) {
    var a = Array.prototype.slice.call(arguments, 1), e = eng();
    if (S) S.busy = true;
    try { return e[name].apply(e, a); } finally { if (S) S.busy = false; }
  }
  function ok(r) {
    if (r && r.ok) { if (r.persisted === false) setMsg(L.notSaved, 'warn'); return true; }
    setMsg(reasonText(r), 'err'); return false;
  }
  function setMsg(text, kind) {
    if (!S || !S.msgEl) return;
    S.msgEl.textContent = text || '';
    S.msgEl.className = 'wt-msg' + (kind ? ' ' + kind : '');
    clearTimeout(S.msgT);
    if (text) S.msgT = setTimeout(function () { if (S && S.msgEl) { S.msgEl.textContent = ''; S.msgEl.className = 'wt-msg'; } }, 6000);
  }
  function btn(cls, label, onclick, extra) {
    var a = { type: 'button', class: cls, onclick: onclick };
    if (extra) Object.keys(extra).forEach(function (k) { a[k] = extra[k]; });
    return h('button', a, label);
  }
  function chip(label, on, fn) { return h('button', { type: 'button', class: on ? 'on' : '', 'aria-pressed': on ? 'true' : 'false', onclick: fn }, label); }

  /* ------------------------------------------------------------------------------------ plans and quick tasks */
  function linkMap() {                                   // today's plans by linked quick-task id (cached until the engine changes)
    if (linkCache) return linkCache;
    var m = {}, e = eng();
    e.listTasks(e.todayKey()).forEach(function (t) { if (t.linkedOneoffId) m[t.linkedOneoffId] = t; });
    if (!hooks.unsub) hooks.unsub = e.subscribe(function () { linkCache = null; });
    linkCache = m; return m;
  }
  function oneoffsOf(day) { var H0 = habits(); return (H0 && H0.oneoffs && Array.isArray(H0.oneoffs[day])) ? H0.oneoffs[day] : []; }
  function findOneoff(id, day) { var l = oneoffsOf(day); for (var i = 0; i < l.length; i++) if (l[i] && l[i].id === id) return l[i]; return null; }

  /* ----------------------------------------------------------------------------- badge on rows that HAVE a plan */
  function decorateRows() {
    var R = document.getElementById('habitsRoot'); if (!R) return;
    var d = todayKey(), map = linkMap(), has = false, k;
    for (k in map) { has = true; break; }
    var old = R.querySelectorAll('.wt-badge');
    if (!has && !old.length) return;                     // no plan and nothing to clean: O(1)
    var rows = R.querySelectorAll('.hb-task[data-id^="o_"]'), i, row, plan, b, nm;
    for (i = 0; i < rows.length; i++) {
      row = rows[i]; plan = row.getAttribute('data-d') === d ? map[row.getAttribute('data-id')] : null;
      b = row.querySelector('.wt-badge');
      if (!plan) { if (b) b.remove(); continue; }
      if (b) { b.textContent = '\uD83E\uDDE9 ' + an(plan.counts.total); b.classList.toggle('done', plan.status === 'completed'); continue; }
      nm = row.querySelector('.hb-n'); if (!nm) continue;
      nm.insertAdjacentElement('afterend', h('span', { class: 'wt-badge' + (plan.status === 'completed' ? ' done' : ''), 'data-wt': '1', 'aria-label': L.badgeLabel, role: 'img' }, '\uD83E\uDDE9 ' + an(plan.counts.total)));
    }
  }
  function installBadgeObserver() {
    if (hooks.observer || typeof MutationObserver !== 'function') return;
    var R = document.getElementById('habitsRoot'); if (!R) return;
    hooks.observer = new MutationObserver(function () { try { decorateRows(); } catch (e) { report(e); } });
    hooks.observer.observe(R, { childList: true });      // direct children only: hRender() replaces them; our own badges sit deeper and never re-trigger it
  }
  function installHooks() { try { installBadgeObserver(); decorateRows(); } catch (e) { report(e); } }

  /* ----------------------------------------------------------------------------------------- entry point (i) */
  function onRootClick(ev) {
    try {
      var t = ev.target; if (!t || !t.closest) return;
      var name = t.closest('.hb-n[data-a="open"]'); if (!name) return;
      var row = name.closest('.hb-task[data-id]'); if (!row) return;
      var id = row.getAttribute('data-id') || '', day = row.getAttribute('data-d') || '';
      if (id.indexOf('o_') !== 0 || day !== todayKey()) return;       // quick tasks of today only (D7/D8); habits and events are never targets
      var one = findOneoff(id, day); if (!one) return;
      openRow({ id: one.id, name: String(one.name || ''), day: day });
    } catch (e) { report(e); }                                          // never break the app's own handler
  }

  /* ---------------------------------------------------------------------------------------- entry point (ii) */
  function quickModal() { var q = document.getElementById('qn'); return q && q.closest ? q.closest('.modal-overlay') : null; }
  function onFabClick() {
    try {
      var ov = quickModal();
      if (ov) decorateQuickModal(ov);
      else setTimeout(function () { try { var o2 = quickModal(); if (o2) decorateQuickModal(o2); } catch (e) { report(e); } }, 0);
    } catch (e) { report(e); }
  }
  function decorateQuickModal(ov) {
    if (!ov || ov.getAttribute('data-wt-q') === '1') return;
    var qn = ov.querySelector('#qn'), hok = ov.querySelector('#hok'), act = ov.querySelector('.settings-actions');
    if (!qn || !hok || !act || !act.parentNode) return;
    var after = false;
    var tgl = h('button', { type: 'button', class: 'wt-chip', 'aria-pressed': 'false', onclick: function () {
      after = !after; tgl.classList.toggle('on', after); tgl.setAttribute('aria-pressed', after ? 'true' : 'false');
    } }, L.chipAfter);
    var solo = h('button', { type: 'button', class: 'wt-chip', onclick: function () {
      try { var nm = qn.value; ov.remove(); openPlanner({ title: nm }); } catch (e) { report(e); }
    } }, L.chipSolo);
    var row = h('div', { class: 'hb-chips wt-chips', 'data-wt': '1' }, [tgl, solo]);
    act.parentNode.insertBefore(row, act);
    ov.setAttribute('data-wt-q', '1');                                  // own marker: never decorated twice
    /* capture phase on the button itself: runs BEFORE the app's onclick, which creates the quick task synchronously.
       Nothing here awaits or replaces that handler; whatever happens below, the quick task is already saved. */
    hok.addEventListener('click', function () {
      try {
        if (!after) return;
        var d = todayKey(), seen = oneoffsOf(d).map(function (o) { return o && o.id; });
        setTimeout(function () {
          try {
            var fresh = oneoffsOf(d).filter(function (o) { return o && seen.indexOf(o.id) < 0; });
            if (fresh.length) { var o = fresh[fresh.length - 1]; openPlanner({ oneoffId: o.id, title: String(o.name || ''), day: d }); }
          } catch (e) { report(e); }
        }, 0);
      } catch (e) { report(e); }
    }, true);
  }

  /* --------------------------------------------------------------------------------------------- the sheet */
  function mount() {
    var msgEl = h('div', { class: 'wt-msg', role: 'status', 'aria-live': 'polite' });
    var titleEl = h('h3', { id: 'wt-title' }, L.plannerTitle);
    var body = h('div', { class: 'wt-body' });
    var sheet = h('div', { class: 'modal wt-sheet', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'wt-title', tabindex: '-1', 'data-wt': '1' }, [
      h('div', { class: 'wt-head' }, [titleEl, btn('wt-x', '\u2715', function () { close(); }, { 'aria-label': L.close })]), msgEl, body
    ]);
    var ov = h('div', { class: 'modal-overlay open wt-ov', 'data-wt': '1', onclick: function (e) { if (e.target === ov) close(); } }, sheet);
    document.body.appendChild(ov);
    S = { overlay: ov, sheet: sheet, body: body, titleEl: titleEl, msgEl: msgEl, msgT: 0, opener: document.activeElement, view: 'day', day: todayKey(), taskId: null, draft: null,
          row: null, moveId: null, moveTo: null, moveBack: 'day', insertAfter: null, newTitle: '', otherOpen: false, focus: null, busy: false,
          titleEl2: null, lastTitle: '', titleTimer: 0, stepTimers: {}, unsub: null, onKey: null, onVV: null, renderQ: 0 };
    S.onKey = onKey; document.addEventListener('keydown', S.onKey, true);
    if (window.visualViewport) { S.onVV = fitViewport; window.visualViewport.addEventListener('resize', S.onVV); window.visualViewport.addEventListener('scroll', S.onVV); fitViewport(); }
    try { S.unsub = eng().subscribe(function (ev) { if (S && !S.busy && ev && (ev.type === 'change' || ev.type === 'reload')) scheduleRender(); }); } catch (e) { report(e); }
  }
  function scheduleRender() {
    if (!S || S.renderQ) return;
    S.renderQ = setTimeout(function () { if (S) { S.renderQ = 0; render(); } }, 0);
  }
  function fitViewport() {                              // keep the sheet above the on-screen keyboard (visualViewport shrinks, the layout viewport may not)
    var vv = window.visualViewport; if (!vv || !S) return;
    S.overlay.style.top = vv.offsetTop + 'px'; S.overlay.style.height = vv.height + 'px'; S.overlay.style.bottom = 'auto';
    S.overlay.style.setProperty('--wt-vh', vv.height + 'px');
    var a = document.activeElement; if (a && S.sheet.contains(a) && a.scrollIntoView) { try { a.scrollIntoView({ block: 'nearest' }); } catch (e) { /* ignore */ } }
  }
  function focusables() {
    var n = S.sheet.querySelectorAll('button:not([disabled]),input:not([disabled]),textarea:not([disabled]),select:not([disabled]),[tabindex]:not([tabindex="-1"])'), out = [], i;
    for (i = 0; i < n.length; i++) if (n[i].offsetParent !== null || n[i] === document.activeElement) out.push(n[i]);
    return out;
  }
  function onKey(e) {
    if (!S) return;
    var co = document.getElementById('confirmOverlay'); if (co && co.classList.contains('open')) return;   // the app's confirm dialog owns the keyboard
    if (e.key === 'Escape') {
      e.preventDefault();
      if (S.insertAfter) { S.insertAfter = null; render(); }
      else if (S.view === 'move') { S.view = S.moveBack; render(); }
      else close();
      return;
    }
    if (e.key !== 'Tab') return;
    var f = focusables(); if (!f.length) { e.preventDefault(); S.sheet.focus(); return; }
    var first = f[0], last = f[f.length - 1], a = document.activeElement;
    if (!S.sheet.contains(a)) { e.preventDefault(); first.focus(); }
    else if (e.shiftKey && (a === first || a === S.sheet)) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && a === last) { e.preventDefault(); first.focus(); }
  }
  function close() {
    if (!S) return;
    var s = S;
    try { flushPending(); } catch (e) { report(e); }
    S = null;
    try { document.removeEventListener('keydown', s.onKey, true); } catch (e) { /* ignore */ }
    if (s.onVV && window.visualViewport) { window.visualViewport.removeEventListener('resize', s.onVV); window.visualViewport.removeEventListener('scroll', s.onVV); }
    if (s.unsub) { try { s.unsub(); } catch (e) { /* ignore */ } }
    clearTimeout(s.msgT); clearTimeout(s.renderQ);
    if (s.overlay.parentNode) s.overlay.parentNode.removeChild(s.overlay);
    try { var o = s.opener; if (o && o !== document.body && o.isConnected && o.focus) o.focus(); } catch (e) { /* ignore */ }
    try { linkCache = null; if (eng().listDays().length) installHooks(); else decorateRows(); } catch (e) { report(e); }
  }

  /* ---------------------------------------------------------------------------------------------- rendering */
  var VIEWS = { row: viewRow, day: viewDay, task: viewTask, move: viewMove };
  function render() {
    if (!S) return;
    try { flushPending(); } catch (e) { report(e); }
    var keep = S.body.scrollTop, nodes;
    K.dom.empty(S.body);
    S.titleEl2 = null;
    try { nodes = VIEWS[S.view](); } catch (e) { report(e); nodes = [h('p', { class: 'field-hint' }, L.err)]; }
    var ro = false; try { ro = !!eng().status().readOnly; } catch (e) { /* ignore */ }
    if (ro) S.body.appendChild(h('p', { class: 'wt-msg err' }, L.readOnly));
    S.sheet.setAttribute('data-ro', ro ? '1' : '0');
    nodes.forEach(function (n) { if (n) S.body.appendChild(n); });
    S.body.scrollTop = keep;
    var t = L.plannerTitle;
    if (S.view === 'row' && S.row) t = '\uD83E\uDDE9 ' + S.row.name;
    else if (S.view === 'task') { var pl = S.taskId ? eng().getTask(S.taskId) : null; t = pl ? pl.title : (S.draft && S.draft.title) || L.plannerTitle; }
    else if (S.view === 'move') t = L.moveTitle;
    S.titleEl.textContent = t;
    var tas = S.body.querySelectorAll('.wt-step-in'), i; for (i = 0; i < tas.length; i++) autosize(tas[i]);
    if (S.focus) {                                       // a selector, or an ordered list of selectors (first match wins)
      var sels = Array.isArray(S.focus) ? S.focus : [S.focus], f = null, k; S.focus = null;
      for (k = 0; k < sels.length && !f; k++) f = S.body.querySelector(sels[k]);
      if (f) { f.focus(); try { f.scrollIntoView({ block: 'nearest' }); } catch (e) { /* ignore */ } }
    }
  }
  function autosize(ta) { ta.style.height = 'auto'; ta.style.height = (ta.scrollHeight + 2) + 'px'; }
  function go(view, patch) { if (!S) return; flushPending(); S.view = view; if (patch) Object.keys(patch).forEach(function (k) { S[k] = patch[k]; }); S.insertAfter = null; setMsg(''); S.body.scrollTop = 0; render(); }
  function goTask(id, from) { go('task', { taskId: id, draft: null, moveBack: from === 'day' ? 'day' : 'task' }); }
  function goDay(day) { go('day', { day: day || S.day, taskId: null, draft: null }); }

  /* -------- row action sheet */
  function viewRow() {
    var one = S.row, plan = eng().getTaskByLink(one.id), acts = [];
    if (!plan) acts.push(btn('btn btn-primary wt-wide', L.split, function () { go('task', { taskId: null, draft: { title: one.name, oneoffId: one.id, day: one.day }, moveBack: 'task' }); }, { 'data-act': 'split' }));
    else {
      acts.push(btn('btn btn-primary wt-wide', L.editSteps, function () { goTask(plan.id, 'row'); }, { 'data-act': 'edit' }));
      if (canStart(plan)) acts.push(startBtn(plan));
    }
    acts.push(btn('btn btn-ghost wt-wide', L.close, function () { close(); }, { 'data-act': 'close' }));
    return [h('p', { class: 'desc' }, plan ? statusText(plan) : L.rowHint), h('div', { class: 'wt-actions' }, acts)];
  }
  /* «ابدأ» for a plan that has not started, «متابعة» for one that is running or paused (B4). The call to the execution screen keeps the
     B3 contract exactly: exec.open(id, {from:'planner'}). Where the user pressed the button (row sheet / day view / task editor) is left in
     `origin`, which the execution screen collects with WirdTasks.ui.takeOrigin(id) so that closing it returns to the same place. */
  function startBtn(plan, small) {
    var cont = plan.status === 'in_progress' || plan.status === 'paused';
    return btn('btn btn-primary wt-start ' + (small ? 'wt-sm' : 'wt-wide'), cont ? L.resume : L.start, function () {
      var id = plan.id; origin = { taskId: id, view: S ? S.view : '', day: plan.dayKey }; close();
      try { T.exec.open(id, { from: 'planner' }); } catch (e) { report(e); }
    }, { 'data-act': 'start', 'data-cont': cont ? '1' : null });
  }

  /* -------- day view: DAY -> TASKS */
  function viewDay() {
    var t = todayKey(), tm = addDays(t, 1), day = S.day, e = eng(), nodes = [];
    var other = S.otherOpen || (day !== t && day !== tm);
    nodes.push(h('div', { class: 'hb-chips wt-chips', role: 'group', 'aria-label': L.pickDay }, [
      chip(L.today, day === t && !S.otherOpen, function () { S.day = t; S.otherOpen = false; render(); }),
      chip(L.tomorrow, day === tm && !S.otherOpen, function () { S.day = tm; S.otherOpen = false; render(); }),
      chip(L.other, other, function () { S.otherOpen = true; S.focus = '.wt-date'; render(); })
    ]));
    if (other) nodes.push(h('input', { type: 'date', class: 'field-input wt-date', value: day, 'aria-label': L.pickDate, onchange: function (ev) {
      var v = ev.target.value; if (isDay(v)) { S.day = v; S.otherOpen = true; render(); }
    } }));
    nodes.push(h('div', { class: 'field-hint wt-dayline' }, (day === t ? L.today + ' — ' : day === tm ? L.tomorrow + ' — ' : '') + fmtDay(day, day.slice(0, 4) !== t.slice(0, 4))));
    var past = day < t, d = e.getDay(day), list = d ? d.tasks : [];
    if (past) nodes.push(h('p', { class: 'field-hint' }, L.pastDay));
    if (!list.length && !past) nodes.push(h('p', { class: 'field-hint wt-empty' }, L.noTasks));
    list.forEach(function (tk, i) { nodes.push(taskCard(tk, i, list)); });
    if (!past) {
      var inp = h('input', { type: 'text', class: 'field-input wt-newtask wt-mut', maxlength: String(LIM.title), placeholder: L.newTaskPh, 'aria-label': L.newTaskPh, dir: 'auto', enterkeyhint: 'done', value: S.newTitle || '',
        oninput: function (ev) { S.newTitle = ev.target.value; },
        onkeydown: function (ev) { if (ev.key === 'Enter' && !ev.isComposing) { ev.preventDefault(); addTask(); } } });
      nodes.push(h('div', { class: 'wt-add' }, [inp, btn('btn btn-primary wt-add-btn wt-mut', L.addTask, addTask)]));
    }
    if (day === t) {
      var od = []; e.listDays().forEach(function (dd) { if (dd.key < t) dd.tasks.forEach(function (tk) { if (!isFinished(tk.status)) od.push(tk); }); });
      if (od.length) {
        nodes.push(h('div', { class: 'wt-block' }, [h('div', { class: 'field-label' }, L.overdue)].concat(od.slice(0, 30).map(function (tk) {
          return h('div', { class: 'wt-task wt-od' }, [
            btn('wt-task-main', [h('span', { class: 'wt-task-title', dir: 'auto' }, tk.title), h('small', { class: 'wt-task-meta' }, dayName(tk.dayKey) + ' · ' + statusText(tk))], function () { goTask(tk.id, 'day'); }),
            h('div', { class: 'wt-tools' }, [btn('btn btn-ghost wt-sm wt-mut', L.moveToToday, function () { var r = call('moveTask', tk.id, t); if (ok(r)) { toast('اتنقلت لليوم'); render(); } }, { 'data-act': 'to-today' })])
          ]);
        })).concat(od.length > 30 ? [h('p', { class: 'field-hint' }, L.overdueMore)] : [])));
      }
    }
    return nodes;
  }
  function addTask() {
    var title = (S.newTitle || '').trim();
    if (!title) { setMsg(L.needTitle, 'err'); S.focus = '.wt-newtask'; render(); return; }
    var r = call('createTask', S.day, title);
    if (!ok(r)) return;
    S.newTitle = ''; installHooks(); S.focus = '.wt-add-in'; goTask(r.task.id, 'day');
  }
  function taskCard(tk, i, list) {
    var fin = isFinished(tk.status), tools = [];
    tools.push(btn('hb-mv wt-ib wt-mut', '\u25B2', function () { shiftTask(tk, list, -1); }, { 'aria-label': L.up, disabled: i === 0, 'data-act': 'up' }));
    tools.push(btn('hb-mv wt-ib wt-mut', '\u25BC', function () { shiftTask(tk, list, 1); }, { 'aria-label': L.down, disabled: i === list.length - 1, 'data-act': 'down' }));
    if (!fin) tools.push(btn('btn btn-ghost wt-sm wt-mut', L.move, function () { go('move', { moveId: tk.id, moveTo: null, moveBack: 'day' }); }, { 'data-act': 'move' }));
    tools.push(btn('hb-mv wt-ib wt-mut', '\uD83D\uDDD1', function () { askDelete(tk); }, { 'aria-label': L.delTask, 'data-act': 'del-task' }));
    if (canStart(tk)) tools.push(startBtn(tk, true));
    return h('div', { class: 'wt-task' + (fin ? ' done' : ''), 'data-task': tk.id }, [
      btn('wt-task-main', [h('span', { class: 'wt-task-title', dir: 'auto' }, tk.title), h('small', { class: 'wt-task-meta' }, statusText(tk))], function () { goTask(tk.id, 'day'); }),
      h('div', { class: 'wt-tools' }, tools)
    ]);
  }
  function arrowFocus(scope, dir) {                      // after a reorder: focus the arrow that was pressed, or its twin when it just became disabled
    var a = dir < 0 ? 'up' : 'down', b = dir < 0 ? 'down' : 'up';
    return [scope + ' [data-act="' + a + '"]:not([disabled])', scope + ' [data-act="' + b + '"]:not([disabled])'];
  }
  function shiftTask(tk, list, dir) {
    var ids = list.map(function (x) { return x.id; }), i = ids.indexOf(tk.id), j = i + dir;
    if (i < 0 || j < 0 || j >= ids.length) return;
    ids[i] = ids[j]; ids[j] = tk.id;
    if (ok(call('reorderTasks', tk.dayKey, ids))) { S.focus = arrowFocus('[data-task="' + tk.id + '"]', dir); render(); }
  }

  /* -------- task editor: TASK -> STEPS */
  function ensureTask() {                               // a plan is created lazily: opening the editor and closing it again writes nothing
    if (S.taskId) return { ok: true, id: S.taskId };
    var v = S.titleEl2 ? S.titleEl2.value : (S.draft && S.draft.title) || '';
    if (!String(v).trim()) { setMsg(L.needTitle, 'err'); S.focus = '.wt-title-in'; render(); return { ok: false }; }
    var dr = S.draft, r = call('createTask', dr.day, v, dr.oneoffId ? { linkedOneoffId: dr.oneoffId } : {});
    if (!r.ok && r.reason === 'link_today_only') r = call('createTask', dr.day, v, {});   // the app stayed open past midnight: keep the plan, drop the link
    if (!ok(r)) return { ok: false };
    S.taskId = r.task.id; S.lastTitle = r.task.title; S.draft = null; installHooks();
    return { ok: true, id: S.taskId };
  }
  function commitTitle(norm) {
    var el = S.titleEl2; if (!el) return;
    var v = el.value;
    if (!S.taskId) { if (String(v).trim()) { var r0 = ensureTask(); if (r0.ok && norm && S.titleEl2) S.titleEl2.value = S.lastTitle; } return; }
    if (v === S.lastTitle) return;
    var r = call('editTask', S.taskId, { title: v });
    if (ok(r)) { S.lastTitle = r.task.title; if (norm) el.value = r.task.title; S.titleEl.textContent = r.task.title; }
    else el.value = S.lastTitle;
  }
  function flushPending() {
    if (!S) return;
    if (S.titleTimer) { clearTimeout(S.titleTimer); S.titleTimer = 0; commitTitle(false); }
    var ids = Object.keys(S.stepTimers);
    ids.forEach(function (id) { var o = S.stepTimers[id]; delete S.stepTimers[id]; if (o) { clearTimeout(o.t); o.commit(false); } });
  }

  function viewTask() {
    var plan = S.taskId ? eng().getTask(S.taskId) : null;
    if (!plan && !S.draft) { S.view = 'day'; S.taskId = null; return viewDay(); }               // deleted meanwhile
    var dayKey = plan ? plan.dayKey : S.draft.day, nodes = [];
    var titleVal = plan ? plan.title : S.draft.title;
    S.lastTitle = plan ? plan.title : '';
    nodes.push(h('div', { class: 'wt-nav' }, [btn('wt-back', L.back + ' ' + dayName(dayKey), function () { goDay(dayKey); }, { 'data-act': 'back' })]));
    var tin = h('input', { type: 'text', id: 'wt-t', class: 'field-input wt-title-in wt-mut', maxlength: String(LIM.title), value: titleVal, dir: 'auto', enterkeyhint: 'done',
      oninput: function () { clearTimeout(S.titleTimer); S.titleTimer = setTimeout(function () { if (S) { S.titleTimer = 0; commitTitle(false); } }, 1200); },
      onchange: function () { clearTimeout(S.titleTimer); S.titleTimer = 0; commitTitle(true); },
      onkeydown: function (ev) { if (ev.key === 'Enter' && !ev.isComposing) { ev.preventDefault(); ev.target.blur(); } } });
    S.titleEl2 = tin;
    nodes.push(h('label', { class: 'field-label', for: 'wt-t' }, L.taskName), tin);
    if ((plan && plan.linkedOneoffId) || (S.draft && S.draft.oneoffId)) nodes.push(h('p', { class: 'field-hint' }, L.linked));
    var steps = plan ? plan.steps : [];
    nodes.push(h('div', { class: 'field-label wt-sec' }, L.steps + (steps.length ? ' (' + an(steps.length) + ')' : '')));
    if (!steps.length) nodes.push(h('p', { class: 'field-hint wt-empty' }, L.noSteps));
    steps.forEach(function (st, i) {
      nodes.push(stepRow(plan, st, i, steps.length));
      if (S.insertAfter === st.id) nodes.push(insertRow(plan, st, i));
    });
    var addIn = h('input', { type: 'text', class: 'field-input wt-add-in wt-mut', maxlength: String(LIM.step), placeholder: L.stepPh, 'aria-label': L.stepPh, dir: 'auto', enterkeyhint: 'done',
      onkeydown: function (ev) { if (ev.key === 'Enter' && !ev.isComposing) { ev.preventDefault(); addStepFrom(addIn, null); } } });
    nodes.push(h('div', { class: 'wt-add' }, [addIn, btn('btn btn-primary wt-add-btn wt-mut', L.addStep, function () { addStepFrom(addIn, null); })]));
    if (plan) {
      var acts = [];
      if (canStart(plan)) acts.push(startBtn(plan));
      if (!isFinished(plan.status)) acts.push(btn('btn btn-ghost wt-wide wt-mut', L.move, function () { go('move', { moveId: plan.id, moveTo: null, moveBack: 'task' }); }, { 'data-act': 'move' }));
      acts.push(btn('btn btn-danger wt-wide wt-mut', L.delTask, function () { askDelete(plan); }, { 'data-act': 'del-task' }));
      nodes.push(h('div', { class: 'wt-actions wt-foot' }, acts));
    }
    return nodes;
  }
  function addStepFrom(input, afterId) {
    var v = input.value;
    if (!String(v).trim()) { setMsg(L.emptyStep, 'err'); input.focus(); return; }
    var en = ensureTask(); if (!en.ok) return;
    var r = call('addStep', en.id, v, afterId ? { afterStepId: afterId } : {});
    if (!ok(r)) return;
    if (afterId) { S.insertAfter = r.step.id; S.focus = '.wt-insert-in'; } else { S.focus = '.wt-add-in'; }
    render();
  }
  function insertRow(plan, st, i) {
    var inp = h('input', { type: 'text', class: 'field-input wt-insert-in wt-mut', maxlength: String(LIM.step), placeholder: L.insertPh, 'aria-label': 'خطوة جديدة بعد الخطوة ' + an(i + 1), dir: 'auto', enterkeyhint: 'done',
      onkeydown: function (ev) { if (ev.key === 'Enter' && !ev.isComposing) { ev.preventDefault(); addStepFrom(inp, st.id); } } });
    return h('div', { class: 'wt-insert' }, [inp, h('div', { class: 'wt-insert-tools' }, [
      btn('btn btn-primary wt-sm wt-mut', L.insertDo, function () { addStepFrom(inp, st.id); }, { 'data-act': 'insert-do' }),
      btn('btn btn-ghost wt-sm', L.insertCancel, function () { S.insertAfter = null; render(); }, { 'data-act': 'insert-done' })
    ])]);
  }
  function stepRow(plan, st, i, n) {
    var last = st.text, ta;
    function commit(norm) {
      var v = ta.value; if (v === last) return;
      var r = call('editStep', st.id, v);
      if (ok(r)) { if (!r.noop && r.step) last = r.step.text; if (norm) { ta.value = last; autosize(ta); } }   // a debounced save never touches the text or the caret
      else { ta.value = last; autosize(ta); }
    }
    ta = h('textarea', { class: 'field-input wt-step-in wt-mut', rows: '1', maxlength: String(LIM.step), 'aria-label': 'نص الخطوة ' + an(i + 1), dir: 'auto',
      oninput: function () {
        autosize(ta);
        var o = S.stepTimers[st.id]; if (o) clearTimeout(o.t);
        S.stepTimers[st.id] = { commit: commit, t: setTimeout(function () { var cur = S && S.stepTimers[st.id]; if (cur) { delete S.stepTimers[st.id]; commit(false); } }, 1200) };
      },
      onchange: function () { var o = S && S.stepTimers[st.id]; if (o) { clearTimeout(o.t); delete S.stepTimers[st.id]; } commit(true); },
      onkeydown: function (ev) { if (ev.key === 'Enter' && !ev.shiftKey && !ev.isComposing) { ev.preventDefault(); ta.blur(); } }
    }, st.text);
    var mark = st.state === 'completed' ? '\u2713' : st.state === 'skipped' ? '\u21B7' : an(i + 1);
    return h('div', { class: 'wt-step ' + (st.state === 'completed' ? 'done' : st.state === 'skipped' ? 'skipped' : ''), 'data-step': st.id }, [
      h('div', { class: 'wt-step-main' }, [h('span', { class: 'wt-num', 'aria-hidden': 'true' }, mark), ta]),
      h('div', { class: 'wt-step-tools' }, [
        btn('hb-mv wt-ib wt-mut', '\u25B2', function () { moveStepBy(plan, st, -1); }, { 'aria-label': L.up + ' (الخطوة ' + an(i + 1) + ')', disabled: i === 0, 'data-act': 'up' }),
        btn('hb-mv wt-ib wt-mut', '\u25BC', function () { moveStepBy(plan, st, 1); }, { 'aria-label': L.down + ' (الخطوة ' + an(i + 1) + ')', disabled: i === n - 1, 'data-act': 'down' }),
        btn('hb-mv wt-ib wt-mut', '\uFF0B', function () { flushPending(); S.insertAfter = S.insertAfter === st.id ? null : st.id; S.focus = S.insertAfter ? '.wt-insert-in' : null; render(); }, { 'aria-label': 'إضافة خطوة بعد الخطوة ' + an(i + 1), 'data-act': 'ins' }),
        btn('hb-mv wt-ib wt-mut', '\u2715', function () { var r = call('deleteStep', st.id); if (ok(r)) { if (S.insertAfter === st.id) S.insertAfter = null; render(); } }, { 'aria-label': L.del + ' (الخطوة ' + an(i + 1) + ')', 'data-act': 'del' })
      ])
    ]);
  }
  function moveStepBy(plan, st, dir) {
    flushPending();
    var i = -1; plan.steps.forEach(function (s, k) { if (s.id === st.id) i = k; });
    if (i < 0) return;
    var r = call('moveStep', st.id, i + dir);
    if (ok(r)) { S.focus = arrowFocus('[data-step="' + st.id + '"]', dir); render(); }
  }

  /* -------- move an unfinished task to another day */
  function viewMove() {
    var plan = S.moveId ? eng().getTask(S.moveId) : null;
    if (!plan) { S.view = 'day'; return viewDay(); }
    var t = todayKey(), tm = addDays(t, 1), to = S.moveTo || (plan.dayKey === t ? tm : t), nodes = [];
    S.moveTo = to;
    var other = S.otherOpen || (to !== t && to !== tm);
    nodes.push(h('p', { class: 'desc wt-move-name', dir: 'auto' }, plan.title));
    nodes.push(h('div', { class: 'field-label' }, L.moveTo));
    nodes.push(h('div', { class: 'hb-chips wt-chips', role: 'group', 'aria-label': L.pickDay }, [
      chip(L.today, to === t && !S.otherOpen, function () { S.moveTo = t; S.otherOpen = false; render(); }),
      chip(L.tomorrow, to === tm && !S.otherOpen, function () { S.moveTo = tm; S.otherOpen = false; render(); }),
      chip(L.other, other, function () { S.otherOpen = true; S.focus = '.wt-date'; render(); })
    ]));
    if (other) nodes.push(h('input', { type: 'date', class: 'field-input wt-date', value: to, min: t, 'aria-label': L.pickDate, onchange: function (ev) { if (isDay(ev.target.value)) { S.moveTo = ev.target.value; S.otherOpen = true; render(); } } }));
    nodes.push(h('div', { class: 'field-hint wt-dayline' }, fmtDay(to, to.slice(0, 4) !== t.slice(0, 4))));
    nodes.push(h('div', { class: 'wt-actions' }, [
      btn('btn btn-primary wt-wide wt-mut', L.moveDo, function () { doMove(plan); }, { 'data-act': 'move-do' }),
      btn('btn btn-ghost wt-wide', L.cancel, function () { S.otherOpen = false; go(S.moveBack === 'task' ? 'task' : 'day', { taskId: S.moveBack === 'task' ? plan.id : null }); }, { 'data-act': 'move-cancel' })
    ]));
    return nodes;
  }
  function doMove(plan) {
    var to = S.moveTo, t = todayKey();
    if (!isDay(to) || to < t) { setMsg(L.pastMove, 'err'); return; }
    if (to === plan.dayKey) { setMsg(L.sameDay, 'err'); return; }
    var r = call('moveTask', plan.id, to);
    if (!ok(r)) return;
    toast('اتنقلت لـ ' + dayName(to) + (r.linkCleared ? ' واتفكّ ربطها بالمهمة السريعة' : ''));
    S.otherOpen = false; go('day', { day: to, taskId: null, moveId: null }); installHooks();
  }

  /* -------- delete with the app's own confirm dialog */
  function askDelete(plan) {
    if (typeof showConfirm !== 'function') { setMsg(L.err, 'err'); return; }
    showConfirm(L.confirmTitle, 'هتتحذف «' + plan.title + '» بكل خطواتها. الحذف نهائي.', function () {
      try {
        var r = call('deleteTask', plan.id); if (!ok(r)) return;
        toast(L.deleted);
        if (S) { if (S.taskId === plan.id) S.taskId = null; go('day', { day: plan.dayKey, taskId: null }); }
        linkCache = null; decorateRows();
      } catch (e) { report(e); }
    });
  }

  /* ----------------------------------------------------------------------------------------------- opening */
  function openRow(one) {
    if (S) close();
    mount(); S.view = 'row'; S.row = one; S.day = one.day; render();
    var b = S.body.querySelector('.wt-actions .btn'); if (b) b.focus(); else S.sheet.focus();
    return handle();
  }
  function handle() { return { ok: true, close: close, view: S ? S.view : null }; }
  /* openPlanner(opts) -> { ok:true, close(), view } | { ok:false, reason:'internal_error' }
       { taskId }                  the editor of that plan
       { oneoffId, title?, day? }  the plan linked to that TODAY quick task (editor), or a new draft linked to it (nothing is written until the user adds a step or a title)
       { day?, title? }            the day view (default today); `title` pre-fills the "new task" field */
  function openPlanner(opts) {
    try {
      opts = opts || {};
      var e = eng(), t = e.todayKey(), fresh = !S;
      if (fresh) mount();
      if (opts.taskId && e.getTask(opts.taskId)) { S.view = 'task'; S.taskId = opts.taskId; S.draft = null; S.moveBack = 'day'; }
      else if (opts.oneoffId) {
        var plan = e.getTaskByLink(opts.oneoffId);
        if (plan) { S.view = 'task'; S.taskId = plan.id; S.draft = null; S.moveBack = 'day'; }
        else { S.view = 'task'; S.taskId = null; S.draft = { title: String(opts.title || ''), oneoffId: String(opts.oneoffId), day: isDay(opts.day) ? opts.day : t }; S.moveBack = 'day'; }
      } else { S.view = 'day'; S.taskId = null; S.draft = null; S.day = isDay(opts.day) ? opts.day : t; S.newTitle = opts.title ? String(opts.title) : S.newTitle; }
      S.insertAfter = null; render();
      if (fresh) S.sheet.focus();
      return handle();
    } catch (err) {
      report(err);
      try { if (S) { var s = S; close(); if (s.overlay.parentNode) s.overlay.parentNode.removeChild(s.overlay); } } catch (x) { /* ignore */ }
      return { ok: false, reason: 'internal_error' };
    }
  }

  /* -------------------------------------------------------------------------------------------------- init */
  function init() {
    var R = document.getElementById('habitsRoot'), F = document.getElementById('hFab');
    if (R) { R.addEventListener('click', onRootClick, true); hooks.root = R; }
    if (F) { F.addEventListener('click', onFabClick); hooks.fab = F; }
    /* A user who already has plans gets the row badges back after a reload. The cheap key test below parses nothing and
       creates nothing: a profile that never used plans keeps the exact load footprint of the pristine page. */
    var raw = K.ls.get('wird_tasks_v1');
    if (raw && raw.length > 2) setTimeout(function () { installHooks(); }, 0);
  }
  function destroy() {
    close();
    if (hooks.root) hooks.root.removeEventListener('click', onRootClick, true);
    if (hooks.fab) hooks.fab.removeEventListener('click', onFabClick);
    if (hooks.observer) hooks.observer.disconnect();
    if (hooks.unsub) { try { hooks.unsub(); } catch (e) { /* ignore */ } }
    hooks.root = hooks.fab = hooks.observer = hooks.unsub = null; linkCache = null;
    var b = document.querySelectorAll('.wt-badge'), i; for (i = 0; i < b.length; i++) b[i].remove();
  }

  T.ui = {
    version: 1,
    openPlanner: openPlanner,
    closePlanner: close,
    isOpen: function () { return !!S; },
    refreshBadges: function () { try { linkCache = null; decorateRows(); } catch (e) { report(e); } },
    status: function () { return { rootHook: !!hooks.root, fabHook: !!hooks.fab, observer: !!hooks.observer, open: !!S, view: S ? S.view : null }; },
    lastError: function () { return lastError; },
    takeOrigin: function (taskId) { var o = origin; origin = null; return o && o.taskId === taskId ? { view: o.view, day: o.day } : null; },   // B4 hand-off, see startBtn
    destroy: destroy
  };
  /* #habitsRoot and #hFab are static markup that precede this block (the app's own script already assigns #hFab.onclick while
     parsing), so no DOMContentLoaded listener is needed: it would be a document listener created at load. */
  try { init(); } catch (e) { report(e); }
})();
