/* ==========================================================================================================
   tasks-exec.js — focused execution screen (B4 / TASK 1.3).   Public API: window.WirdTasks.exec
   ONE TASK -> ONE CURRENT STEP -> ONE ACTION.  An immersive full-screen view (own element, position:fixed; inset:0) that shows
   a small task-context line, ONE current step in large type and ONE primary action. No day list, no statistics, no settings,
   no "Step 2 of 8" text unless the user chose the "detailed" progress preference.

   Everything goes through the engine (WirdTasks.getEngine()) and WirdKit.h (no innerHTML). The engine owns the truth:
   the current step is derived from the steps and the event log, so closing the view, reloading the page or restarting the
   browser always restores the exact step (nothing is stored here). The view is NEVER opened at app start (interpretation I4);
   the planner offers «ابدأ» / «متابعة» (tasks-ui.js feature-detects WirdTasks.exec.open).

   Preferences are read from the session snapshot of the engine (getSessionPrefs): autoTransition, backNavigation, skipStep,
   editDuringExecution, timer, progress (hidden | subtle | detailed), completionAnimation (off | subtle), sound, haptic,
   microInteractions. The UI for editing them is B5; defaults are Minimal.

   Load-time footprint: NOTHING runs at load except the definition of T.exec. Listeners (document keydown, visualViewport,
   popstate), the timer interval and every timeout exist only while the view is open and are removed on close.
   Feedback (T-10): CSS-only, opacity/transform only, inside @media (prefers-reduced-motion: no-preference) (tasks-exec.css);
   when reduced motion is requested the swap is instant (no delay is added in JS either). No points, coins or streaks.
   Android Back: one history entry is pushed while the view is open and popstate closes it (the app has no history handling of
   its own, so nothing can conflict); if history is unavailable the explicit close button is the only exit.
   ========================================================================================================== */
(function () {
  'use strict';
  var T = window.WirdTasks, K = window.WirdKit;
  if (!T || !K) return;
  if (T.exec && T.exec.version >= 1) return;            // a re-evaluated block must never replace a live run

  /* ----------------------------------------------------------------------------------------------- strings */
  var L = {
    dialog: 'تنفيذ المهمة', close: 'إغلاق', pause: 'إيقاف مؤقت',
    done: '\u2713 تمّت', next: 'التالية', back: 'السابقة', skip: 'تخطّي', resume: '\u25B6 متابعة', finish: 'تمام',
    editStep: 'تعديل نص الخطوة', save: 'حفظ', cancel: 'إلغاء',
    undo: 'تراجع', recorded: 'اتسجّلت \u2713', skipped: 'اتخطّت',
    pausedTitle: 'موقوفة', pausedNote: 'تقدّمك محفوظ. كمّل لما تجهز.',
    doneTitle: 'خلصت المهمة', donePartial: 'خلصت — وفيه خطوات اتخطّت', doneSkipped: 'اتخطّيت كل الخطوات',
    progress: 'التقدّم', of: ' من ',
    undoExpired: 'فات وقت التراجع.', err: 'حصلت مشكلة. جرّب تاني.',
    notSaved: '\u26A0 التعديل ده لسه ما اتحفظش على الجهاز (ممكن المساحة مليانة).',
    readOnly: 'الخطط دي اتحفظت بنسخة أحدث من التطبيق، فمينفعش تتنفّذ هنا.',
    emptyStep: 'نص الخطوة فاضي. اكتب حاجة أو دوس إلغاء.',
    atFirst: 'دي أول خطوة.'
  };

  var LEAVE_MS = 170, ENTER_MS = 260;                    // transition phases (only used when motion is allowed)
  var LOCK_MOTION_MS = LEAVE_MS + ENTER_MS + 130;        // UI lock after a resolving tap: covers the whole transition
  var LOCK_STILL_MS = 350;                               // ... and the same protection when motion is reduced
  var X = null;                                          // the open run (null when closed)
  var lastError = null;
  var popPending = false;                                // a history.back() issued by close() has not been delivered yet

  /* -------------------------------------------------------------------------------------------- utilities */
  function report(e) { lastError = e; try { if (window.console && window.console.warn) window.console.warn('[wird-tasks-exec]', e && e.message ? e.message : e); } catch (x) { /* ignore */ } }
  function h() { return K.h.apply(K, arguments); }
  function eng() { return T.getEngine(); }
  function an(n) { try { return typeof toArabicNum === 'function' ? toArabicNum(n) : String(n); } catch (e) { return String(n); } }
  function isFinished(st) { return st === 'completed' || st === 'partial' || st === 'skipped'; }
  function fail(reason, extra) { var o = { ok: false, reason: reason }; if (extra) Object.keys(extra).forEach(function (k) { o[k] = extra[k]; }); return o; }
  function motionOk() { try { return !(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches); } catch (e) { return true; } }
  function animOk() { return !!X && motionOk() && !(X.prefs && X.prefs.completionAnimation === 'off'); }
  function limits() { return (T.engine && T.engine.LIMITS) || { title: 120, step: 300 }; }
  function pad2(n) { return (n < 10 ? '0' : '') + n; }
  function clock(ms) { var s = Math.max(0, Math.floor(ms / 1000)), m = Math.floor(s / 60); return an(pad2(m)) + ':' + an(pad2(s % 60)); }
  function btn(cls, label, onclick, extra) {
    var a = { type: 'button', class: cls, onclick: onclick };
    if (extra) Object.keys(extra).forEach(function (k) { a[k] = extra[k]; });
    return h('button', a, label);
  }
  function reasonText(r) {
    var why = r && r.reason;
    if (why === 'read_only') return L.readOnly;
    if (why === 'empty_text') return L.emptyStep;
    if (why === 'too_long') return 'النص طويل (الحد الأقصى ' + an(r.max || limits().step) + ' حرف).';
    if (why === 'at_first_step') return L.atFirst;
    return L.err;
  }
  function setMsg(text, kind) {
    if (!X || !X.msgEl) return;
    X.msgEl.textContent = text || '';
    X.msgEl.className = 'wx-msg' + (kind ? ' ' + kind : '');
    clearTimeout(X.msgT);
    if (text) X.msgT = setTimeout(function () { if (X && X.msgEl) { X.msgEl.textContent = ''; X.msgEl.className = 'wx-msg'; } }, 5000);
  }
  function lockFor(ms) { if (!X) return; X.lock = true; clearTimeout(X.lt); X.lt = setTimeout(function () { if (X) X.lock = false; }, ms); }

  /* ------------------------------------------------------------------------- the per-step stopwatch (timer preference) */
  function timerElapsed() { return X ? Math.max(0, X.acc + (X.t0 === null ? 0 : Date.now() - X.t0)) : 0; }
  function timerStop() { if (X && X.t0 !== null) { X.acc += Math.max(0, Date.now() - X.t0); X.t0 = null; } }
  function timerSync(stepId) {                           // the stopwatch counts the CURRENT step only: a different step starts from zero
    if (X.timerStep !== stepId) { X.timerStep = stepId; X.acc = 0; X.t0 = null; }
    if (X.t0 === null) X.t0 = Date.now();
  }
  function timerTick() { if (X && X.timerEl) X.timerEl.textContent = clock(timerElapsed()); }
  function timerDrop() { if (X && X.iv) { clearInterval(X.iv); X.iv = 0; } }

  /* ---------------------------------------------------------------------------------------------- history (Back) */
  function histOpen(x, inherited) {
    try {
      if (inherited) { x.hist = true; return; }
      if (popPending || !window.history || typeof window.history.pushState !== 'function') return;
      if (window.history.state && window.history.state.wirdExec) { x.hist = true; return; }   // a stale entry from before a reload: reuse it
      window.history.pushState({ wirdExec: 1 }, '');
      x.hist = true;
    } catch (e) { x.hist = false; report(e); }
  }
  function histClose(x) {
    try {
      if (!x.hist || !window.history || !(window.history.state && window.history.state.wirdExec)) return;
      var done = false, t = 0;
      var fin = function () { if (done) return; done = true; popPending = false; clearTimeout(t); window.removeEventListener('popstate', fin); };
      popPending = true; window.addEventListener('popstate', fin); t = setTimeout(fin, 1500);   // one-shot: removed again at once
      window.history.back();
    } catch (e) { report(e); }
  }
  function onPop() { var x = X; if (!x) return; x.hist = false; closeRun({ fromPop: true }); }

  /* ------------------------------------------------------------------------------------------------ keyboard */
  function focusables() {
    var n = X.overlay.querySelectorAll('button:not([disabled]),textarea:not([disabled]),input:not([disabled])'), out = [], i;
    for (i = 0; i < n.length; i++) if (n[i].offsetParent !== null || n[i] === document.activeElement) out.push(n[i]);
    return out;
  }
  function onKey(e) {
    if (!X) return;
    var co = document.getElementById('confirmOverlay'); if (co && co.classList.contains('open')) return;
    if (e.key === 'Escape') { e.preventDefault(); if (X.editing) cancelEdit(); else closeRun({}); return; }
    if (e.key !== 'Tab') return;
    var f = focusables(); if (!f.length) { e.preventDefault(); X.overlay.focus(); return; }
    var first = f[0], last = f[f.length - 1], a = document.activeElement;
    if (!X.overlay.contains(a)) { e.preventDefault(); first.focus(); }
    else if (e.shiftKey && (a === first || a === X.overlay)) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && a === last) { e.preventDefault(); first.focus(); }
  }
  function fitViewport() {                               // keep the whole view inside the visible area while the on-screen keyboard is open
    var vv = window.visualViewport; if (!vv || !X) return;
    if (vv.scale && vv.scale > 1.05) return;             // pinch-zoomed: leave the layout alone
    X.overlay.style.top = vv.offsetTop + 'px'; X.overlay.style.height = vv.height + 'px'; X.overlay.style.bottom = 'auto';
    var a = document.activeElement; if (a && X.overlay.contains(a) && a.scrollIntoView) { try { a.scrollIntoView({ block: 'nearest' }); } catch (e) { /* ignore */ } }
  }

  /* -------------------------------------------------------------------------------------------------- mounting */
  function mount(taskId, opts, inheritedHist) {
    var ctx = h('div', { class: 'wx-ctx', dir: 'auto' });
    var timerSlot = h('div', { class: 'wx-timer-slot' });
    var closeBtn = btn('wx-x', '\u2715', function () { closeRun({}); }, { 'aria-label': L.close, 'data-act': 'close' });
    var pauseBtn = btn('wx-pause', [h('span', { class: 'wx-bar', 'aria-hidden': 'true' }), h('span', { class: 'wx-bar', 'aria-hidden': 'true' })], onPause, { 'aria-label': L.pause, 'data-act': 'pause' });
    var top = h('div', { class: 'wx-top' }, [closeBtn, ctx, timerSlot, pauseBtn]);
    var prog = h('div', { class: 'wx-prog-slot' });
    var stage = h('div', { class: 'wx-stage' });
    var main = h('div', { class: 'wx-main', 'aria-live': 'polite' }, stage);
    var msg = h('div', { class: 'wx-msg', role: 'status', 'aria-live': 'polite' });
    var undoEl = h('div', { class: 'wx-undo', role: 'status', hidden: true });
    var actions = h('div', { class: 'wx-actions' });
    var ov = h('div', { class: 'wx-ov', role: 'dialog', 'aria-modal': 'true', 'aria-label': L.dialog, tabindex: '-1', 'data-wx': '1', 'data-anim': 'subtle' }, [top, prog, main, msg, undoEl, actions]);
    var from = opts && opts.from ? String(opts.from) : '';
    X = { overlay: ov, ctx: ctx, timerSlot: timerSlot, timerEl: null, pauseBtn: pauseBtn, progSlot: prog, stage: stage, msgEl: msg, msgT: 0, undoEl: undoEl, actions: actions,
          taskId: taskId, from: from, fromView: opts && opts.fromView ? String(opts.fromView) : '', fromDay: opts && opts.fromDay ? String(opts.fromDay) : '',
          opener: document.activeElement, prefs: null, view: '', stepId: null, hold: null, lock: false, lt: 0, tt: 0, ut: 0, iv: 0,
          undo: null, editing: false, ta: null, editStepId: null, editOrig: '', hist: false, acc: 0, t0: null, timerStep: null };
    document.body.appendChild(ov);
    document.addEventListener('keydown', onKey, true);
    if (window.visualViewport) { window.visualViewport.addEventListener('resize', fitViewport); window.visualViewport.addEventListener('scroll', fitViewport); fitViewport(); }
    histOpen(X, inheritedHist);
    if (X.hist) window.addEventListener('popstate', onPop);
  }

  /* ------------------------------------------------------------------------------------------------ rendering */
  function renderBody() {
    if (!X) return;
    var e = eng(), t = e.getTask(X.taskId);
    if (!t) { closeRun({ gone: true }); return; }                   // the plan was deleted meanwhile (another tab)
    X.prefs = e.getSessionPrefs(X.taskId);
    X.overlay.setAttribute('data-anim', X.prefs.completionAnimation === 'off' ? 'off' : 'subtle');
    if (X.prefs.microInteractions) X.overlay.setAttribute('data-micro', '1'); else X.overlay.removeAttribute('data-micro');
    X.ctx.textContent = t.title;
    K.dom.empty(X.stage); K.dom.empty(X.actions); K.dom.empty(X.timerSlot); K.dom.empty(X.progSlot);
    X.timerEl = null; X.editing = false; X.ta = null; X.stepId = null;
    timerDrop();
    var cur = e.getCurrent(X.taskId);
    if (t.status === 'paused') viewPaused(t);
    else if (X.hold && cur) viewHold(t, cur);
    else if (!cur || isFinished(t.status)) { X.hold = null; viewDone(t); }
    else viewRun(t, cur);
    renderProgress(t, cur);
  }
  function renderProgress(t, cur) {
    var mode = X.prefs.progress, c = cur ? cur.counts : t.counts;
    if ((mode !== 'subtle' && mode !== 'detailed') || !c || !c.total || X.view === 'paused') return;     // 'hidden' (default): no node at all
    var resolved = (c.completed || 0) + (c.skipped || 0), pct = Math.round(100 * resolved / c.total);
    var bar = h('div', { class: 'wx-prog', role: 'progressbar', 'aria-label': L.progress, 'aria-valuemin': '0', 'aria-valuemax': String(c.total), 'aria-valuenow': String(resolved) },
      h('span', { class: 'wx-prog-fill', style: { width: pct + '%' } }));
    var kids = [bar];
    if (mode === 'detailed') kids.push(h('span', { class: 'wx-prog-txt' }, an(resolved) + L.of + an(c.total)));
    X.progSlot.appendChild(h('div', { class: 'wx-prog-row' + (mode === 'detailed' ? ' detailed' : '') }, kids));
  }
  function secondary(list) { var l = list.filter(Boolean); return l.length ? h('div', { class: 'wx-sec' }, l) : null; }
  function setActions(primary, sec) { X.actions.appendChild(primary); if (sec) X.actions.appendChild(sec); }

  function viewRun(t, cur) {
    X.view = 'run'; X.pauseBtn.hidden = false;
    var step = cur.step, p = X.prefs;
    X.stepId = step.id;
    X.stage.appendChild(h('p', { class: 'wx-step', dir: 'auto', 'data-wx-step': step.id, tabindex: '-1' }, step.text));
    if (p.editDuringExecution) X.stage.appendChild(btn('wx-edit', '\u270E', startEdit, { 'aria-label': L.editStep, 'data-act': 'edit' }));
    if (p.timer) {
      timerSync(step.id);
      X.timerEl = h('span', { class: 'wx-timer', 'data-wx-timer': '1' }, clock(timerElapsed()));
      X.timerSlot.appendChild(X.timerEl);
      X.iv = setInterval(timerTick, 1000);
    } else { timerStop(); }
    var prim = btn('wx-primary', L.done, onDone, { 'data-act': 'done' });
    var back = p.backNavigation && step.index > 0 ? btn('wx-ghost', L.back, onBack, { 'data-act': 'back' }) : null;
    var skip = p.skipStep ? btn('wx-ghost', L.skip, onSkip, { 'data-act': 'skip' }) : null;
    setActions(prim, secondary([back, skip]));
  }
  function viewHold(t, cur) {                            // automatic transition OFF: the resolved step stays until «التالية» is tapped
    X.view = 'hold'; X.pauseBtn.hidden = false;
    timerStop();
    X.stage.appendChild(h('p', { class: 'wx-step done', dir: 'auto', 'data-wx-step': 'hold' }, X.hold.text));
    setActions(btn('wx-primary', L.next, onNext, { 'data-act': 'next' }), null);
  }
  function viewPaused(t) {
    X.view = 'paused'; X.pauseBtn.hidden = true; timerStop();
    X.stage.appendChild(h('div', { class: 'wx-paused' }, [
      h('div', { class: 'wx-pause-mark', 'aria-hidden': 'true' }, [h('span', { class: 'wx-bar' }), h('span', { class: 'wx-bar' })]),
      h('p', { class: 'wx-big' }, L.pausedTitle), h('p', { class: 'wx-note' }, L.pausedNote)
    ]));
    setActions(btn('wx-primary', L.resume, onResume, { 'data-act': 'resume' }), secondary([btn('wx-ghost', L.close, function () { closeRun({}); }, { 'data-act': 'close2' })]));
  }
  function viewDone(t) {
    X.view = 'done'; X.pauseBtn.hidden = true; timerStop(); X.timerStep = null;
    var title = t.status === 'skipped' ? L.doneSkipped : t.status === 'partial' ? L.donePartial : L.doneTitle;
    X.stage.appendChild(h('div', { class: 'wx-finished' }, [
      h('div', { class: 'wx-check', 'aria-hidden': 'true' }, '\u2713'),
      h('p', { class: 'wx-big' }, title), h('p', { class: 'wx-note', dir: 'auto' }, t.title)
    ]));
    var back = X.prefs.backNavigation ? btn('wx-ghost', L.back, onBack, { 'data-act': 'back' }) : null;
    setActions(btn('wx-primary', L.finish, function () { closeRun({}); }, { 'data-act': 'finish' }), secondary([back]));
  }

  /* a short fade between two renders; with reduced motion (or completionAnimation off) it is an immediate render */
  function swap() {
    if (!X) return;
    var st = X.stage;
    clearTimeout(X.tt); st.classList.remove('wx-enter', 'wx-leave');
    if (!animOk() || !st.firstChild) { renderBody(); focusPrimary(); return; }
    st.classList.add('wx-leave');
    X.tt = setTimeout(function () {
      if (!X) return;
      renderBody(); focusPrimary();
      st.classList.remove('wx-leave'); st.classList.add('wx-enter');
      X.tt = setTimeout(function () { if (X) { st.classList.remove('wx-enter'); X.tt = 0; } }, ENTER_MS + 40);
    }, LEAVE_MS);
  }
  function focusPrimary() {
    try { var p = X && X.actions.querySelector('.wx-primary'); if (p && X.overlay.contains(document.activeElement) || (p && document.activeElement === document.body)) p.focus(); } catch (e) { /* ignore */ }
  }

  /* ----------------------------------------------------------------------------------------- undo snackbar */
  function showUndo(kind, rec) {
    if (!X || !rec) return;
    var ms = 8000; try { ms = eng().status().undoWindowMs || 8000; } catch (e) { /* default */ }
    X.undo = { key: rec.key, kind: kind };
    K.dom.empty(X.undoEl);
    X.undoEl.appendChild(h('span', { class: 'wx-undo-msg' }, kind === 'skip' ? L.skipped : L.recorded));
    X.undoEl.appendChild(btn('wx-undo-btn', L.undo, onUndo, { 'data-act': 'undo' }));
    X.undoEl.appendChild(h('span', { class: 'wx-undo-bar', 'aria-hidden': 'true' }));
    X.undoEl.style.setProperty('--wx-undo-ms', ms + 'ms');
    X.undoEl.hidden = false;
    clearTimeout(X.ut); X.ut = setTimeout(hideUndo, ms);
  }
  function hideUndo() {
    if (!X) return;
    clearTimeout(X.ut); X.ut = 0; X.undo = null;
    X.undoEl.hidden = true; K.dom.empty(X.undoEl);
  }
  function onUndo() {
    if (!X || !X.undo) return;
    var u = X.undo, r = eng().undo(X.taskId, { key: u.key });
    hideUndo();
    if (r && r.ok) { X.hold = null; swap(); }
    else { setMsg(r && r.reason === 'window_expired' ? L.undoExpired : r && r.reason === 'paused' ? '' : L.err, 'warn'); }
  }

  /* ---------------------------------------------------------------------------------------------- actions */
  function feedback() {                                  // optional sound / haptic: both OFF by default, both only when the preference says so
    try { if (X.prefs.haptic) K.vibrate(20); } catch (e) { /* ignore */ }
    try { if (X.prefs.sound) K.audio.blip({ freq: 740, ms: 90 }); } catch (e) { /* ignore */ }
  }
  function resolveStep(kind) {
    if (!X || X.lock || X.editing) return;
    var e = eng(), t = e.getTask(X.taskId), sid = X.stepId;            // the step the user is LOOKING at, never "whatever is current now"
    if (!t) { renderBody(); return; }                                  // the plan vanished behind the view: renderBody closes it
    if (!sid || t.status !== 'in_progress') { renderBody(); return; }
    lockFor(motionOk() && X.prefs.completionAnimation !== 'off' ? LOCK_MOTION_MS : LOCK_STILL_MS);   // the lock starts BEFORE the engine call
    var opts = X.prefs.timer ? { elapsedMs: Math.round(timerElapsed()) } : undefined;
    var r = kind === 'skip' ? e.skip(sid, opts) : e.complete(sid, opts);
    if (!r.ok) {
      X.lock = false;
      if (r.reason === 'not_current' || r.reason === 'paused' || r.reason === 'not_started' || r.reason === 'already_resolved' || r.reason === 'not_found' || r.reason === 'deleted') { renderBody(); return; }
      setMsg(reasonText(r), 'err'); return;
    }
    if (r.noop) { X.lock = false; renderBody(); return; }              // already resolved elsewhere: record nothing, just show the real current step
    if (r.persisted === false) setMsg(L.notSaved, 'warn');
    if (kind === 'complete') feedback();
    showUndo(kind, r.record);
    var next = e.getCurrent(X.taskId);
    X.hold = (!X.prefs.autoTransition && next) ? { text: r.record.stepText || '', kind: kind } : null;
    if (animOk()) { var pb = X.actions.querySelector('.wx-primary'); if (pb) { pb.classList.add('wx-pop'); } }
    swap();
  }
  function onDone() { resolveStep('complete'); }
  function onSkip() { resolveStep('skip'); }
  function onNext() { if (!X || X.lock) return; lockFor(motionOk() ? 300 : 200); X.hold = null; swap(); }
  function onBack() {
    if (!X || X.lock || X.editing) return;
    lockFor(300);
    var r = eng().back(X.taskId);
    if (r.ok) { hideUndo(); X.hold = null; swap(); } else { X.lock = false; setMsg(reasonText(r), 'warn'); }
  }
  function onPause() {
    if (!X || X.editing) return;
    var r = eng().pause(X.taskId);
    if (r.ok) { hideUndo(); X.hold = null; clearTimeout(X.tt); X.stage.classList.remove('wx-enter', 'wx-leave'); renderBody(); try { var b = X.actions.querySelector('.wx-primary'); if (b) b.focus(); } catch (e) { /* ignore */ } }
    else setMsg(reasonText(r), 'err');
  }
  function onResume() {
    if (!X) return;
    var r = eng().resume(X.taskId);
    if (r.ok) { clearTimeout(X.tt); X.stage.classList.remove('wx-enter', 'wx-leave'); renderBody(); focusPrimary(); } else setMsg(reasonText(r), 'err');
  }

  /* ------------------------------------------------------------------------------------------ edit in the run */
  function autosize(ta) { ta.style.height = 'auto'; ta.style.height = (ta.scrollHeight + 2) + 'px'; }
  function startEdit() {
    if (!X || X.lock || X.editing) return;
    var e = eng(), cur = e.getCurrent(X.taskId); if (!cur) return;
    X.editing = true; X.editStepId = cur.step.id; X.editOrig = cur.step.text;
    K.dom.empty(X.stage); K.dom.empty(X.actions);
    var ta = h('textarea', { class: 'field-input wx-edit-in', rows: '2', maxlength: String(limits().step), 'aria-label': L.editStep, dir: 'auto', enterkeyhint: 'done',
      oninput: function () { autosize(ta); },
      onkeydown: function (ev) { if (ev.key === 'Enter' && !ev.shiftKey && !ev.isComposing) { ev.preventDefault(); saveEdit(); } } }, cur.step.text);
    X.ta = ta;
    X.stage.appendChild(ta);
    setActions(btn('wx-primary', L.save, saveEdit, { 'data-act': 'edit-save' }), secondary([btn('wx-ghost', L.cancel, cancelEdit, { 'data-act': 'edit-cancel' })]));
    autosize(ta); ta.focus(); try { ta.setSelectionRange(ta.value.length, ta.value.length); } catch (x) { /* ignore */ }
  }
  function saveEdit() {
    if (!X || !X.editing || !X.ta) return;
    var r = eng().editStep(X.editStepId, X.ta.value);
    if (!r.ok) { setMsg(reasonText(r), 'err'); X.ta.focus(); return; }
    if (r.persisted === false) setMsg(L.notSaved, 'warn');
    X.editing = false; renderBody(); focusPrimary();
  }
  function cancelEdit() { if (!X || !X.editing) return; X.editing = false; renderBody(); focusPrimary(); }

  /* ----------------------------------------------------------------------------------------- open and close */
  function closeRun(o) {
    var x = X; if (!x) return;
    o = o || {};
    if (x.editing && x.ta && !o.silent) {                // closing saves state: a valid, changed edit is kept, anything else is dropped
      try { var v = x.ta.value; if (String(v).trim() && v !== x.editOrig) eng().editStep(x.editStepId, v); } catch (e) { report(e); }
    }
    X = null;
    clearTimeout(x.tt); clearTimeout(x.lt); clearTimeout(x.ut); clearTimeout(x.msgT);
    if (x.iv) clearInterval(x.iv);
    try { document.removeEventListener('keydown', onKey, true); } catch (e) { /* ignore */ }
    try { window.removeEventListener('popstate', onPop); } catch (e) { /* ignore */ }
    if (window.visualViewport) { try { window.visualViewport.removeEventListener('resize', fitViewport); window.visualViewport.removeEventListener('scroll', fitViewport); } catch (e) { /* ignore */ } }
    var finished = false, dayKey = x.fromDay;
    try { var t = eng().getTask(x.taskId); if (t) { finished = isFinished(t.status); if (!dayKey) dayKey = t.dayKey; } } catch (e) { report(e); }
    if (x.overlay.parentNode) x.overlay.parentNode.removeChild(x.overlay);
    if (o.keepHist) { return { hist: x.hist }; }
    if (!o.fromPop) histClose(x);
    if (o.silent || o.gone) return null;
    var wentToPlanner = false;
    if (x.from === 'planner' && x.fromView !== 'row' && T.ui && typeof T.ui.openPlanner === 'function') {     // back to where the user came from
      try {
        var res = (finished || x.fromView === 'day') ? T.ui.openPlanner({ day: dayKey }) : T.ui.openPlanner({ taskId: x.taskId });
        wentToPlanner = !!(res && res.ok);
      } catch (e) { report(e); }
    }
    if (!wentToPlanner) { try { var op = x.opener; if (op && op !== document.body && op.isConnected && op.focus) op.focus(); } catch (e) { /* ignore */ } }
    try { if (T.ui && T.ui.refreshBadges) T.ui.refreshBadges(); } catch (e) { /* ignore */ }
    return null;
  }

  /* open(taskId, opts) -> { ok:true, close(), taskId } | { ok:false, reason }
       opts.from      'planner' (the planner calls this after closing itself) | anything else = no navigation on close
       opts.fromView  'day' | 'task' | 'row'  optional; when absent and from === 'planner' it is collected from WirdTasks.ui.takeOrigin(taskId)
       opts.fromDay   day key of the task (same rule); a missing origin means 'task' (the editor of that plan)
       opts.resume    false: open a PAUSED task in its paused state instead of resuming it (default: opening = coming back = resume)
     A not-started task is started (the engine takes the preference snapshot); an in-progress task continues at its exact step.
     Reasons: not_found, no_steps, finished, read_only, paused, internal_error (plus engine reasons). */
  function open(taskId, opts) {
    try {
      opts = opts || {};
      var e = eng(), t = e.getTask(taskId);
      if (e.status().readOnly) return fail('read_only');
      if (!t) return fail('not_found');
      if (!t.counts.total) return fail('no_steps');
      if (isFinished(t.status)) return fail('finished');
      var inherited = false, fromView = opts.fromView || '', fromDay = opts.fromDay || '';
      if (opts.from === 'planner' && !fromView) {          // the planner leaves its position behind (B3 contract: the call itself is just {from:'planner'})
        try { var og = T.ui && typeof T.ui.takeOrigin === 'function' ? T.ui.takeOrigin(taskId) : null; if (og) { fromView = og.view; fromDay = og.day; } } catch (x) { report(x); }
      }
      if (X) { var kept = closeRun({ silent: true, keepHist: true }); inherited = !!(kept && kept.hist); }
      try { if (T.ui && T.ui.isOpen && T.ui.isOpen()) T.ui.closePlanner(); } catch (x) { report(x); }
      var r = null;
      if (t.status === 'not_started') r = e.start(taskId);
      else if (t.status === 'paused' && opts.resume !== false) r = e.resume(taskId);
      if (r && !r.ok) return fail(r.reason);
      mount(taskId, { from: opts.from, fromView: fromView, fromDay: fromDay }, inherited);
      X.hold = null;
      renderBody();
      if (r && r.persisted === false) setMsg(L.notSaved, 'warn');
      try { X.overlay.focus(); } catch (x) { /* ignore */ }
      return { ok: true, close: function () { closeRun({}); }, taskId: taskId };
    } catch (err) {
      report(err);
      try { if (X) { var s = X; X = null; if (s.iv) clearInterval(s.iv); if (s.overlay.parentNode) s.overlay.parentNode.removeChild(s.overlay); document.removeEventListener('keydown', onKey, true); window.removeEventListener('popstate', onPop); } } catch (x) { /* ignore */ }
      return fail('internal_error');
    }
  }
  function resumeActive(opts) {                          // the unfinished task touched last (the resume target); used by later entry points
    try { var a = eng().getActiveTask(); if (!a) return fail('not_found'); return open(a.id, opts); } catch (e) { report(e); return fail('internal_error'); }
  }

  T.exec = {
    version: 1,
    open: open,
    resumeActive: resumeActive,
    close: function () { closeRun({}); },
    isOpen: function () { return !!X; },
    status: function () { return { open: !!X, taskId: X ? X.taskId : null, view: X ? X.view : null, stepId: X ? X.stepId : null, hold: !!(X && X.hold), undo: !!(X && X.undo), history: !!(X && X.hist), locked: !!(X && X.lock) }; },
    lastError: function () { return lastError; },
    destroy: function () { closeRun({ silent: true }); }
  };
})();
