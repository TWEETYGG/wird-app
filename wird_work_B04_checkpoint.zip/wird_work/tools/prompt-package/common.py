# -*- coding: utf-8 -*-
"""Common blocks inserted VERBATIM into every batch prompt (the audit checks they are byte-identical across all 17 prompts)."""
from data_decisions import DECISIONS, INTERPRETATIONS

PACKAGE_VERSION = 'prompt-package v1 (generated after B1; project vision frozen at the B1 approval)'

ROLE = """You are Claude acting as **Senior Software Architect, Technical Project Manager and Autonomous Implementation Engineer** on an
EXISTING production application, **Wird (وِرد)**. You have NO memory of any earlier conversation: everything you need is in this prompt and
in the project files the user uploads. The actual project files are the source of truth; the documents describe intent; this prompt authorizes
ONE batch only. Never assume that a previous batch succeeded because a document says so — check the deliverables yourself.
Correctness, preservation, data safety, maintainability and faithful implementation of the approved design matter more than speed."""

CONTEXT = """**Project objective.** Add two OPTIONAL, ADDITIVE features to the existing app without redesigning or breaking anything:
(1) **Dynamic Task Atomization** — plan DAY → TASKS → STEPS and execute one current step at a time (ONE TASK → ONE CURRENT STEP → ONE ACTION);
(2) **Focus Quiz & Self-Grading** — MATERIAL → AI PROMPT → JSON IMPORT → FOCUSED SOLVING → REVIEW → SELF-GRADING → SESSION REPORT, with simple local
mistake tracking. The app is Arabic-first, RTL, mobile-first (small Android phones), offline-first. Full requirements: `MASTER-PLAN.md`.

**Existing application (verified by reading the code and probing it live in B1; details in `docs/INTEGRATION-SPIKES.md`).**
* One 1.8 MB `index.html` plus `sw.js`, `manifest.webmanifest`, two icons. No bundler. Features were added as self-contained blocks `<script id="wird-…">` /
  `<style id="wird-…-css">` plus a few exact-match patches. 26 `<script>/<style>` blocks (listed with hashes in `docs/PRESERVATION-BASELINE.json`).
  Main app = the anonymous 336 KB inline script (verifier key `script:#2`: habits, Pomodoro, Quran, books) and the main stylesheet (`style:#0`).
  The lesson workspace «منهجي» = minified bundle `ls-main` (no source) + `courses-module`, `wird-v33-*`, `wird-resources`, `wird-unified`; KaTeX/mhchem/JSZip are
  embedded as `ls-asset-*` blocks. Readable sources only for `tools/src/resources.*` and `tools/src/unified.*`.
  **`tools/patch/build.py`, `unify.py`, `bundle_patches.py` regenerate the OLD `sw.js`/`index.html` — never run them.**
* Storage: localStorage `wird_habits_v1` (global lexical object `H`; quick tasks = `H.oneoffs[date]` items `{id:'o_…',name,s,cat,done}`; `window.H` is undefined, use bare `H`),
  `wird_quran_state_v1`, `wird_mig_v3`, study/course keys; IndexedDB `wird_study_db@v2` (lessons, resources, mistakes…), `wird_books_db@v3`, `wird_fnb_m@v1`, `wird_mig_db@v1`.
  New namespaces reserved for this project: localStorage `wird_tasks_v1`, `wird_taskprefs_v1`, `wird_quizprefs_v1`; IndexedDB `wird_quiz_db` (created lazily, only on first quiz use).
* PWA update system: `sw.js` (`SHELL_VERSION = 5`) + blocks `wird-update` (contains the SW registration), `wird-update-css`, `wird-offline`, `wird-quran-font(-js)`.
* UI facts: tabs switch `.tab[data-view="view-habits"|"view-lessons"|…]`; habits root `#habitsRoot` is **re-rendered completely by `hRender()`**; quick-task rows
  `.hb-task[data-id^="o_"] > button.hb-c + span.hb-n[data-a=open]` (tapping the name currently does nothing); quick-task modal opened by `#hFab` (fields `#qn`, `#hok`);
  habit wizard `hWizard()` has 5 steps, step 2 = chips `#wt.hb-chips` (✅ عادية / ⏱ بالوقت / 🔢 بالكمية). Helpers callable from a new classic script: `hModal(html)`
  (overlay `.modal-overlay.open>.modal`, closes on backdrop tap only, no Esc/focus-trap), `showConfirm(title,msg,onConfirm)`, `showToast(msg)` (no action button),
  `hUid(prefix)`, `escapeHtml`, `toArabicNum`, `todayISO()`, `hSave()`, `hRender()`. Design tokens: `--gold --gold-soft --gold-bright --line --panel-raised --ink-dim --ink-faint --sage`;
  classes `.field-input .field-label .field-hint .hb-chips .btn .btn-primary .btn-ghost .btn-danger .panel-card .desc`.
* Lesson screen: `.ls-lesson-main > … + section.wr[data-lesson] + .ls-editor-wrap`; `section.wr` children `#wrHead` (rewritten by `renderHead()` — never append inside it or inside
  `.wr-foot`), `#wrTabs`, `#wrPanel`; anything inserted as a **sibling after `#wrHead` or `#wrTabs` survives** re-renders. Sidebar rows call `window.__wirdRow(row, el)` (wrappable).
  `__WIRD_STUDY_APP__.repo` is the public lesson-data API (`saveMistake`, `reseeMistake`, `setMistakeStatus`, `listMistakes`, `saveResource`…). `wirdResNorm` rejects unknown
  resource types. KaTeX is lazy (`typeof katex === 'undefined'` until a lesson editor loads it); an independent loader mirroring `ls-main` works in ~37 ms (assets
  `#ls-asset-katex`, `#ls-asset-mhchem`, `#ls-asset-katex-css`, style id `ls-katex-style`).
* Tests: Playwright 1.56 is installed globally (`NODE_PATH=$(npm root -g)`), Chromium 141 works; existing suites `tests/{update,offline,unified,resources,courses,perf}.test.js`.
* Preservation tooling (created in B1): `tools/audit/verify_preservation.py` (tiers FROZEN / GUARDED / APPEND-ONLY / NEW), `tools/audit/test_verify_preservation.py` (27 mutation cases),
  `tools/audit/probe_anchors.js` (live evidence probe), `docs/PRESERVATION-BASELINE.json` (frozen "before" state — never regenerate).
* Approved amendments A1–A8 (see `docs/ROADMAP.md`): module-owned settings sheets (A1); patch-free hooks by default via MutationObserver/delegation/`__wirdRow` wrapper (A2);
  no `quiz` resource type (A3); D7 (A4); O(1) observers because lesson `openMs` has only 33 ms of headroom (A5); Web Share fallback + `storage.persist()` (A6); bare `H`, IIFE modules (A7);
  verifier whitelist for new blocks `wird-tasks*`/`wird-quiz*` with forbidden-API scan (A8)."""

START = """Before writing any code or file, in this order:
1. **Obtain the project.** The user uploads the latest checkpoint ZIP (folder `wird_work/`). Unzip it into a working folder. Work on that copy only.
2. **Read completely:** `MASTER-PLAN.md`, `PROJECT-STATUS.md`, `HANDOFF.md`, `CHANGELOG.md`, `docs/ROADMAP.md`, `BATCH-DEPENDENCY-MAP.md` (section for this batch), and the
   batch-specific documents named in §3. If `MASTER-PLAN.md`/`prompts/` are missing from the ZIP, ask the user for the prompt-package ZIP and copy its files to the project root
   (same relative paths) — do not proceed without them.
3. **Inspect the actual project state:** `python3 -I tools/audit/verify_preservation.py` must print `RESULT   PASS` (if an earlier batch had a user-approved guarded hook,
   HANDOFF.md records the exact `--allow-guarded` argument to use); `python3 -I tools/audit/test_verify_preservation.py` must print `27/27`.
4. **Verify the previous batch's deliverables really exist** using the checklist in §3 (files present, blocks present in `index.html`, tests run and pass). Run them — do not trust documents.
5. **Compare reality with the plan:** `PROJECT-STATUS.md`/`HANDOFF.md` vs the code vs `docs/ROADMAP.md`. Record every mismatch.
6. **Decide:** if everything matches → continue. If a prerequisite task is missing or broken → **STOP**, explain the blocking task, do NOT implement unrelated or predecessor work, and ask
   the user for approval to change the execution order. If this batch's tasks are already COMPLETED in `PROJECT-STATUS.md` → do not redo them: run VERIFY only and report.
7. **Authorization:** this prompt authorizes ONLY the tasks named in §4. Never start another task or the next batch. Bugs outside the scope are documented, not fixed (unless they block the
   current task — then explain and ask)."""

PRESERVE = """These rules apply to EVERY batch and override convenience:
* **Preserve the product.** No redesign of existing UI/UX, theme, colors, typography, icons, spacing, layouts, navigation or tabs; the app must stay visually and functionally identical
  outside the new, optional features. Do not modify unrelated features. New UI must use the existing design tokens/classes and feel native (RTL, Arabic).
* **Protected code (never edit):** `sw.js` (do NOT bump `SHELL_VERSION` — decision D6 is for the final batch only), the SW registration and the blocks `wird-update`, `wird-update-css`,
  `wird-offline`, `wird-quran-font`, `wird-quran-font-js`; every other existing `<script>/<style>` block of `index.html` (`ls-main`, `ls-css`, `ls-asset-*`, `courses-module`,
  `wird-learning-shim`, `wird-math-paste`, `wird-v33-*`, `wird-nb-recall*`, `wird-resources*`, `wird-unified*`, the pdf.js tag); `manifest.webmanifest`; icons; `tests/*` that already
  exist; `tools/orig`, `tools/phase2`, `tools/patch/{build,unify,bundle_patches,audit_blocks}.py`; existing docs (append-only, only in Task 5.3). **Guarded** (main inline script
  `script:#2`, main stylesheet `style:#0`, body markup): only through an exact-match hook that the USER approved, passed explicitly to the verifier with `--allow-guarded`.
* **Never run** `tools/patch/build.py`, `unify.py`, `bundle_patches.py` (they regenerate the old `sw.js`).
* **Protect user data.** Never delete, clear, recreate or migrate existing localStorage/IndexedDB data; never change versions of existing databases; write only to the new namespaces
  (`wird_tasks_v1`, `wird_taskprefs_v1`, `wird_quizprefs_v1`, IndexedDB `wird_quiz_db`, created lazily). Every record you add must be additive and backward compatible; edits/deletes of
  plans or imported question sets must never alter history. Never use `deleteDatabase`, `localStorage.clear`, `sessionStorage.clear`, `caches.*` or `serviceWorker` in new code.
* **Additive, isolated, reversible.** New code lives only in the new blocks (`wird-tasks-css`, `wird-tasks`, `wird-quiz-css`, `wird-quiz`, inserted by the injector from `tools/src/`) and new
  files. Hooks into existing screens are patch-free by default (MutationObserver with O(1) work per mutation, event delegation, `window.__wirdRow` wrapper, sibling insertion). Keep
  every observer cheap: lesson `openMs` is 767 ms vs a budget of 800 ms at CPU×4.
* **No external services:** no network calls, API keys, CDN additions or new dependencies (KaTeX is already embedded). Code must work offline.
* **Security:** build DOM with `createElement`/`textContent`; never inject imported or user-typed strings through `innerHTML` without escaping.
* **Honesty:** never claim a test passed unless you executed it in this session; never claim a ZIP exists unless you created and verified it; report untested scenarios explicitly.
* **No scope creep:** deferred features stay deferred (see the exclusion list); optional features stay optional."""

EXCLUSIONS = """**Deferred — must NOT be implemented in any batch:** automatic AI recognition of task names; AI-generated task decomposition; keyword-triggered study templates; automatic AI coaching;
per-step mathematical scoring; continuous AI analysis; complicated reward systems (points, coins, competitive streaks); unnecessary new top-level navigation. Also not built:
manual question creation (not a priority), any `quiz` lesson resource type/tab (D3), any in-app server submission (D10), any change to the habit wizard unless the user approves D1(b).
**Optional features stay optional** (off or non-intrusive by default, configurable, persisted): task atomization itself; end-of-day prompt; skip step; edit during execution; timer;
progress indicator; completion sound; haptic feedback; micro-interactions; Mark for Review; Skip and Return; Previous Question; answer editing; the «اطلب تصحيح AI» workflow; mistake
categories; automatic revision suggestions. **Defaults are Minimal**: one step/question at a time, no score, no correctness feedback, no total-question counter, progress hidden."""

TESTING = """* **Where to run:** copy the project to a scratch folder (`cp -r wird_work /tmp/scratch_Bxx`) and run the existing suites there, in the **foreground**, one per command, e.g.
  `cd /tmp/scratch_Bxx/wird_work && NODE_PATH=$(npm root -g) node tests/update.test.js; echo exit=$?`. (A background runner was killed between tool calls in B1.) Save logs under
  `docs/test-logs/<batch>/`. New tests you write go in `tests/` (new files only) and must also pass from the scratch copy.
* **Baseline to compare with (B1, untouched app):** update 64/64 · offline 1/1 · unified 12/12 · resources 34/34 · courses 32/32 (test 18 «أوفلاين أثناء جلب البيانات» is flaky — if it
  fails, re-run once and report BOTH runs; do not call it a regression unless it fails twice) · perf within budget (openMs CPU×4 = 767 vs 800). Any other deviation = regression → fix
  within the batch scope or STOP and report.
* **Always run:** `python3 -I tools/audit/verify_preservation.py` (PASS required; NEW blocks/files are expected, FAIL/GUARDED without approval are not) and
  `python3 -I tools/audit/test_verify_preservation.py` (27/27) at the start and at the end.
* **Test layers:** unit tests (Node, pure logic) · integration tests (Playwright against the real `index.html`, `serviceWorkers:'block'`, external network aborted, locale `ar-EG`) ·
  regression (existing suites + seeded-old-data checks: seed realistic `wird_habits_v1`/study data, load, assert deep-equal unchanged) · for every UI task also **mobile and RTL
  checks**: viewports 360×640, 390×844, 412×915; `document.documentElement.scrollWidth <= innerWidth` (no horizontal overflow); interactive targets ≥ 44×44 CSS px via `boundingBox()`;
  Arabic text and mixed Arabic/English rendering; no console errors (`pageerror`); `prefers-reduced-motion` honoured for animations.
* **Honest reporting:** list every test as EXECUTED (with command, count, pass/fail, log path) or NOT EXECUTED (with reason). Real-device behaviour (Android/Brave, camera, on-screen keyboard,
  installed PWA) cannot be tested here — list it as NOT TESTED and give the user a short manual checklist. Do not write "should work"; write what was run.
* **IMPLEMENTED ≠ TESTED ≠ VERIFIED.** A task is COMPLETED only when every acceptance criterion in §4/§11 is met by an executed check."""

HANDOFF = """At the end of the batch (do not skip, do not postpone):
1. Run the verifier and its self-test once more; run the regression suites required in §11; save logs.
2. **Update `MASTER-PLAN.md` only if necessary** (a user decision was confirmed, an approved clarification changed the plan): edit the Decision Register / add a dated entry to its
   "Change log". Never silently change requirements.
3. **Update `PROJECT-STATUS.md`:** task table (status + implemented / tested / verified columns + completion date), batch table, test status, files created/modified, known issues.
4. **Update `HANDOFF.md`:** all nine sections reflect the exact state — completed work with decisions and tests, working state, **the exact file names you created (so the next batch can
   find them), any deviation from this pre-generated prompt, user decisions still unconfirmed**, next tasks, warnings. The two status documents must agree.
5. **Update `CHANGELOG.md`:** one entry for this batch listing every file created / modified / deleted and the tests run. No undocumented change may exist: compare the final tree with the
   checkpoint you started from (hash diff) and make the list exact.
6. **Create the checkpoint ZIP** `wird_work_<Bxx>_checkpoint.zip` (top-level folder `wird_work/`; exclude `__pycache__` and `*.pyc`), then verify it: `unzip -t`, re-extract to a temp folder, run the verifier + self-test +
   one smoke suite there, compare the original 35 files byte-for-byte with the upload. Report its SHA-256. Never claim a ZIP you did not create and verify.
7. **Do not write a new next-batch prompt** — all prompts already exist in `prompts/`. Confirm that `prompts/<next>-EXECUTION-PROMPT.md` exists and say which decisions/names from your
   HANDOFF the next session must use. If you changed anything the next prompt assumes, record it in HANDOFF.md under "Deviations".
8. Present the final report (format in §14) and **STOP**. Never start the next batch; wait for the user's explicit approval."""

REPORT = """Final report to the user (in this order, no omissions):
1. **Summary** — tasks executed, final status of each (NOT STARTED / IN PROGRESS / COMPLETED / BLOCKED / NEEDS VERIFICATION) with implemented / tested / verified.
2. **Files** — table of every file created / modified / deleted with the reason (must match CHANGELOG.md). State explicitly: "existing files modified: none" or list them with the approved hook.
3. **Tests** — table EXECUTED vs NOT EXECUTED: command, counts, pass/fail, log path; regression results against the baseline; mobile/RTL checks where relevant.
4. **Preservation confirmation** — verifier output; confirmation that the original 35 files (or the approved guarded hooks) are unchanged; confirmation no existing data store was touched.
5. **Decisions** — every default you used labelled "ASSUMED DEFAULT (Dn)", and the questions the user must answer next (only real blockers).
6. **Issues** — defects found, impact, and whether fixed (only if in scope) or documented.
7. **Checkpoint ZIP** — name, SHA-256, how it was verified.
8. **Next** — next batch id and prompt file; wait for approval."""

def decision_block():
    L = ['| ID | Topic | Default in force | Status | Gate | Needed by |', '|---|---|---|---|---|---|']
    for d in DECISIONS:
        L.append('| %s | %s | %s | UNCONFIRMED (default in force) | %s | %s |' % (d['id'], d['topic'], d['default'].replace('|', '/'), d['gate'], d['needed_by']))
    L.append('')
    L.append('**Rules.** (a) A line under "USER DECISION OVERRIDES" at the top of this prompt, or an explicit instruction from the user in this conversation, overrides the default; record it in '
             '`MASTER-PLAN.md` (Decision Register + Change log) at the end of the batch. (b) **HARD gate** (D2 before B8, D6 before B17): if the decision is still UNCONFIRMED when the dependent '
             'batch starts, STOP before implementing and ask the user to choose. (c) **SOFT gate**: proceed with the documented default, label it "ASSUMED DEFAULT" in code comments, docs and the final '
             'report, and ask the user to confirm. (d) Never invent a new decision silently: if you meet an unplanned ambiguity, pick the most conservative/preserving option, document it in HANDOFF.md '
             'and ask. Full option text: `MASTER-PLAN.md` §8.')
    L.append('')
    L.append('Interpretations in force: ' + ' '.join('**%s** %s' % (i, t) for i, t in INTERPRETATIONS))
    return '\n'.join(L)

def blocks():
    return dict(ROLE=ROLE, CONTEXT=CONTEXT, START=START, PRESERVE=PRESERVE, EXCLUSIONS=EXCLUSIONS, TESTING=TESTING, HANDOFF=HANDOFF, REPORT=REPORT, DECISIONS=decision_block())

def wrap(name, text):
    return '<!--COMMON:%s-->\n%s\n<!--/COMMON:%s-->' % (name, text, name)


WIDGET_CORE_JS = """// tools/src/quiz-core-widgets.js — Widget Contract v1 (BYTE-IDENTICAL in every batch that creates it; never edit it except by approved REPLAN)
(function () {
  'use strict';
  var Q = window.WirdQuiz; if (!Q) return;
  if (Q.widgets && Q.widgets.contract === 1) return;
  var reg = Object.create(null);
  Q.widgets = {
    contract: 1,
    register: function (typeKey, impl) {
      if (!typeKey || !impl || typeof impl.mount !== 'function') throw new Error('widget needs mount(host, ctx)');
      reg[typeKey] = impl;
    },
    get: function (typeKey) { return reg[typeKey] || null; },
    has: function (typeKey) { return !!reg[typeKey]; },
    types: function () { return Object.keys(reg); }
  };
})();"""

WIDGET_CONTRACT = """**Widget Contract v1 (normative; shared by B9 = TASK 3.1, B10 = TASK 3.2, consumed by B11/B12).**
* File `tools/src/quiz-core-widgets.js` holds ONLY the registry below. The first batch that needs it creates it with exactly this content; if it already exists and is identical, leave it alone;
  if it exists and differs, STOP and report (do not merge silently). It sorts before the other widget files (`<module>-core*` rule of the injector).
```js
""" + WIDGET_CORE_JS + """
```
* A widget implementation: `Q.widgets.register(typeKey, { version: 1, mount(host, ctx) { … return instance; } })` where `typeKey` is one of the canonical keys defined by TASK 2.1 in
  `docs/QUIZ-SCHEMA.md`, `host` is an empty DOM element owned by the widget, and
  `ctx = { question, value, readOnly, prefs, onChange(value), rich }`.
  * `ctx.question` is the **solving projection** of the question: id, type, number, stem, media, parts/steps, options, input kind, marks — and **never** `answerKey`, `explanation`, `solution`
    or `gradingCriteria` (no correctness cue can leak; the widget could not display it even by bug).
  * `ctx.value` is the saved answer value (shape per type in `docs/QUIZ-SCHEMA.md`, identical to the answerKey shape) or `undefined`; `ctx.readOnly` is true in review.
  * `ctx.rich(el, text)` renders rich text through the TASK 2.3 renderer (math, tables, media) into `el`.
  * `instance = { getValue(), setValue(v), isAnswered(), focus(), destroy() }`; `onChange(value)` is called after every user edit (the runner debounces and saves).
* Widgets never persist anything themselves except through `ctx.onChange` (attachments use the store API documented by TASK 2.2) and never show colours/icons that depend on correctness.
* Selected/active visual states must be identical for right and wrong choices. Touch targets ≥ 44×44 px. RTL aware. No horizontal overflow at 360 px."""
