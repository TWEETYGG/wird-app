#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Generates: prompts/B01..B17-EXECUTION-PROMPT.md, MASTER-PLAN.md, BATCH-DEPENDENCY-MAP.md, TRACEABILITY-MATRIX.md, PROMPT-USAGE-GUIDE.md
usage: python3 -I tools/prompt-package/build_package.py [--root PROJECT_ROOT]      (idempotent; overwrites only the generated files)"""
import os, sys, re, datetime
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pkg_lib as L
from common import blocks, wrap, PACKAGE_VERSION, WIDGET_CONTRACT, WIDGET_CORE_JS
from data_decisions import DECISIONS, INTERPRETATIONS, SHORT_DEFAULTS
from data_requirements import REQUIREMENTS

ROOT = L.ROOT
if '--root' in sys.argv: ROOT = os.path.abspath(sys.argv[sys.argv.index('--root') + 1])
BATCHES = L.load_batches(); CARDS = L.load_cards(ROOT); T2B = L.task_batch_map(BATCHES); BY = {b['id']: b for b in BATCHES}
CL = L.closure(BATCHES); COMMON = blocks()
DATE = '2026-11-03'

PART13_TASKS = ['Create a task with multiple steps.','Edit a step.','Delete a step.','Reorder steps.','Execute one step.','Confirm automatic transition.','Return to the previous step.','Skip a step when skipping is enabled.','Pause and resume.','Close and reopen the app.','Confirm exact state restoration.','Finish all tasks scheduled for one day.','Confirm the optional next-day prompt.','Verify no duplicate completion records.','Verify all preferences persist.']
PART13_QUIZ = ['Copy the saved AI Prompt.','Import valid JSON.','Import invalid JSON and verify clear errors.','Import all supported question types.','Render mathematical notation.','Display diagrams and images.','Attach a handwritten answer image.','Navigate questions.','Use Mark for Review.','Skip and return.','Confirm answers are preserved.','Close and reopen the app.','Resume an unfinished session.','Finish a session with an answer key.','Finish a session without an answer key.','Manually grade answers.','Leave answers awaiting grading.','Export the complete answer sheet.','Generate optional AI grading material.','Verify correct report calculations.','Verify mistake tracking.','Verify settings persist.']
PART13_REGRESSION = ['Existing task management still works.','Existing habit tracking still works.','Existing lesson pages still work.','Existing Notes and Summary functionality still works.','Existing study materials remain intact.','Existing Quran and Wird functionality still works.','Existing offline functionality still works.','No existing data is deleted.','The new features do not break the PWA update system.','The app works properly on mobile.']
PART14 = ['The complete modified project as a ZIP.','A list of every modified, created and deleted file.','A precise explanation of every modification.','Confirmation that existing application features were preserved.','Confirmation that existing user data was preserved.','The final JSON schema.','The reusable fixed AI prompt.','The implementation and testing report.','Instructions for importing questions.','Instructions for using task atomization.','A list of deferred features.']

def fmt_doc(d):
    m = re.match(r'^(\S+)(?: \((.*)\))?$', d)
    return ('`%s`' % m.group(1) + (' — ' + m.group(2) if m.group(2) else '')) if m else '`' + d + '`'

def num(items): return '\n'.join('%d. %s' % (i, t) for i, t in enumerate(items, 1))
def bullets(items): return '\n'.join('* ' + t for t in items)
def rep(t): return t.replace('{{WIDGET_CONTRACT}}', WIDGET_CONTRACT)

def reqs_for(batch):
    ts = set(batch['tasks']); prim, ver = [], []
    for r in REQUIREMENTS:
        if r['impl'] == ['ALL']: continue
        if ts & set(r['impl']): prim.append(r)
        elif ts & set(r['verify']): ver.append(r)
    return prim, ver

def build_prompt(b):
    P = []
    nxt = b['next']
    prereq = ', '.join(b['prereq_batches']) if b['prereq_batches'] else 'none (first batch)'
    P.append('# %s EXECUTION PROMPT — %s\n' % (b['id'], b['title']))
    P.append('> **Package:** %s  \n> **Authorizes ONLY:** %s  \n> **Phase:** %s · **Requires completed batches:** %s · **Next batch:** %s  \n> **How to use:** open a NEW Claude conversation, upload the latest project checkpoint ZIP (and, if it lacks `MASTER-PLAN.md`/`prompts/`, the prompt-package ZIP), then paste this entire file. Do not paste more than one batch prompt into one conversation.\n' % (
        PACKAGE_VERSION, ' + '.join('TASK ' + t for t in b['tasks']), b['phase'], prereq, nxt or 'none (final batch)'))
    P.append('**USER DECISION OVERRIDES** (edit before pasting; "(none)" means: accept the defaults of §9): (none)\n')
    if b.get('status_note'): P.append(b['status_note'] + '\n')
    P.append('---\n\n## 1. ROLE AND MODE\n\n' + wrap('ROLE', COMMON['ROLE']) + '\n')
    P.append('## 2. PROJECT CONTEXT\n\n' + wrap('CONTEXT', COMMON['CONTEXT']) + '\n')
    P.append('## 3. SESSION START — mandatory verification before any work\n\n' + wrap('START', COMMON['START']) + '\n')
    P.append('### 3.1 Documents to read for this batch (in addition to those in the procedure above)\n\n' + bullets(['`docs/ROADMAP.md` — the normative task cards (§4 embeds yours verbatim)'] + [fmt_doc(d) for d in b['docs_extra']]) + '\n')
    P.append('### 3.2 Previous-batch deliverables to verify (run them; do not trust documents)\n\n' + bullets(b['prereq']) + '\n\n_File names mentioned in this prompt are conventions of the plan: if the previous batch chose different names, `HANDOFF.md` (sections "Completed work" and "Deviations") records them — use those._\n')
    P.append('## 4. AUTHORIZED SCOPE (exact)\n\n**This batch authorizes: %s — nothing else.** Goal: %s\n\n### 4.1 Task definitions (verbatim from `docs/ROADMAP.md`; do not reinterpret them)\n' % (' and '.join('TASK ' + t for t in b['tasks']), b['goal']))
    for t in b['tasks']:
        P.append('<!--CARD:%s-->\n%s\n<!--/CARD:%s-->\n' % (t, CARDS[t]['text'], t))
    P.append('Dependencies of these tasks: ' + '; '.join('TASK %s ← %s' % (t, ', '.join(CARDS[t]['depends']) or 'none') for t in b['tasks']) + '. Each dependency must be verified COMPLETED (§3) before you start; never assume.\n')
    P.append('## 5. IMPLEMENTATION REQUIREMENTS FOR THIS BATCH\n\n' + '\n\n'.join(rep(x) for x in b['impl']) + '\n')
    P.append('## 6. FILES\n\n**Expected to be created:**\n' + bullets(b['files_new']) + '\n\n**Expected to be modified (and only these):**\n' + bullets(b['files_mod']) + '\n\nAnything else that changes is an undocumented change: list it, justify it, or revert it. Compare the final tree with the starting checkpoint by hash to prove the list is exact.\n')
    P.append('## 7. EXPLICIT EXCLUSIONS\n\n**For this batch:**\n' + bullets(b['exclusions']) + '\n\n**Global:**\n\n' + wrap('EXCLUSIONS', COMMON['EXCLUSIONS']) + '\n')
    P.append('## 8. PRESERVATION CONSTRAINTS\n\n' + wrap('PRESERVE', COMMON['PRESERVE']) + '\n')
    P.append('## 9. DECISIONS (defaults in force)\n\n' + wrap('DECISIONS', COMMON['DECISIONS']) + '\n')
    prim, ver = reqs_for(b)
    s = '## 10. REQUIREMENTS COVERED BY THIS BATCH (from `MASTER-PLAN.md` §6; full register there)\n\n**Implemented here (%d):**\n' % len(prim)
    s += '\n'.join('* **%s** [%s] %s' % (r['id'], r['kind'], r['text']) for r in prim) if prim else '* (none — verification/tooling batch)'
    s += '\n\n**Verified here, implemented elsewhere (IDs):** ' + (', '.join(r['id'] for r in ver) if ver else '(none)')
    s += '\n\n**Cross-cutting constraints that apply to every batch:** PRES-01…PRES-07, PROC-01…PROC-05, TS-04.\n'
    P.append(s)
    t = b['tests']
    s = '## 11. VERIFICATION\n\n**Acceptance criteria (all must be met by executed checks):**\n' + bullets(b['accept']) + '\n\n**Required tests**\n'
    s += '* **Unit:** ' + ' '.join(t['unit']) + '\n* **Integration:** ' + ' '.join(t['integration']) + '\n* **Regression:** ' + ' '.join(t['regression']) + '\n* **Mobile / RTL:** ' + ' '.join(t['mobile_rtl']) + '\n'
    if b.get('part13') in ('tasks', 'final'):
        s += '\n**Part-13 Task Atomization tests (each must be reported EXECUTED or NOT EXECUTED):**\n' + num(PART13_TASKS) + '\n'
    if b.get('part13') in ('quiz', 'final'):
        s += '\n**Part-13 Focus Quiz tests (each must be reported EXECUTED or NOT EXECUTED):**\n' + num(PART13_QUIZ) + '\n'
    if b.get('part13') in ('tasks', 'quiz', 'final'):
        s += '\n**Part-13 regression list:**\n' + num(PART13_REGRESSION) + '\n'
    if b.get('part13') == 'final':
        s += '\n**Part-14 final deliverables (all must exist):**\n' + num(PART14) + '\n'
    s += '\n**Test protocol (common):**\n\n' + wrap('TESTING', COMMON['TESTING']) + '\n'
    P.append(s)
    P.append('## 12. PARALLELISM AND SHARED FILES\n\n' + b['parallel'] + '\n\nGraph and merge rules for the whole plan: `BATCH-DEPENDENCY-MAP.md`.\n')
    P.append('## 13. END-OF-BATCH HANDOFF\n\n' + wrap('HANDOFF', COMMON['HANDOFF']) + '\n\n**Batch-specific handoff content:**\n' + bullets(b['handoff_extra']) + '\n')
    P.append('## 14. FINAL REPORT FORMAT\n\n' + wrap('REPORT', COMMON['REPORT']) + '\n')
    P.append('## 15. NEXT BATCH\n\n' + ('Next: **%s** — file `prompts/%s-EXECUTION-PROMPT.md` (tasks: %s). **Do not start it.** Wait for the user’s explicit approval, then the user will open a new conversation with that prompt.' % (nxt, nxt, ' + '.join('TASK ' + t for t in BY[nxt]['tasks'])) if nxt else 'This is the final batch. After the final report, stop and wait for the user.') + '\n')
    return '\n'.join(P)

# ---------------------------------------------------------------------------------------------------------------------------------
def build_master():
    M = []
    M.append('''# MASTER-PLAN — Wird: Dynamic Task Atomization + Focus Quiz & Self-Grading

**Authoritative project specification.** Package: %s. Prepared on %s (container clock). Generated sections (§6 requirements, §8 decisions, §10 roadmap index) come from `tools/prompt-package/*` — edit the data files and re-run `python3 -I tools/prompt-package/build_package.py`, or record changes in §12 by hand when a session is told to.

**Order of authority when documents disagree:** (1) the user’s latest explicit instruction; (2) the actual project files — for *what exists*; (3) this MASTER-PLAN — for *what must be built and why*; (4) `docs/ROADMAP.md` — the normative task cards; (5) the batch prompts in `prompts/`; (6) `PROJECT-STATUS.md`/`HANDOFF.md` — for state, always verified against the files. A session that finds a contradiction must STOP and report it; it never resolves it silently.

**Companion documents:** `docs/ROADMAP.md` (24 task cards + amendments A1–A8) · `BATCH-DEPENDENCY-MAP.md` · `TRACEABILITY-MATRIX.md` · `PROMPT-USAGE-GUIDE.md` · `PROJECT-STATUS.md` · `HANDOFF.md` · `CHANGELOG.md` · `docs/INTEGRATION-SPIKES.md` (evidence) · `docs/BASELINE-TEST-RESULTS.md` (baseline).
''' % (PACKAGE_VERSION, DATE))
    M.append('''## 1. Vision

Wird (وِرد) is a production, Arabic-first, RTL, mobile-first, offline-first PWA (Quran/worship tracking, habits and quick tasks, Pomodoro, and the study workspace «منهجي»). This project extends it with two **optional, additive** systems without redesigning anything:

1. **Dynamic Task Atomization** — divide a task into steps, organize them by day (DAY → TASKS → STEPS) and execute them through a focused view that shows ONE current step at a time. *ONE TASK → ONE CURRENT STEP → ONE ACTION.*
2. **Focus Quiz & Self-Grading** — MATERIAL → AI PROMPT → JSON IMPORT → FOCUSED SOLVING → REVIEW → SELF-GRADING → SESSION REPORT, using a reusable prompt with an external AI (no API keys, no paid calls), an immersive one-question-at-a-time solving view, review with or without an answer key, a fair session report and simple local mistake tracking.

**Final product principle (the user’s words):** for tasks — "I know what I need to do. Show me the next step."; for studying — "I know what I need to solve. Show me the next question."; for evaluation — "Let me finish first. I will evaluate afterward." Wird should remove unnecessary decisions from the user’s path. *Preserve the existing product; improve how the user interacts with it; do not turn the application into something else.*

Priorities in order: correctness · preservation · data safety · maintainability · faithful implementation of the approved design · speed (last).
''')
    M.append('''## 2. Scope

**First release (mandatory):** everything in §6 whose kind is MANDATORY/PRESERVATION/PROCESS, plus the OPTIONAL items implemented as optional (configurable, off or non-intrusive by default). **Optional features:** the atomization feature itself, end-of-day prompt, skip step, edit during execution, timer, progress indicator, sound, haptic, micro-interactions, Mark for Review, Skip and Return, Previous Question, answer editing, «اطلب تصحيح AI», mistake categories, automatic revision suggestions. **Conditional:** if the user does not want automatic suggestions the feature stays disabled (MT-03); if no answer key exists the app must not invent one (G-04). **Deferred (must not be built):** the eight items DF-01…DF-08 (automatic AI recognition of task names, AI task decomposition, keyword-triggered templates, automatic AI coaching, per-step math scoring, continuous AI analysis, complicated reward systems, unnecessary new top-level navigation). **Not built:** manual question creation (Q-05), a `quiz` lesson resource type (D3), server submission (D10), changes to the habit wizard (T-02) unless D1(b) is approved.
''')
    M.append('''## 3. Preservation constraints (summary — the full text is embedded in every prompt, §8)

* Existing UI/UX/theme/navigation/features/data are preserved; new work is additive, isolated, reversible.
* **Never touched:** `sw.js` (no `SHELL_VERSION` bump before D6 at B17), the SW registration and `wird-update`, `wird-update-css`, `wird-offline`, `wird-quran-font(-js)`; every other existing block of `index.html`; manifest; icons; existing tests/tools/docs (docs append-only in 5.3). **Guarded:** `script:#2`, `style:#0`, markup — only by user-approved exact-match hooks.
* **Never run:** `tools/patch/build.py`, `unify.py`, `bundle_patches.py`.
* **Data:** never clear/recreate/migrate existing localStorage/IndexedDB; new namespaces only (§7.2).
* **Tooling that enforces it:** `tools/audit/verify_preservation.py` + `docs/PRESERVATION-BASELINE.json` (frozen "before" state; never regenerated) + `tools/audit/test_verify_preservation.py` (27 mutation cases).
''')
    M.append('''## 4. Existing application — verified architecture

''' + COMMON['CONTEXT'] + '\n')
    M.append('## 5. Roadmap shape\n\n6 phases, 24 tasks, 17 batches; task cards in `docs/ROADMAP.md`; batch graph in `BATCH-DEPENDENCY-MAP.md`; the generated index is in §10.\n')
    M.append('## 6. Requirement register\n\nKinds: MANDATORY, OPTIONAL (must stay optional), CONDITIONAL, PRESERVATION, PROCESS, DEFERRED / EXCLUDED (must NOT be built). `impl` = implementing tasks; `verify` = verifying tasks. Traceability to batches: `TRACEABILITY-MATRIX.md`.\n')
    g = None
    for r in REQUIREMENTS:
        if r['group'] != g:
            g = r['group']; M.append('\n### ' + g + '\n')
        M.append('* **%s** [%s] %s _(impl: %s · verify: %s)_' % (r['id'], r['kind'], r['text'], 'ALL' if r['impl'] == ['ALL'] else (', '.join(r['impl']) or '—'), ', '.join(r['verify']) or '—'))
    M.append('''

## 7. Technical contracts (normative for all batches)

### 7.1 Modules and injection
New code lives in four blocks inserted by `tools/patch/inject_wird_modules.py` immediately before `<script id="wird-offline">`: `style#wird-tasks-css`, `script#wird-tasks`, `style#wird-quiz-css`, `script#wird-quiz`. Sources are `tools/src/wird-kit.js` (prepended to both blocks, single guarded instance `window.WirdKit`), `<module>-shell.js`, `<module>-core*.js`, then all other `<module>-*.js` in lexicographic order; CSS: `<module>.css` then `<module>-*.css`. Load-time code may depend only on files earlier in that order. Modules are IIFEs exposing only `window.WirdTasks` / `window.WirdQuiz`; habits state is read by bare `H`. **`index.html` is regenerated by the injector from `tools/src/`; it is never hand-merged.**

### 7.2 Storage namespaces
localStorage: `wird_tasks_v1` (plans, days, steps, execution, history, schemaVersion), `wird_taskprefs_v1`, `wird_quizprefs_v1`. IndexedDB: `wird_quiz_db` v1, created lazily on first quiz use, stores `sessions`, `answers`, `images`, `gradings`, `reports`, `mistakes`. Nothing else may be written; existing databases/keys/versions never change.

### 7.3 Hooks into existing screens (patch-free by default)
* Habits: capture-phase delegation + MutationObserver on `#habitsRoot` / `.modal-overlay.open` (quick-task modal `#qn`/`#hok`), owner B3.
* Lessons: MutationObserver for `section.wr[data-lesson]`; inject a sibling after `#wrHead` (never inside `#wrHead`/`.wr-foot`); optional `window.__wirdRow` wrapper; owner B8.
* Every observer is O(1) per mutation (lesson `openMs` headroom is 33 ms). A guarded patch of `script:#2` needs the user’s approval and `--allow-guarded script:#2`.

### 7.4 Task engine
Defined by TASK 1.1 and documented in `docs/TASKS-ENGINE.md` (model, events, storage format). Pure logic, injected dependencies, idempotent completion, append-only events, tombstones, schemaVersion, degraded mode instead of throwing. Undo window constant `UNDO_WINDOW_MS` (I3).

### 7.5 Quiz schema
`wird.quiz/1`, defined by TASK 2.1 and documented in `docs/QUIZ-SCHEMA.md`: canonical type keys for the 14 types, answer-value shapes (== answerKey shapes), rich-text spec (D4), validator error format `{path, code, severity, message_ar}`, media placeholders (`src:null`, `alt` mandatory).

### 7.6 Widget contract v1
''' + WIDGET_CONTRACT + '''

### 7.7 Solving projection
The runner and widgets receive only the **solving projection** of a question — never `answerKey`, `explanation`, `solution`, `gradingCriteria`. Answers/explanations exist in memory only in review (B12+).

### 7.8 Conventions
Files `tools/src/<module>-<area>.js|css`; tests `tests/<area>.<kind>.test.js` (new files only); docs under `docs/`; logs under `docs/test-logs/<batch>/`; checkpoint ZIP `wird_work_<Bxx>_checkpoint.zip` with top-level folder `wird_work/`; Arabic UI strings in the app’s Egyptian tone; design tokens and classes of the existing app; DOM built with `textContent` (no unescaped `innerHTML`).

### 7.9 Verification contract
Each batch starts and ends with the verifier (PASS) and its self-test (27/27), runs the six existing suites on a scratch copy in the foreground against the baseline (update 64/64, offline 1/1, unified 12/12, resources 34/34, courses 32/32 with flaky test 18, perf within budget), reports executed vs not executed honestly, and lists real-device checks as NOT TESTED.

### 7.10 Release contract
No `sw.js` change until D6 (HARD gate at B17). A bump, if approved, changes only the single `SHELL_VERSION` number and is recorded as an approved exception — the baseline is never regenerated.
''')
    M.append('## 8. Decision register\n')
    M.append('Status of every decision at package time: **UNCONFIRMED — the default is in force**. The user answered none of D1–D11 explicitly; B1 did not depend on them. Gate HARD = stop and ask before the dependent batch; SOFT = proceed with the default, label it ASSUMED DEFAULT, ask for confirmation.\n')
    for d in DECISIONS:
        M.append('### %s — %s\n* **Needed by:** %s · **Gate:** %s · **Status:** UNCONFIRMED (default in force)\n* **Options:** %s\n* **Default:** %s\n* **Evidence/why:** %s\n' % (d['id'], d['topic'], d['needed_by'], d['gate'], d['options'], d['default'], d['why']))
    M.append('### Interpretations (not decisions; recorded so they are not mistaken for requirements)\n' + '\n'.join('* **%s** %s' % x for x in INTERPRETATIONS) + '\n')
    M.append('''## 9. Unresolved items and contradictions (identified; none resolved silently)

| # | Item | Where | Treatment |
|---|---|---|---|
| U1 | The user circled the free slot beside «بالكمية» in the wizard screenshot, but the brief says the wizard must stay intact and atomization may live on a task card. | D1 | Default: no wizard change; ask. |
| U2 | "Add New Sheet" does not exist as a control; three candidates. | D2 | HARD gate before B8. |
| U3 | The brief assumes Markdown heading semantics; the lesson renderer is a JSON node tree. | D4 | Default: Markdown-style subset mapped to node types. |
| U4 | The brief forbids modifying `sw.js`; releasing normally bumps `SHELL_VERSION`. | D6 | HARD gate at B17; default no change. |
| U5 | The brief asks for "an appropriate settings location within the existing app"; no global settings screen exists. | D11 | Default: module-owned sheets; ask. |
| U6 | "Task and habit management": atomization targets quick tasks/standalone plans; habits are recurring and are not link targets. | D8 | Default: quick tasks + standalone plans only. |
| U7 | Partial-credit value, mixed marks and the mastery threshold are not specified. | D9 | Defaults documented; ask before trusting numbers. |
| U8 | "Submit the answers to a teacher" has no backend. | D10 | Export/share only. |
| U9 | Defaults of the mistake-tracking toggles are not specified. | D5 | Recording ON, suggestions OFF. |
| U10 | The brief’s screenshot order differs from the files received. | I2 | Identified by content. |
| U11 | The amendments A1–A8 and the decision defaults were presented after B1 and the user proceeded without objection; not explicit approval. | MASTER-PLAN | Treated as adopted-but-unconfirmed; the user may override at any batch. |
| U12 | The container clock (2026-11-03 UTC) is one day behind the chat date. | docs | Cosmetic. |
| U13 | Real devices cannot be tested here. | I5 | Always reported as NOT TESTED with a manual checklist. |

Checked and found consistent (no action): default "no total-question counter" vs the settable "Question counter Hidden/Visible"; "no correctness until review" vs Scenario A review; manual question creation not a priority vs the import format; optional Mark for Review/Skip and Return vs the first-release list; Phase-1/Phase-2–4 independence vs the join points listed in `BATCH-DEPENDENCY-MAP.md`.
''')
    M.append('## 10. Roadmap and batch index (generated)\n\n| Task | Title | Size | Depends | Batch |\n|---|---|---|---|---|')
    for t, c in CARDS.items():
        M.append('| %s | %s | %s | %s | %s |' % (t, c['title'], c['size'], ', '.join(c['depends']) or '—', ', '.join(T2B[t])))
    M.append('\n| Batch | Tasks | Phase | Requires | Prompt |\n|---|---|---|---|---|')
    for b in BATCHES:
        M.append('| %s | %s | %s | %s | `prompts/%s-EXECUTION-PROMPT.md` |' % (b['id'], ' + '.join(b['tasks']), b['phase'], ', '.join(b['prereq_batches']) or '—', b['id']))
    M.append('''

## 11. Governance and workflow

* **Status vocabulary:** NOT STARTED · IN PROGRESS · COMPLETED · BLOCKED · NEEDS VERIFICATION. **IMPLEMENTED ≠ TESTED ≠ VERIFIED.** A task is COMPLETED only when its acceptance criteria are met by executed checks.
* **Commands the user may use:** `CREATE ROADMAP`, `EXECUTE: TASK X [+ TASK Y]`, `STATUS`, `HANDOFF`, `VERIFY`, `RESUME`, `REPLAN`, `FINAL AUDIT`. A batch prompt is the standing form of `EXECUTE` for its tasks; `VERIFY` = run the checks without changing anything; `REPLAN` = reassess remaining tasks without discarding completed work (output is a proposal; the user approves before prompts/roadmap change).
* **One batch per conversation; one approval per batch.** No batch starts another batch. Bugs outside the scope are documented, not fixed. Missing prerequisites stop the session.
* **End-of-batch handoff:** update MASTER-PLAN (if necessary), PROJECT-STATUS, HANDOFF, CHANGELOG; checkpoint ZIP verified by re-extraction; exact modified-file list; honest test report.
* **Change control:** requirements change only on the user’s explicit instruction, recorded in §12 and in the register; amendments to task cards go through `REPLAN` and are noted in `docs/ROADMAP.md`.
''')
    M.append('''## 12. Change log

| Date | Entry |
|---|---|
| 2026-11-03 | **B1 executed** (TASK 0.1 + 0.2): baseline, preservation verifier, integration spikes; no application code changed. Amendments A1–A8 and decisions D1–D7 proposed in the B1 report. |
| 2026-11-03 | **PKG-1 (planning package, docs only):** this MASTER-PLAN, 17 batch prompts, BATCH-DEPENDENCY-MAP, TRACEABILITY-MATRIX, PROMPT-USAGE-GUIDE; ROADMAP.md restored to the full approved card text; new decisions D8–D11 and interpretations I1–I5 added (all UNCONFIRMED defaults); no application code changed. |
''')
    return '\n'.join(M)

# ---------------------------------------------------------------------------------------------------------------------------------
def build_depmap():
    D = ['# BATCH-DEPENDENCY-MAP\n', 'Generated from `docs/ROADMAP.md` (task dependencies) and `tools/prompt-package/batches_*.py` (batch grouping). **Hard edge** = a task-level dependency from the approved roadmap. **Order edge** = the approved batch sequence (a batch also waits for earlier batches that its UI/entry points need, e.g. B11 needs the lesson entry from B8).\n']
    D.append('## 1. Task dependencies (verbatim from the roadmap) and their batch\n\n| Task | Batch | Depends on (tasks) | Depends on (batches) |\n|---|---|---|---|')
    for t, c in CARDS.items():
        deps = c['depends']
        if deps == ['ALL']: dbs = 'all earlier batches'; dtxt = 'all tasks'
        else: dbs = ', '.join(sorted(set(T2B[x][0] for x in deps if T2B[x][0] != T2B[t][0]))) or '— (same batch)'; dtxt = ', '.join(deps) or '—'
        D.append('| %s | %s | %s | %s |' % (t, T2B[t][0], dtxt, dbs))
    D.append('\n## 2. Batch graph\n\n```')
    D.append('B01 (0.1,0.2)  [COMPLETED]\n  └─ B02 (0.3,1.1)  ── gateway; NOT parallelizable\n       ├─ PHASE-1 CHAIN ───────────────  B03 (1.2) → B04 (1.3) → B05 (1.4,1.5)  ─────────────┐\n       └─ QUIZ CHAIN (Phases 2–4)                                                              │\n            B06 (2.1,2.2) → B07 (2.3) → B08 (2.4) ─┐                                           │\n                                   └→ B09 (3.1) ─┐ ├→ B11 (3.3,3.4) ◄── JOIN: needs B05 (1.4) ┘\n                                   └→ B10 (3.2) ─┘ │\n                            (B08 also needed by B11 for the lesson entry)\n            B11 → B12 (4.1) → B13 (4.2,4.3) → B14 (4.4)\n       B14 + (Phase 1 done) → B15 (5.1) → B16 (5.2,5.3) → B17 (5.4)')
    D.append('```\n')
    D.append('## 3. Batch table\n\n| Batch | Tasks | Requires (direct) | Requires (transitive) | Can run in parallel with |\n|---|---|---|---|---|')
    par = {'B03':'quiz chain B06–B08 (after B02)','B04':'quiz chain','B05':'quiz chain up to B10 (B11 must wait for B05)','B06':'B03–B05','B07':'B03–B05','B08':'B03–B05 (hook ownership differs: B3 habits, B8 lesson)','B09':'B10 (+ B03–B05)','B10':'B09 (+ B03–B05)','B11':'— (join point)','B12':'—','B13':'— (4.2 ∥ 4.3 inside the batch)','B14':'—','B15':'—','B16':'—','B17':'—','B01':'—','B02':'—'}
    for b in BATCHES:
        D.append('| %s | %s | %s | %s | %s |' % (b['id'], ' + '.join(b['tasks']), ', '.join(b['prereq_batches']) or '—', ', '.join(sorted(CL[b['id']])) or '—', par[b['id']]))
    D.append('''
**Join points:** B11 (TASK 3.4 ← TASK 1.4 in B05); B15 (needs all of Phase 4 and, for the regression part, Phase 1); B17 (needs everything).

## 4. Parallel windows (allowed by the dependency graph) and their risks

Default recommendation: **run sequentially** (B02 → B03 → … → B17). Parallel work is optional and needs the integration procedure in §6.

| Window | Which batches | Allowed because | Shared-file risk | Mitigation |
|---|---|---|---|---|
| W1 | Phase-1 chain (B03–B05) ∥ quiz chain (B06–B10) after B02 | No dependency edge between 1.x and 2.x–3.2 | `index.html` (regenerated by the injector), `tools/src/wird-kit.js` (consumed by both), tracking docs, `docs/MODULES.md` | Separate working copies from the B02 checkpoint; nobody edits `wird-kit.js` without coordination; merge via §6 |
| W2 | B09 ∥ B10 (after B07) | 3.1 and 3.2 have no edge between them | `tools/src/quiz-core-widgets.js` (identical by contract), `docs/QUIZ-SCHEMA.md` (append-only clarifications), `index.html`, tracking docs | Both embed Widget Contract v1 verbatim; merge via §6 |
| W3 | inside B13: TASK 4.2 ∥ TASK 4.3 | No edge between them | the hooks in `quiz-ui-review.js` | One session, one pass over that file |

Not parallelizable: B02 (gateway), B03→B04→B05, B06→B07→B08, B11→B12→B13→B14, B15→B16→B17.

## 5. Shared files (who may touch what)

| File | Batches that modify it | Rule |
|---|---|---|
| `index.html` | B02 (first insertion), then every batch that changes `tools/src/*` | Only through the injector; regenerate, never hand-merge; verifier PASS after each run |
| `tools/src/wird-kit.js` | B02 (creates); later batches only with documented need | Version field; keep API backward compatible |
| `tools/src/tasks-ui.js`, `tasks.css` | B03, B04, B05 | Strict chain |
| `tools/src/quiz.css` | B02 (placeholder), B07 (base styles) | Later batches add their own CSS files |
| `tools/src/quiz-core-widgets.js` | B09 or B10 (whoever is first) | Byte-identical to the reference; never edited otherwise |
| `tools/src/quiz-ui-import.js` | B08, B11 (feature-detected start button), B14 (mistakes entry) | Small, documented hooks |
| `tools/src/quiz-ui-run.js` | B11, B12 (hand-off hook) | Hook only |
| `tools/src/quiz-ui-review.js` | B12, B13 (export/AI/report entries), B14 (category chooser) | Hooks only |
| `tools/src/quiz-ui-prefs.js` | B11, B14 (two toggles) | Append only |
| `docs/QUIZ-SCHEMA.md` | B06, B09, B10 (clarifications), B16 (final) | Append-only until B16 |
| `PROJECT-STATUS.md`, `HANDOFF.md`, `CHANGELOG.md`, `MASTER-PLAN.md` | every batch | Each batch edits its own rows/sections; in parallel work merge by hand in the integration session |

## 6. Integration procedure for parallel work (an "integration session", not a numbered batch)

1. Start from the common ancestor checkpoint (e.g. `wird_work_B02_checkpoint.zip`). Create one working copy per parallel batch; each produces its own `wird_work_<Bxx>_checkpoint.zip` using its prompt unchanged.
2. Integration (one new conversation, use the prompt in `PROMPT-USAGE-GUIDE.md` §7): unzip the ancestor; copy from each parallel checkpoint ONLY the files listed as created/modified in its CHANGELOG entry **except `index.html`**; resolve overlaps using the table in §5; run `python3 tools/patch/inject_wird_modules.py` to regenerate the blocks; run the verifier and self-test; run the union of both batches’ tests plus the six existing suites; merge PROJECT-STATUS/HANDOFF/CHANGELOG by hand (each batch’s rows, sections and entries are kept); produce `wird_work_<B..>+<B..>_integrated_checkpoint.zip` and report. No new feature work is allowed in an integration session.
3. The next batch uploads the integrated checkpoint. A batch prompt must never be run on a checkpoint that lacks one of its prerequisites (§3.2 of every prompt checks this).

## 7. Prerequisite verification (every prompt, §3.2)

Each prompt lists the concrete deliverables of the previous batches (files, blocks in `index.html`, test files and their expected pass state). A session must run them, compare `PROJECT-STATUS.md`/`HANDOFF.md` with the code, and STOP on any mismatch — it must never implement a predecessor’s work.
''')
    return '\n'.join(D)

# ---------------------------------------------------------------------------------------------------------------------------------
def b_of(tasks): return ', '.join(sorted(set(x for t in tasks for x in T2B[t])))
def build_trace():
    X = ['# TRACEABILITY-MATRIX — requirement → task → batch → verification\n', 'Generated from `tools/prompt-package/data_requirements.py` and the batch grouping. **Status column = plan only (PLANNED / NOT BUILT BY DESIGN).** The evidence columns are filled by the final audit (B17); until then nothing here claims that anything is implemented, tested or verified. `ALL` = cross-cutting constraint repeated in every prompt.\n']
    X.append('| Requirement | Kind | Implemented by (tasks) | Batch(es) | Verified by (tasks) | Verifying batch(es) | Plan status | Evidence (B17) |\n|---|---|---|---|---|---|---|---|')
    for r in REQUIREMENTS:
        impl = 'ALL' if r['impl'] == ['ALL'] else (', '.join(r['impl']) or '—')
        ib = 'all (constraint)' if r['impl'] == ['ALL'] else (b_of(r['impl']) or '— (not built by design)')
        st = 'NOT BUILT BY DESIGN' if r['kind'] in ('DEFERRED', 'EXCLUDED') else 'PLANNED'
        X.append('| %s | %s | %s | %s | %s | %s | %s | UNVERIFIED |' % (r['id'], r['kind'], impl, ib, ', '.join(r['verify']), b_of(r['verify']), st))
    X.append('\n## Task coverage (reverse view)\n\n| Task | Batch | Requirements implemented |\n|---|---|---|')
    infra = {'0.1': 'tooling/baseline (PRES-04, PRES-07 verification)', '0.2': 'D-01 (+ evidence for D-decisions)', '0.3': 'infrastructure for PRES-03/PRES-04 (additive modules) and A2/A7/A8', '5.2': 'GS-04..GS-07, QM-03 (verification/polish)', '5.4': 'DL-01..DL-11, PROC verification'}
    for t in CARDS:
        rs = [r['id'] for r in REQUIREMENTS if t in r['impl']]
        X.append('| %s | %s | %s |' % (t, T2B[t][0], ', '.join(rs) if rs else infra.get(t, '**ORPHAN — review**')))
    X.append('\n## Counts\n\n' + ', '.join('%s: %d' % (k, sum(1 for r in REQUIREMENTS if r['kind'] == k)) for k in ('MANDATORY','OPTIONAL','CONDITIONAL','PRESERVATION','PROCESS','DEFERRED','EXCLUDED')) + ' — total %d requirements.' % len(REQUIREMENTS))
    return '\n'.join(X)

# ---------------------------------------------------------------------------------------------------------------------------------
def build_guide():
    G = ['# PROMPT-USAGE-GUIDE — how to run the 17 batch prompts\n']
    G.append('''## 1. What you have

* `prompts/B01…B17-EXECUTION-PROMPT.md` — one standalone prompt per batch (paste ONE into a NEW Claude conversation).
* `MASTER-PLAN.md` (requirements, decisions, contracts) · `BATCH-DEPENDENCY-MAP.md` · `TRACEABILITY-MATRIX.md` · `PROJECT-STATUS.md` · `HANDOFF.md` · `CHANGELOG.md` · `docs/ROADMAP.md` (task cards).
* **Project ZIP:** the latest checkpoint of the app (`wird_work_<Bxx>_checkpoint.zip`). The first one to use is `wird_work_B1_checkpoint_with_plan.zip` (B1 result + all planning documents merged), which is the correct upload for B2.
* **B1 is already done** — its prompt (B01) is verify-only. Start real work at **B02**.

## 2. Before the first batch: the decision sheet

The plan has 11 decisions (D1–D11, `MASTER-PLAN.md` §8). None is confirmed; defaults are in force. Two are HARD gates (the session will stop and ask): **D2** before B8 (where the quiz prompt button goes) and **D6** before B17 (touching `sw.js`). You can answer any time by editing the line `USER DECISION OVERRIDES` at the top of the prompt, e.g. `D1: also add a 4th chip in wizard step 2; D9: partial credit = 0.5`. Sessions record your answers in `MASTER-PLAN.md`.

| ID | Question in one line | Default |
|---|---|---|
''' + '\n'.join('| %s | %s | %s |' % (d['id'], d['topic'], SHORT_DEFAULTS[d['id']].replace('|', '/')) for d in DECISIONS) + '''

## 3. Running one batch (the loop)

1. Open a **new** Claude conversation.
2. Upload the **latest project checkpoint ZIP** (the output of the previous batch; for B2 use `wird_work_B1_checkpoint_with_plan.zip`). If that ZIP does not contain `MASTER-PLAN.md` and `prompts/`, also upload the prompt-package ZIP.
3. Paste the whole batch prompt (`prompts/Bxx-EXECUTION-PROMPT.md`). Edit `USER DECISION OVERRIDES` if you decided something.
4. The session first **verifies** the previous batch (documents vs files vs tests). If something is missing it stops and tells you — do not push it to continue; fix the prerequisite first.
5. It implements only its tasks, runs the tests, updates the documents and delivers: the report, the checkpoint ZIP and its SHA-256.
6. **You** check the report (§5 below), test on your phone if the report lists items, and then — only then — go to the next batch with the new ZIP.

## 4. Which ZIP to upload

| Batch | Upload the ZIP produced by | Notes |
|---|---|---|
| B01 | any checkpoint (verify only) | already executed |
| B02 | `wird_work_B1_checkpoint_with_plan.zip` | |
| B03, B04, B05 | the previous batch of the Phase-1 chain | |
| B06 | B02 (or the integrated checkpoint if Phase 1 ran in parallel) | Phase 2 needs only B02 |
| B07, B08 | previous quiz batch | B8 needs your D2 answer |
| B09 | B07/B08 | |
| B10 | B09 (sequential) or B07 (parallel, see map) | |
| B11 | B10 + **Phase 1 finished (B05)** | join point: the ZIP must contain both chains |
| B12–B17 | previous batch | B15 needs Phase 1 and Phase 4; B17 asks you about D6 |

## 5. What to check after each batch (2 minutes)

* The report has the 8 sections (summary, files, tests EXECUTED vs NOT EXECUTED, preservation confirmation, decisions used, issues, ZIP + SHA-256, next).
* "Existing files modified" says **none** (or only the approved hook). `sw.js` unchanged until B17.
* Tests: counts match the baseline for the six old suites; the new tests are listed with real numbers; anything NOT EXECUTED is explained.
* The new ZIP exists in the outputs; the session re-extracted it and re-ran the verifier.
* If the report lists "real device — NOT TESTED" items, try them on your phone before approving the next batch (camera, keyboard, Back button, offline, installed PWA).

## 6. When something goes wrong

* **Session says a prerequisite is missing/mismatched:** it will stop. Upload the correct checkpoint, or ask for `REPLAN`. Never ask it to "just continue".
* **Context almost exhausted:** B5, B6, B11, B16 are large; they are allowed to stop at an intermediate boundary (e.g. after TASK 1.4) with a partial checkpoint. Start a new conversation with the same prompt: it will detect which tasks are already COMPLETED and resume.
* **Flaky test:** `courses` test 18 may fail once; the session re-runs and reports both runs.
* **Wrong result:** keep the previous checkpoint ZIP (they are never overwritten); you can re-run a batch from it.

## 7. Parallel work (optional) and the integration session

Only the windows in `BATCH-DEPENDENCY-MAP.md` §4 are allowed. After parallel batches finish, open ONE new conversation, upload the common-ancestor ZIP and every parallel checkpoint, and paste:

```
You are running an INTEGRATION SESSION for the Wird project (no feature work). Read MASTER-PLAN.md, PROJECT-STATUS.md,
HANDOFF.md, CHANGELOG.md and BATCH-DEPENDENCY-MAP.md §5–§6 from the ancestor ZIP. Verify each uploaded checkpoint
(verifier PASS, 27/27 self-test, its batch tests). Create the merged project as follows: start from the ancestor; for each
parallel checkpoint copy ONLY the files listed as created/modified in its CHANGELOG entry, except index.html; resolve overlaps
with the table in BATCH-DEPENDENCY-MAP.md §5 (never overwrite another batch's work silently; report conflicts instead);
regenerate index.html with `python3 tools/patch/inject_wird_modules.py`; merge PROJECT-STATUS.md, HANDOFF.md and CHANGELOG.md
by hand keeping every batch's rows/sections/entries; run the verifier, the self-test, the union of the parallel batches' tests
and the six existing suites (scratch copy, foreground); then deliver `wird_work_<batches>_integrated_checkpoint.zip`
(verified by re-extraction) and an honest report (EXECUTED vs NOT EXECUTED, conflicts, files). Do not implement anything new.
Never touch sw.js or protected blocks. Stop afterwards and wait for my approval.
```

## 8. Keeping the package consistent

The prompts are generated: edit `tools/prompt-package/{data_*.py,batches_*.py,common.py}` and run `python3 -I tools/prompt-package/build_package.py` then `python3 -I tools/prompt-package/audit_package.py` (it must print PASS). Changing a task card means editing `docs/ROADMAP.md` first (via `REPLAN`) and rebuilding so every prompt embeds the new text verbatim.

## 9. Quick reference

| Batch | Tasks | Title |
|---|---|---|
''' + '\n'.join('| %s | %s | %s |' % (b['id'], ' + '.join(b['tasks']), b['title']) for b in BATCHES) + '\n')
    return '\n'.join(G)

def write(rel, text):
    p = os.path.join(ROOT, rel); os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, 'w', encoding='utf-8', newline='\n').write(text.rstrip('\n') + '\n')

if __name__ == '__main__':
    for b in BATCHES: write('prompts/%s-EXECUTION-PROMPT.md' % b['id'], build_prompt(b))
    write('MASTER-PLAN.md', build_master()); write('BATCH-DEPENDENCY-MAP.md', build_depmap()); write('TRACEABILITY-MATRIX.md', build_trace()); write('PROMPT-USAGE-GUIDE.md', build_guide())
    print('built %d prompts + 4 documents into %s' % (len(BATCHES), ROOT))
