#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Mutation self-test for audit_package.py (each case must make the audit FAIL with the expected check name)."""
import os, sys, shutil, tempfile, subprocess, re
ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))
res = []
def run(tree):
    p = subprocess.run([sys.executable, '-I', os.path.join(tree, 'tools', 'prompt-package', 'audit_package.py'), '--root', tree], capture_output=True, text=True)
    return p.returncode, p.stdout + p.stderr
def case(name, mutate, expect_fail_containing):
    tmp = tempfile.mkdtemp(prefix='wird-ap-'); tree = os.path.join(tmp, 'p')
    shutil.copytree(ROOT, tree, ignore=shutil.ignore_patterns('.git', '__pycache__', 'node_modules', 'tests', 'docs/test-logs'))
    try:
        mutate(tree); rc, out = run(tree)
        if expect_fail_containing is None: ok = rc == 0
        else: ok = rc != 0 and expect_fail_containing in out
        res.append((ok, name))
        if not ok: print(out[-1500:])
    finally: shutil.rmtree(tmp, ignore_errors=True)
def edit(rel, fn):
    def m(tree):
        p = os.path.join(tree, rel); s = open(p, encoding='utf-8').read(); t = fn(s); assert t != s, 'no change in ' + rel
        open(p, 'w', encoding='utf-8').write(t)
    return m
case('untouched package passes', lambda t: None, None)
case('a task card altered inside a prompt', edit('prompts/B03-EXECUTION-PROMPT.md', lambda s: s.replace('Objective:** Create and organize plans', 'Objective:** Create plans', 1)), 'B03 embeds its task cards verbatim')
case('a common block altered in one prompt', edit('prompts/B09-EXECUTION-PROMPT.md', lambda s: s.replace('Never edit', 'You may edit', 1) if 'Never edit' in s else s.replace('**No scope creep:**', '**Scope creep is fine:**', 1)), 'common block')
case('a deferred feature removed from the exclusions of one prompt', edit('prompts/B12-EXECUTION-PROMPT.md', lambda s: s.replace('automatic AI coaching', 'x', 1)), 'B12 lists all 8 deferred features')
case('a prompt loses its decision table row', edit('prompts/B05-EXECUTION-PROMPT.md', lambda s: s.replace('| D7 |', '| DX |', 1)), 'B05')
case('a prompt file is missing', lambda t: os.remove(os.path.join(t, 'prompts', 'B14-EXECUTION-PROMPT.md')), '17 prompt files')
case('a task card dependency points to a later batch', edit('docs/ROADMAP.md', lambda s: s.replace('- **Depends:** 1.1, 1.2.\n- **Accept:** Only one step', '- **Depends:** 1.1, 1.2, 4.1.\n- **Accept:** Only one step', 1)), 'dependency integrity of TASK 1.3')
case('a requirement without implementing task', edit('tools/prompt-package/data_requirements.py', lambda s: s.replace("r('FT-10',G,'MANDATORY'", "r('FT-10X',G,'MANDATORY'", 1).replace("['3.3'],['5.1'])\n# ---- Part 5", "[],['5.1'])\n# ---- Part 5", 1)), 'buildable requirements')
case('a HARD gate removed from B08', edit('prompts/B08-EXECUTION-PROMPT.md', lambda s: s.replace('HARD GATE D2', 'gate D2')), 'HARD gate D2')
case('a bump authorised in a non-final prompt', edit('prompts/B06-EXECUTION-PROMPT.md', lambda s: s.replace('## 15. NEXT BATCH', 'You may bump SHELL_VERSION now.\n\n## 15. NEXT BATCH', 1)), 'never authorizes a SHELL_VERSION bump')
case('conversation-dependent wording', edit('prompts/B10-EXECUTION-PROMPT.md', lambda s: s.replace('## 15. NEXT BATCH', 'As discussed earlier in this conversation, skip step 3.\n\n## 15. NEXT BATCH', 1)), 'conversation dependence')
case('traceability matrix loses a requirement', edit('TRACEABILITY-MATRIX.md', lambda s: s.replace('| QT-07 |', '| QT-0X |', 1)), 'every requirement appears')
bad = [n for ok, n in res if not ok]
for ok, n in res: print(('PASS ' if ok else 'FAIL ') + n)
print('\n%d/%d audit self-tests passed' % (len(res) - len(bad), len(res))); sys.exit(1 if bad else 0)
