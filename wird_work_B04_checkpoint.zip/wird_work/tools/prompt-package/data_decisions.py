# -*- coding: utf-8 -*-
"""Decision register (single source). Status UNCONFIRMED = the user has not answered; the default is used and must be
labelled 'ASSUMED DEFAULT' in every report. gate: HARD = the session must STOP and ask before executing the dependent batch if
still UNCONFIRMED; SOFT = proceed with the default, label it, and ask for confirmation in the report; NONE."""

DECISIONS = [
 dict(id='D1', topic='Entry point of Task Atomization', needed_by='B3', gate='SOFT',
      options='(a) action on quick-task rows + chip in the quick-task modal (no wizard change); (b) additionally a 4th tracking chip in habit-wizard step 2 (the user circled the free slot beside «بالكمية» in a screenshot, but the brief also says the wizard must stay intact).',
      default='(a). No 4th wizard chip: it would edit `hWizard` type logic in the guarded main script (`w.type` = b|time|qty drives routing, `meas()` and saving).',
      why='Docs/INTEGRATION-SPIKES.md §h; brief Part 1.2 (wizard intact) vs the circled screenshot.'),
 dict(id='D2', topic='Meaning/location of "Add New Sheet" = anchor of the saved-prompt button', needed_by='B8', gate='HARD',
      options='A = unit-row `＋` aria «ملخص جديد» in the sidebar (via `window.__wirdRow` wrapper); B = lesson header, sibling directly after `#wrHead` (beside «📅 جدولة»); C = sidebar-top `＋` «مادة جديدة».',
      default='B. NOT confirmed by the user; no literal "Add New Sheet" control exists in the app.',
      why='Docs/INTEGRATION-SPIKES.md §a (probe c1–c4). Wrong anchor = rework of B8, hence a HARD gate.'),
 dict(id='D3', topic='How quizzes appear inside a lesson', needed_by='B8', gate='SOFT',
      options='(a) lesson-linked panel owned by the new module; (b) a new `quiz` lesson resource type/tab (requires patching frozen blocks).',
      default='(a). Proven: `repo.saveResource({type:"quiz"})` is rejected ("Invalid resource").',
      why='Docs/INTEGRATION-SPIKES.md §b.'),
 dict(id='D4', topic='Rich-text format of quiz content', needed_by='B6', gate='SOFT',
      options='(a) small Markdown-style subset mapped to the existing lesson node types (heading 1–3, lists, `$…$`, `$$…$$`, `\\ce{}`, pipe tables, images via media); (b) raw lesson-node JSON.',
      default='(a), obeying the `wMathTok` tokenizer rules. The brief assumed Markdown headings; the real lesson content is a JSON node tree.',
      why='Docs/INTEGRATION-SPIKES.md §c.'),
 dict(id='D5', topic='Mistake tracking: pool, notebook integration, defaults', needed_by='B14', gate='SOFT',
      options='Separate pool in `wird_quiz_db` + optional one-tap push to «دفتر الأخطاء»; or write only into the notebook; defaults for the on/off toggles.',
      default='Separate pool + optional push through `repo.saveMistake` (needs a `lessonId`). Recording ON (passive, no popups); automatic revision suggestions OFF until enabled (threshold default 3 incorrect in one topic); status rule: correct once → improving, correct in two separate sessions → mastered; incorrect again → open and recurrence +1.',
      why='Docs/INTEGRATION-SPIKES.md §d; brief Part 9 does not state defaults.'),
 dict(id='D6', topic='`sw.js` SHELL_VERSION bump at release', needed_by='B17', gate='HARD',
      options='(a) never touch sw.js; (b) bump `SHELL_VERSION` once at the end (single number) with explicit approval.',
      default='(a) until B17. The brief forbids modifying sw.js; the update guide says users still get updates through index.html change detection when the number is not bumped.',
      why='Brief Part 0.B vs docs/UPDATE-GUIDE.md release procedure.'),
 dict(id='D7', topic='Future-day plans storage', needed_by='B2', gate='SOFT',
      options='(a) standalone in `wird_tasks_v1`, optional link to a TODAY quick task; (b) also materialise quick tasks in `H.oneoffs[date]` for future days.',
      default='(a). No writes to `wird_habits_v1` for other days.',
      why='Docs/INTEGRATION-SPIKES.md §9.2 (quick tasks can only be created for today).'),
 dict(id='D8', topic='Link targets of a step plan', needed_by='B3', gate='SOFT',
      options='(a) standalone plans and quick tasks only; (b) also habit rows.',
      default='(a). Habits are recurring; atomizing them is not requested explicitly.',
      why='Brief Part 1.2 says "task and habit management" but the plan model is DAY → TASKS → STEPS.'),
 dict(id='D9', topic='Scoring rules of the session report', needed_by='B13', gate='SOFT',
      options='Partial-credit weight when no awarded marks are typed; handling of questions without marks when others have marks; when a mastery % may be shown.',
      default='Partial = 50 % of the question marks unless the user types awarded marks. If some questions have marks and others do not: the weighted score covers only the questions that have marks and the rest are listed separately ("بدون درجات"); with no marks at all every question weighs 1. Mastery % is shown only when no question is Awaiting Grading or Needs Review; otherwise show the graded-only score with its denominator, never labelled mastery. Unanswered counts as 0 once graded Unanswered.',
      why='Brief Part 8 requires partial credit and unequal marks but gives no numbers.'),
 dict(id='D10', topic='Meaning of "submit the answers to a teacher"', needed_by='B13', gate='SOFT',
      options='(a) export/share (copy, Web Share, print/PDF) — no backend; (b) any in-app submission to a server.',
      default='(a). No backend exists and external services are excluded by the brief.',
      why='Brief Part 6 Scenario B and Part 0.D.'),
 dict(id='D11', topic='Location of settings (no global settings screen exists)', needed_by='B5', gate='SOFT',
      options='(a) module-owned settings sheets (⚙ in the planner/execution screens and the quiz start sheet); (b) rows added inside existing settings screens (frozen/guarded code).',
      default='(a).',
      why='Docs/INTEGRATION-SPIKES.md §e.'),
]

INTERPRETATIONS = [
 ('I1', 'The saved prompt is built into the app as a versioned constant (one-tap viewer + copy). It is not user-editable (editing was not requested).'),
 ('I2', 'The brief lists three screenshots in a different order than the files received; they were identified by content: wizard step 1, wizard step 2, lesson page. Annotation marks (arrow on the lesson screenshot, circle in wizard step 2) are interpreted as in D1/D2 and are not treated as requirements.'),
 ('I3', 'Undo window default is an implementation constant (suggested 8 s, adjustable) because the brief only says "brief".'),
 ('I4', 'No automatic opening of the execution screen at app start; resume is offered through the planner/row actions (the brief requires exact resume but not auto-open).'),
 ('I5', 'Real-device behaviour (Android Brave, camera capture, on-screen keyboard, installed PWA) cannot be tested in the container; it must be reported as NOT TESTED and listed for the user to try on a phone.'),
]


SHORT_DEFAULTS = {
 'D1': 'Action on quick-task rows + chip in the quick-task modal; wizard untouched',
 'D2': 'B — a sibling after #wrHead in the lesson header (beside «📅 جدولة»). HARD gate before B8',
 'D3': 'Lesson-linked quiz panel; no new resource type/tab',
 'D4': 'Markdown-style subset mapped to the lesson node types',
 'D5': 'Separate quiz mistake pool + optional push to «دفتر الأخطاء»; recording ON, suggestions OFF',
 'D6': 'Never touch sw.js until B17, then ask. HARD gate',
 'D7': 'Future-day plans live only in wird_tasks_v1',
 'D8': 'Quick tasks + standalone plans; habit rows are not link targets',
 'D9': 'Partial = 50 % of marks; marks-less questions reported separately; mastery only when nothing awaits grading',
 'D10': 'Export/share (copy, Web Share, print/PDF); no backend',
 'D11': 'Module-owned settings sheets (⚙ in the planner and the quiz sheet)',
}
