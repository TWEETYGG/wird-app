#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Consistency audit of the prompt package. usage: python3 -I tools/prompt-package/audit_package.py [--root PROJECT_ROOT]
Exit 0 only if every check passes. Prints one line per check."""
import os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pkg_lib as L
from common import blocks
from data_decisions import DECISIONS
from data_requirements import REQUIREMENTS
ROOT = L.ROOT
if '--root' in sys.argv: ROOT = os.path.abspath(sys.argv[sys.argv.index('--root') + 1])
BATCHES = L.load_batches(); CARDS = L.load_cards(ROOT); T2B = L.task_batch_map(BATCHES); CL = L.closure(BATCHES); COMMON = blocks()
BY = {b['id']: b for b in BATCHES}
results = []
def check(name, ok, detail=''):
    results.append((bool(ok), name, detail))
def rd(rel):
    return open(os.path.join(ROOT, rel), encoding='utf-8').read()
P = {}
for b in BATCHES:
    rel = 'prompts/%s-EXECUTION-PROMPT.md' % b['id']
    P[b['id']] = rd(rel) if os.path.exists(os.path.join(ROOT, rel)) else None

# --- structure --------------------------------------------------------------------------------------------------------------------
check('17 prompt files B01..B17 exist', all(P[b['id']] for b in BATCHES) and len(BATCHES) == 17, ','.join(k for k, v in P.items() if not v))
P = {k: (v if v is not None else '') for k, v in P.items()}   # a missing file now fails the checks below instead of crashing
files = sorted(f for f in os.listdir(os.path.join(ROOT, 'prompts')) if f.endswith('.md')) if os.path.isdir(os.path.join(ROOT, 'prompts')) else []
check('no unexpected files in prompts/', files == ['B%02d-EXECUTION-PROMPT.md' % i for i in range(1, 18)], str(files))
hdr = ['## %d. ' % i for i in range(1, 16)]
for bid, t in P.items():
    pos = [t.find(h) for h in hdr]
    check('%s has sections 1..15 in order' % bid, all(p >= 0 for p in pos) and pos == sorted(pos))
for bid, t in P.items():
    m = re.search(r'\*\*Authorizes ONLY:\*\* (.*?)  \n', t)
    exp = ' + '.join('TASK ' + x for x in BY[bid]['tasks'])
    check('%s authorizes exactly its tasks' % bid, m and m.group(1).strip() == exp, (m.group(1) if m else 'missing'))
# --- tasks ------------------------------------------------------------------------------------------------------------------------
check('every roadmap task is owned by exactly one batch', set(CARDS) == set(T2B) and all(len(v) == 1 for v in T2B.values()), str({k: v for k, v in T2B.items() if len(v) != 1}))
check('24 task cards parsed from docs/ROADMAP.md', len(CARDS) == 24)
for bid, t in P.items():
    ok = True; why = ''
    found = re.findall(r'<!--CARD:(\d\.\d)-->\n(.*?)\n<!--/CARD:\1-->', t, re.S)
    ids = [f[0] for f in found]
    if ids != BY[bid]['tasks']: ok = False; why = 'cards %s != tasks %s' % (ids, BY[bid]['tasks'])
    for tid, body in found:
        if body != CARDS[tid]['text']: ok = False; why += ' card %s differs from ROADMAP' % tid
    check('%s embeds its task cards verbatim (and only those)' % bid, ok, why)
# --- dependencies -----------------------------------------------------------------------------------------------------------------
order = {b['id']: b['n'] for b in BATCHES}
for tid, c in CARDS.items():
    mb = T2B[tid][0]; ok = True; why = ''
    deps = c['depends']
    if deps == ['ALL']:
        need = {b['id'] for b in BATCHES} - {mb}
        ok = need <= CL[mb]; why = 'closure lacks %s' % (need - CL[mb])
    else:
        for d in deps:
            db = T2B[d][0]
            if db == mb:
                if BY[mb]['tasks'].index(d) > BY[mb]['tasks'].index(tid): ok = False; why += ' %s listed after %s in batch' % (d, tid)
            elif db not in CL[mb]: ok = False; why += ' %s(%s) not in prerequisite closure of %s' % (d, db, mb)
    check('dependency integrity of TASK %s' % tid, ok, why)
check('prerequisite batches precede their dependents', all(all(order[p] < b['n'] for p in b['prereq_batches']) for b in BATCHES))
nx = all((BY[b['id']]['next'] == 'B%02d' % (b['n'] + 1)) if b['n'] < 17 else b['next'] is None for b in BATCHES)
check('next-batch pointers form the sequence B01→B17', nx)
for b in BATCHES:
    if b['next']:
        check('%s points to an existing next prompt' % b['id'], 'prompts/%s-EXECUTION-PROMPT.md' % b['next'] in P[b['id']] and P[b['next']] is not None)
# hard cross-chain edges: phase 1 (1.x) vs quiz tasks (2.x-4.x)
cross = set()
for tid, c in CARDS.items():
    for d in c['depends']:
        if d == 'ALL': continue
        a, bb = tid.split('.')[0], d.split('.')[0]
        if (a == '1' and bb in '234') or (a in '234' and bb == '1'): cross.add((tid, d))
check('only one hard cross-chain edge (3.4 -> 1.4) between Phase 1 and the quiz chain', cross == {('3.4', '1.4')}, str(cross))
check('B09 and B10 (3.1 ∥ 3.2) have no dependency edge between them', '3.2' not in CARDS['3.1']['depends'] and '3.1' not in CARDS['3.2']['depends'])
check('TASK 4.2 and 4.3 have no dependency edge (parallel inside B13)', '4.3' not in CARDS['4.2']['depends'] and '4.2' not in CARDS['4.3']['depends'])
check('B11 declares the Phase-1 join (needs B05)', 'B05' in BY['B11']['prereq_batches'])
# --- common blocks identical ------------------------------------------------------------------------------------------------------
for name, text in COMMON.items():
    bad = []
    for bid, t in P.items():
        m = re.search(r'<!--COMMON:%s-->\n(.*?)\n<!--/COMMON:%s-->' % (name, name), t, re.S)
        if not m or m.group(1) != text: bad.append(bid)
    check('common block %s identical in all 17 prompts' % name, not bad, ','.join(bad))
# --- policy strings ---------------------------------------------------------------------------------------------------------------
deferred = ['automatic AI recognition of task names', 'AI-generated task decomposition', 'keyword-triggered study templates', 'automatic AI coaching', 'per-step mathematical scoring', 'continuous AI analysis', 'complicated reward systems', 'unnecessary new top-level navigation']
for bid, t in P.items():
    check('%s lists all 8 deferred features' % bid, all(x in t for x in deferred))
    check('%s keeps optional features optional' % bid, 'Optional features stay optional' in t)
    check('%s has the preservation essentials' % bid, all(x in t for x in ['sw.js', 'wird-update', 'wird-offline', 'build.py', 'wird_quiz_db', '--allow-guarded', 'wird_tasks_v1']) and 'never claim a test passed' in t.lower())
    check('%s requires reading MASTER-PLAN/PROJECT-STATUS/HANDOFF and verifying deliverables' % bid, all(x in t for x in ['`MASTER-PLAN.md`', '`PROJECT-STATUS.md`', '`HANDOFF.md`', 'Verify the previous batch', 'STOP']))
    check('%s ends with handoff protocol (status, handoff, changelog, ZIP, report)' % bid, all(x in t for x in ['Update `PROJECT-STATUS.md`', 'Update `HANDOFF.md`', 'Update `CHANGELOG.md`', 'checkpoint ZIP', 'Final report to the user']))
    check('%s has no unresolved placeholders or conversation dependence' % bid, not re.search(r'\{\{|TODO|TBD|XXX|as discussed|earlier in this conversation|original conversation|master conversation|as we discussed', t))
    check('%s size is sane' % bid, 12000 < len(t.encode('utf-8')) < 90000, str(len(t.encode('utf-8'))))
    ids = set(re.findall(r'\bD(\d+)\b', t)); check('%s references only registered decisions' % bid, all(1 <= int(i) <= len(DECISIONS) for i in ids), str(ids))
    check('%s embeds the full decision table D1..D%d' % (bid, len(DECISIONS)), all('| D%d |' % i in t for i in range(1, len(DECISIONS) + 1)))
    if bid != 'B17':
        bad = [l.strip()[:90] for l in t.split('\n') if 'bump' in l and not re.search(r'not|NOT|never|Never|without|no bump|D6|before D6|only', l)]
        check('%s never authorizes a SHELL_VERSION bump' % bid, not bad, str(bad))
check('B08 carries the HARD gate D2', 'HARD GATE D2' in P['B08'])
check('B17 carries the HARD gate D6', 'HARD GATE D6' in P['B17'])
check('only B08 and B17 contain HARD GATE instructions', all(('HARD GATE' in P[b]) == (b in ('B08', 'B17')) for b in P))
check('B05 lists the 15 Part-13 task tests', all(x in P['B05'] for x in ['Create a task with multiple steps.', 'Verify all preferences persist.']))
check('B15 lists the 22 Part-13 quiz tests', all(x in P['B15'] for x in ['Copy the saved AI Prompt.', 'Verify settings persist.', 'Generate optional AI grading material.']) and len(re.findall(r'^\d+\. ', P['B15'].split('Part-13 Focus Quiz tests')[1].split('Part-13 regression list')[0], re.M)) == 22)
check('B05 task-test list has exactly 15 items', len(re.findall(r'^\d+\. ', P['B05'].split('Part-13 Task Atomization tests')[1].split('Part-13 regression list')[0], re.M)) == 15)
check('B17 lists both test sets and the 11 Part-14 deliverables', 'Part-13 Task Atomization tests' in P['B17'] and 'Part-13 Focus Quiz tests' in P['B17'] and len(re.findall(r'^\d+\. ', P['B17'].split('Part-14 final deliverables')[1].split('**Test protocol')[0], re.M)) == 11)
check('B01 is marked as already executed (verify-only)', 'ALREADY EXECUTED' in P['B01'] and 'EXECUTED and COMPLETED' in P['B01'])
check('B02 is not marked executed', 'ALREADY EXECUTED' not in P['B02'])
# B1 deliverable files must exist (B01/B02 prerequisite checks refer to them)
for rel in ['tools/audit/verify_preservation.py', 'tools/audit/test_verify_preservation.py', 'tools/audit/probe_anchors.js', 'docs/PRESERVATION-BASELINE.json', 'docs/BASELINE-TEST-RESULTS.md', 'docs/INTEGRATION-SPIKES.md', 'docs/ROADMAP.md', 'docs/UPDATE-GUIDE.md', 'PROJECT-STATUS.md', 'HANDOFF.md', 'CHANGELOG.md', 'MASTER-PLAN.md', 'BATCH-DEPENDENCY-MAP.md', 'TRACEABILITY-MATRIX.md', 'PROMPT-USAGE-GUIDE.md']:
    check('file exists: %s' % rel, os.path.exists(os.path.join(ROOT, rel)))
# --- requirements ----------------------------------------------------------------------------------------------------------------
ids = [r['id'] for r in REQUIREMENTS]
check('requirement ids are unique', len(ids) == len(set(ids)))
tm = rd('TRACEABILITY-MATRIX.md'); mp = rd('MASTER-PLAN.md')
check('every requirement appears in MASTER-PLAN.md and TRACEABILITY-MATRIX.md', all(('**%s**' % i) in mp and ('| %s |' % i) in tm for i in ids), str([i for i in ids if ('**%s**' % i) not in mp or ('| %s |' % i) not in tm][:5]))
bad = []
for r in REQUIREMENTS:
    for t in r['impl'] + r['verify']:
        if t != 'ALL' and t not in CARDS: bad.append((r['id'], t))
check('requirement task references exist in the roadmap', not bad, str(bad))
check('buildable requirements have an implementing task (or ALL)', all(r['impl'] for r in REQUIREMENTS if r['kind'] not in ('DEFERRED', 'EXCLUDED')), str([r['id'] for r in REQUIREMENTS if r['kind'] not in ('DEFERRED', 'EXCLUDED') and not r['impl']]))
check('deferred/excluded requirements have NO implementing task', all(not r['impl'] for r in REQUIREMENTS if r['kind'] in ('DEFERRED', 'EXCLUDED')))
check('every requirement has a verifying task', all(r['verify'] for r in REQUIREMENTS), str([r['id'] for r in REQUIREMENTS if not r['verify']]))
infra = {'0.1', '0.2', '0.3', '5.2', '5.4'}
orph = [t for t in CARDS if not any(t in r['impl'] for r in REQUIREMENTS) and t not in infra]
check('no orphan tasks (every task implements a requirement or is declared infrastructure)', not orph, str(orph))
miss = []
for b in BATCHES:
    for r in REQUIREMENTS:
        if r['impl'] != ['ALL'] and set(b['tasks']) & set(r['impl']) and ('**%s**' % r['id']) not in P[b['id']]: miss.append((b['id'], r['id']))
check('every implemented requirement is listed in the prompt of its batch (§10)', not miss, str(miss[:5]))
check('traceability maps every requirement to existing batches', all(re.search(r'\| %s \|' % r['id'], tm) for r in REQUIREMENTS))
check('15 Part-13 task tests + 22 quiz tests accounted (TS-01/TS-02)', any(r['id'] == 'TS-01' for r in REQUIREMENTS) and any(r['id'] == 'TS-02' for r in REQUIREMENTS))
dm = rd('BATCH-DEPENDENCY-MAP.md')
check('dependency map lists every task and batch', all(('| %s |' % t) in dm for t in CARDS) and all(('| %s |' % b['id']) in dm for b in BATCHES))
check('usage guide lists all 17 prompts', all(('| %s |' % b['id']) in rd('PROMPT-USAGE-GUIDE.md') for b in BATCHES))
# --- final-scope check ------------------------------------------------------------------------------------------------------------
check('the final batch (B17) depends transitively on all other batches', CL['B17'] == {b['id'] for b in BATCHES} - {'B17'})
check('final batch covers the whole approved scope (TASK 5.4 depends on ALL)', CARDS['5.4']['depends'] == ['ALL'])

fails = [r for r in results if not r[0]]
for ok, name, detail in results:
    if not ok or '--verbose' in sys.argv: print(('PASS ' if ok else 'FAIL ') + name + (('  :: ' + detail) if detail and not ok else ''))
print('-' * 78); print('%d checks, %d passed, %d failed' % (len(results), len(results) - len(fails), len(fails)))
print('RESULT   ' + ('PASS' if not fails else 'FAIL'))
sys.exit(1 if fails else 0)
