# -*- coding: utf-8 -*-
import os, re, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
ROOT = os.path.abspath(os.path.join(HERE, '..', '..'))

def load_batches():
    from batches_a import BATCHES_A
    from batches_b import BATCHES_B
    from batches_c import BATCHES_C
    bs = BATCHES_A + BATCHES_B + BATCHES_C
    bs.sort(key=lambda b: b['n'])
    return bs

def load_cards(root=ROOT):
    """Parse docs/ROADMAP.md -> {task_id: dict(id,title,size,text,depends[],raw_depends)} in file order."""
    lines = open(os.path.join(root, 'docs', 'ROADMAP.md'), encoding='utf-8').read().split('\n')
    cards, cur = {}, None
    for ln in lines:
        m = re.match(r'^### TASK (\d\.\d) — (.*?) · ([SML])\s*$', ln)
        if m:
            cur = dict(id=m.group(1), title=m.group(2), size=m.group(3), lines=[ln]); cards[cur['id']] = cur; continue
        if cur is not None:
            if ln.startswith('## ') or ln.startswith('### '):
                cur = None; continue
            cur['lines'].append(ln)
    for c in cards.values():
        while c['lines'] and not c['lines'][-1].strip(): c['lines'].pop()
        c['text'] = '\n'.join(c['lines'])
        dm = [l for l in c['lines'] if l.startswith('- **Depends:**')]
        c['raw_depends'] = dm[0] if dm else ''
        c['depends'] = re.findall(r'\b(\d\.\d)\b', c['raw_depends'])
        if re.search(r'\*\*Depends:\*\*\s*all', c['raw_depends']): c['depends'] = ['ALL']
    return cards

def task_batch_map(batches):
    m = {}
    for b in batches:
        for t in b['tasks']:
            m.setdefault(t, []).append(b['id'])
    return m

def closure(batches):
    """prerequisite closure per batch id"""
    by = {b['id']: b for b in batches}
    memo = {}
    def go(i):
        if i in memo: return memo[i]
        s = set()
        for p in by[i]['prereq_batches']:
            s.add(p); s |= go(p)
        memo[i] = s; return s
    return {i: go(i) for i in by}
