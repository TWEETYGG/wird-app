# -*- coding: utf-8 -*-
"""Requirement register (single source). kind: MANDATORY | OPTIONAL | CONDITIONAL | DEFERRED | EXCLUDED | PRESERVATION | PROCESS.
impl = task ids that implement it (['ALL'] = cross-cutting constraint for every batch); verify = task ids whose tests/audit verify it.
DEFERRED/EXCLUDED requirements have impl=[] on purpose: they must NOT be built; they are guarded by the exclusion blocks of every prompt."""
R = []
def r(id, group, kind, text, impl, verify): R.append(dict(id=id, group=group, kind=kind, text=text, impl=impl, verify=verify))

# ---- Part 0 + protocol ------------------------------------------------------------------------------------------
G='Part 0 — Preservation'
r('PRES-01',G,'PRESERVATION','Preserve the existing UI/UX, theme, colors, typography, icons, spacing, layouts, navigation and tab structure; the app stays visually and functionally identical outside the new features; never replace existing screens with invented layouts.',['ALL'],['0.3','1.2','1.5','2.4','5.2','5.4'])
r('PRES-02',G,'PRESERVATION','Preserve existing task and habit functionality, study materials/lessons/notes/summaries, Quran and Wird functionality and user workflows; do not modify unrelated features.',['ALL'],['1.5','5.1','5.4'])
r('PRES-03',G,'PRESERVATION','No change to existing database structures unless an additive migration is genuinely necessary (then explain and get approval).',['ALL'],['0.3','5.4'])
r('PRES-04',G,'PRESERVATION','Do not rewrite, remove or modify sw.js, the Service Worker registration, the wird-update functionality, cache ownership/versioning, offline Quran/Tafsir storage or existing localStorage/IndexedDB data; never regenerate the old SW from legacy build scripts; modify only if absolutely required, after explanation and approval.',['ALL'],['0.1','0.3','1.5','5.4'])
r('PRES-05',G,'PRESERVATION','Preserve every existing record: all new storage is additive and backward compatible; never clear or recreate existing databases; existing tasks, habit history, notes, course progress and user content stay intact.',['ALL'],['1.5','5.1','5.4'])
r('PRES-06',G,'PRESERVATION','No unnecessary external services, API dependencies or paid AI; prioritize local processing and locally stored preferences; the user never has to re-configure the same settings.',['ALL'],['5.4'])
r('PRES-07',G,'PRESERVATION','Changes are additive, isolated and reversible; protected files are never modified without explicit authorization.',['ALL'],['0.1','5.4'])
G='Protocol (global development rules + batch workflow)'
r('PROC-01',G,'PROCESS','Read MASTER-PLAN.md, PROJECT-STATUS.md and HANDOFF.md before each batch; never rely on conversation memory; never repeat completed tasks; never skip dependencies.',['ALL'],['5.4'])
r('PROC-02',G,'PROCESS','Execute only the explicitly authorized batch; respect dependencies and acceptance criteria; stop at the batch boundary; never start the next batch without approval; document (do not fix) bugs outside the scope.',['ALL'],['5.4'])
r('PROC-03',G,'PROCESS','Verify all changes before declaring completion; never claim a test passed unless it was executed; clearly separate executed from untested.',['ALL'],['5.4'])
r('PROC-04',G,'PROCESS','At the end of every batch: update MASTER-PLAN.md if necessary, PROJECT-STATUS.md, HANDOFF.md and CHANGELOG.md; produce the next-batch prompt and a checkpoint ZIP; report exact modified files; no undocumented changes.',['ALL'],['5.4'])
r('PROC-05',G,'PROCESS','IMPLEMENTED ≠ TESTED ≠ VERIFIED; a task is COMPLETED only after its acceptance criteria are satisfied; PROJECT-STATUS.md and HANDOFF.md always describe the same actual state.',['ALL'],['5.4'])
# ---- Part 1 -----------------------------------------------------------------------------------------------------
G='Part 1 — Dynamic Task Atomization'
r('T-01',G,'OPTIONAL','Task atomization is an OPTIONAL feature integrated into the existing task/habit system (no separate app, no unnecessary top-level tab), reachable from an appropriate existing task-management entry point, task-card action or an optional step after creating a complex task; regular creation of simple habits stays just as easy.',['1.2'],['1.5'])
r('T-02',G,'PRESERVATION','The existing five-step habit creation wizard stays intact: steps, order and tracking methods are not reordered or removed.',['1.2'],['1.5','5.4'])
r('T-03',G,'MANDATORY','Planning operations: create a task, name it, add multiple steps, edit any step, delete any step, insert steps between existing steps, reorder steps, select which task to work on, edit a task without losing completion history, delete a task with confirmation, pause and resume an unfinished task, save state automatically.',['1.1','1.2'],['1.5'])
r('T-04',G,'MANDATORY','The planning interface may show the full editable list of steps; the execution interface shows only ONE current step by default (never the whole checklist).',['1.3'],['1.5'])
r('T-05',G,'DEFERRED','Automatic AI keyword recognition, smart keyword templates and AI-generated task decomposition (typing "Chemistry Lecture" triggers nothing) are deferred to a future release.',[],['5.4'])
r('T-06',G,'MANDATORY','Day-based organization DAY → TASKS → STEPS: today, tomorrow and future days; multiple tasks per day; multiple steps per task; reorder tasks within a day; move an unfinished task to another day; edit or delete planned tasks.',['1.1','1.2'],['1.5'])
r('T-07',G,'MANDATORY','The focused interface executes the selected task and its steps without displaying the full daily task list.',['1.3'],['1.5'])
r('T-08',G,'OPTIONAL','End-of-day prompt when all of the day’s tasks are complete: «خلصت مهام النهارده. تحب تدخل على مهام اليوم التالي؟» with actions «الانتقال لليوم التالي» and «ليس الآن»; configurable and disableable; never forces navigation; if the next day is empty allow opening it or returning to the normal task list.',['1.4'],['1.5'])
r('T-09',G,'MANDATORY','One-at-a-time execution: current task/context where useful, ONE current step, ONE primary completion action; flow: see step → complete → check → recorded → next step appears automatically with a pleasant transition; no "Step 2 of 8" by default; current step visually dominant; no lists, statistics or settings clutter.',['1.3'],['1.5'])
r('T-10',G,'MANDATORY','Satisfying but restrained feedback: smooth fade/transition, brief completion animation, pleasant state change, optional haptic, optional subtle sound, optional micro-interaction — all configurable; no points, coins, artificial rewards or competitive streaks.',['1.3','1.4'],['1.5','5.2'])
r('T-11',G,'MANDATORY','Execution controls (persistent): display mode (one step by default), automatic transition, back navigation, skip step (optional, configurable), edit during execution (optional, configurable), pause/resume, timer (optional), progress indicator (optional), completion animation (configurable), sound (optional), haptic (optional), end-of-day prompt (optional).',['1.3','1.4'],['1.5'])
r('T-12',G,'MANDATORY','Undo protection: a brief, unobtrusive undo action after completion; a skipped step never automatically counts as completed.',['1.1','1.3'],['1.5'])
r('T-13',G,'MANDATORY','Progress visibility setting: completely hidden / subtle indicator / detailed indicator; the default minimizes visual pressure.',['1.3','1.4'],['1.5'])
r('T-14',G,'MANDATORY','Preferences are saved locally and persist across sessions; a default profile exists for new task sessions; session-specific overrides are possible; changing a setting never affects an active session.',['1.1','1.4'],['1.5'])
r('T-15',G,'MANDATORY','State management: not started, in progress, paused, completed, skipped, partially completed; autosave after every action; current step preserved after closing; resume from the exact position; history preserved; the same completion is never recorded twice; completed vs skipped stays distinct; editing/deleting steps never corrupts progress.',['1.1'],['1.5'])
# ---- Part 2 -----------------------------------------------------------------------------------------------------
G='Part 2 — Focus Quiz: workflow, integration, AI prompt'
r('Q-01',G,'MANDATORY','Workflow chain: MATERIAL → AI PROMPT → JSON IMPORT → FOCUSED SOLVING → REVIEW → SELF-GRADING → SESSION REPORT.',['2.4','3.3','4.1','4.3'],['5.1'])
r('Q-02',G,'MANDATORY','Focus Quiz lives inside the existing lesson/study environment without replacing or redesigning it; accessible in the context of the lesson/material/sheet; no independent app or top-level navigation; the solving screen may be an immersive dedicated view; on exit the user returns to the original lesson context.',['2.4','3.3'],['5.1','5.4'])
r('Q-03',G,'MANDATORY','A persistent, easily accessible button for the fixed AI Prompt is placed next to the existing "Add New Sheet" action (anchor per decision D2).',['2.4'],['5.1'])
r('Q-04',G,'MANDATORY','The fixed AI Prompt is reusable, reachable with one tap, easy to copy, stored persistently, versioned for future improvements and consistent across sessions.',['2.4'],['5.1','5.3'])
r('Q-05',G,'EXCLUDED','Manual question creation is NOT a priority for this release (not built).',[],['5.4'])
r('Q-06',G,'MANDATORY','Import supports pasting JSON, importing a JSON file, validation, a preview of the generated session, malformed-JSON detection, useful validation errors, and prevents invalid data from entering an active session.',['2.1','2.4'],['5.1'])
r('Q-07',G,'PRESERVATION','No API keys, paid AI calls or automatic AI requests inside Wird; the workflow uses a reusable prompt with an external AI.',['2.4','4.2'],['5.4'])
r('Q-08',G,'MANDATORY','The prompt instructs the external AI to extract questions accurately, preserve original wording and source language, identify the correct question type, preserve numbering when useful, extract options, figures/diagrams where possible, math notation, physics symbols and units, tables and structured content.',['2.4'],['5.3'])
r('Q-09',G,'MANDATORY','The prompt instructs the AI to extract official answers only when they exist, explanations/solutions only when present or explicitly requested, never invent an answer key, mark missing answers null/unavailable, assign stable question IDs, follow the actual Wird JSON schema and output valid JSON without surrounding prose.',['2.4'],['5.3'])
r('Q-10',G,'MANDATORY','Imported content follows the existing Wird content framework (heading hierarchy, math, tables, media) rather than an invented formatting language (decision D4).',['2.1','2.3','2.4'],['5.1'])
r('Q-11',G,'MANDATORY','Source material may be any format the external AI supports (PDF, images, screenshots, scanned worksheets, Word, plain text, existing question banks): the prompt is format-agnostic.',['2.4'],['5.3'])
# ---- Part 3 -----------------------------------------------------------------------------------------------------
G='Part 3 — Question types and content'
for i,(t,k,w) in enumerate([('Single-choice MCQ','mcq_single',['3.1']),('Multiple-select MCQ','mcq_multi',['3.1']),('True/False','true_false',['3.1']),
        ('Short text answers','short_text',['3.2']),('Long written/essay answers','long_text',['3.2']),('Numerical answers','numeric',['3.2']),
        ('Mathematical expressions and equations','math_expression',['3.2']),('Physics and chemistry problems','sci_problem',['3.2']),
        ('Fill in the blanks','fill_blank',['3.1']),('Matching','matching',['3.1']),('Ordering and sequencing','ordering',['3.1']),
        ('Multi-part questions','multi_part',['3.2']),('Step-based problem statements','step_based',['3.2']),
        ('Questions containing images, diagrams or tables','media',['2.3','3.2'])],1):
    r('QT-%02d'%i,G,'MANDATORY','Question type %d must be supported in the first release: %s (schema in 2.1, rendering in 2.3, answer widget in %s).'%(i,t,'/'.join(w)),['2.1']+w,['5.1'])
r('QT-15',G,'MANDATORY','Each question is rendered according to its type; the application is not limited to multiple choice.',['2.3','3.1','3.2'],['5.1'])
r('QM-01',G,'MANDATORY','Math/science content: fractions, exponents, square roots, Greek symbols, operators, equations, subscripts/superscripts, physics units, chemical notation, multiple equations in one question, tables, diagrams, image attachments.',['2.3'],['5.1'])
r('QM-02',G,'PRESERVATION','Use the existing math renderer (embedded KaTeX/mhchem); introduce a new rendering dependency only if absolutely necessary.',['2.3'],['5.4'])
r('QM-03',G,'MANDATORY','Equations never overflow the mobile screen.',['2.3'],['5.2'])
r('QA-01',G,'MANDATORY','Answer inputs: selecting options, numerical values, text, mathematical expressions, multiple fields where necessary.',['3.1','3.2'],['5.1'])
r('QA-02',G,'MANDATORY','A student can attach an image of handwritten work (photo of a paper solution).',['3.2'],['5.1'])
r('QA-03',G,'MANDATORY','A complete solution can be written or attached.',['3.2'],['5.1'])
r('QA-04',G,'MANDATORY','Image attachments persist reliably across application reloads.',['2.2','3.2'],['5.1'])
# ---- Part 4 -----------------------------------------------------------------------------------------------------
G='Part 4 — Focus Tunnel'
r('FT-01',G,'MANDATORY','ONE QUESTION AT A TIME: during solving show only the current question — no side question list by default, no correct answers, explanations, scores, mastery percentages, distracting statistics or unnecessary navigation.',['3.3'],['5.1'])
r('FT-02',G,'MANDATORY','Default flow: display a single question with its answer interface, allow answering, save, and on pressing «تثبيت الإجابة والانتقال للسؤال التالي» save the answer and show the next question.',['3.3'],['5.1'])
r('FT-03',G,'MANDATORY','The interface never reveals whether a submitted answer is correct; answers are recorded privately and correctness appears only in the review stage.',['3.1','3.2','3.3'],['5.1'])
r('FT-04',G,'MANDATORY','Persistent solving settings: focus mode (Minimal/Balanced/Advanced), question display (one by default), progress display (Hidden/Subtle/Detailed), question counter (Hidden/Visible), timer (Disabled/Visible/Hidden background), previous question, Mark for Review, Skip and Return, answer editing, navigation animation, input font size, question font size, keyboard behaviour optimized per input type, media display (Fit/Expand/Full-screen).',['3.4'],['5.1'])
r('FT-05',G,'MANDATORY','A session-specific override is possible without replacing the saved defaults.',['3.4'],['5.1'])
r('FT-06',G,'MANDATORY','Default configuration: minimal interface, one question, no visible score, no correctness feedback, no total-question counter, progress hidden, no unnecessary side navigation, automatic saving, explicit submit-and-continue action.',['3.3','3.4'],['5.1'])
r('FT-07',G,'OPTIONAL','Mark for Review: mark a question for later review without revealing the answer (configurable, remembered).',['3.3'],['5.1'])
r('FT-08',G,'OPTIONAL','Skip and Return: skip a question and return before final submission (configurable, remembered).',['3.3'],['5.1'])
r('FT-09',G,'OPTIONAL','Previous Question: return to a previously answered question when enabled (configurable, remembered).',['3.3'],['5.1'])
r('FT-10',G,'MANDATORY','An unanswered question never disappears silently; all answers are preserved when navigating backward or forward.',['3.3'],['5.1'])
# ---- Part 5 -----------------------------------------------------------------------------------------------------
G='Part 5 — Session management'
r('S-01',G,'MANDATORY','Sessions survive interruptions: automatic saving, pause and resume, closing and reopening the application, returning after the phone is restarted.',['2.2','3.3'],['5.1'])
r('S-02',G,'MANDATORY','Preserve the current question, previously submitted answers, unfinished input and attached images.',['2.2','3.3'],['5.1'])
r('S-03',G,'MANDATORY','A session completes only once; duplicate reports are prevented.',['2.2','4.3'],['5.1'])
r('S-04',G,'MANDATORY','Session states: Prepared, In Progress, Paused, Ready for Review, Completed; an unfinished session can be resumed without losing work.',['2.2'],['5.1'])
# ---- Part 6 -----------------------------------------------------------------------------------------------------
G='Part 6 — Review and self-grading'
r('G-01',G,'MANDATORY','Scenario A (answer key available): after the final question enter review showing the question, the user’s answer, the official model answer and the explanation if available; the user grades their own answer.',['4.1'],['5.1'])
r('G-02',G,'MANDATORY','Never automatically mark an answer correct because its text matches; the user remains responsible for the final assessment.',['4.1'],['5.1'])
r('G-03',G,'MANDATORY','Grades: Correct, Partially Correct, Incorrect, Unanswered, Needs Review; the grading interface is fast and easy.',['4.1'],['5.1'])
r('G-04',G,'MANDATORY','Scenario B (no answer key): do not treat every question as incorrect and do not invent model answers; preserve all submitted answers; show the original questions and responses; mark questions Awaiting Grading.',['4.1'],['5.1'])
r('G-05',G,'MANDATORY','Answer sheet export: export all questions and submitted answers, copy the sheet, share it with a teacher (decision D10), generate a printable report/PDF where supported; preserve numbering and formatting; works even when nothing is graded.',['4.2'],['5.1'])
r('G-06',G,'OPTIONAL','Optional «اطلب تصحيح AI» workflow: the app prepares a grading prompt (original questions, student answers, available marking criteria, any supplied official answer key); the user sends it to an external AI and imports the structured grading result.',['4.2'],['5.1'])
r('G-07',G,'PRESERVATION','No automatic AI requests and no mandatory AI API usage or recurring credit consumption.',['4.2'],['5.4'])
r('G-08',G,'MANDATORY','If there is no reliable answer key or marking basis, the system communicates that limitation instead of fabricating certainty.',['4.2'],['5.1'])
# ---- Part 7 -----------------------------------------------------------------------------------------------------
G='Part 7 — Mathematical review'
r('M-01',G,'MANDATORY','Full rendering of mathematical expressions and complete written solutions (also in review).',['2.3','4.1'],['5.1'])
r('M-02',G,'DEFERRED','Per-step scoring of mathematical solutions is NOT required in this release; the student assesses the overall answer with the normal grading states.',[],['5.4'])
r('M-03',G,'MANDATORY','The architecture stays extensible so detailed step-by-step marking can be added later (reserved `stepMarks`, not built).',['2.1','4.1'],['5.4'])
# ---- Part 8 -----------------------------------------------------------------------------------------------------
G='Part 8 — Session report'
r('R-01',G,'MANDATORY','After review generate a report with: number of questions, number graded, correct, partially correct, incorrect, unanswered, awaiting grading, mastery percentage when grading data is complete enough, questions requiring revision, weak topics when topic data exists, session duration when timing is enabled.',['4.3'],['5.1'])
r('R-02',G,'MANDATORY','Accuracy rules: never a misleading mastery percentage; graded and awaiting questions are clearly separated; the score follows supplied marks; partial credit is supported; equal marks are never assumed when the data provides different marks (decision D9).',['4.3'],['5.1'])
r('R-03',G,'MANDATORY','Provide an option to return directly to weak questions.',['4.3'],['5.1'])
# ---- Part 9 -----------------------------------------------------------------------------------------------------
G='Part 9 — Long-term mistake tracking'
r('MT-01',G,'MANDATORY','A simple local mistake-tracking system using deterministic IF rules; no continuous AI analysis and no recurring AI API calls.',['4.4'],['5.1'])
r('MT-02',G,'MANDATORY','Rules: Incorrect → mistake pool; Partially Correct → weak question; repeated errors in a topic → optionally suggest a revision session; a mistake successfully reviewed again → status update.',['4.4'],['5.1'])
r('MT-03',G,'CONDITIONAL','If the user does not want automatic suggestions, the suggestion feature stays disabled (decision D5).',['4.4'],['5.1'])
r('MT-04',G,'OPTIONAL','Optional mistake categories: Conceptual error, Wrong formula, Calculation error, Memorization error, Careless mistake, Other; users are never forced to classify.',['4.4'],['5.1'])
r('MT-05',G,'MANDATORY','No new complicated planning system; mistake data is accessible from the existing study/lesson context.',['4.4'],['5.1'])
# ---- Part 10 ----------------------------------------------------------------------------------------------------
G='Part 10 — Global settings and UX'
r('GS-01',G,'MANDATORY','Remember task execution/transition/feedback/animation/progress/edit-skip/end-of-day settings and Focus Quiz mode/navigation/progress/timer/text sizes/review preferences/mistake-tracking behaviour; apply them automatically to new sessions.',['1.4','3.4'],['1.5','5.1'])
r('GS-02',G,'MANDATORY','Provide an appropriate settings location within the existing app (decision D11: module-owned sheets).',['1.4','3.4'],['5.2'])
r('GS-03',G,'MANDATORY','Three saved display modes — Minimal, Balanced, Advanced — with Minimal as the default.',['1.4','3.4'],['1.5','5.1'])
r('GS-04',G,'MANDATORY','Subtle visual transitions only; optional haptic and sound only when supported and enabled; no animations that harm performance.',['1.3','1.4','3.3'],['5.2'])
r('GS-05',G,'MANDATORY','Arabic-first: correct RTL, Arabic typography, mixed Arabic/English rendering, proper mathematical equation direction and layout.',['1.2','1.3','1.4','2.3','3.1','3.2','3.3','4.1'],['5.2'])
r('GS-06',G,'MANDATORY','Mobile-first portrait design usable on small Android screens, proper keyboard behaviour, no horizontal overflow, accessible touch targets.',['1.2','1.3','1.4','2.3','3.1','3.2','3.3','4.1'],['5.2'])
r('GS-07',G,'MANDATORY','The features feel like a native part of Wird (existing design system), not an embedded third-party page.',['1.2','1.3','2.4','3.3'],['5.2','5.4'])
# ---- Part 11 ----------------------------------------------------------------------------------------------------
G='Part 11 — Data architecture and JSON import'
r('D-01',G,'MANDATORY','Inspect the current persistence architecture before designing schemas and use it where appropriate.',['0.2'],['0.2'])
r('D-02',G,'MANDATORY','Separate clearly named structures for task plans, day groups, task steps, task execution state, persistent preferences, imported quiz sessions, questions, submitted answers, attached answer images, grading records, session reports and mistake records.',['1.1','2.2','3.4'],['5.1'])
r('D-03',G,'MANDATORY','Stable IDs; historical sessions are preserved when a task or imported question set is edited or deleted; no destructive updates.',['1.1','2.2'],['1.5','5.1'])
r('D-04',G,'MANDATORY','A versioned, validated JSON import format supporting at least: session title, subject, lesson, source material info, instructions, questions, question IDs/types, rich content, media attachments, answer input type, options, optional answer key, explanation, solution, marks, topic, difficulty and grading criteria.',['2.1'],['2.1'])
r('D-05',G,'MANDATORY','The format supports different question structures without forcing empty irrelevant fields.',['2.1'],['2.1'])
r('D-06',G,'MANDATORY','Unknown fields never corrupt an import; invalid question types produce clear validation errors.',['2.1'],['2.1'])
r('D-07',G,'MANDATORY','The application never silently discards media or mathematical notation.',['2.1','2.3'],['5.1'])
r('D-08',G,'MANDATORY','The reusable fixed AI prompt generates exactly the JSON format the application accepts.',['2.4'],['5.3'])
# ---- Deferred list (Part 12) -------------------------------------------------------------------------------------
G='Part 12 — Explicitly deferred (must NOT be implemented in this release)'
for i,t in enumerate(['Automatic AI recognition of task names','AI-generated task decomposition','Keyword-triggered study templates','Automatic AI coaching','Per-step mathematical scoring','Continuous AI analysis','Complicated reward systems','Unnecessary new top-level navigation'],1):
    r('DF-%02d'%i,G,'DEFERRED',t+' — deferred to a future release.',[],['5.4'])
# ---- Part 13 tests ----------------------------------------------------------------------------------------------
G='Part 13 — Testing and acceptance'
r('TS-01',G,'MANDATORY','Execute the 15 Task Atomization tests: create a task with multiple steps; edit a step; delete a step; reorder steps; execute one step; confirm automatic transition; return to the previous step; skip a step when skipping is enabled; pause and resume; close and reopen the app; confirm exact state restoration; finish all tasks scheduled for one day; confirm the optional next-day prompt; verify no duplicate completion records; verify all preferences persist.',['1.5'],['1.5'])
r('TS-02',G,'MANDATORY','Execute the 22 Focus Quiz tests: copy the saved AI Prompt; import valid JSON; import invalid JSON with clear errors; import all question types; render mathematical notation; display diagrams and images; attach a handwritten answer image; navigate questions; Mark for Review; skip and return; confirm answers preserved; close and reopen; resume an unfinished session; finish with an answer key; finish without an answer key; manually grade; leave answers awaiting grading; export the complete answer sheet; generate optional AI grading material; verify report calculations; verify mistake tracking; verify settings persist.',['5.1'],['5.1'])
r('TS-03',G,'MANDATORY','Regression: existing task management, habit tracking, lesson pages, Notes and Summary, study materials, Quran and Wird functionality, offline functionality all still work; no existing data deleted; the PWA update system is not broken; the app works on mobile.',['1.5','5.1','5.4'],['5.4'])
r('TS-04',G,'PROCESS','Never claim a test passed unless it was actually executed; clearly distinguish executed tests from untested scenarios.',['ALL'],['5.4'])
# ---- Part 14 deliverables ---------------------------------------------------------------------------------------
G='Part 14 — Final deliverables'
for i,t,w in [(1,'The complete modified project as a ZIP.',['5.4']),(2,'A list of every modified, created and deleted file.',['5.4']),(3,'A precise explanation of every modification.',['5.4']),
              (4,'Confirmation that existing application features were preserved.',['5.4']),(5,'Confirmation that existing user data was preserved.',['5.4']),
              (6,'The final JSON schema.',['5.3','5.4']),(7,'The reusable fixed AI prompt.',['5.3','5.4']),(8,'The implementation and testing report.',['5.4']),
              (9,'Instructions for importing questions.',['5.3']),(10,'Instructions for using task atomization.',['5.3']),(11,'A list of deferred features.',['5.3','5.4'])]:
    r('DL-%02d'%i,G,'MANDATORY','Final deliverable %d: %s'%(i,t),w,['5.4'])

REQUIREMENTS = R
