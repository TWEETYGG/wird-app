# NEXT-SESSION-PROMPT — superseded

The B1-era single next-session prompt has been replaced by the complete prompt set generated in planning package PKG-1.

* **Next batch:** B5 (TASK 1.4 + 1.5) → `prompts/B05-EXECUTION-PROMPT.md`  (B4 = TASK 1.3 is COMPLETED)
* **Before B5 (user decision):** approve or reject the proposed updates of the two protected tests that now fail by construction — `docs/test-logs/B04/inject.test.js.PROPOSED.patch` (`tests/inject.test.js`, 44/46 → 46/46) and `docs/test-logs/B04/tasks.planning.test.js.PROPOSED.patch` (`tests/tasks.planning.test.js`, 49/53 → 53/53); see `PROJECT-STATUS.md` known issue 21.
* **Upload to the new conversation:** `wird_work_B04_checkpoint.zip` (project + planning documents), then paste the prompt.
* **All prompts:** `prompts/B01-EXECUTION-PROMPT.md` … `prompts/B17-EXECUTION-PROMPT.md` — see `PROMPT-USAGE-GUIDE.md`.
