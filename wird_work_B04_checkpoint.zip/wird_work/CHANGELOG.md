# CHANGELOG — Wird: Task Atomization + Focus Quiz

Every batch adds an entry listing **every** file created / modified / deleted and the tests run. "Existing files modified: none" means none of the 35 files of the original upload (`wird_work_updated.zip`, SHA-256 `6ad6ebc34c3c3c9d527ddad482b7c28f169ed73ba927e11f4c2d966ddb1c2a3f`).
Dates use the container clock (UTC).

## [B4] — 2026-11-08 — TASK 1.3 (focused execution screen)
**Existing original files modified: ONE — `index.html`, only through the injector** (refresh of the `wird-tasks-css` and `wird-tasks` blocks; the quiz blocks are unchanged; `verify_preservation.py`: PASS, OK=68, only NEW files besides it). Hash-compared (SHA-256) with the B3 checkpoint: exactly 9 files modified (`index.html`, `tools/src/tasks-engine.js`, `tools/src/tasks-ui.js` and the six docs listed below), 0 deleted, 49 created (3 source/test files + 46 files under `docs/test-logs/B04/`); `sw.js`, `tasks-shell.js`, the kit, every existing test, `tools/orig`, `tools/phase2`, all original files other than `index.html` are byte-identical.

Created:
* `tools/src/tasks-exec.js` — the execution screen, `WirdTasks.exec` (≈400 lines; reference in `docs/MODULES.md` §7)
* `tools/src/tasks-exec.css` — `.wx-*` selectors only, ≈7 KB; every transition/animation inside `@media (prefers-reduced-motion: no-preference)`
* `tests/tasks.exec.test.js` — 70 tests, 470 assertions (6 Node tests of the new engine field + 64 Chromium tests; watchdog)
* `docs/test-logs/B04/` — logs of every suite run, 19 screenshots (3 phone viewports, landscape, paused, done, keyboard, progress), `mutations/` (7 deliberate mutations), `inject.test.js.PROPOSED.patch`, `tasks.planning.test.js.PROPOSED.patch`

Modified (not original files):
* `tools/src/tasks-engine.js` — ONE additive, documented change: `complete(stepId, {elapsedMs})` / `skip(...)` store an optional integer `elapsedMs` (0 … 24 h) on the event (`EVENT_FIELDS` + a 6-line helper); invalid values are ignored; `schemaVersion` unchanged; the 39 existing engine tests pass unchanged (39/39, 26,844 assertions)
* `tools/src/tasks-ui.js` — the planner now labels the entry «▶ متابعة» for plans that are in progress or paused (day card, task editor and quick-task row sheet) and records where the button was pressed for the execution screen (`origin`, `WirdTasks.ui.takeOrigin(id)`); the call stays `exec.open(id, {from:'planner'})`. ≈12 changed lines
* `docs/TASKS-ENGINE.md` (the field), `docs/MODULES.md` (§3 key list, §5 note, §6.8 one sentence, §7 appended), `PROJECT-STATUS.md`, `HANDOFF.md`, `CHANGELOG.md`, `NEXT-SESSION-PROMPT.md` (pointer now points to B5; documented deviation, as in B2/B3)

Deleted: none.

Deviations from the pre-generated B4 prompt (all deliberate, all listed here):
1. The new code is in **new files** `tasks-exec.js` / `tasks-exec.css` instead of being added to `tasks-ui.js` / `tasks.css` (the prompt's file list). Reason: `HANDOFF.md` §B4 asked for it ("add its code as NEW files … do not rewrite `tasks-ui.js` beyond what is needed"), the injector includes them automatically (verified: `--list`, `--check`, verifier), and the planner and the execution screen stay independently reviewable. `tasks.css` was not touched.
2. «Returns to the planner/day» after the last step is an explicit «تمام» button, not an automatic jump: the undo window must stay usable on the completion screen.
3. `tests/inject.test.js` and `tests/tasks.planning.test.js` were **not** edited although they now fail by construction (44/46 and 49/53; see below). Proposed patches that make them pass (46/46 and 53/53 on a scratch copy) await the user's decision.
4. Opening a **paused** task resumes it (opening = coming back); `open(id, {resume:false})` shows the paused view. Added `status().locked`, `resumeActive()` and `WirdTasks.ui.takeOrigin()` (small, documented API additions).
5. Android Back: one `{wirdExec:1}` history entry is pushed while the view is open (the app has no history handling, so nothing conflicts). Verified with Chromium `goBack`, **not** on a real device.

Defects found while building B4 and fixed before completion:
1. First draft completed «whatever step is current now» instead of the step on screen, so a view that was stale (plan changed in another tab) could complete a step the user had not seen. Fixed (the tap targets the displayed step; an already-resolved step records nothing and re-syncs the view); covered by a test and by a mutation.
2. First draft called `exec.open(id, {from:'planner', fromView, fromDay})` from the planner, changing the B3 contract that B3's own test pins. Found by running the B3 suite; restored the exact call and moved the hand-off to `WirdTasks.ui.takeOrigin`.
3. Test-side mistakes (not product bugs): a test raced the 560 ms UI lock with fixed sleeps and failed once (fixed by waiting on the new `status().locked`); `plan()` helper reset the saved preferences before the snapshot was taken; the reduced-motion assertion expected `0s` but the app itself clamps transitions to 0.01 ms; a few tautological assertions were removed before the first full run.

Checks run (all executed in this session, foreground):
* `NODE_PATH=$(npm root -g) node tests/tasks.exec.test.js` — **70/70, 470 assertions** (final tree). 7 deliberate mutations, all caught.
* `node tests/tasks.unit.test.js` — 39/39, 26,844 assertions · `python3 -I tools/audit/verify_preservation.py` — PASS (OK=68) · `test_verify_preservation.py` 27/27 · `inject --check` CURRENT
* `tests/inject.test.js` (protected, unedited) — **44/46** (the same 2 stale expectations as in B3, now also covering `tasks-exec.*` and `WirdTasks.exec`); with the proposed patch on a scratch copy **46/46**
* `tests/tasks.planning.test.js` (protected, unedited) — **49/53**: 4 tests assert that no execution screen exists (row sheet lists exactly two buttons, «ابدأ» absent without a stub); two of the four only fail as a cascade. With the proposed patch on a scratch copy **53/53, 405 assertions**
* Six existing suites on a scratch copy of the final tree: update 64/64 · offline 1/1 · unified 12/12 · resources 34/34 · perf within budget on both runs (CPU×4 scroll step 59.1 ms, then 45.9 ms; budget 60 — the first run is close to the limit, B3 also saw 61.0 ms once, so this metric is noisy on this machine) · courses 31/32, 31/32, 32/32, 32/32 — the failing check is test 8-10-11, listed as intermittent in the project README; on the untouched **B3 checkpoint** the same suite gave 32/32, 31/32, 32/32, so it is not a B4 regression (logs in `docs/test-logs/B04/`)
* NOT executed: any real device (Android Brave, installed PWA), the real Android Back button, a real soft keyboard / IME, multi-tab behaviour, sound/haptic on hardware, TalkBack/screen reader.

## [B3] — 2026-11-07 — TASK 1.2 (planning UI & entry points)
**Existing original files modified: ONE — `index.html`, only through the injector** (refresh of the `wird-tasks-css` and `wird-tasks` blocks; the injected region grew from 92,493 to 141,684 bytes; the quiz blocks are unchanged). Cutting the region out reproduces the B2 `index.html` byte for byte (checked).

Created:
* `tools/src/tasks-ui.js` — planner UI and entry points, `WirdTasks.ui` (633 lines; reference in `docs/MODULES.md` §6)
* `tests/tasks.planning.test.js` — 53 tests, 405 assertions (Chromium; pristine-vs-injected comparison under a fixed clock; watchdog)
* `docs/test-logs/B03/` — logs of every suite run, 18 screenshots (3 phone viewports × 6 screens), `mutations/` (3 deliberate mutations), `inject.test.js.PROPOSED.patch`

Modified (not original files):
* `tools/src/tasks.css` — the B2 placeholder filled (≈6 KB, only `.wt-*` / `.modal.wt-sheet` selectors)
* `docs/MODULES.md` (§3 load-footprint wording and `WirdTasks.ui`; §5 note on `inject.test.js`; §6 appended), `PROJECT-STATUS.md`, `HANDOFF.md`, `CHANGELOG.md`
* `NEXT-SESSION-PROMPT.md` — pointer file now points to B4; not in the prompt's expected-modified list (documented deviation, same as B2)

Deleted: none. **Not modified (hash-compared with the starting checkpoint):** `sw.js`, the engine, the shell, the kit, `tasks-shell.js`, every existing test including `tests/inject.test.js`, `tools/orig`, `tools/phase2`, all original files other than `index.html`. `TRACEABILITY-MATRIX.md` and `docs/ROADMAP.md` were left as they are (generated; B2 did not update their status columns either).

Defects found by B3's own tests in B3's own code and fixed before completion:
1. `editTask` was called with a string instead of `{ title }`, so every title edit failed with `invalid_argument` and silently reverted (found by the title-edit test).
2. The «تم» button of the insert row was 43 px wide (< 44 px) in all three phone viewports.
3. A `DOMContentLoaded` listener was registered at load (inline scripts run while `readyState` is `'loading'`), breaking the zero-footprint-at-load invariant (found by B2's load-footprint check; fixed by calling `init()` directly).
Test-side mistakes also fixed (not product bugs): an out-of-scope variable inside `$$eval`, an Arabic regex that missed «للحد» (ل merges with the article), a wrong engine method name, and several weak assertions rewritten before the first run.

Deviations from the pre-generated B3 prompt:
1. The quick-task-modal chips are injected by a click listener on `#hFab`, not by a `MutationObserver` (`#hFab` is the only opener; creates no observer at load; keeps B2's tested invariant). The badge observer exists only after a plan exists.
2. `tests/inject.test.js` was **not** edited although 2 of its 46 checks now fail by construction (44/46); a 2-line proposed update (46/46 on a scratch copy) awaits the user's decision.
3. Additions inside TASK 1.2's scope: lazy plan creation; an overdue block so unfinished tasks of earlier days are not stranded; moves to past days refused; `data-act` hooks on every control.

Tests run (details and logs: `PROJECT-STATUS.md`, `docs/test-logs/B03/`): `tasks.planning` 53/53 · `tasks.unit` 39/39 · `inject` 44/46 (46/46 with the proposed patch on a scratch copy) · verifier PASS (OK=68) · self-test 27/27 · `inject --check` CURRENT · six existing suites on a scratch copy: update 64/64, offline 1/1, unified 12/12, resources 33/34 then 34/34, courses 31/32 then 32/32, perf within budget on 2 of 3 runs (one run 1 ms over); the intermittent checks also fail on the untouched B2 checkpoint in this environment. Not tested: real device, real soft keyboard, IME composition, Android Back, `WirdTasks.exec` (B4).

## [B2] — 2026-11-06 — TASK 0.3 + TASK 1.1 (module scaffold, injector, shared kit; task engine)
**Existing original files modified: ONE — `index.html`, by the approved insertion only** (four new blocks `style#wird-tasks-css`, `script#wird-tasks`, `style#wird-quiz-css`, `script#wird-quiz` directly before `<script id="wird-offline">`, written by the injector). Every byte outside those blocks is identical to the upload; the other 34 original files (incl. `sw.js`) are byte-identical. **No UI.** Verified by a file-level SHA-256 diff against the B1 checkpoint: 22 files created, 1 modified (`index.html`) + the tracking documents below, 0 deleted.

Created (22):
* `tools/patch/inject_wird_modules.py` — idempotent injector (see `docs/MODULES.md`)
* `tools/src/wird-kit.js`, `tools/src/tasks-shell.js`, `tools/src/quiz-shell.js`, `tools/src/tasks-engine.js`, `tools/src/tasks.css`, `tools/src/quiz.css`
* `tests/tasks.unit.test.js` (39 tests), `tests/inject.test.js` (46 checks)
* `docs/MODULES.md`, `docs/TASKS-ENGINE.md`
* `docs/test-logs/B02/` — `_exit-codes.txt`, `courses.log`, `inject.log`, `offline.log`, `perf.log`, `resources.log`, `tasks.unit.log`, `test_verify_preservation.log`, `unified.log`, `update.log`, `verify_preservation.log`

Modified: `index.html` (above) · `PROJECT-STATUS.md`, `HANDOFF.md`, `CHANGELOG.md` (this entry) · `MASTER-PLAN.md` (one row in §12 Change log; no decision changed) · `NEXT-SESSION-PROMPT.md` (pointer now B3; not in the prompt's expected list, a one-line pointer file).
Deleted: none.

Defects found by B2's own tests in B2's own new code, and fixed before completion:
1. `wird-kit.js` — the URL sanitising regex contained raw U+2028/U+2029/zero-width characters (typed escapes had turned into literal characters); a raw line separator ends a regex literal, so both injected script blocks failed to parse (`SyntaxError`). Found by the browser part of `tests/inject.test.js` (Node unit tests load the engine file alone and could not see it). Fixed with `\u` escapes; a parse check of both injected blocks and a scan for invisible characters were added to the tests. Three other files had harmless raw BOM/RLM characters and were converted to escapes.
2. `inject_wird_modules.py` — with `verify_preservation.py` missing it wrote `index.html` first and refused afterwards (exit 2 with the file changed), contradicting "exit 2 = nothing written". Now checked before any write, plus a restore backstop.
3. `tasks-engine.js` — header promised `WirdTasks.getEngine()` but only `WirdTasks.engine.getEngine` existed; now attached.
4. `tasks-engine.js` — data it could not fully understand (unparseable / invalid schema / repaired) was kept only in memory, so the first save would have overwritten the only copy. Now copied byte for byte to `wird_tasks_v1_recovered_<ms>` (prefs: `wird_taskprefs_v1_recovered_<ms>`) first; if that copy cannot be written, nothing is overwritten. 3 tests added, validated with 4 mutants.
(Also during test writing: one test mistake overwrote the real frozen `tools/src/resources.js` **in a scratch copy**; the verifier correctly failed. The project tree was never affected.)

Tests executed (all on scratch copies except the unit test and the injector test, which create their own temp copies; logs in `docs/test-logs/B02/`):
* `node tests/tasks.unit.test.js` — 39/39, 26,844 assertions; 150-seed randomised run; engine mutated 6 + 4 ways, every mutant caught
* `NODE_PATH=$(npm root -g) node tests/inject.test.js` — 46/46 (33 injector scenarios incl. 24 refusal/rollback cases; 13 injected-page-vs-pristine-page checks in Chromium)
* `python3 -I tools/audit/verify_preservation.py` — PASS, OK=68, NEW=81 · `python3 -I tools/audit/test_verify_preservation.py` — 27/27 · `python3 -I tools/prompt-package/audit_package.py` — 317/317
* Six existing suites on a scratch copy of the final tree, foreground: update 64/64 · offline 1/1 · unified 12/12 · resources 34/34 · courses 32/32 (first run) · perf within budget (CPU×1 open 282 ms, CPU×4 open 336 ms; budget 800)
* NOT executed: any real device (Android Brave, installed PWA), engine speed or storage growth measured in a real browser, multi-tab behaviour.

## [PKG-1] — 2026-11-03 — Planning package (docs and generator only; NOT a development batch)
**Existing original files modified: none. Application code changed: none.**

Created:
* `MASTER-PLAN.md`, `BATCH-DEPENDENCY-MAP.md`, `TRACEABILITY-MATRIX.md`, `PROMPT-USAGE-GUIDE.md`, `CHANGELOG.md`
* `prompts/B01-EXECUTION-PROMPT.md` … `prompts/B17-EXECUTION-PROMPT.md` (17 files)
* `tools/prompt-package/` — `build_package.py`, `audit_package.py`, `test_audit_package.py`, `pkg_lib.py`, `common.py`, `data_decisions.py`, `data_requirements.py`, `batches_a.py`, `batches_b.py`, `batches_c.py`

Modified (all were created in B1; none is an original file):
* `docs/ROADMAP.md` — restored the full approved task-card text (Objective / Scope / Files / Depends / Accept / Tests) for all 24 tasks, removed status markers from headings (status lives only in PROJECT-STATUS.md), kept amendments A1–A8.
* `PROJECT-STATUS.md`, `HANDOFF.md` — added the batch table, decisions D1–D11, planning-package state, and the B2 continuation via `prompts/B02-EXECUTION-PROMPT.md`.
* `NEXT-SESSION-PROMPT.md` — replaced by a pointer to `prompts/B02-EXECUTION-PROMPT.md` (the B1 version is superseded).

Deleted: none.

Checks run: `python3 -I tools/prompt-package/audit_package.py` (consistency audit of the package: 317/317) · `python3 -I tools/prompt-package/test_audit_package.py` (12/12) · `python3 -I tools/audit/verify_preservation.py` · `python3 -I tools/audit/test_verify_preservation.py` — results in `PROJECT-STATUS.md` / the PKG-1 report.

## [B1] — 2026-11-03 — TASK 0.1 + TASK 0.2 (baseline, verifier, integration spikes)
**Existing original files modified: none. Application code changed: none.**

Created (24): `PROJECT-STATUS.md`, `HANDOFF.md`, `NEXT-SESSION-PROMPT.md`, `docs/ROADMAP.md`, `docs/INTEGRATION-SPIKES.md`, `docs/BASELINE-TEST-RESULTS.md`, `docs/PRESERVATION-BASELINE.json`, `docs/baseline-logs/` (9 logs), `docs/spike-evidence/` (4 PNG + `probe-output.json`), `tools/audit/verify_preservation.py`, `tools/audit/test_verify_preservation.py`, `tools/audit/probe_anchors.js`.
Deleted: none.

Tests executed: the six existing suites on a scratch copy — update 64/64, offline 1/1, unified 12/12, resources 34/34, courses 31/32 then 32/32 (flaky test 18), perf within budget; verifier self-test 27/27 (first run 26/27 because of a wrong expected string in the test itself, fixed in the test only); verifier PASS on the pristine upload and on the B1 tree; live probe with 0 page errors. Checkpoint: `wird_work_B1_checkpoint.zip` (SHA-256 `6143002de3733a9d538a9d7e10c3b2fa2d08323fdfe302e4d02aa9b21f74d677`), re-extracted and verified.
