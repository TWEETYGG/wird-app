# PROJECT-STATUS — Wird: Task Atomization + Focus Quiz

Last updated: **after Batch B3 (TASK 1.2)** · dates use the container clock (UTC): 2026-11-07.
`HANDOFF.md` and this file describe the same state; the actual project files are the source of truth. **IMPLEMENTED ≠ TESTED ≠ VERIFIED.**
Requirements and decisions: `MASTER-PLAN.md` · task cards: `docs/ROADMAP.md` · batch graph: `BATCH-DEPENDENCY-MAP.md` · traceability: `TRACEABILITY-MATRIX.md` · how to run prompts: `PROMPT-USAGE-GUIDE.md`.

## Current execution position
* Latest completed **development** batch: **B4 = TASK 1.3** (focused execution screen `WirdTasks.exec`: one step, one action, undo snackbar, back, pause/resume, exact restore, optional skip / in-run edit / timer / progress; the planner now offers «ابدأ» / «متابعة»). Before it: B3 = TASK 1.2 (planning UI), B2 = TASK 0.3 + 1.1 (scaffold, injector, kit, task engine) and B1 = TASK 0.1 + 0.2.
* Latest completed **planning** work: **PKG-1** — MASTER-PLAN, 17 batch prompts, dependency map, traceability matrix, usage guide, CHANGELOG (documents and generator only; no application code changed). **Having a prompt does not mean its batch is done.**
* Next recommended batch (needs the user’s explicit approval): **B5 = TASK 1.4 + 1.5** (preferences UI, feedback, end-of-day prompt, Phase-1 verification) — prompt `prompts/B05-EXECUTION-PROMPT.md`; upload `wird_work_B04_checkpoint.zip`.
* **Decision needed (found in B3, widened in B4):** two protected tests now fail *by construction* because the modules legitimately grew. `tests/inject.test.js` 44/46 (hard-codes the file list and the `WirdTasks` key list; B4 added `tasks-exec.*` and `WirdTasks.exec`) and `tests/tasks.planning.test.js` 49/53 (four B3 tests assert that **no execution screen exists**; two of them fail only as a cascade). Proposed patches that make them 46/46 and 53/53 (proved on scratch copies): `docs/test-logs/B04/inject.test.js.PROPOSED.patch` (supersedes the B3 one) and `docs/test-logs/B04/tasks.planning.test.js.PROPOSED.patch`. Neither is applied without approval; B5 must not “fix” them by editing the tests on its own.
* Open user decisions: **D1–D11**, all UNCONFIRMED (defaults in force). HARD gates: **D2 before B8**, **D6 before B17**.

## Batch table (B1–B17)

| Batch | Tasks | Phase | Prompt file | Status |
|---|---|---|---|---|
| B01 | 0.1 + 0.2 | Phase 0 | `prompts/B01-EXECUTION-PROMPT.md` | **COMPLETED** (verify-only prompt) |
| B02 | 0.3 + 1.1 | Phase 0 / Phase 1 | `prompts/B02-EXECUTION-PROMPT.md` | **COMPLETED** (2026-11-06) |
| B03 | 1.2 | Phase 1 | `prompts/B03-EXECUTION-PROMPT.md` | **COMPLETED** (2026-11-07) — one open decision (stale `inject.test.js` expectations) |
| B04 | 1.3 | Phase 1 | `prompts/B04-EXECUTION-PROMPT.md` | **COMPLETED** (2026-11-08) — one open decision (two protected tests with stale expectations) |
| B05 | 1.4 + 1.5 | Phase 1 | `prompts/B05-EXECUTION-PROMPT.md` | NOT STARTED |
| B06 | 2.1 + 2.2 | Phase 2 | `prompts/B06-EXECUTION-PROMPT.md` | NOT STARTED |
| B07 | 2.3 | Phase 2 | `prompts/B07-EXECUTION-PROMPT.md` | NOT STARTED |
| B08 | 2.4 | Phase 2 | `prompts/B08-EXECUTION-PROMPT.md` | NOT STARTED |
| B09 | 3.1 | Phase 3 | `prompts/B09-EXECUTION-PROMPT.md` | NOT STARTED |
| B10 | 3.2 | Phase 3 | `prompts/B10-EXECUTION-PROMPT.md` | NOT STARTED |
| B11 | 3.3 + 3.4 | Phase 3 | `prompts/B11-EXECUTION-PROMPT.md` | NOT STARTED |
| B12 | 4.1 | Phase 4 | `prompts/B12-EXECUTION-PROMPT.md` | NOT STARTED |
| B13 | 4.2 + 4.3 | Phase 4 | `prompts/B13-EXECUTION-PROMPT.md` | NOT STARTED |
| B14 | 4.4 | Phase 4 | `prompts/B14-EXECUTION-PROMPT.md` | NOT STARTED |
| B15 | 5.1 | Phase 5 | `prompts/B15-EXECUTION-PROMPT.md` | NOT STARTED |
| B16 | 5.2 + 5.3 | Phase 5 | `prompts/B16-EXECUTION-PROMPT.md` | NOT STARTED |
| B17 | 5.4 | Phase 5 | `prompts/B17-EXECUTION-PROMPT.md` | NOT STARTED |

## Task table

| Task | Title | Batch | Status | Implemented | Tested | Verified | Completed | Depends on |
|---|---|---|---|---|---|---|---|---|
| 0.1 | Baseline, preservation verifier, tracking files | B01 | **COMPLETED** | yes | yes | yes | 2026-11-03 | — |
| 0.2 | Integration-point spikes (read-only) | B01 | **COMPLETED** | yes | yes | yes | 2026-11-03 | 0.1 |
| 0.3 | Module scaffold, injector, storage namespaces | B02 | **COMPLETED** | yes | yes | yes | 2026-11-06 | 0.1, 0.2 |
| 1.1 | Task engine & persistence | B02 | **COMPLETED** | yes | yes | yes (Node + desktop Chromium; no UI exists yet) | 2026-11-06 | 0.3 |
| 1.2 | Planning UI & entry points | B03 | **COMPLETED** | yes | yes | yes (desktop Chromium emulation at 360/390/412 px; no real device) | 2026-11-07 | 1.1, 0.2 |
| 1.3 | Focused execution screen | B04 | **COMPLETED** | yes | yes | yes (desktop Chromium emulation at 360/390/412 px + landscape; no real device, no real Android Back) | 2026-11-08 | 1.1, 1.2 |
| 1.4 | Preferences, feedback, end-of-day | B05 | NOT STARTED | no | no | no | — | 1.3 |
| 1.5 | Verification & regression | B05 | NOT STARTED | no | no | no | — | 1.1, 1.2, 1.3, 1.4 |
| 2.1 | JSON schema, content spec, validator | B06 | NOT STARTED | no | no | no | — | 0.3, 0.2 |
| 2.2 | Storage & session state machine | B06 | NOT STARTED | no | no | no | — | 2.1 |
| 2.3 | Rich question renderer | B07 | NOT STARTED | no | no | no | — | 2.1, 0.2 |
| 2.4 | AI prompt, import UI, lesson placement | B08 | NOT STARTED | no | no | no | — | 2.1, 2.2, 2.3 |
| 3.1 | Choice-family widgets | B09 | NOT STARTED | no | no | no | — | 2.1, 2.3 |
| 3.2 | Free-form widgets & attachments | B10 | NOT STARTED | no | no | no | — | 2.2, 2.3 |
| 3.3 | Focus Tunnel flow | B11 | NOT STARTED | no | no | no | — | 3.1, 3.2, 2.2 |
| 3.4 | Quiz preferences & modes | B11 | NOT STARTED | no | no | no | — | 3.3, 1.4 |
| 4.1 | Review & self-grading | B12 | NOT STARTED | no | no | no | — | 3.3, 2.2 |
| 4.2 | Export & external-AI grading workflow | B13 | NOT STARTED | no | no | no | — | 4.1 |
| 4.3 | Session report | B13 | NOT STARTED | no | no | no | — | 4.1 |
| 4.4 | Mistake tracking | B14 | NOT STARTED | no | no | no | — | 4.1, 4.3, 0.2 |
| 5.1 | Quiz end-to-end suite | B15 | NOT STARTED | no | no | no | — | 4.1, 4.2, 4.3, 4.4 |
| 5.2 | Mobile / RTL / accessibility / performance pass | B16 | NOT STARTED | no | no | no | — | 5.1 |
| 5.3 | Documentation | B16 | NOT STARTED | no | no | no | — | 5.2 |
| 5.4 | FINAL AUDIT & packaging | B17 | NOT STARTED | no | no | no | — | ALL |

Verification detail for the completed tasks (B2: see `docs/MODULES.md`, `docs/TASKS-ENGINE.md`, `docs/test-logs/B02/`; B2 found and fixed four defects in its own new code before completion — listed in `CHANGELOG.md`): TASK 0.1 — six baseline suites run on a scratch copy, verifier + 27-case self-test, baseline written once from the pristine upload; TASK 0.2 — live Chromium probe (0 page errors), claims fact-checked against the source, screenshots compared with the user’s. See `docs/BASELINE-TEST-RESULTS.md`, `docs/INTEGRATION-SPIKES.md`.

## Decision register status (full text: `MASTER-PLAN.md` §8)

| ID | Topic | Gate | Needed by | Status |
|---|---|---|---|---|
| D1 | Entry point of Task Atomization | SOFT | B3 | UNCONFIRMED (default in force) |
| D2 | Meaning/location of "Add New Sheet" = anchor of the saved-prompt button | HARD | B8 | UNCONFIRMED (default in force) |
| D3 | How quizzes appear inside a lesson | SOFT | B8 | UNCONFIRMED (default in force) |
| D4 | Rich-text format of quiz content | SOFT | B6 | UNCONFIRMED (default in force) |
| D5 | Mistake tracking: pool, notebook integration, defaults | SOFT | B14 | UNCONFIRMED (default in force) |
| D6 | `sw.js` SHELL_VERSION bump at release | HARD | B17 | UNCONFIRMED (default in force) |
| D7 | Future-day plans storage | SOFT | B2 | UNCONFIRMED (default in force) |
| D8 | Link targets of a step plan | SOFT | B3 | UNCONFIRMED (default in force) |
| D9 | Scoring rules of the session report | SOFT | B13 | UNCONFIRMED (default in force) |
| D10 | Meaning of "submit the answers to a teacher" | SOFT | B13 | UNCONFIRMED (default in force) |
| D11 | Location of settings (no global settings screen exists) | SOFT | B5 | UNCONFIRMED (default in force) |

## Test status (what has actually been executed)

| What | Result |
|---|---|
| Existing suites on the untouched upload (scratch copy, B1) | update 64/64 · offline 1/1 · unified 12/12 · resources 34/34 · courses 31/32 then 32/32 (flaky test 18) · perf within budget — `docs/BASELINE-TEST-RESULTS.md` |
| `tools/audit/test_verify_preservation.py` | 27/27 |
| `tools/audit/verify_preservation.py` | PASS (pristine, B1 tree, and the PKG-1 tree: OK=68, only NEW files) |
| `tools/prompt-package/audit_package.py` (PKG-1 consistency audit: 17 prompts, 24 task cards verbatim, dependency integrity, identical common blocks, deferred/optional/preservation strings, requirement traceability) | 317/317 checks passed |
| `tools/prompt-package/test_audit_package.py` (12 mutation cases proving the audit detects tampering) | 12/12 (one case first exposed a crash on a missing prompt file; the audit was fixed and re-run) |
| B2 `node tests/tasks.unit.test.js` (task engine; 39 tests incl. 150-seed randomised run, backup-before-overwrite) | 39/39 · 26,844 assertions · validated by 10 deliberate mutants (all caught) — `docs/test-logs/B02/tasks.unit.log` |
| B2 `node tests/inject.test.js` (injector on scratch copies + injected page vs pristine page in Chromium) | 46/46 (33 injector + 13 browser) — `docs/test-logs/B02/inject.log` |
| B2 existing suites on a scratch copy of the final B2 tree | update 64/64 · offline 1/1 · unified 12/12 · resources 34/34 · courses 32/32 (first run, no flake) · perf within budget (CPU×1: render 9 ms, open 282 ms; CPU×4: render 20 ms, scroll step 30 ms, open 336 ms — budget 800; this machine is faster than the B1 one, so the numbers are not comparable one to one) — `docs/test-logs/B02/*.log` |
| B2 `verify_preservation.py` on the final tree | PASS — OK=68, NEW=81 (4 new blocks + new files); `test_verify_preservation.py` 27/27 |
| B3 `node tests/tasks.planning.test.js` (pristine vs injected page under a fixed clock; every planning operation; fault injection; observer discipline; 3 phone viewports) | **53/53 · 405 assertions** on a scratch copy of the final tree (`docs/test-logs/B03/tasks.planning.log`). It found two real defects in B3's own code before completion (see CHANGELOG). 3 deliberate mutations are caught (`docs/test-logs/B03/mutations/`) |
| B3 `node tests/inject.test.js` (B2's, protected, NOT edited) | **44/46** — the load-footprint check passes; the 2 failures are stale expectations (file list, `WirdTasks` key list) that any correct B3 must break. **46/46** with the 2-line proposed update on a scratch copy (`inject.log`, `inject.with-proposed-patch.log`) |
| B3 `node tests/tasks.unit.test.js` | 39/39 · 26,844 assertions (engine unchanged) |
| B3 existing suites on a scratch copy of the final tree | update 64/64 · offline 1/1 · unified 12/12 · resources 33/34 then 34/34 · courses 31/32 then 32/32 · perf CPU×4 scroll step 61.0 ms (budget 60, one run) then 49.1 and 46.1 ms. The intermittent checks are the ones the project README already lists (VID-3, END-3, 8-10-11): on the **untouched B2 checkpoint** in this environment resources failed VID-3 2/2 runs, courses gave 32/32 then 31/32, perf gave 57.9 and 47.0 ms — so they are not B3 regressions (all logs in `docs/test-logs/B03/`) |
| B3 `verify_preservation.py` / its self-test / `inject --check` | PASS (OK=68, all original files intact; NEW = new files only) · 27/27 · CURRENT |
| B4 `node tests/tasks.exec.test.js` (6 Node tests of the additive engine field + 64 Chromium tests under a fixed clock: flow, undo, back, pause, reload **and browser-restart** restore, dedupe, skip, edit, timer, progress, reduced motion, history, listener balance, 3 phone viewports + landscape) | **70/70 · 470 assertions** on the final tree, twice (`docs/test-logs/B04/tasks.exec.log`, `tasks.exec.second-run.log`). 7 deliberate mutations all caught (`docs/test-logs/B04/mutations/`) |
| B4 `node tests/tasks.unit.test.js` (engine, with the additive `elapsedMs` field) | 39/39 · 26,844 assertions (unchanged tests) |
| B4 `node tests/inject.test.js` (protected, NOT edited) | **44/46** (the same two stale expectations; load-footprint check passes) · 46/46 with `docs/test-logs/B04/inject.test.js.PROPOSED.patch` on a scratch copy |
| B4 `node tests/tasks.planning.test.js` (B3's, protected, NOT edited) | **49/53** — 4 tests assume no execution screen exists · **53/53 · 405 assertions** with `docs/test-logs/B04/tasks.planning.test.js.PROPOSED.patch` on a scratch copy |
| B4 existing suites on a scratch copy of the final tree | update 64/64 · offline 1/1 · unified 12/12 · resources 34/34 · perf within budget (CPU×4 scroll step 59.1 then 45.9 ms, budget 60) · courses 31/32, 31/32, 32/32, 32/32 (test 8-10-11, the documented flake; the untouched B3 checkpoint gave 32/32, 31/32, 32/32) — logs in `docs/test-logs/B04/` |
| B4 `verify_preservation.py` / its self-test / `inject --check` | PASS (OK=68, NEW=177 = new files only) · 27/27 · CURRENT |
| B4 real Android device, real Android Back button, real soft keyboard / IME, sound and haptic on hardware, screen reader, two tabs | **not tested** (Back verified with Chromium `goBack`; keyboard simulated by a viewport shrink) |
| Quiz feature tests | **none exist yet** (B2 has only the empty quiz shell) |
| Real Android device, PWA install, camera | **not tested** |
| Task engine speed and storage behaviour in a real browser at scale | **not measured** (Node only: 1.6 ms per action at 1000 completions) |

## Existing files modified
**One: `index.html`**, by the approved insertion only — four new blocks (`style#wird-tasks-css`, `script#wird-tasks`, `style#wird-quiz-css`, `script#wird-quiz`) directly before `<script id="wird-offline">`, written by `tools/patch/inject_wird_modules.py`. Every byte outside those four blocks is identical to the upload (cutting the region out reproduces the B1 `index.html` byte for byte; verified by hash). The other 34 original files, including `sw.js`, are byte-identical to the upload; verifier PASS (all 26 original blocks hash-identical).

**B4 modifies (besides `index.html` through the injector): `tools/src/tasks-engine.js`** (one additive documented field, `elapsedMs`), **`tools/src/tasks-ui.js`** (the «متابعة» label and the origin hand-off, ≈12 lines) and the docs (`docs/TASKS-ENGINE.md`, `docs/MODULES.md`, `PROJECT-STATUS.md`, `HANDOFF.md`, `CHANGELOG.md`, `NEXT-SESSION-PROMPT.md`). SHA-256 comparison with the B3 checkpoint: exactly 9 files modified (`index.html`, the two source files, the six docs), 0 deleted. No original file other than `index.html` was touched.

**B3 modifies (besides `index.html` through the injector): `tools/src/tasks.css`** (the B2 placeholder, a file created in B2 — not an original file) and the tracking docs. No original file other than `index.html` was touched; `sw.js`, the engine, the shell, the kit and every existing test are byte-identical to the B2 checkpoint (hash manifest compared; see CHANGELOG).
## Files created since the upload
B1 (24 files, see `CHANGELOG.md`), B2 (22 files: `tools/patch/inject_wird_modules.py`, `tools/src/{wird-kit,tasks-shell,tasks-engine,quiz-shell}.js`, `tools/src/{tasks,quiz}.css`, `tests/{tasks.unit,inject}.test.js`, `docs/MODULES.md`, `docs/TASKS-ENGINE.md`, `docs/test-logs/B02/` ×11) and PKG-1: `MASTER-PLAN.md`, `BATCH-DEPENDENCY-MAP.md`, `TRACEABILITY-MATRIX.md`, `PROMPT-USAGE-GUIDE.md`, `CHANGELOG.md`, `prompts/B01…B17-EXECUTION-PROMPT.md`, `tools/prompt-package/*` (10 files). Modified (all B1 documents, none original): `docs/ROADMAP.md`, `PROJECT-STATUS.md`, `HANDOFF.md`, `NEXT-SESSION-PROMPT.md`.

B3 (new files only): `tools/src/tasks-ui.js`, `tests/tasks.planning.test.js`, `docs/test-logs/B03/` (logs, 18 screenshots, 3 mutation logs, the proposed patch).

B4 (new files only): `tools/src/tasks-exec.js`, `tools/src/tasks-exec.css`, `tests/tasks.exec.test.js`, `docs/test-logs/B04/` (logs, 19 screenshots, 7 mutation logs, 2 proposed patches).
## Known issues / items outside scope (documented, not fixed)
1. `courses.test.js` test 18 («أوفلاين أثناء جلب البيانات») is flaky (failed once, passed on re-run). Not investigated.
2. README mentions VID-3 / END-3 / 8-10-11 failures. **They did not reproduce at B1, but they do reproduce intermittently in the B3 environment (Chromium 153, Playwright 1.63)** — also on the untouched B2 checkpoint. Treat a single failure of exactly these checks as the known flake: re-run once and compare with the B2 checkpoint before calling it a regression.
3. `hModal` has no Esc handling or focus trap (existing behaviour; new UI supplies its own).
4. `perf.test.js` lesson `openMs` at CPU×4 = 767 ms vs budget 800 ms — 33 ms headroom.
5. Amendments A1–A8 and decisions D1–D11 are adopted-but-unconfirmed (the user proceeded without objecting; no explicit approval) — see `MASTER-PLAN.md` §9 (U1–U13).
6. The container clock can differ from the chat date by a day; dates in documents follow the container clock (UTC).
7. **(B2) Task-engine storage grows without bound:** one JSON value, event history never pruned, ≈13 KB per day of heavy use (1000 completions ≈ 413 KB). A compaction/export policy is a **user-facing decision needed before B17**; not done silently.
8. **(B2) Last write wins across tabs:** two open tabs each hold their own copy of `wird_tasks_v1`; `engine.reload()` exists for a UI to call on a `storage` event (not wired in B2).
9. **(B2) KaTeX loader residual race:** if the kit and the lessons module start loading KaTeX in the same instant on a cold page, each may add a `<script>`; the common orders evaluate it exactly once (tested). Documented in `docs/MODULES.md` §4.
10. **(B2) Playwright 1.63.0 here vs 1.56.0 in the B1 baseline notes** (Chromium build differs too). Results are compared by pass counts, not by timings.
11. **(B2) `endOfDayPrompt` defaults to ON** and the undo window to 8 s — interpretations the brief does not fix (ASSUMED DEFAULT A1 / I3); the user may answer when the UI batches (B3–B5) arrive.
12. **(B2) Engine recovery backups** (`wird_tasks_v1_recovered_<ms>`, `wird_taskprefs_v1_recovered_<ms>`) are never deleted by code; a later batch should let the user export or discard them.
13. **(B2) Process note:** a background test runner was again stopped when the session paused (the `update` suite had to be re-run in the foreground). Run long suites in the foreground.
14. **(B3) `tests/inject.test.js` expectations are stale (decision needed).** Two checks hard-code B2's file list and `WirdTasks` key list. B3 adds `tasks-ui.js` and `WirdTasks.ui`, so they fail by construction (44/46). The file is protected and was not edited; hiding `ui` (non-enumerable) to dodge the check would be wrong. Approve the 2-line update (`docs/test-logs/B03/inject.test.js.PROPOSED.patch`) or decide another policy; B4 (`WirdTasks.exec`, `tasks-exec.js`) and B5 hit the same checks.
15. **(B3) Deviation from the generated prompt:** the quick-task-modal chips are injected by a click listener on `#hFab` instead of a `MutationObserver` (`#hFab` is the only opener; no observer at load; B2's load-footprint invariant kept). Documented in `docs/MODULES.md` §6.1.
16. **(B3) Soft keyboard only simulated** (viewport shrink + `visualViewport` handler); no real device, no IME composition test, no Android Back handling (the sheet closes by ✕, Esc or backdrop).
17. **(B3) Discoverability:** a quick-task row **without** a plan looks exactly like before on purpose (rows must stay identical), so the only visible entry points are the two modal chips; tapping the name is a hidden shortcut. The user may want a hint.
18. **(B3) Plan title and quick-task name are independent** after creation; deleting a quick task from the habits screen leaves its plan (orphan link, harmless; no unlink UI). Adding a step to a finished plan reopens it (engine behaviour) and the planner does not explain that.
19. **(B3) Every title/step commit appends an engine event** (`task_edit` / `step_edit`), which adds to the storage growth in item 7.
20. **(B3) Process notes:** one command is stopped after 300 s by the tool (run mutation checks under `timeout 240`); under a frozen test clock the app's quick-task ids (`o_<Date.now()>`) collide, so tests must advance the fixed time between creations.
21. **(B4) Two protected tests have stale expectations (decision needed; supersedes item 14).** `tests/inject.test.js` 44/46 and `tests/tasks.planning.test.js` 49/53 fail by construction (see "Current execution position"). Not edited. Every later batch that adds a source file or a `WirdTasks` key hits the same `inject.test.js` checks again.
22. **(B4) Deviations from the generated prompt:** the code is in new files `tasks-exec.js` / `tasks-exec.css` (as `HANDOFF.md` asked) rather than in `tasks-ui.js` / `tasks.css`; «returns to the planner/day» after the last step is an explicit «تمام» button (the undo window needs the screen); opening a **paused** task resumes it. All in `CHANGELOG.md`.
23. **(B4) Android Back** closes the view through one pushed history entry (`{wirdExec:1}`); verified with Chromium `goBack` only. A reload while the view is open leaves one stale same-URL entry (reused by the next open, never stacked), so one Back press after such a reload may appear to do nothing.
24. **(B4) The stopwatch** counts the time the current step has been on screen in this opening; it restarts from zero when the view is reopened, and only the completed/skipped step's reading is stored (`elapsedMs`). Nothing reads `elapsedMs` yet.
25. **(B4) Cross-tab:** the view does not listen for another tab; a tap on a step that another tab already resolved records nothing and re-syncs the view (tested), but the screen is not live.
26. **(B4) Sound / haptic / progress / timer / skip / edit-in-run** work from preferences but there is **no settings UI yet** (B5); until then they are reachable only through the engine API. The completion state has no end-of-day prompt (B5).
27. **(B4) Process notes:** the shell is `/bin/sh` (no `<( )` process substitution); a full run of `tasks.exec.test.js` takes ≈2 min and `tasks.planning.test.js` ≈2.5 min, both fit one 300 s command; `perf` scroll step is noisy (59.1 ms on one run, budget 60).
