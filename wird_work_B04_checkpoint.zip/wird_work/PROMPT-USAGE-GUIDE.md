# PROMPT-USAGE-GUIDE — how to run the 17 batch prompts

## 1. What you have

* `prompts/B01…B17-EXECUTION-PROMPT.md` — one standalone prompt per batch (paste ONE into a NEW Claude conversation).
* `MASTER-PLAN.md` (requirements, decisions, contracts) · `BATCH-DEPENDENCY-MAP.md` · `TRACEABILITY-MATRIX.md` · `PROJECT-STATUS.md` · `HANDOFF.md` · `CHANGELOG.md` · `docs/ROADMAP.md` (task cards).
* **Project ZIP:** the latest checkpoint of the app (`wird_work_<Bxx>_checkpoint.zip`). The first one to use is `wird_work_B1_checkpoint_with_plan.zip` (B1 result + all planning documents merged), which is the correct upload for B2.
* **B1 is already done** — its prompt (B01) is verify-only. Start real work at **B02**.

## 2. Before the first batch: the decision sheet

The plan has 11 decisions (D1–D11, `MASTER-PLAN.md` §8). None is confirmed; defaults are in force. Two are HARD gates (the session will stop and ask): **D2** before B8 (where the quiz prompt button goes) and **D6** before B17 (touching `sw.js`). You can answer any time by editing the line `USER DECISION OVERRIDES` at the top of the prompt, e.g. `D1: also add a 4th chip in wizard step 2; D9: partial credit = 0.5`. Sessions record your answers in `MASTER-PLAN.md`.

| ID | Question in one line | Default |
|---|---|---|
| D1 | Entry point of Task Atomization | Action on quick-task rows + chip in the quick-task modal; wizard untouched |
| D2 | Meaning/location of "Add New Sheet" = anchor of the saved-prompt button | B — a sibling after #wrHead in the lesson header (beside «📅 جدولة»). HARD gate before B8 |
| D3 | How quizzes appear inside a lesson | Lesson-linked quiz panel; no new resource type/tab |
| D4 | Rich-text format of quiz content | Markdown-style subset mapped to the lesson node types |
| D5 | Mistake tracking: pool, notebook integration, defaults | Separate quiz mistake pool + optional push to «دفتر الأخطاء»; recording ON, suggestions OFF |
| D6 | `sw.js` SHELL_VERSION bump at release | Never touch sw.js until B17, then ask. HARD gate |
| D7 | Future-day plans storage | Future-day plans live only in wird_tasks_v1 |
| D8 | Link targets of a step plan | Quick tasks + standalone plans; habit rows are not link targets |
| D9 | Scoring rules of the session report | Partial = 50 % of marks; marks-less questions reported separately; mastery only when nothing awaits grading |
| D10 | Meaning of "submit the answers to a teacher" | Export/share (copy, Web Share, print/PDF); no backend |
| D11 | Location of settings (no global settings screen exists) | Module-owned settings sheets (⚙ in the planner and the quiz sheet) |

## 3. Running one batch (the loop)

1. Open a **new** Claude conversation.
2. Upload the **latest project checkpoint ZIP** (the output of the previous batch; for B2 use `wird_work_B1_checkpoint_with_plan.zip`). If that ZIP does not contain `MASTER-PLAN.md` and `prompts/`, also upload the prompt-package ZIP.
3. Paste the whole batch prompt (`prompts/Bxx-EXECUTION-PROMPT.md`). Edit `USER DECISION OVERRIDES` if you decided something.
4. The session first **verifies** the previous batch (documents vs files vs tests). If something is missing it stops and tells you — do not push it to continue; fix the prerequisite first.
5. It implements only its tasks, runs the tests, updates the documents and delivers: the report, the checkpoint ZIP and its SHA-256.
6. **You** check the report (§5 below), test on your phone if the report lists items, and then — only then — go to the next batch with the new ZIP.

## 4. Which ZIP to upload

| Batch | Upload the ZIP produced by | Notes |
|---|---|---|
| B01 | any checkpoint (verify only) | already executed |
| B02 | `wird_work_B1_checkpoint_with_plan.zip` | |
| B03, B04, B05 | the previous batch of the Phase-1 chain | |
| B06 | B02 (or the integrated checkpoint if Phase 1 ran in parallel) | Phase 2 needs only B02 |
| B07, B08 | previous quiz batch | B8 needs your D2 answer |
| B09 | B07/B08 | |
| B10 | B09 (sequential) or B07 (parallel, see map) | |
| B11 | B10 + **Phase 1 finished (B05)** | join point: the ZIP must contain both chains |
| B12–B17 | previous batch | B15 needs Phase 1 and Phase 4; B17 asks you about D6 |

## 5. What to check after each batch (2 minutes)

* The report has the 8 sections (summary, files, tests EXECUTED vs NOT EXECUTED, preservation confirmation, decisions used, issues, ZIP + SHA-256, next).
* "Existing files modified" says **none** (or only the approved hook). `sw.js` unchanged until B17.
* Tests: counts match the baseline for the six old suites; the new tests are listed with real numbers; anything NOT EXECUTED is explained.
* The new ZIP exists in the outputs; the session re-extracted it and re-ran the verifier.
* If the report lists "real device — NOT TESTED" items, try them on your phone before approving the next batch (camera, keyboard, Back button, offline, installed PWA).

## 6. When something goes wrong

* **Session says a prerequisite is missing/mismatched:** it will stop. Upload the correct checkpoint, or ask for `REPLAN`. Never ask it to "just continue".
* **Context almost exhausted:** B5, B6, B11, B16 are large; they are allowed to stop at an intermediate boundary (e.g. after TASK 1.4) with a partial checkpoint. Start a new conversation with the same prompt: it will detect which tasks are already COMPLETED and resume.
* **Flaky test:** `courses` test 18 may fail once; the session re-runs and reports both runs.
* **Wrong result:** keep the previous checkpoint ZIP (they are never overwritten); you can re-run a batch from it.

## 7. Parallel work (optional) and the integration session

Only the windows in `BATCH-DEPENDENCY-MAP.md` §4 are allowed. After parallel batches finish, open ONE new conversation, upload the common-ancestor ZIP and every parallel checkpoint, and paste:

```
You are running an INTEGRATION SESSION for the Wird project (no feature work). Read MASTER-PLAN.md, PROJECT-STATUS.md,
HANDOFF.md, CHANGELOG.md and BATCH-DEPENDENCY-MAP.md §5–§6 from the ancestor ZIP. Verify each uploaded checkpoint
(verifier PASS, 27/27 self-test, its batch tests). Create the merged project as follows: start from the ancestor; for each
parallel checkpoint copy ONLY the files listed as created/modified in its CHANGELOG entry, except index.html; resolve overlaps
with the table in BATCH-DEPENDENCY-MAP.md §5 (never overwrite another batch's work silently; report conflicts instead);
regenerate index.html with `python3 tools/patch/inject_wird_modules.py`; merge PROJECT-STATUS.md, HANDOFF.md and CHANGELOG.md
by hand keeping every batch's rows/sections/entries; run the verifier, the self-test, the union of the parallel batches' tests
and the six existing suites (scratch copy, foreground); then deliver `wird_work_<batches>_integrated_checkpoint.zip`
(verified by re-extraction) and an honest report (EXECUTED vs NOT EXECUTED, conflicts, files). Do not implement anything new.
Never touch sw.js or protected blocks. Stop afterwards and wait for my approval.
```

## 8. Keeping the package consistent

The prompts are generated: edit `tools/prompt-package/{data_*.py,batches_*.py,common.py}` and run `python3 -I tools/prompt-package/build_package.py` then `python3 -I tools/prompt-package/audit_package.py` (it must print PASS). Changing a task card means editing `docs/ROADMAP.md` first (via `REPLAN`) and rebuilding so every prompt embeds the new text verbatim.

## 9. Quick reference

| Batch | Tasks | Title |
|---|---|---|
| B01 | 0.1 + 0.2 | Foundation and integration-point investigation (ALREADY EXECUTED — verify-only prompt) |
| B02 | 0.3 + 1.1 | Module scaffold, injector, storage namespaces + Task engine |
| B03 | 1.2 | Task planning UI & entry points |
| B04 | 1.3 | Focused task execution screen |
| B05 | 1.4 + 1.5 | Task preferences, feedback, end-of-day prompt + Phase 1 verification/regression |
| B06 | 2.1 + 2.2 | Quiz schema, content spec, validator + quiz storage and session state machine |
| B07 | 2.3 | Rich question renderer (math, tables, media, bidi) |
| B08 | 2.4 | Fixed AI prompt, import UI and lesson placement |
| B09 | 3.1 | Choice-family answer widgets |
| B10 | 3.2 | Free-form widgets and handwritten-answer attachments |
| B11 | 3.3 + 3.4 | Focus Tunnel solving flow + quiz preferences and modes |
| B12 | 4.1 | Review and self-grading (with and without an answer key) |
| B13 | 4.2 + 4.3 | Answer-sheet export, external-AI grading workflow and session report |
| B14 | 4.4 | Local mistake tracking (deterministic rules) — Phase 4 checkpoint |
| B15 | 5.1 | Quiz end-to-end test suite (Part-13 tests 1–22) |
| B16 | 5.2 + 5.3 | Mobile/RTL/accessibility/performance pass and documentation |
| B17 | 5.4 | FINAL AUDIT and packaging |
