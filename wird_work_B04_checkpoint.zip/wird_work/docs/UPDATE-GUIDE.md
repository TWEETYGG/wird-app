# Wird — update system guide

Hosted at `https://tweetygg.github.io/wird-app/` (GitHub Pages, sub-path `/wird-app/`).

## 1. Releasing a new version (what you actually do)

1. Change whatever you need in `index.html`.
2. Open `sw.js` and change **only the number** on the line `const SHELL_VERSION = 5;` → `6` (next time `7`, …). Never use `1`.
3. Upload `index.html` **and** `sw.js` in the **same commit** (see §5). Upload `manifest.webmanifest` / icons only if they changed.
4. Wait for GitHub Pages to finish deploying (Actions tab → "pages build and deployment" turns green, usually 1–2 min).

If you forget step 2, users still get the change: the worker notices that `index.html` differs from its stored copy and shows the same "تحديث الآن" prompt. Do step 2 anyway — it is what installs a fresh copy of *every* shell file in one piece.

## 2. Cache ownership (what is kept, what is deleted)

| Cache | What it holds | Written by | On update |
|---|---|---|---|
| `wird-v5` (`wird-v<N>`) | App shell: `index.html`, `manifest.webmanifest`, `icon-192.png`, `icon-512.png` | worker, at install | **Replaced** by `wird-v6` etc. Deleted only after the new version is active |
| `wird-v1` | Quran + Tafsir pages (the "download for offline" button, plus pages read online) | page `pack()` and the worker on a cache miss | **Never deleted.** Never overwritten by the worker |
| `wird-runtime` | pdf.js, font files, other third-party static files, last prayer-times answer | worker | **Never deleted** |
| `wird-v2`, `wird-v3`, `wird-v4` | Old shell caches (they also contained Quran pages / pdf.js / prayer times captured at runtime) | old workers | Content copied into `wird-v1` / `wird-runtime` (only entries not already there), **then** deleted. If the copy cannot finish, they are kept and retried |
| anything else | unknown | — | **Never touched** |

Notes
* `wird-v1` has the same naming pattern as a shell cache. It is protected explicitly, and the list of deletable shell caches starts at `wird-v2`.
* User data (localStorage, IndexedDB: `wird_books_db`, `wird_study_db`, `wird_study_handles`, `wird_fnb_m`, `wird_mig_db`) is not touched by the worker at all and no database version was changed.

## 3. How users receive an update

1. The browser re-checks `sw.js` every time the app opens, and the app also checks when it returns to the foreground (at most every 10 min), when the network comes back, and hourly while open.
2. A newer `sw.js` is downloaded and its shell is stored in a new cache. The running app is not touched. If any file fails to download, the new version is discarded and the installed one keeps running; the next check retries.
3. A banner appears: **"فيه نسخة جديدة من ورد جاهزة — تحديث الآن / لاحقًا"**. Nothing reloads by itself.
4. **تحديث الآن** → the new worker activates → the page reloads once, after activation has finished. If you typed within the last 30 s or a Quran download is running, the banner asks for a second tap first.
5. Other open tabs are not reloaded; they show "النسخة الجديدة اتفعّلت — إعادة التحميل".
6. **لاحقًا** hides the banner for 30 min. If the app is closed, the waiting version is picked up the next time the app is opened anyway (a reload of the only open tab also activates it).

**First rollout (v4 → v5):** installed v4 pages have no banner code. They download v5 in the background and switch to it the next time the app is closed and reopened. From v5 onward the banner is used.

## 4. Behaviour changes versus v4 (deliberate)

* No automatic `skipWaiting()`: activation happens on the user's tap (or when the app is closed).
* Quran API pages are served cache-first from `wird-v1` and are never refreshed in the background. On a miss the page is fetched and stored **only if** the JSON body is not an error envelope (`code >= 400`).
* Prayer times (network-first, offline fallback) and third-party files now live in `wird-runtime`, so they survive releases.
* The duplicate `./` entry (a second 1.8 MB copy of `index.html`) is no longer precached.
* Unchanged: YouTube (incl. `googleapis.com`, which also bypasses Google Fonts CSS, as before), `everyayah.com`, `api.dictionaryapi.dev` and `Range` requests are never intercepted; `api.aladhan.com` is network-first.

## 5. Uploading from a phone

Use a mobile **browser** (the GitHub app cannot upload files). Open `https://github.com/tweetygg/wird-app`, and if the page is cramped turn on "Desktop site" in the browser menu.

1. Tap **Add file → Upload files**.
2. Pick `index.html` and `sw.js` (and the manifest/icons if they changed). Files with the same name replace the old ones; keep them in the repo root, next to the existing ones.
3. Write a commit message, choose "Commit directly to the main branch", tap **Commit changes**.
4. Wait for the green check on the Actions tab, then open the app.

Do **not** upload the `tools/` folder to the site if you do not need it; `tools/*/sw.js` and `tools/*/index.html` are old build inputs.
**Warning:** `tools/patch/build.py` and `unify.py` regenerate `sw.js` and the old registration from the old templates. If you ever re-run them, copy the new `sw.js` and the `wird-update` block from `index.html` back afterwards.

## 6. Manual testing checklist (real device)

1. Fresh install in a new browser profile: app opens, no banner, works offline after one reload.
2. Download Quran + Tafsir, note one page. Release a new version (§1). The banner appears within a few minutes of opening the app → tap تحديث الآن → app reloads once.
3. Airplane mode → open the app → open that Quran page, pdf viewer, prayer times (shows last answer).
4. Notes, bookmarks, wird progress, course progress are all still there after the update.
5. Open two tabs (desktop): update from one; the other shows "إعادة التحميل" and is not reloaded.
6. Upload a release with a deliberately missing `index.html` (or turn off network during install): the app keeps working on the old version and no banner shows. Upload the fixed release: banner appears.
7. Type in a note, then tap تحديث الآن: it asks for a second tap.
8. DevTools → Application → Cache Storage: `wird-v<N>`, `wird-v1`, `wird-runtime` present; `wird-v2…v4` gone after the first activation.

## 7. Automated tests (this folder)

`NODE_PATH=$(npm root -g) node tests/update.test.js` — 64 checks in real Chromium against a local GitHub-Pages-like server (`/wird-app/`, `max-age=600`, ETag, 404 outside the prefix): fresh install, v4→v5 upgrade with seeded localStorage/IndexedDB and a real pack download, offline before/after, excluded hosts, two tabs, failed install and recovery, forgotten version bump, typing guard, reload-loop guard.

**Not covered by any test:** the real GitHub Pages CDN, real Android/iOS installs, Firefox and Safari, the real Quran API. The Quran API, prayer API and CDN files are stubbed in the tests.
`tests/courses.test.js` has two timing-sensitive checks (END-3, 8-10-11) that also fail intermittently on the original project; `tests/resources.test.js` VID-3 fails on the original too.
