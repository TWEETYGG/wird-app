# Manhaji — Lesson Resources: developer notes

> **Superseded in part by the unified-tree release — see `docs/UNIFIED-DEV-NOTES.md`.** After `tools/patch/unify.py` runs on this
> document's output (`tools/phase2/`): the learning-hub module (patches H1–H5 below) and the standalone books / study / courses screens
> are removed; the "Phase 2" resource types (course, study text, notebook) are implemented; the courses suite is 32 tests (the six hub
> tests were replaced) and the resources suite is 35 with `ORIG_INDEX`; the service-worker cache is `wird-v4`. Everything else in this
> document (data model, progress rules, YouTube compliance) still holds.

Scope: the "lesson as a learning container" feature (video / book / link resources attached to a lesson) and the
`دروسي → منهجي` rename. Everything below is verified by `tests/resources.test.js` (35 tests; 34 without the optional real-v1 migration test) and
`tests/courses.test.js` (36 tests, unchanged behaviour).

## 1. Why a patch pipeline

The Lessons app ships inside `index.html` as one minified bundle (`<script id="ls-main">`); no source exists in the
project. So the feature is delivered as:

* **`tools/src/resources.js` + `resources.css`** — a readable, self-contained module injected as its own
  `<script id="wird-resources">` / `<style id="wird-resources-css">` (all UI, validation, progress rules, player glue).
* **`tools/patch/bundle_patches.py`** — a short list of *exact-match, must-match-once* string patches on the minified bundle
  (data layer + two tiny hooks). If the bundle ever changes, a patch fails loudly instead of silently mis-patching.
* **`tools/patch/build.py`** — runs the bundle patches, small patches to the courses and learning-hub modules, injects the
  module, renames the strings and bumps the service-worker cache (`wird-v2 → wird-v3`).

Rebuild from the pristine v1 files kept in `tools/orig/`:

```
python3 -I tools/patch/build.py tools/orig <out-dir>
```

The output is byte-identical to the shipped `index.html` / `sw.js` / README. No framework or dependency was added.

## 2. Data model

New IndexedDB store `resources` (keyPath `id`, indexes `lessonId`, `subjectId`). DB version `1 → 2` — **only** this store is
added; `onupgradeneeded` creates missing stores/indexes only, so the upgrade is idempotent and existing stores/records are never
touched (tests MIG-1/2, and MIG-3 which seeds data with the real v1 build and opens it with the new one).

```
Resource { id, lessonId, subjectId /*denormalised, like mistakes*/, type: video|book|link, title, order,
           status: todo|doing|done, completedAt, createdAt, updatedAt, rev, deletedAt, deleteBatch,
           video?{ youtubeVideoId, startSec?, endSec?, metadataStatus }
           book?{ bookId, pageStart?, pageEnd? }
           link?{ url } }
```

References, not copies: video watch progress/position live in the per-video record of `WirdCourses` (`C.videos[id]`),
book position in the book record. A resource never stores progress. Invalid input is rejected at the repo boundary
(`wirdResNorm`: 11-char YouTube id, http/https URL, integer pages ≥ 1, valid enums) and skipped with a warning on import.

Timestamp anchors in the note are ordinary `link` marks with `href = wird-res://<resourceId>?t=<sec>` or `?p=<page>` — the
existing document validator already preserves `link.href`, so **no schema/validator change** was needed. They render as chips
(CSS attribute selector), clicks are intercepted in the capture phase and routed to the player / book reader. Anchors are only
written through the live editor (normal save + conflict path), never by writing the doc behind the editor's back.

## 3. Injection points in the minified bundle (`bundle_patches.py`)

| Label | What | Why |
|---|---|---|
| P1, P2 | `oo=1→2`; add `"resources"` to store list and `resources:["lessonId","subjectId"]` to the index map | schema v2 |
| P3 | helpers `wirdResNorm`, `wirdResAll` before `var Os=` (applied last) | validation shared by repo + import |
| P4 | repo methods `listResources / listAllResources / getResource / saveResource / removeResource / putResourceRaw` | CRUD with `expectedRev` (ConflictError), mutex `mu.run`, `emit({type:"resources"})` |
| P5 | `softDelete` also soft-deletes the lessons' resources **in the same batch** with the lesson's `deleteBatch` | lifecycle |
| P6 | `restoreBatch` restores resources whose `deleteBatch` matches | lifecycle |
| P7 | `purgeWhere` also removes the lesson's resources | no orphans after purge / empty trash |
| P8a/b | `moveUnit` / `moveLesson` keep `resources.subjectId` in sync (same pattern as `mistakes`) | denormalised key |
| P9a–e | `dump`, `dumpMeta`, import replace (clear+put) and merge (newer `updatedAt` wins, never deletes) | JSON export/import |
| P10a–f | backup zip: write `data/resources.json`, manifest count, read (optional file ⇒ old backups still open), validate, copy-mode id remap incl. remapping `wird-res://` anchors in docs and version history | backup/restore |
| P11 | config strings `📖 دروسي/دروسي → 📖 منهجي/منهجي` | rename |
| P12 | one call `globalThis.__wirdRow&&globalThis.__wirdRow(t,n)` in the sidebar `rowEl` | badges + progress on rows |

`build.py` additionally patches (each guarded, must match exactly once):

* **courses module** — C1/C2/C3: the per-tick progress step is extracted verbatim into `applyStep(v,prev,t,wall,rate,now)`
  (the courses player now calls it too) and `loadYT, ytLink, saveSoon, applyStep, pausePlayer` are exported on `WirdCourses`.
  Lesson resources therefore *reuse* the same player loader, seek-vs-watch logic and per-video record — nothing is forked.
* **learning hub** — H1–H5: `lres` open action, search appends `WirdResources.hubSearch(k)`, the "continue" card gets the last
  lesson + next unfinished resource from `WirdResources.hubContinue()`, placeholder/hint text.
* global rename `دروسي → منهجي` in `index.html` and the README.

Existing hooks used (not modified): `window.__ctxLesson(view, slots, dirSel)` is wrapped (the previous handler still runs
first and its return value is preserved); the module attaches the head + segmented control under the lesson title.

## 4. Progress rules (also shown in the UI under «كيف يُحسب التقدّم؟»)

* lesson readiness = done ÷ eligible resources; resources whose source is missing are excluded and never deleted;
* a video only *suggests* completion at ≥ 90 % unique coverage of its range; completion is always an explicit action
  (and reversible: back to `doing` if there is progress, else `todo`); reaching the end of a range pauses + suggests only;
* lesson status: none / doing / review (all done + open mistakes in the lesson) / mastered (all done, no open mistakes);
* unit/subject = mean of the lessons that have eligible resources (each lesson weight 1) — deterministic, no double counting;
* independent from habit statistics; scheduling a lesson stores only `lessonRef {lessonId, resourceId?}` on a task and the
  task's completion never completes resources (nor vice-versa).

## 5. YouTube compliance

Official IFrame Player API only (through the existing `loadYT`); metadata via the keyless oEmbed endpoint (title, channel,
thumbnail shown unaltered); nothing is downloaded, extracted, cached or proxied; nothing is overlaid on the player/controls;
embedding-disabled or API-load failure shows an "open in YouTube" link (`rel="noopener noreferrer"`) and keeps all data;
`sw.js` still never intercepts youtube/ytimg/googlevideo/googleapis requests. Everything except playback and oEmbed lookups
works offline; offline lookups fall back to a manual title.

## 6. Tests

```
NODE_PATH=$(npm root -g) node tests/resources.test.js         # 34 tests, ~1–2 min
ORIG_INDEX=tools/orig/index.html NODE_PATH=$(npm root -g) node tests/resources.test.js   # 35 tests: adds MIG-3 (data written by the real v1 build, opened by v2)
NODE_PATH=$(npm root -g) node tests/courses.test.js           # 36 tests (existing suite, rename expectations updated)
```

Set `CHROME=/path/to/chrome` if Playwright's bundled browser is not installed. Both suites use a fake `YT.Player` driven by
Playwright's mocked clock (playback time follows `Date.now`, like a real player), mocked oEmbed and no real network.

## 7. Known limitations / not done

* **Phase 2 items are not implemented**: "course lesson" resource type, study-notebook (cloze) resource, pomodoro linkage.
* Unit/subject rollup is a plain mean of lessons (by design); there is no per-resource weighting (e.g. by video length).
* The book reader integration only calls the existing `openBookReader` / `renderBookPage`; PDF page ranges are not
  enforced inside the reader (the range is advisory: opens at range start / current page when inside it).
* Resource ordering is by creation time; there is no drag-and-drop reordering UI yet (`order` is stored for it).
* YouTube thumbnails are loaded from `i.ytimg.com` at display time (network); offline they show a neutral placeholder.
* The lesson's own history/version snapshots are unchanged; resources have `rev` for optimistic concurrency but no history.
* Not verified on a physical Android device / installed PWA — only headless Chromium at 360 px and 320 px.
