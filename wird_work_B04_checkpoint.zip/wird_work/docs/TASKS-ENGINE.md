# Task engine — design and API (B2 / TASK 1.1)

`tools/src/tasks-engine.js` is the pure-logic core of **Task Atomization**: days, tasks, steps, step-by-step execution, undo, preferences,
persistence and the link to a quick task. It has **no DOM, no timers and no listeners**, and it does nothing at load. It is injected
into `index.html` as part of the `wird-tasks` block (see `docs/MODULES.md`). B2 delivers the engine and its tests only; there is no UI yet.

Two environments, one file:

```js
// Node (unit tests)
const E = require('./tools/src/tasks-engine.js');
const eng = E.createEngine({ storage, clock, idGen });      // everything injectable
// Browser (after injection)
const eng = WirdTasks.getEngine();                           // lazy singleton on WirdKit.ls.adapter(); same API as E.getEngine()
```

`createEngine(deps)` — all optional: `storage` (`{getItem, setItem}`; default in-memory), `clock` (`() => ms`; default `Date.now`),
`idGen` (`prefix => string`; default a counter), `habits` (`{markOneoffDone(id, dayKey)}`; default a **no-op**, see §7),
`undoWindowMs` (default 8000).

## 1. Model

```
DAY (key "YYYY-MM-DD", local calendar day)  →  TASK (title ≤ 120)  →  STEP (text ≤ 300)
limits: 100 tasks per day, 100 steps per task
```
* **Task status** (derived): `not_started | in_progress | paused | completed | skipped | partial`.
  `completed` = every live step completed; `skipped` = every live step skipped; `partial` = all resolved, mixed.
* **Step state**: `not_started | in_progress | completed | skipped`.
* The **current step** is *derived*: the first unresolved live step in plan order. It is never stored, so it cannot get out of sync with
  the steps. Editing, inserting, deleting or reordering steps while a task runs simply re-derives it.
* **Events are append-only.** Every start / complete / skip / undo / back / pause / resume / edit / delete / move / link change appends an
  event with a unique `key` (for example `done:<stepId>:<n>`). The active resolution of a step is derived from the events: an *undo* or *back*
  **voids** the earlier event, it never deletes it. `getCompletions()` therefore always reflects exactly the completions that still stand,
  and survives later edits or deletion of the step or task (the completion record keeps the step text and task title as they were).
* **Deletes are tombstones** (`deletedAt`): history stays consistent; deleted tasks/steps disappear from every normal query.
* **Idempotent actions:** `complete(stepId)` on an already-completed step, a repeated `start`, `pause`, `resume`, or a repeated `undo` with
  the same `key` return `{ok:true, noop:true, duplicate:true}` and write nothing. A double tap can never record a completion twice.

## 2. Storage

| Key | Content |
|---|---|
| `wird_tasks_v1` | the whole state, `{schemaVersion:1, seq, savedAt, days, tasks, steps, exec, events}` as JSON |
| `wird_taskprefs_v1` | `{schemaVersion:1, values:{...prefs}}` |
| `wird_tasks_v1_recovered_<ms>`, `wird_taskprefs_v1_recovered_<ms>` | byte-exact copy of data that could not be fully understood (§5) |

Nothing else is ever read or written — in particular **not** `wird_habits_v1` (B2). Every mutating action saves the whole state before it
returns (autosave); a reload therefore always shows exactly what the last call showed. `persisted` in every result tells whether that save worked.

## 3. Results

Every method returns an object and **never throws** (an unexpected exception becomes `{ok:false, reason:'internal_error'}`):

```js
{ ok: true,  ...data, persisted?: boolean, noop?: true, duplicate?: true }
{ ok: false, reason: '<code>', ...details }
```
Reason codes: `read_only, invalid_argument, not_found, deleted, too_long, empty_text, limit_steps, limit_tasks, bad_day, bad_order, bad_index,
not_current, not_started, paused, finished, already_resolved, nothing_to_undo, not_latest, window_expired, at_first_step, link_today_only,
bad_link, task_finished, no_steps, internal_error`.

Task / step *views* returned by the API are copies: changing them never changes the engine.

## 4. API

**Tasks and steps** — `createTask(day, title, {steps:[text], linkedOneoffId})` · `editTask(taskId, {title})` · `deleteTask(taskId)` ·
`moveTask(taskId, toDay, index?)` · `reorderTasks(day, orderedIds)` · `setLink(taskId, oneoffId|null)` ·
`addStep(taskId, text, {index | afterStepId})` · `insertStep(taskId, index, text)` · `editStep(stepId, text)` · `deleteStep(stepId)` ·
`reorderSteps(taskId, orderedIds)` · `moveStep(stepId, toIndex)`.
Text is trimmed, control characters removed, whitespace collapsed; empty → `empty_text`, over the limit → `too_long`.

**Execution** — `start(taskId, {prefs})` (needs ≥ 1 step) · `complete(stepId, {elapsedMs}?)` · `skip(stepId, {elapsedMs}?)` · `undo(taskId, {key})` · `back(taskId)` ·
`pause(taskId)` · `resume(taskId)`.
* `complete` / `skip` only act on the **current** step (`not_current` otherwise) and return `{record, undoUntil, current, status, ...}`.
  `skip` is an engine capability; whether the user may skip is the UI's decision through the `skipStep` preference.
* **`elapsedMs` (added in B4, additive, optional).** `complete` / `skip` accept a second argument `{elapsedMs}`: the per-step stopwatch reading of the
  execution screen, an integer number of milliseconds from `0` to `86 400 000` (24 h). A valid reading is stored on the new `complete` / `skip` event as
  the field `elapsedMs` (and appears on the returned `record`). Anything else (negative, fractional, `NaN`, a string, over 24 h, a non-object second
  argument) is **ignored**: the action still succeeds and the event simply has no such field. It never decides whether the action succeeds; a duplicate
  (no-op) completion writes nothing, so the first reading is never overwritten; an `undo` voids the event but the history keeps its reading. Data
  written before B4 has no such field and loads unchanged (`repairs` stays 0); an older engine that does not know the field drops it on load and
  keeps everything else. `schemaVersion` stays `1`. Nothing reads the field yet (statistics arrive with Task 3.x).
* `undo` reverts the task's **most recent** completion/skip, only within the undo window (`undoWindowMs`, default **8 s**, interpretation I3:
  the brief says only "brief") and only while it is still the latest execution event (after a `back`, `pause`, `resume` or another completion
  there is nothing to undo). Passing the `key` from the `complete` result makes a repeated tap harmless.
* `back` reopens the step right before the current one, **without a time limit**; its earlier completion is voided, not deleted.
* `pause` / `resume` keep progress; a paused task refuses `complete`, `skip`, `back`, `undo` with `paused`.

**Preferences** — `getPrefs()` · `setPrefs(patch)` · `resetPrefs()` · `getSessionPrefs(taskId)` · `setSessionPrefs(taskId, patch)`.
`start()` takes a **snapshot** of the preferences (plus any `opts.prefs` override). Changing the saved preferences later never alters a running
session; `setSessionPrefs` changes only that session.

| Preference | Values | Default |
|---|---|---|
| `displayMode` | `one` (one step at a time) | `one` |
| `autoTransition` | bool | `true` |
| `backNavigation` | bool | `true` |
| `skipStep` | bool | `false` |
| `editDuringExecution` | bool | `false` |
| `timer` | bool | `false` |
| `progress` | `hidden` / `subtle` / `detailed` | `hidden` |
| `completionAnimation` | `off` / `subtle` | `subtle` |
| `sound`, `haptic`, `microInteractions` | bool | `false` |
| `endOfDayPrompt` | bool | `true` (**assumption A1**, below) |

Unknown keys or invalid values in a patch are rejected individually (`rejected` in the result); valid ones in the same patch still apply.

**Queries** — `getTask(id, {includeDeleted})` · `getCurrent(taskId)` · `listTasks(day)` · `getDay(day)` (`{tasks, counts, allFinished}`) · `listDays()` ·
`getTaskByLink(oneoffId)` · `getActiveTask()` (the unfinished started task touched last — the resume target) · `getEvents({taskId, stepId, type, dayKey})` ·
`getCompletions({taskId, dayKey, since, until})` · `getState()` (deep copy) · `status()` · `getRecoveredRaw()` · `todayKey()`.

**Events** — `subscribe(fn)` returns an unsubscribe function; listeners are called after every state or preference change with
`{type, action, taskId?}` (and `{type:'reload'}`); an exception in a listener is swallowed. `reload()` re-reads both keys from storage
(for example after a `storage` event from another tab).

`status()` → `{loadedFrom, degraded, readOnly, readOnlyReason, foundSchemaVersion, lastError, repairs, recovered, prefsLoadedFrom, prefsReadOnly,
schemaVersion, undoWindowMs, backups}`; `loadedFrom` is one of `empty | storage | repaired | recovered | newer_schema | unavailable`.

## 5. Failure behaviour (all covered by tests)

| Situation | Behaviour |
|---|---|
| storage key missing | empty start, nothing written |
| storage unreadable (`getItem` throws) | in-memory session, `degraded:true`, `lastError.code = storage_unavailable`; nothing is written until a read works |
| quota exceeded / `setItem` throws | the action **still succeeds in memory**, result has `persisted:false`, `degraded:true`, `lastError.quota`; the **next** successful save writes everything |
| invalid JSON / wrong or missing `schemaVersion` | `loadedFrom:'recovered'`: empty state, original text kept in memory (`getRecoveredRaw()`), **and copied to `wird_tasks_v1_recovered_<ms>` before the first save** |
| valid JSON with broken parts (unknown event types, orphan steps, duplicate ids, non-primitive fields...) | `loadedFrom:'repaired'`: bad elements dropped, valid ones kept, `repairs` counts them; the original text is backed up the same way |
| backup copy cannot be written | **nothing is overwritten**: the session continues in memory, results say `persisted:false`, `lastError.code = backup_failed`; the first save after storage works again writes the backup and then the state |
| `schemaVersion` newer than this code | **read-only**: every mutating call returns `read_only`, not a single write; the data is shown as empty and left untouched |
| corrupt / newer preferences | defaults are used; corrupt text is backed up before the first prefs save; newer schema is never overwritten |

## 6. Quick-task link

A task may link to one of today's quick tasks (`linkedOneoffId` of the form `o_<alnum>`, **today only** — `link_today_only`; anything else
`bad_link`). When a linked task becomes finished the engine calls `habits.markOneoffDone(id, day)` once; in B2 the injected adapter is a
**no-op**, so the habits data (`wird_habits_v1`) is never written. The real adapter and the UI are a later batch (see the integration
spike notes in `docs/INTEGRATION-SPIKES.md`). `moveTask` to another day clears the link (`linkCleared:true`).

## 7. Decisions and assumptions (unplanned points, resolved conservatively — please confirm or correct)

| # | Point | What B2 does |
|---|---|---|
| A1 | The brief does not say whether `endOfDayPrompt` is on by default | **on** (non-intrusive, disableable, never forces navigation); every other optional feature is **off** ("Defaults are Minimal") |
| I3 | length of the "brief" undo window | **8 s**, adjustable (`deps.undoWindowMs`) |
| A2 | `back` on a finished task | allowed: it reopens the last step (its completion is voided, not deleted) and the task returns to `in_progress` |
| A3 | inserting a step **before** the current step while running | the new step becomes the current step (the derived rule: first unresolved step in plan order) |
| A4 | adding a step to a finished task | the task is reopened (`reopened:true`) because it has an unresolved step again |
| A5 | the `skip` capability | exists in the engine; offering it is a preference (`skipStep`, default off) |

## 8. Known limitations (documented, not hidden)

* **Storage grows.** The whole state is one JSON value and the event history is not pruned. Measured: about **13 KB per day** of heavy use
  (the test scenario: 1000 completions ≈ 413 KB). `localStorage` holds ~5 MB, so this is years of normal use, but a **compaction / export policy
  must be decided before the final batch** (it changes what "history" means, so it is not done silently).
* **Last write wins across tabs.** Two tabs with the app open each hold their own in-memory copy and each save replaces the whole key. `reload()`
  exists for a UI to call on a `storage` event; B2 does not wire it.
* **Whole-state save cost** is linear in state size (1.6 ms per action at 1000 completions in Node; browser speed is not measured in B2).
* The `recovered`/`repaired` backups are never deleted by the engine (never delete user data); a later batch should offer the user a way to
  export or discard them.

## 9. Tests

`node tests/tasks.unit.test.js` — 39 tests, ~26.8k assertions, plain Node, no network:
day keys · creation validation and limits · lifecycle and every illegal transition · double tap and complete → undo → complete · skip and partial ·
undo window and `key` guards · back · pause / resume and resume after reload · step and task editing while running · autosave counts and round trip ·
corrupt, repaired, newer-schema, quota and unavailable storage · backup-before-overwrite (3 tests) · reload and `subscribe` · copy semantics ·
preferences and per-session snapshots · linked quick task and key isolation (only the two keys, plus backups) · queries · text handling ·
a **150-seed randomised run** (random operation sequences with invariants after every step, including "reload equals memory") · a scale test.
The tests were validated by mutation: deliberately breaking the engine in 6 + 4 ways makes the matching tests fail.
