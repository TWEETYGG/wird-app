# Manhaji — one unified tree (Subject › Unit › Lesson › Items): developer notes

Scope: every study feature lives in one tree. The sidebar is the only navigator; the hub bar and the standalone
books / study / courses screens are gone; creation happens in the context of the selected lesson; legacy data is linked
into the tree by a non-destructive, idempotent migration. Habits, Pomodoro, Ibadat, Quran code is untouched
(see §4 for the block-level proof). Still a single offline `index.html`.

## 1. Build pipeline

```
tools/orig/            v1 (pristine)
  └─ build.py ───────► tools/phase2/   resources-phase output  (index.html + sw.js wird-v3 + README)   ← the real base
        └─ unify.py ─► index.html + sw.js (wird-v4) + README-OFFLINE-AR.txt                            ← this release
```

```
python3 -I tools/patch/build.py tools/orig <dir1>                         # reproduces tools/phase2 byte for byte
python3 -I tools/patch/unify.py tools/phase2/index.html <out-dir>         # reproduces the shipped index.html / sw.js / README byte for byte
python3 -I tools/patch/audit_blocks.py tools/phase2/index.html index.html # which <script>/<style> blocks changed
```

* Both steps are exact-match, must-match-once patches; if a bundle ever changes a patch fails loudly (`PATCH FAILED …`).
* `tools/phase2/` is pinned because the files the project shipped as `sw(1).js` and `README-OFFLINE-AR(1).txt` *are* build.py's
  output (they differ from the unnumbered `sw.js` / README, which are stale v1 copies kept in `tools/orig/`).
  The service-worker cache therefore goes `wird-v3 → wird-v4` (not v2 → v3).
* Readable sources of the new code: `tools/src/unified.js`, `unified.css`, `README-unified-AR.txt`. The Lessons app engine
  (`ls-main`) is minified with no source; it is only touched through the patches below.

## 2. Data model and migration

Items are rows of the existing `resources` store in `wird_study_db` (schema version unchanged; the store is widened by types):

```
{ id:'res_…', lessonId, subjectId, type: video|book|link|course|text|notebook, title, order, status, completedAt,
  createdAt, updatedAt, rev, deletedAt, deleteBatch,
  exactly one payload: video{…} | book{bookId} | link{url} | course{courseId} | text{sessionId,subject} | notebook{key} }
```
The lesson row itself is the Summary item. Items are references — books, courses, study texts and notebooks are never copied or moved.

| Source (unchanged) | Becomes |
|---|---|
| IDB `wird_books_db`.`books` | `book` item; lesson named after the book; status `doing` if `currentPage > 1` |
| LS `wird_courses_v1` `courses` | `course` item |
| LS `wird_study_v1` `sessions` | `text` item; lesson named after the text's subject |
| IDB `wird_fnb_m` key `L<lessonId>` / `G` (non-empty only) | `notebook` item under its own lesson / lesson «النوت العام» |
| anything without a parent | under subject **«غير مصنّف»**, units كتب · كورسات · المذاكرة · دفاتر |

`LS wird_mig_v3`: `{v, ts, before{books,courses,notebooks,texts,resources}, after{…}, now{…}, created{subject,units,lessons,items}, reported, off?, rolledBack?}`.
`before`/`after` are a snapshot of the first pass (later edits do not fake a mismatch); `now` is live.
Backup: IDB `wird_mig_db`.`b`.`pre-v3` — metadata only (PDF/image blobs are not copied), downloadable as JSON from the report.
Rollback removes only what the migration created (items; the auto-created subject goes to the app trash) and sets `off`;
«↻ إعادة ربط البيانات القديمة» runs it again. Both are reachable any time from the «منهجي» home screen (📋 / ↻), not just from the one-time report.
Removing an item never deletes its source: book/course/text/notebook reappear under «غير مصنّف» after the 7 s undo window
(video and link items are real records and are truly deleted, with undo). Permanent deletion paths: book → item ⋯ «حذف الكتاب نهائيًا»
(original confirm + book + file); course → ⋯ inside its screen; text → the study screen.

## 3. Patches (`unify.py`)

| Group | Where | What |
|---|---|---|
| D1–D2 | `ls-main` | `wirdResTypes` + `wirdResNorm` accept `course`, `text`, `notebook` |
| S1–S10 | `ls-main` | `computeRows` pushes item rows under each lesson; `rowEl` depth/`aria-level`/no chevron/no ＋/not draggable; click opens item; item ⋯ menu; lesson ⋯ gets the ＋ add menu; palette (Ctrl+K) merges item hits and opens them |
| M1–M2 | main script | two one-line hooks (`stCreate`, add-book handler) → `__wirdDirty()` so new data appears in the tree |
| R1–R7 | `wird-resources` | new types/tabs/cards, `openForm` delegates to `__wirdCreate`, PDF upload button in the book form, badges for all six types |
| X1–X6 | markup/CSS/hub | hub script → 201-char `WirdLearning` shim; `#lrnNav`, `#view-lrn`, books screen → inert containers; three hidden tab buttons; 29 hub CSS rules |
| I1–I2 | head | inject `<style id="wird-unified-css">` and `<script id="wird-unified">` (tokens `--wu-*`, sheet/menu/toast, migration, hooks, course panel) |
| SW, README | `sw.js`, README | cache `wird-v3 → wird-v4`; stale README sections (hub bar, courses tab, tab list, rebuild commands) replaced |

Hooks exposed on `window` by the module: `__wirdItems, __wirdIcon, __wirdSearch, __wirdCard, __wirdOpen, __wirdMenu, __wirdAddMenu, __wirdCreate, __wirdDirty`;
public API `window.WirdUnified = {__host, reconcile, report, rollback, remigrate, downloadBackup, state, counts}`.

## 4. Proof that nothing else changed (`audit_blocks.py`)

```
block                    before     after  status
courses-module, wird-v33-js (notebook), wird-nb-recall, wird-math-paste, wird-offline,
wird-quran-font(+js), ls-css, katex/mhchem/jszip assets             identical (byte for byte)
script:#2 (main app: Habits, Pomodoro, Ibadat, Quran, books, study)  336217 → 336317   CHANGED, exactly 2 lines (M1, M2)
script:ls-main                                                      243474 → 244571   6 lines (S/D patches)
script:wird-resources                                                48305 →  49097   20 lines (R patches)
style:#0                                                             64381 →  61880   hub CSS removed
markup                                                               20765 →  20285   hub bar / views / hidden tabs removed
script:learning-hub                                                  12273 →      -    REMOVED (201-char shim added)
ADDED  wird-unified (29774), wird-unified-css (3538), wird-learning-shim (201)
```

## 5. Phase log — change log and test checklist

| Phase | Change log | Tests |
|---|---|---|
| 0 Audit | Inventory of screens, stores, globals, z-index scale; base files identified (§1) | — |
| 1 Data layer | D1–D2: one items table, six types, references only | MIG-U1 (types), resources suite (REV/EXP/TRASH on the same table) |
| 2 Tree | S1–S10 + `aria-level`; item icons/menus; palette merge; shared `--wu-*` tokens, sheet/menu/toast | UNI-1, UNI-K1, UNI-A2 |
| 3 Migration | backup → reconcile (idempotent) → report → rollback / re-link; orphans under «غير مصنّف» | MIG-U1, MIG-U2, resources MIG-3 (real v1) |
| 4 Context creation | lesson ⋯ → ＋ type; forms in the lesson panel; course panel; item header/⋯ everywhere; PDF upload above the workspace | UNI-A1, A4, A5, A6, UNI-C2 |
| 5 Removal | X1–X6, M1–M2; curricula («مناهجي الدراسية») and permanent book delete re-homed so nothing is stranded | UNI-C1, UNI-C3, UNI-A6 |
| 6 Quality | persisted state (expansion, scroll, last item), keyboard/focus/aria, listener hygiene, offline, perf | UNI-P1, UNI-K1, UNI-L1, `offline.test.js`, `perf.test.js` |

## 6. Final acceptance checklist

| Requirement | Evidence |
|---|---|
| One tree Subject › Unit › Lesson › Items; sidebar is the only navigator | UNI-1, UNI-C1 (no `#lrnNav`/`#view-lrn`, workspace opens directly), block diff |
| Item types: Summary, Notebook, Book, Video, Course, Study text, Link | MIG-U1 (book/course/text/notebook), resources suite (video/link/book), UNI-A1/A4/A5 |
| Hub bar, sections button, standalone screens + CSS removed | §7; UNI-C1 |
| Bottom tabs untouched | UNI-C1 cycles Today/Log/Habits/Pomodoro/Ibadat; main script differs by 2 hook lines (§4) |
| Open item: breadcrumb + segmented switcher + sidebar one tap away | resources UI-1/PROG-1, UNI-A2, UNI-K1 (tap on row → lesson on its tab) |
| Creation in context, ≤ 2 taps | UNI-A1 (⋯ → ＋ نص), A4, A5; reach = 1 tap on a row (+1 for the drawer on phones) |
| Same header + ⋯ (rename, move, settings, delete + undo) | UNI-A2, UNI-A3, UNI-K1 |
| Migration non-destructive, idempotent, backup, rollback, report, orphans | MIG-U1/U2 (sources byte-identical before/after, counts, 3 extra passes change nothing) |
| No console errors | every test asserts zero page/console errors (aborted external requests of the offline sandbox excluded) |
| No duplicate listeners | UNI-L1 (7 open/close cycles: document/window/body listeners and observers identical) |
| Persisted UI state | UNI-P1 |
| Virtualized tree / large data | `perf.test.js`: 2 613 rows → 26–34 DOM rows; render 3 ms (8–13 ms at 4× CPU throttle); search < 2 ms; item open 170 ms (290 ms throttled) |
| Keyboard + screen-reader basics | UNI-K1: menu focus/arrows/Home/End/Esc + focus return, dialog focus trap + Esc + focus return, `role=dialog aria-modal`, tree `aria-level` 1–4 |
| Single offline file | `offline.test.js`: after one online visit the page and pdf.js (CDN) are served from `wird-v4` with the network cut |

## 7. Removed code

* `<script id="learning-hub">` — 12 308 chars → replaced by a 201-char `WirdLearning` shim (`go/last/search/renderHub`).
* Markup: `#lrnNav`, `#view-lrn`, the «مكتبتي» screen (now inert containers `#booksList`, `#cuReminderBanner`, hidden `#addBookBtn`/`#cuOpenBtn` that old code still binds to), hidden tab buttons for books / study / courses.
* CSS: 29 rules (`.lrn-nav`, `.lh-*`, `#lrnNav`, `#view-lrn`, `#lrnRoot`).
* Tests: `HUB-1` (resources) and `HUB-1…6` (courses) → replaced by UNI-1, UNI-C1, UNI-C2 and the new unified suite.
* **Not removed (dead or inert, still in the file):** `WirdResources.hubContinue/hubSearch`; the old library renderer `renderBooksList` and the `cu*` curricula code keep running against the inert containers / are re-used (curricula is live again via the home screen button); `#view-study`, `#view-courses` containers (the course panel re-parents `#view-courses`). Deleting them needs edits inside the 336 KB main script beyond exact-match hooks.

## 8. Behaviour changes vs the previous build

* The hub **Home** dashboard (today's numbers, «continue where you left off», per-section summaries, hub search box) is gone with the hub. Replacements: «منهجي» reopens the last item and sidebar scroll; Ctrl+K / sidebar search finds lessons and every item title; the workspace home keeps its recent-lessons list.
* Tapping «منهجي» opens the workspace as a full-screen layer (the Lessons app's original behaviour); ✕ returns to the tab bar. The bottom tab bar is not visible while it is open.
* The old library card's overall «% complete / pages remaining» is no longer a list; the book item card shows the current page (and range progress); the reader still shows the daily-target line.
* «مناهجي الدراسية» + today's tasks banner: now on the «منهجي» home screen (same code, same data `wird_curricula_v1`).
* Delete on a book/course/text/notebook item is labelled «إزالة من الدرس» (unlink); permanent deletion is a separate action (§2).

## 9. Known limitations / not verified

* Not tried with a real screen reader (NVDA/TalkBack/VoiceOver) or on a physical Android device; only headless Chromium (390×844, 1280×800) and a CPU-throttled run.
* The app has a single dark theme (light/sepia exist only inside the PDF reader), so there is no light mode to check.
* Offline: the page and `pdf.min.js` are verified; the pdf.js **worker** script is only fetched when a PDF is opened, and offline PDF rendering end-to-end was not tested with a real PDF.
* The tree does not highlight which *item* is open (the lesson row is highlighted; the lesson panel shows the active type tab).
* The sidebar's own ⋯ popup (`.ls-ctx`, original code) handles Esc and outside clicks but has no arrow-key navigation; the new menus do.
* The book reader and study text screens are still full-screen overlays, not embedded in the lesson pane; the course panel reuses the original course screen (including its «→ كورساتي» list header).
* The undo toast is 7 s and is not reachable by keyboard in time for some users; a source unlinked and not restored is re-adopted under «غير مصنّف» (nothing is lost).
* Rolling back moves «غير مصنّف» to the trash, including items added under it after the migration (restorable from the trash).

## 10. Running the tests (always sequentially — parallel runs cause false timeouts)

```
export NODE_PATH=$(npm root -g)            # CHROME=/path/to/chrome if Playwright's browser is elsewhere
ORIG_INDEX=tools/orig/index.html node tests/resources.test.js   # 35 (34 without ORIG_INDEX)
node tests/courses.test.js                                      # 32
node tests/unified.test.js                                      # 12   (ONLY=<id> for one test, DEBUG=1 for details)
node tests/perf.test.js                                         # large-data budget check
node tests/offline.test.js                                      # real service worker, network cut
```
