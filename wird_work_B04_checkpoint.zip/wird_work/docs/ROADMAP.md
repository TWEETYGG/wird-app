# Wird — Task Atomization + Focus Quiz: approved roadmap (task definitions)

This file holds the **normative task definitions** (24 tasks, 6 phases) exactly as approved, plus the amendments discovered in B1.
Task *status* is NOT stored here (see `PROJECT-STATUS.md`) so the cards stay byte-stable and can be embedded verbatim in every batch prompt.
Size: S/M/L. Test command pattern: `NODE_PATH=$(npm root -g) node tests/<file>`. Every batch also runs `python3 -I tools/audit/verify_preservation.py`.
Decisions D1–D11, requirements and architecture: `MASTER-PLAN.md`. Batch grouping and dependency graph: `BATCH-DEPENDENCY-MAP.md`.

## Amendments made after B1 (evidence: docs/INTEGRATION-SPIKES.md)

* **A1** No settings hook is needed: task and quiz preferences live in module-owned settings sheets (⚙ in planner/execution screens and the quiz start sheet). Any optional entry row inside existing settings screens needs approval.
* **A2** Hook mechanics are **patch-free by default**: habits row action / quick-task follow-up via `MutationObserver` on `#habitsRoot` + event delegation (`hRender` re-renders everything); lesson button via a MutationObserver for `section.wr[data-lesson]` inserting a **sibling after `#wrHead`** (anything inside `#wrHead`/`.wr-foot` is wiped by `renderHead()`); optional sidebar entry by wrapping `window.__wirdRow`. A guarded exact-match patch of `script:#2` is a last resort and needs user approval.
* **A3** D3 confirmed by evidence: `repo.saveResource({type:'quiz'})` → "Invalid resource". No resource type, no tab, no bundle patch.
* **A4** Decision D7: future-day plans live only in `wird_tasks_v1` (default); writing quick tasks into `H.oneoffs[date]` only if approved.
* **A5** Perf budget: lesson `openMs` at CPU×4 is 767 ms vs budget 800 ⇒ observers must be O(1); no work added to lesson opening.
* **A6** `navigator.share` may be missing ⇒ answer-sheet sharing = Web Share if present, else copy/download. Request `navigator.storage.persist()` before storing images.
* **A7** New modules read `H` by **bare name** (`typeof window.H` is `undefined`), wrap in an IIFE, expose only `window.WirdTasks` / `window.WirdQuiz`.
* **A8** The verifier allows new `<script>`/`<style>` blocks only with ids starting `wird-tasks` / `wird-quiz`, and forbids in them: `deleteDatabase`, web-storage `clear`, `caches.*`, `serviceWorker`, IndexedDB names other than `wird_quiz_db`, and storage keys outside `wird_tasks*` / `wird_taskprefs*` / `wird_quiz*`.

## Hierarchy

```
PROJECT
├── PHASE 0  Foundation & safety:  0.1 · 0.2 · 0.3
├── PHASE 1  Task Atomization:     1.1 · 1.2 · 1.3 · 1.4 · 1.5
├── PHASE 2  Quiz foundation:      2.1 · 2.2 · 2.3 · 2.4
├── PHASE 3  Focus Quiz solving:   3.1 · 3.2 · 3.3 · 3.4
├── PHASE 4  Review & reporting:   4.1 · 4.2 · 4.3 · 4.4
└── PHASE 5  Integration/release:  5.1 · 5.2 · 5.3 · 5.4
```

## Batches (≈17 sessions; one explicit user approval per batch)

B1 = 0.1+0.2 · B2 = 0.3+1.1 · B3 = 1.2 · B4 = 1.3 · B5 = 1.4+1.5 (Phase-1 checkpoint) · B6 = 2.1+2.2 · B7 = 2.3 · B8 = 2.4 · B9 = 3.1 · B10 = 3.2 · B11 = 3.3+3.4 (Phase-3 checkpoint) · B12 = 4.1 · B13 = 4.2+4.3 · B14 = 4.4 (Phase-4 checkpoint) · B15 = 5.1 · B16 = 5.2+5.3 · B17 = 5.4.
Phase 1 and Phases 2–4 are independent after 0.3. Parallelizable pairs (no dependency edge): 3.1∥3.2, 4.2∥4.3, 2.2∥2.3-after-2.1. Recommended order: Phase 1 first.

---------------------------------------------------------------------------------------------------

## PHASE 0 — Foundation & safety

### TASK 0.1 — Baseline, preservation verifier, tracking files · S
- **Objective:** Freeze a verifiable "before" state.
- **Scope:** Run all six existing suites (update, offline, unified, resources, courses, perf) and record results honestly, including known failures. Hash `sw.js`, the manifest and the protected blocks (`wird-update`, `wird-offline`, `ls-main`, `wird-resources`, `wird-unified`, `wird-v33-js`, …). Create the tracking files and a preservation verifier that fails if protected blocks change.
- **Files/output:** New `PROJECT-STATUS.md`, `HANDOFF.md` skeleton, `docs/PRESERVATION-BASELINE.json`, `tools/audit/verify_preservation.py` (+ self-test, baseline test report and logs). No existing file is modified.
- **Depends:** none.
- **Accept:** Baseline report lists every suite result; the verifier passes on the untouched project; Chromium confirmed available (or the blocker documented).
- **Tests:** The six existing suites and the verifier (and the verifier's self-test).

### TASK 0.2 — Integration-point spikes (read-only) · M
- **Objective:** Resolve the unknowns in code before building.
- **Scope:** (a) locate/confirm the "Add New Sheet" control and the prompt-button anchor; (b) how the lesson tab strip / "＋ item" menu are built and whether a `quiz` item type needs patching `wirdResNorm` (minified); (c) how `katex`/mhchem become available and reuse of `wMathTok`; (d) shape and write API of the existing `mistakes` store/«دفتر الأخطاء»; (e) existing Settings screen location and pattern; (f) existing timer, sound and haptic helpers; (g) `hModal`, `showConfirm`, `showToast` signatures; (h) step-2 chip row markup (where a 4th chip would sit).
- **Files/output:** New `docs/INTEGRATION-SPIKES.md` with exact anchors (function or selector), evidence and risks; `tools/audit/probe_anchors.js`. No code changes.
- **Depends:** 0.1 (and the user's answers to the decision gates; defaults were used when unanswered).
- **Accept:** All eight items are answered with code evidence; no code changed; open questions listed.
- **Tests:** None (read-only); a throwaway Playwright probe confirms the selectors.

### TASK 0.3 — Module scaffold, injector, storage namespaces · M
- **Objective:** Establish a safe mechanism for adding code without touching protected blocks.
- **Scope:** New idempotent `tools/patch/inject_wird_modules.py` that inserts `<style id="wird-tasks-css">`, `<script id="wird-tasks">`, `<style id="wird-quiz-css">`, `<script id="wird-quiz">` **immediately before `<script id="wird-offline">`**; it refuses to run if frozen blocks differ from the baseline and never touches `sw.js`; sources in `tools/src/tasks-*.js|css` and `tools/src/quiz-*.js|css`, concatenated by the injector (re-running with changed sources refreshes the blocks; re-running with unchanged sources produces no diff) [A2/A8]. Module shells expose `window.WirdTasks` / `window.WirdQuiz` (IIFE, bare-name access to `H`) [A7]. Shared helper kit `WirdKit`: safe localStorage wrappers (try/catch), uid, own lazy `AudioContext` blip, guarded `vibrate`, lazy `wird_quiz_db` opener (**database created only on first quiz use**), KaTeX loader mirroring `ls-main` with double-evaluation guards, DOM-safe element builder.
- **Files/output:** New `tools/patch/inject_wird_modules.py`, `tools/src/*`; modified: `index.html` (insertion only). Output: the app boots identically.
- **Depends:** 0.1, 0.2.
- **Accept:** Existing suites at baseline; verifier PASS showing only NEW blocks; injector idempotent (second run = no diff); no new IndexedDB until a quiz feature is used.
- **Tests:** Verifier; injector idempotency test; smoke subset of the existing suites (offline, unified) plus perf.

## PHASE 1 — Task Atomization

### TASK 1.1 — Task engine & persistence · M
- **Objective:** Pure logic with no UI.
- **Scope:** Model Day → Task → Step with stable IDs. States: not started, in progress, paused, completed, skipped, partially completed. Actions: add, insert, edit, delete and reorder steps; move and reorder tasks; start, complete (idempotent), undo (time-limited), back, skip (never counts as completed), pause and resume. Edits and deletes keep history (tombstones). Completions are append-only events with unique keys, so none can be recorded twice. Autosave after every action to LS `wird_tasks_v1` (schema-versioned, quota-safe). Preferences in `wird_taskprefs_v1` with Minimal defaults and a per-session snapshot, so changing a setting never alters an active session. Optional link to a today quick-task id (**D7/D8**). Never writes `wird_habits_v1` except the approved done-flag on a linked quick task.
- **Files/output:** `tools/src/tasks-engine.js`, `tests/tasks.unit.test.js`.
- **Depends:** 0.3.
- **Accept:** All operations covered; corrupt or missing storage never throws; completing the same step twice yields one record; deleting the current step lands on the next; no write to `wird_habits_v1` beyond the approved link.
- **Tests:** Node unit tests: state machine, dedupe, edit and delete mid-progress, undo window, persistence round trip, preference isolation.

### TASK 1.2 — Planning UI & entry points · L
- **Objective:** Create and organize plans (planning UI only).
- **Scope:** Entry points per **D1** (patch-free per A2): task-card action on quick-task rows and an optional follow-up chip in the quick-task modal; the planner is never a new top-level tab. Steps editor with add, edit, delete, insert-between and reorder (consistent with the existing `hb-mv` pattern). Day hierarchy view: Today, Tomorrow and future days; multiple tasks per day; reorder; move an unfinished task to another day; delete with `showConfirm`. Reuses the existing modal, input and chip classes; RTL.
- **Files/output:** `tools/src/tasks-ui.js`, `tools/src/tasks.css` (injected). Any guarded hook in the main script requires user approval.
- **Depends:** 1.1, 0.2.
- **Accept:** All planning operations work at 360 px width; rows look unchanged when no plan exists; the existing wizard flow is unchanged.
- **Tests:** Playwright: create, edit, delete, insert and reorder steps; day moves; delete confirmation; screenshots; habits regression subset.

### TASK 1.3 — Focused execution screen · L
- **Objective:** ONE TASK → ONE CURRENT STEP → ONE ACTION.
- **Scope:** Immersive full-screen view showing a small task context, ONE current step and ONE primary check action. Automatic transition after checking; completion animation (opacity/transform only; `prefers-reduced-motion` honoured); own undo toast (the shared `showToast` has no action button); back navigation; pause and resume; choosing which task to work on without showing the day list during execution; exact-position restore after reload; skip, in-run edit, timer and progress indicator (hidden, subtle or detailed) all read from preferences.
- **Files/output:** `tools/src/tasks-ui.js`, `tools/src/tasks.css`.
- **Depends:** 1.1, 1.2.
- **Accept:** Only one step is visible by default and there is no "Step 2 of 8" text; rapid double-taps record one completion; closing and reopening restores the same step.
- **Tests:** Playwright: execute, auto transition, undo, back, pause, reload restore, double-tap dedupe, skip disabled vs enabled.

### TASK 1.4 — Preferences, feedback, end-of-day · M
- **Objective:** Persistent options and polish.
- **Scope:** Module-owned settings sheet [A1]: display mode (Minimal default, Balanced, Advanced), automatic transition, back navigation, skip, in-run edit, timer, progress visibility, animation, sound (generated tone, off by default), haptic (guarded `vibrate`, off by default). A per-session override sheet. The end-of-day prompt «خلصت مهام النهارده. تحب تدخل على مهام اليوم التالي؟» with actions «الانتقال لليوم التالي» and «ليس الآن»: disableable, never forces navigation, handles an empty next day.
- **Files/output:** `tools/src/tasks-ui.js`, `tools/src/tasks.css`.
- **Depends:** 1.3.
- **Accept:** Every setting persists across reload; session overrides do not change saved defaults; a setting changed mid-session does not alter the active session; sound and haptic are off by default.
- **Tests:** Playwright.

### TASK 1.5 — Verification & regression · M
- **Objective:** Part-13 task tests plus regression for Phase 1.
- **Scope:** Execute the 15 task tests; regression of existing habits, Today, wizard and quick tasks; a seeded-old-data preservation check; the preservation verifier; the existing suites against baseline. Fixes are limited to Phase 1 defects.
- **Files/output:** `tests/tasks.test.js`, `docs/TASKS-TEST-REPORT.md` (executed vs not-executed table). Phase-1 checkpoint handoff and an optional release-candidate ZIP.
- **Depends:** 1.1, 1.2, 1.3, 1.4.
- **Accept:** All 15 task tests are run and reported honestly; the verifier is clean; existing suites are at baseline.
- **Tests:** As described.

## PHASE 2 — Quiz foundation

### TASK 2.1 — JSON schema, content spec, validator · M
- **Objective:** The versioned import format.
- **Scope:** Schema `wird.quiz/1`. Session fields: title, subject, lesson, source, instructions, questions. Question fields: id, type (the 14 types), number, stem, media, parts, options, input kind, optional answerKey (null = unavailable), explanation, solution, marks, topic, difficulty, gradingCriteria. The rich-text spec per **D4**, obeying the `wMathTok` rules. The validator returns structured Arabic errors and warnings with JSON paths; unknown fields are preserved, never fatal; unknown types are errors; media is never silently dropped; Markdown code fences from AI output are stripped with a warning. The answer-value serialization per type (identical in shape to the answerKey) is specified so widgets can be built independently.
- **Files/output:** `tools/src/quiz-schema.js`, fixtures for all types, `tests/quiz.schema.unit.test.js`, draft `docs/QUIZ-SCHEMA.md`.
- **Depends:** 0.3, 0.2.
- **Accept:** A valid fixture for every type; at least 25 invalid fixtures that give specific path errors; unknown fields survive.
- **Tests:** Node unit tests.

### TASK 2.2 — Storage & session state machine · M
- **Objective:** Durable, additive persistence.
- **Scope:** New IDB `wird_quiz_db` v1 created lazily, with stores: sessions (full question snapshot, so later edits or deletes never alter history), answers (draft and submitted), images (blobs), gradings, reports, mistakes. State machine Prepared → In Progress ⇄ Paused → Ready for Review → Completed, with complete-once and no duplicate reports. Debounced draft autosave plus flush on `visibilitychange`/`pagehide`. Quota errors surfaced. `navigator.storage.persist()` requested [A6].
- **Files/output:** `tools/src/quiz-store.js`, tests.
- **Depends:** 2.1.
- **Accept:** Round trips work; images survive reload; completing twice yields one report; failed writes do not corrupt data; `wird_quiz_db` is not created until first use and no existing DB version changes.
- **Tests:** Playwright (IDB) plus Node logic tests.

### TASK 2.3 — Rich question renderer · L
- **Objective:** Safe, mobile-correct rendering of imported content.
- **Scope:** Headings matching existing sizes, lists, tables in a scroll container, images (fit, expand, full-screen), inline and block KaTeX plus `\ce` through the embedded assets (same options and macros as `ls-main`), raw-TeX fallback on error, bidi handling (`dir=auto`, math LTR), font-size scaling. Built via DOM construction and escaping only; never raw `innerHTML` of imported JSON.
- **Files/output:** `tools/src/quiz-render.js`, `tools/src/quiz.css`.
- **Depends:** 2.1, 0.2.
- **Accept:** Fractions, roots, Greek, sub/superscripts, units, `\ce`, tables and images render at 360 and 412 px with no horizontal page scroll; XSS strings stay inert.
- **Tests:** Playwright with `scrollWidth ≤ clientWidth` checks and XSS fixtures.

### TASK 2.4 — AI prompt, import UI, lesson placement · M
- **Objective:** The material → prompt → JSON → ready-session workflow.
- **Scope:** Versioned prompt generated from the schema definition (so the two cannot drift) with an example JSON per type; one-tap copy with a clipboard fallback; the prompt button at the **D2** anchor (patch-free per A2); import by paste or `.json` file; validation report; preview (counts by type, answer-key presence, media); saving as a Prepared session in the lesson-linked list (**D3**).
- **Files/output:** `tools/src/quiz-prompt.js`, `tools/src/quiz-ui-import.js`.
- **Depends:** 2.1, 2.2, 2.3 (and **D2**, **D3**).
- **Accept:** Invalid JSON is blocked with useful errors; valid JSON creates a linked Prepared session; the lesson DOM is unchanged except the new elements.
- **Tests:** Playwright: copy, paste, file, invalid and valid, plus lesson regression.

## PHASE 3 — Focus Quiz solving

### TASK 3.1 — Choice-family widgets · M
- **Objective:** Answer inputs for the choice-based question types.
- **Scope:** Single MCQ, multi-select, true/false, matching, ordering and fill-in-the-blank. Touch targets of at least 44 px; no correctness cues; the answer serialization documented for each type.
- **Files/output:** `tools/src/quiz-widgets-choice.js`.
- **Depends:** 2.1, 2.3.
- **Accept:** Each widget saves and restores its answer exactly and works in RTL.
- **Tests:** Playwright per widget.

### TASK 3.2 — Free-form widgets & attachments · L
- **Objective:** Text, numeric and handwritten-work inputs.
- **Scope:** Short text, long/essay, numeric (decimal keypad, unit), math expression (symbol palette plus live preview), physics/chemistry multi-field, multi-part and step-based questions. Handwritten photo attachment from camera or file: downscaled to about 1600 px, thumbnails, replace or remove, stored in IDB `images`. Keyboard behaviour per input type.
- **Files/output:** `tools/src/quiz-widgets-free.js`.
- **Depends:** 2.2, 2.3.
- **Accept:** Attached images survive reload; multi-part answers are saved per part; equations do not overflow.
- **Tests:** Playwright with fixture images.

### TASK 3.3 — Focus Tunnel flow · L
- **Objective:** One question at a time.
- **Scope:** Immersive one-question view and the «تثبيت الإجابة والانتقال للسؤال التالي» action. No scores, correctness or answers shown. Optional Mark for Review, Skip and Return, Previous and answer editing. A finish screen listing skipped, unanswered and marked questions so nothing vanishes silently. Timer visible or hidden. Pause and resume. Exit back to the lesson. Exact resume of the question, draft and images.
- **Files/output:** `tools/src/quiz-ui-run.js`.
- **Depends:** 3.1, 3.2, 2.2.
- **Accept:** The default UI shows no counter, progress or score; closing and reopening resumes the same question.
- **Tests:** Playwright.

### TASK 3.4 — Quiz preferences & modes · M
- **Objective:** Persistent solving settings.
- **Scope:** The Part-4 settings table in a module-owned sheet [A1]; Minimal default; session override; saved prompt version.
- **Files/output:** `tools/src/quiz-ui-prefs.js`.
- **Depends:** 3.3, 1.4.
- **Accept:** New sessions use saved defaults; overrides do not replace them; an active session is unaffected by later changes.
- **Tests:** Playwright.

## PHASE 4 — Review, grading, reporting

### TASK 4.1 — Review & self-grading · L
- **Objective:** Evaluate after solving.
- **Scope:** Per-question review showing your answer, the model answer and explanation when they exist, and five grades (Correct, Partially Correct, Incorrect, Unanswered, Needs Review). No auto-marking on text match. With no key, questions become Awaiting Grading and nothing is invented. Resumable review; Completed only when finished. The `stepMarks` field is reserved but not built.
- **Files/output:** `tools/src/quiz-ui-review.js`.
- **Depends:** 3.3, 2.2.
- **Accept:** Both key and no-key sessions work; nothing is counted incorrect by default.
- **Tests:** Playwright (with and without an answer key).

### TASK 4.2 — Export & external-AI grading workflow · M
- **Objective:** Share the answer sheet and optionally prepare an AI grading prompt.
- **Scope:** Answer sheet via copy, Web Share (fallback copy/download [A6]) and print/PDF where supported; numbering preserved; images embedded in print. «اطلب تصحيح AI» builds a prompt from the questions, answers, criteria and key. A grading-result schema and validator import the result as **suggestions** the user confirms. No network calls. A clear limitation message when there is no marking basis.
- **Files/output:** `tools/src/quiz-export.js`, `tools/src/quiz-grading-ai.js`.
- **Depends:** 4.1.
- **Accept:** Export works with zero grades; an imported result never overwrites grades without confirmation.
- **Tests:** Playwright and unit tests for the validator.

### TASK 4.3 — Session report · M
- **Objective:** Honest numbers.
- **Scope:** Counts by grade; graded vs awaiting shown separately; mark-weighted score when marks exist; partial credit (**D9**); mastery percentage only when graded data suffices; weak topics; duration; a "return to weak questions" action. Duplicate reports are impossible.
- **Files/output:** `tools/src/quiz-report.js`.
- **Depends:** 4.1.
- **Accept:** The calculations are verified against hand-computed fixtures.
- **Tests:** Unit tests plus Playwright.

### TASK 4.4 — Mistake tracking · M
- **Objective:** Simple, deterministic, local tracking.
- **Scope:** IF-rules only: Incorrect → pool; Partial → weak; a repeated error reuses the notebook semantics (`reseeMistake`-like); a later correct review updates the status (`open → improving → mastered`). Optional categories (conceptual, wrong formula, calculation, memorization, careless, other), never forced. Repeated-topic revision suggestion behind a toggle. A revision session built from the pool. Optional one-tap push to «دفتر الأخطاء» (**D5**). Accessible from the lesson context.
- **Files/output:** `tools/src/quiz-mistakes.js`.
- **Depends:** 4.1, 4.3, 0.2.
- **Accept:** With the feature off, no suggestions appear; categories are never forced.
- **Tests:** Playwright.

## PHASE 5 — Integration & release

### TASK 5.1 — Quiz end-to-end suite · L
- **Objective:** Part-13 quiz tests 1–22.
- **Scope:** Fixture images through file input, clipboard handling, a 200-question session, kill and reopen, and update-banner interaction mid-session. Defects found are documented, not fixed here.
- **Files/output:** `tests/quiz.test.js`, `docs/QUIZ-TEST-REPORT.md`.
- **Depends:** Phase 4 (4.1, 4.2, 4.3, 4.4).
- **Accept:** Each test is marked executed or not executed.
- **Tests:** As described.

### TASK 5.2 — Mobile / RTL / accessibility / performance pass · M
- **Objective:** A native feel on small Android screens.
- **Scope:** 360 and 412 px layouts, the on-screen keyboard (`visualViewport`), 44 px touch targets, focus order, reduced motion, bidi, and a performance budget (lesson `openMs` must stay under 800 ms at CPU×4). Fixes only defects found by tests.
- **Files/output:** Edits to the new modules only.
- **Depends:** 5.1.
- **Accept:** No horizontal overflow, targets of at least 44 px, and no jank on the 200-question session.
- **Tests:** Playwright viewport matrix.

### TASK 5.3 — Documentation · S
- **Objective:** Finalize the schema, prompt and user guides.
- **Scope:** Final schema doc, the prompt text, import instructions, task-atomization instructions, the deferred list, and additive README and update-guide notes about the new DB; a script comparing the prompt with the schema.
- **Files/output:** `docs/*`, additive README append.
- **Depends:** 5.2.
- **Accept:** The docs match the actual code (checked by the script).
- **Tests:** The consistency script.

### TASK 5.4 — FINAL AUDIT & packaging · M
- **Objective:** Verify everything and ship.
- **Scope:** All old and new suites; the verifier (`sw.js` hash identical, frozen blocks identical, seeded old data intact); a requirement traceability matrix for Parts 0–14; decision **D6**; the final ZIP, file lists and final HANDOFF/PROJECT-STATUS.
- **Files/output:** Final ZIP and docs.
- **Depends:** all.
- **Accept:** Every requirement is mapped to code and a test result; nothing is labeled passed unless run.
- **Tests:** Everything.
