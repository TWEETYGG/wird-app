# Wird modules — how new features are added to `index.html` (B2 / TASK 0.3)

Wird is one file, `index.html`. New features (Task Atomization = **tasks**, Focus Quiz = **quiz**) are developed as
separate source files under `tools/src/` and **injected** into `index.html` by one deterministic script. Nobody edits the
generated blocks by hand.

```
tools/src/wird-kit.js      shared kit (prepended to BOTH script blocks)
tools/src/tasks-shell.js   WirdTasks namespace            tools/src/quiz-shell.js   WirdQuiz namespace
tools/src/tasks-engine.js  task engine (B2 / TASK 1.1)    tools/src/tasks.css / quiz.css   styles (placeholders in B2)
tools/patch/inject_wird_modules.py   the injector         tests/inject.test.js   its tests
```

## 1. The four blocks

The injector writes exactly four blocks, in this order, directly in front of `<script id="wird-offline">` and nowhere else:

| id | tag | built from |
|---|---|---|
| `wird-tasks-css` | `<style>` | `tasks.css`, then `tasks-*.css` (file-name order) |
| `wird-tasks` | `<script>` | `wird-kit.js`, `tasks-shell.js`, `tasks-core*.js`, then the other `tasks-*.js` (file-name order) |
| `wird-quiz-css` | `<style>` | `quiz.css`, then `quiz-*.css` |
| `wird-quiz` | `<script>` | `wird-kit.js`, `quiz-shell.js`, `quiz-core*.js`, then the other `quiz-*.js` |

Rules that follow from the file-name pattern: a file is injected only if it is `M.css`, `M-*.css`, `wird-kit.js`, `M-shell.js` or
`M-*.js` (M = `tasks` or `quiz`). Any other file in `tools/src/` (the frozen `resources.*`, `unified.*`, the READMEs) is never touched.
`tasks-engine.js` is injected automatically because it is a `tasks-*.js` file. A later batch adds a feature by **adding a file**
(for example `tasks-ui.js`, `quiz-core.js`) and re-running the injector. No injector change is needed.

Each source is introduced by a marker comment `/* ---- tools/src/NAME ---- */`, so any line of the page can be traced to its source.
Source text is normalised (UTF-8, BOM removed, CRLF to LF, exactly one trailing newline), so the output does not depend on the editor
or operating system.

### Why the kit is in both script blocks
`wird-kit.js` starts with `if (root.WirdKit && root.WirdKit.version >= KIT_VERSION) return;`. The first block defines `window.WirdKit`;
the second finds it and does nothing. Both blocks therefore work alone and together, and the version check lets a later kit upgrade
replace an older one safely.

## 2. Running the injector

```
python3 tools/patch/inject_wird_modules.py            # build / refresh the four blocks
python3 tools/patch/inject_wird_modules.py --check    # read-only; exit 1 if the blocks are missing or stale
python3 tools/patch/inject_wird_modules.py --list     # read-only; print the resolved source order
python3 tools/patch/inject_wird_modules.py --root DIR # act on another copy of the project (used by the tests)
```

| exit | meaning |
|---|---|
| 0 | done, or already up to date |
| 1 | `--check` found missing or stale blocks |
| 2 | **refused** — nothing was written (see below) |
| 3 | written, but the preservation verifier failed → the original `index.html` was restored byte for byte |
| 4 | I/O error |

It is idempotent (a second run changes nothing, not even the file's modification time) and writes atomically (temporary file,
`fsync`, rename). Running it after changing a source updates only the blocks whose content changed.

### It refuses (exit 2, nothing written) when
`docs/PRESERVATION-BASELINE.json` or `tools/audit/verify_preservation.py` is missing; any **frozen** block of `index.html` differs from the
baseline; the anchor `<script id="wird-offline">` is not present exactly once; a block id exists twice; only some of the four blocks exist
(partial insertion) or they are not directly in front of the anchor or are separated unexpectedly; a required source is missing
(`wird-kit.js`, `M-shell.js`, `M.css`); a source is not UTF-8; or a source contains `</script`, `<script` or `<!--` (JS) / `</style`
or `<!--` (CSS), which would break out of its block.

After every run it executes the preservation verifier. The verifier also scans the new blocks (see `tools/audit/verify_preservation.py`):
they must not write any `localStorage` key other than `wird_tasks*`, `wird_taskprefs*`, `wird_quiz*`; must not open an IndexedDB other
than `wird_quiz_db`; and must not use `localStorage.clear`, `sessionStorage`, `caches.*`, `serviceWorker`, `deleteDatabase` and similar.

### Updating after a source change (normal workflow)
1. Edit the file under `tools/src/`.
2. `python3 tools/patch/inject_wird_modules.py`
3. Run the tests of the batch, then `python3 -I tools/audit/verify_preservation.py`.
4. Because `index.html` changed, the service-worker shell version must be raised **when a release is published**; that is the job of the
   update procedure (`docs/UPDATE-GUIDE.md`), not of the injector. B2 does not touch `sw.js`.

## 3. What the shells expose

```js
window.WirdKit    // shared kit, version 1 (below)
window.WirdTasks  // { version:1, kit, ext:{}, readHabits(), engine, getEngine(), ui, exec }   engine/getEngine: tasks-engine.js · ui: tasks-ui.js (B3) · exec: tasks-exec.js (B4)
window.WirdQuiz   // { version:1, kit, ext:{} }
```
`ext` is an empty object on purpose: later batches register their parts there (`WirdTasks.ext.planner = {...}`) without changing the shell.
**Load footprint.** After B2 nothing ran at load. After **B3** the footprint is exactly this (still checked against a pristine copy by the
load-footprint check of `tests/inject.test.js`, which passes): two element-level listeners (a capture-phase `click` on `#habitsRoot`, a `click` on
`#hFab`) and one `getItem('wird_tasks_v1')` **read** (never parsed, never written). No observer, no interval, no `window`/`document`/`body`
listener, no storage write, no IndexedDB open, no engine instance, no DOM change except the four `<style>`/`<script>` elements. If that key
already exists (the user has plans) a `setTimeout(…,0)` installs the badge observer (§6.4).

`WirdTasks.readHabits()` returns the app's habits object `H` (or `null`). `H` is a top-level `let` binding of the main script, so it is
visible to other classic scripts by the bare name but is **not** `window.H`; never write `window.H`.

## 4. WirdKit reference (version 1)

| Part | What it does |
|---|---|
| `ls.get/set/remove/getJson/setJson` | `localStorage` wrappers that **never throw**; they return `{ok, error}` or a fallback. Writes are limited to keys matching `^wird_(tasks|taskprefs|quiz)`; any other key is refused with `KeyNotAllowed` and nothing is written. Quota errors are recognised (`error.quota === true`). `ls.isQuotaError(e)`, `ls.available()`, `ls.lastError`. |
| `ls.adapter()` | `{getItem, setItem}` with the same whitelist that **lets exceptions propagate**; this is what the task engine uses, because it must react to quota and blocked storage. |
| `uid(prefix)` | collision-resistant ids, `prefix_<time36>_<random36>`; the prefix is sanitised. |
| `audio` | lazy `AudioContext`: `context()`, `unlock()`, `unlockOnFirstTap()` (opt-in, returns a cancel function), `blip({freq, ms, gain})`. Nothing is created until used; browsers that block audio simply return `false`. |
| `vibrate(pattern)` | `navigator.vibrate` guarded; returns a boolean, never throws. |
| `openDb(name, version, onUpgrade)` | IndexedDB opener. **Only `wird_quiz_db` is accepted**; any other name rejects with `DbNameNotAllowed`. Memoised; a failed first upgrade leaves no database behind. |
| `openQuizDb(onUpgrade, version)`, `quizDbExists()` | shortcuts for the quiz database; `quizDbExists()` checks without creating it. |
| `katex.ensure()` / `ensureKatex()` | loads KaTeX, `auto-render` and `mhchem` from the app's own bundled assets, once; resolves `null` (never rejects) when an asset is missing. If the lessons module already loaded KaTeX, it is reused and nothing is evaluated twice. `katex.options(display)` returns render options; `katex.macros()` returns the lesson macros (`\R`, `\vect`, ...). |
| `h(tag, attrs, children)` (`dom.h`, `dom.empty`) | DOM builder. Text is always inserted as text; `innerHTML`/`srcdoc` and string event handlers are ignored; handlers must be functions; `javascript:`/`vbscript:`/most `data:` URLs are dropped; `script/style/iframe/object/embed/link/meta/base/template` cannot be created (throws `TypeError`). |

Limits worth knowing: the KaTeX loader mirrors the lessons module's loader. If both start loading at the same instant on a cold page,
the two loaders may each add a `<script>`; the second evaluation is harmless but it is a documented residual race (the test shows that the
common orders — kit first, lessons first, concurrent kit calls — evaluate KaTeX exactly once).

## 5. Tests

**B3 adds `tests/tasks.planning.test.js`** (53 tests, Chromium; see §6.7).

`NODE_PATH=$(npm root -g) node tests/inject.test.js` — 46 checks:
* **Part A (33, Python only)**: fresh injection; four blocks in order before the anchor; verifier passes; only `index.html` changes; bytes
  outside the blocks preserved (cutting the region reproduces the input exactly); idempotency; refresh and revert; source-order rule; a later
  batch adding a file; 24 refusal and rollback scenarios; injector and verifier parse blocks identically; every injected JS block parses;
  no raw line/paragraph separator or invisible character in a source.
* **Part B (13, Chromium)**: pristine page versus injected page — no errors; only `WirdKit`, `WirdTasks`, `WirdQuiz` added to `window`; no new
  storage key or database; same observers, intervals and listeners; seeded legacy data left identical; KaTeX once; IndexedDB lazy and restricted;
  storage whitelist and quota behaviour; `uid`; DOM-builder safety; audio laziness; `H` access by bare name; engine persistence across a reload.

> **State after B3 (needs the user's decision):** two of these 46 checks — the *source-order rule* (it hard-codes the file list of `tools/src`)
> and *boot: only WirdKit, WirdTasks, WirdQuiz are added* (it hard-codes the key list of `WirdTasks`) — fail **by construction** because B3
> legitimately adds `tasks-ui.js` and `WirdTasks.ui`. `tests/inject.test.js` is a protected file, so it was NOT edited. With a two-line update
> of those expectations the suite is 46/46, including the load-footprint check (proved on a scratch copy; patch in
> `docs/test-logs/B03/inject.test.js.PROPOSED.patch`, logs `inject.log` = 44/46 and `inject.with-proposed-patch.log` = 46/46). Every later batch
> that adds a file or a `WirdTasks` key (B4 adds `WirdTasks.exec`) will hit the same two checks until the user approves updating them.
>
> **State after B4 (still needs the user's decision):** B4 adds `tasks-exec.js` / `tasks-exec.css` and `WirdTasks.exec`, so the same two `inject.test.js` checks still fail (44/46); the
> B3 proposal is now incomplete, so B4 ships an updated one covering both batches: `docs/test-logs/B04/inject.test.js.PROPOSED.patch` (`inject.log` = 44/46, `inject.with-proposed-patch.log` = 46/46).
> In addition **four tests of `tests/tasks.planning.test.js` (protected, B3) now fail by construction** because they assert that no execution screen exists (the row sheet lists exactly two buttons,
> «ابدأ» is absent without a stub…) — and two of them fail only as a cascade (the first leaves a sheet open). A three-line proposal makes it 53/53 again (proved on a scratch copy):
> `docs/test-logs/B04/tasks.planning.test.js.PROPOSED.patch` (`tasks.planning.log` = 49/53, `tasks.planning.with-proposed-patch.log` = 53/53). Neither protected file was edited.

## 6. Planner UI (B3 / TASK 1.2) — `tools/src/tasks-ui.js` + `tools/src/tasks.css`

Planning only: **day → tasks → steps**. No execution screen, no step completion, no settings sheet (B4/B5). Everything goes through
`WirdKit.h` (no `innerHTML`; asserted by a static scan in the test) and the engine API (`WirdTasks.getEngine()`); both are looked up **at call
time**, so a test can break them to prove the app keeps working.

### 6.1 Entry points (decision D1 default (a), ASSUMED DEFAULT; patch-free, amendment A2)
| Entry | Mechanism | Notes |
|---|---|---|
| Tap the **name** of a quick-task row `.hb-task[data-id^="o_"] .hb-n` | capture-phase `click` delegation on `#habitsRoot` | `hRender()` replaces the root's children but not the root, so the listener survives. Only rows of **today** whose id exists in `H.oneoffs[today]`; habit and event rows are never targets. The app's own handler is a no-op for quick tasks, so nothing is stopped or replaced. |
| Chip **«🧩 قسّمها لخطوات بعد الحفظ»** in the quick-task modal | `click` listener on `#hFab` injects the chip; a capture listener on `#hok` records today's ids **before** the app's handler runs, a `setTimeout(0)` afterwards opens the planner for the id that appeared | The quick task is created by the app's untouched handler first. Empty name ⇒ nothing is created ⇒ the planner does not open and the modal stays. |
| Chip **«🧩 خطّة بخطوات (بدون مهمة سريعة)»** | same injection | Removes the quick-task modal and opens the **day view** with the typed name pre-filled. |

**Deviation from the generated B3 prompt:** the prompt asked for a `MutationObserver` to inject the modal chips. `#hFab.onclick` is the only code
path that creates that modal (grep-verified) and the app's own handler is registered before ours, so the modal already exists when our `#hFab`
listener runs. This is equivalent, cheaper, and creates **no observer at load**, which keeps the tested B2 invariant (see §3).

### 6.2 Views (one bottom sheet, the app's own `.modal-overlay.open > .modal` look)
`row` (action sheet: «🧩 قسّمها لخطوات» / «تعديل الخطوات» / «▶ ابدأ» / «إغلاق») · `day` (chips اليوم / غدًا / يوم آخر with a date picker; the tasks
of the day with ▲ ▼ reorder, «نقل ليوم…», 🗑; "new task" field; **overdue block** = unfinished tasks of earlier days with a one-tap «نقل لليوم») ·
`task` (title, steps with inline edit, ▲ ▼ ＋ ✕ per step, add-step field, «نقل»/«حذف المهمة») · `move` (destination day; same-day and past days refused).
* A plan is created **lazily**: opening the editor and closing it writes nothing; the first step (or a typed title) creates it. A draft linked to a
  quick task shows «🔗 مربوطة بمهمة سريعة النهارده».
* Edits are autosaved: step/title commit on blur, Enter, close, navigation, or a 1.2 s typing pause (a debounced save never touches the text or caret).
* Deleting a task uses the app's own `showConfirm` (above the sheet); deleting a step has no confirmation.
* Own focus handling: focus moves into the sheet, Tab is trapped (suspended while `#confirmOverlay` is open), Esc cancels the innermost sub-state then
  closes, focus returns to the opener, backdrop tap closes, the sheet follows `visualViewport` (soft keyboard) and scrolls the focused field into view.
* Rendering is read from the engine on every render; the sheet subscribes to the engine and re-renders on **foreign** changes (e.g. B4), ignoring its own.
* Test hooks on every control: `data-act="up|down|ins|del|move|del-task|start|edit|split|close|back|move-do|move-cancel|insert-do|insert-done|to-today"`.

### 6.3 Public API — `WirdTasks.ui`
```js
WirdTasks.ui.openPlanner(opts) -> { ok:true, close(), view } | { ok:false, reason:'internal_error' }   // never throws
   { taskId }                  the editor of that plan
   { oneoffId, title?, day? }  the plan linked to that TODAY quick task, or a new unsaved draft linked to it
   { day?, title? }            the day view (default today); `title` pre-fills the "new task" field
WirdTasks.ui.closePlanner() · isOpen() · refreshBadges() · status() -> {rootHook, fabHook, observer, open, view} · lastError() · destroy() · version (1)
WirdTasks.ui.takeOrigin(taskId) -> {view, day} | null     // B4: where «ابدأ»/«متابعة» was pressed; consumed once (see §7.1)
```
**Contract for B4 («ابدأ»):** the button is rendered only if `WirdTasks.exec && typeof WirdTasks.exec.open === 'function'` (checked at render time),
for plans that have ≥1 step and are not finished. Click ⇒ the planner **closes**, then `WirdTasks.exec.open(taskId, { from: 'planner' })`. To return
to the planner B4 calls `WirdTasks.ui.openPlanner({ taskId })` or `({ day })`.

### 6.4 Badge on rows that HAVE a plan, and observer discipline (amendment A5)
Rows without a plan are byte-identical to the pristine page (tested for 3 list modes, calendar, table, stats, today). A row whose quick task has a
plan gets one `<span class="wt-badge" data-wt>🧩 N</span>` inserted **after** `.hb-n` (so line-through of done rows does not strike it).
* One `MutationObserver`, on `#habitsRoot`, `{ childList: true }` **only** (no `subtree` — `subtree` would re-trigger itself with the badge insertion
  and spin forever; a mutation test proved that freezes the page). It is created **lazily**: after the first plan is created, or at load only if
  `wird_tasks_v1` already exists. No observer exists on lesson screens. When no plan exists and no badge is present the callback returns immediately (the plan-by-quick-task map is cached until the engine changes).
* `destroy()` disconnects it and removes the hooks and badges.

### 6.5 Load footprint, storage, safety
* Writes only `wird_tasks_v1` (through the engine). **Nothing is ever written to `wird_habits_v1`** (D8: the habits adapter stays a no-op). No new
  IndexedDB, no new key. Newer-schema data ⇒ read-only banner, edits refused with the reason, stored bytes untouched (tested).
* Every hook is wrapped in `try/catch` and reports through `WirdTasks.ui.lastError()` (+ `console.warn`, never `console.error`): quick-task creation
  never depends on this file (tested with a deliberately throwing `WirdKit.h`, before and after the toggle chip, and with a throwing engine).
* User text is only ever text: titles, steps, quick-task names and the confirm message with `<img onerror>` never become elements (tested).

### 6.6 CSS (`tasks.css`, ~6 KB)
Only new selectors (`.wt-*`, `.modal.wt-sheet`; enforced by a static test). Reuses the app's tokens and classes. Every interactive control inside the
planner and the two modal chips is ≥ 44×44 CSS px (measured per viewport). No animation or transition is defined. Logical properties only (RTL).

### 6.7 Tests — `NODE_PATH=$(npm root -g) node tests/tasks.planning.test.js` (≈2.5 min, 53 tests, 405 assertions)
Pristine page vs injected page with the same seed under a **fixed clock**: every habits view byte-identical; modal markup identical apart from the two
chips; quick-task creation, check-off sheet and the 5-step wizard identical; `wird_habits_v1` byte-identical after "save then plan". Then every planning
operation with the engine as oracle and a reload; days (today / tomorrow / date picker); reorder; move (same day, past day, finished, linked); overdue;
delete with confirm (cancel / ok / stacking / Esc); `exec` feature detection; XSS; read-only data; storage discipline; fault injection ×3; observer
discipline (one observer, `childList` only, 50 `hRender()` neither loop nor slow down); keyboard trap and focus return; static hygiene; and a
360 / 390 / 412 px sweep (RTL order, no horizontal overflow, ≥ 44 px controls, simulated keyboard) with screenshots in `docs/test-logs/B03/screens/`.
Three mutations (planner opens for habit rows; badge on every row; observer with `subtree`) are caught (`docs/test-logs/B03/mutations/`). A watchdog
ends a frozen run as a failure.

### 6.8 Known limitations
Soft keyboard only **simulated** (viewport shrink), no real device, no IME composition test, no Android Back button handling, last-write-wins across
tabs, no unlink-from-quick-task UI, pause/resume UI belongs to B4 (done: §7). Plan title and quick-task name are independent after creation.

---

## 7. Execution screen (B4 / TASK 1.3) — `tools/src/tasks-exec.js` + `tools/src/tasks-exec.css`

**ONE TASK → ONE CURRENT STEP → ONE ACTION.** `WirdTasks.exec` (`version: 1`) is a full-screen overlay (`.wx-ov`, own element, `position:fixed; inset:0`,
`z-index:150`: above the app's modals (100), below its confirm dialog (200) and toast (300); `visualViewport`-aware) with a small task-context line, the current
step in large type and one primary action («✓ تمّت», 64 px high, in the thumb zone). Built with `WirdKit.h` only (no `innerHTML`); the engine owns all state.
New files (not rewrites of `tasks-ui.js` / `tasks.css`): the injector picks them up by its source-order rule (`tasks-engine.js` → `tasks-exec.js` → `tasks-ui.js`;
`tasks.css` → `tasks-exec.css`) — `inject --list` shows the order, `inject.test.js`'s scratch fixtures are unaffected.

### 7.1 API — `WirdTasks.exec`
`open(taskId, opts)` → `{ok:true, close(), taskId}` | `{ok:false, reason}` (`not_found`, `no_steps`, `finished`, `read_only`, `internal_error`, or an engine reason).
A not-started task is started (the engine takes the preference snapshot); an in-progress task continues at its exact step; a **paused** task is resumed
(opening = coming back) unless `opts.resume === false`, which opens it in the paused view. `opts.from === 'planner'` + `opts.fromView` (`day` | `task` | `row`) and
`opts.fromDay` say where to return on close; when `fromView` is absent the planner's hand-off `WirdTasks.ui.takeOrigin(taskId)` supplies it (the planner's call stays
exactly `exec.open(id, {from:'planner'})`, the B3 contract). Other `from` values: no navigation on close. `resumeActive(opts)` opens the engine's active task.
`close()`, `isOpen()`, `status()` (`{open, taskId, view: run|hold|paused|done, stepId, hold, undo, history, locked}`), `lastError()`, `destroy()`.
The view is **never opened at app start**; the planner offers «ابدأ» (not started) or «متابعة» (in progress / paused) from the day card, the task editor and the quick-task row sheet.

### 7.2 Behaviour
* **Check** → `engine.complete(displayedStepId, {elapsedMs?})` (idempotent) → short fade (≈170 ms out, ≈260 ms in) → the next step. A UI lock (≈560 ms with motion, 350 ms without) starts
  **before** the engine call, so a double/triple tap records one completion and never skips a step. The tap targets the step on screen: if the engine moved on behind the view's back
  (another tab) nothing is recorded and the view re-syncs.
* **Last step** → a quiet completion state (✓, «خلصت المهمة» / «خلصت — وفيه خطوات اتخطّت» / «اتخطّيت كل الخطوات»), the undo snackbar still available, a «تمام» button that closes and returns
  to where the user came from (day view, or the task editor if the plan was started from there; the habits screen when started from a row). Interpretation: no automatic navigation — the undo window needs the screen.
* **Undo snackbar** (own element, above the primary action, `UNDO_WINDOW_MS` = the engine's `undoWindowMs`, 8 s): «اتسجّلت ✓ · تراجع». The engine decides (`window_expired` → «فات وقت التراجع.»). Undo restores the previous step exactly and records an `undo` event.
* **Back** (preference `backNavigation`, default on): `engine.back` — no time limit; also from the completion state (A2). **Pause** (⏸ in the top bar) → paused view with a large «▶ متابعة»; the engine refuses completion while paused.
* **Preferences** are read from the **session snapshot** (`getSessionPrefs`): `autoTransition` (off → the checked step stays, marked done, with «التالية»), `skipStep` (default off), `editDuringExecution` (inline edit through `editStep`; Enter saves, Esc cancels;
  closing while editing keeps a valid change), `timer` (a per-step stopwatch; its reading is stored with the completion as the additive engine field `elapsedMs`, see `TASKS-ENGINE.md` §4; paused time is not counted;
  the stopwatch restarts from zero when the view is reopened), `progress` (`hidden` = no node at all, the default · `subtle` = a thin bar, no numbers · `detailed` = bar + «N من M»), `completionAnimation`, `microInteractions`, `sound`, `haptic` (the last two call `WirdKit` blip/vibrate **only** when ON; default OFF).
  The settings UI is B5; until then prefs change only through the engine API.
* **Exit / Android Back:** one history entry (`{wirdExec:1}`) is pushed while the view is open and `popstate` closes it (the app has **no** history handling of its own, so nothing conflicts); closing with ✕/Esc pops the entry it pushed.
  A stale entry left by a reload is reused, never stacked; a `popPending` guard makes rapid open/close safe. If `pushState` is unavailable the ✕ button is the only exit. Esc closes (or cancels an edit); Tab is trapped inside the dialog.
* **Motion:** all `transition`/`animation`/`@keyframes` live inside `@media (prefers-reduced-motion: no-preference)`, only `opacity`/`transform`; under reduced motion (or `completionAnimation: 'off'`) the swap is immediate and JS adds no delay. (The app itself also clamps every transition to 0.01 ms under reduced motion.)
* **Footprint:** nothing runs at load except defining `T.exec`. The `keydown` (document, capture), `popstate` and `visualViewport` listeners, the 1 s timer interval and every timeout exist only while the view is open and are removed on close (test: balanced add/remove counts). No storage of its own: nothing is written except through the engine (`wird_tasks_v1`).

### 7.3 Tests — `NODE_PATH=$(npm root -g) node tests/tasks.exec.test.js` (≈2 min, 70 tests, 470 assertions)
Part 1 (Node): the additive `elapsedMs` field (stored, invalid readings ignored, reload, duplicate, undo, backward compatibility, sanitizer). Part 2 (Chromium, fixed clock): default view, flow, undo in/out of the window and after the real 8 s,
back, pause/resume, reload **and a real browser restart** (persistent profile) restore, triple-tap dedupe + lock duration, skip off/on and partial/skipped endings, in-run edit, timer, progress modes, autoTransition off, haptic/sound off by default,
reduced motion (computed styles + CSS scan), history/Back, listener balance, entry points and return navigation, quota failure, deleted plan, 360/390/412 px + landscape 844×390 + long Arabic/English steps + simulated keyboard.
Seven deliberate mutations are caught (`docs/test-logs/B04/mutations/`): lock removed, stale step, skip recorded as completion, reduced-motion check removed, step counter text, CSS motion outside the media block, fake undo.

### 7.4 Known limitations
No real device / real IME / real Android Back button (history behaviour verified with Chromium's `goBack`), the soft keyboard is only simulated by a viewport shrink, last-write-wins across tabs (a second tab changing the same plan is re-synced on the next tap, not live),
the stopwatch reading of an unfinished step is not saved across a reopen, sound/haptic have no settings UI yet (B5), no end-of-day prompt (B5/Phase 1.5).

