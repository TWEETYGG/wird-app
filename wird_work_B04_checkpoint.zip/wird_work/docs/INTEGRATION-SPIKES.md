# Integration-point spikes (Task 0.2) — READ-ONLY investigation

No application code was changed. Evidence: static reading of `index.html` + the live probe `tools/audit/probe_anchors.js`
(Chromium 141, 390×844, service worker blocked, no external network). Raw output: `docs/spike-evidence/probe-output.json`;
screenshots `docs/spike-evidence/01…04-*.png`. Re-run: `NODE_PATH=$(npm root -g) node tools/audit/probe_anchors.js`.

Line numbers refer to the **untouched** `index.html` (SHA of the file is recorded in `docs/PRESERVATION-BASELINE.json` via block hashes).

## 0. Summary table

| # | Question | Answer (short) | Needs a patch to an existing block? |
|---|---|---|---|
| a | Where is "Add New Sheet"? | No control with that name. Real candidates: **A** unit-row `＋` (aria «ملخص جديد»); **B** lesson header (`section.wr`, beside «📅 جدولة»); **C** sidebar-top `＋` (aria «مادة جديدة»). | No — A via `window.__wirdRow` wrapper, B via sibling element + MutationObserver |
| b | Can a `quiz` lesson item type/tab be added? | **Not without patching frozen code.** `wirdResNorm` rejects unknown types; tab list is hard-coded in `wird-resources`. | Yes (frozen blocks) ⇒ **avoid** (D3 default holds) |
| c | KaTeX / mhchem reuse | Present, **lazy**: `katex` is `undefined` until a lesson opens. Own loader mirroring `ls-main`'s works in a fresh page (37 ms). | No |
| d | Existing mistake notebook API | Public, safe repo methods: `saveMistake / listMistakes / setMistakeStatus / reseeMistake / deleteMistake`. Statuses `open · improving · mastered`. | No |
| e | Settings location | **There is no general settings screen.** Each area has its own (see §5). Self-contained settings sheet recommended. | No |
| f | Timer / sound / haptic helpers | `pmAudio()/pmChime()` and `navigator.vibrate` exist but are Pomodoro-coupled. Use own tiny helpers. `navigator.share` is not available everywhere ⇒ fallback needed. | No |
| g | UI helper signatures | `hModal(html)`, `showConfirm(title,msg,onConfirm)`, `showToast(msg)` (no action button), `hUid`, `escapeHtml`, `toArabicNum`, `todayISO`, `hSave`, `hRender` — all callable from a new classic `<script>`. | No |
| h | Wizard step-2 chips | Confirmed: free slot beside «بالكمية» is real (164 px, fits a chip). **Adding a 4th tracking type is invasive** (touches `hWizard` type logic) ⇒ not recommended. | Yes (guarded main script) ⇒ only if you ask |

Additional findings (§9): quick-task row anchor, quick tasks are today-only, hRender re-renders everything, storage footprint.

---

## a. "Add New Sheet" — candidates and hook mechanics

Sidebar rows (probe `c1`): subject row buttons `＋ aria="وحدة جديدة"` and `⋯`; **unit row `＋ aria="ملخص جديد"`** and `⋯`;
lesson row `⋯` only. Workspace top bar (`c3`): `＋ مادة جديدة`, `قائمة الدروس`, breadcrumb, view switch `📝 الملخص | 📓 النوت`.
Lesson header (`c3`): `.ls-lesson-main > .ls-banner, input.ls-title, .ls-lesson-stats, section.wr[data-lesson], .ls-editor-wrap`;
`section.wr` children: `#wrHead`, `#wrTabs`, `#wrPanel`; `.wr-foot` children: `details.wr-help` («كيف يُحسب التقدّم؟») and `button.ls-btn.wr-sched` («📅 جدولة»).
This matches the lesson screenshot the user supplied (جدولة + «كيف يُحسب التقدّم؟» + the tab strip الملخص/فيديو/كتاب/روابط/كورس/نص).

| Candidate | Selector | Hookable without patching? | Evidence |
|---|---|---|---|
| **A** unit-row ＋ «ملخص جديد» (new summary = "new sheet") | `.ls-row-unit .ls-row-btn[aria-label="ملخص جديد"]` | **Yes**: wrap `window.__wirdRow(row, el)` (called once per sidebar row on every `sidebar.render()`; `row.kind==='unit'`). Probe `c2`: wrapper called 3×, unit row marked, original restored cleanly. Only visible inside the sidebar drawer; one per unit. | `c1`, `c2` |
| **B** lesson header, beside «📅 جدولة» | `section.wr[data-lesson] #wrHead`, `.wr-foot` | **Yes**, but **not by appending inside `.wr-foot`/`#wrHead`**: `renderHead()` rewrites `#wrHead.innerHTML` on every resources reload (probe `c4`: element inside `.wr-foot` **did not survive**). A **sibling after `#wrHead`** or **after `#wrTabs`** survives (`c4`: both true). Detect mounting with a MutationObserver for `section.wr[data-lesson]` (created in `attach(view)`, line ~9655, via `view.statsEl.after(wrap)`). | `c3`, `c4` |
| **C** sidebar-top ＋ «مادة جديدة» | `.ls-side-add` | Possible (static element) but semantically "new subject". | `c1` |

**Recommendation (D2 default, unchanged): B** — a persistent button row as a *sibling directly after `#wrHead`* (visually next to «📅 جدولة»), because the
prompt is global/reusable and quiz sessions are lesson-scoped, so the lesson header is the one place both belong. A one-tap secondary entry can be added at
A later. **Needs the user's confirmation before Task 2.4** — I could not determine from the annotated screenshot whether "Add New Sheet" means A or B.

## b. Lesson tab strip / item types

* `renderTabs()` (line ~9705) builds `defs=[['note','📝','الملخص'],['video',…],['book',…],['link',…],['course',…],['text',…]]` — inside the frozen `wird-resources` block.
* `wirdResNorm(o)` (global function, in the bundle) returns `null` unless `wirdResTypes.includes(o.type)`. Probe `e2`: `repo.saveResource({type:'quiz',…})` ⇒ **`REJECTED: Invalid resource`**.
* Therefore a `quiz` resource type or 7th tab would need edits to `wirdResTypes`/`wirdResNorm` (bundle), `renderTabs` (`wird-resources`) and probably the sidebar badge code and `wird-unified` item handling (not audited in detail) — several frozen places.
* **Conclusion:** keep **D3 default** — a lesson-linked quiz panel owned by the new module (sibling section after `#wrTabs`/`#wrHead`), data in `wird_quiz_db`, **no resource-type change, no bundle patch**.
  The panel can still look like the existing tab panel (`.wr-panel`-like classes are CSS only).

## c. KaTeX / mhchem / math tokenizer

* `katex` is **undefined at app start and after opening the lessons workspace** (probe `a0`, `katexBeforeLessonsOpen`); it becomes `object` (v0.16.45) once a lesson editor loads it (probe `d1`).
* Loader pattern (in `ls-main`, line ~8718): `fr()` injects `<style id="ls-katex-style">` from `#ls-asset-katex-css`; `Vi(id)` evaluates `#id`.textContent through a temporary `<script>`; `un()` runs `fr(); Vi('ls-asset-katex') && Vi('ls-asset-mhchem')` inside a `setTimeout(0)` promise.
* **Own loader works without opening any lesson** (probe `d2`): katex `undefined → object` in **37 ms**, `\ce{H2O}` renders, no error.
  **Race rule:** both loaders must be guarded with `typeof katex !== 'undefined'` and `document.getElementById('ls-katex-style')` so KaTeX is never evaluated twice.
* Render options used by the lesson (copy for consistency): `{displayMode, throwOnError:true, strict:'ignore', trust:false, output:'htmlAndMathml', maxExpand:1000, macros:{\vect,\unit,\abs,\norm,\dd,\deriv,\pderiv,\R,\N,\Z,\Q}}`.
  Macro definitions (var `hr`, ls-main): `\vect→\vec{\mathbf{#1}}`, `\unit→\,\mathrm{#1}`, `\abs→\left|#1\right|`, `\norm→\left\|#1\right\|`, `\dd→\mathrm{d}`, `\deriv→\frac{\mathrm{d}#1}{\mathrm{d}#2}`, `\pderiv→\frac{\partial #1}{\partial #2}`, `\R \N \Z \Q → \mathbb{…}`.
* Lesson content model (relevant to **D4**), verified by grepping `ls-main`: a JSON node document with node types `paragraph`, `heading` (`attrs.level` clamped to **1–3**, default 2), `bulletList`, `orderedList`, `listItem`, `callout` (`attrs.kind`), `toggle`, `table`/`tableRow`/`tableCell`, `image`, `mathBlock`, `mathInline`, `horizontalRule`. There is **no** `codeBlock`, `blockquote`, `taskList` or `tableHeader` node. **It is not Markdown.** Chemistry is `\ce{…}` inside math.
* The paste tokenizer in the `wird-math-paste` block is exposed as globals (`window.wMathTok`, `wMathJoin`, `wMathFrag`, `wMathHtml` — probe: all `function`). Exact rules (read from the source) that the quiz text format and AI prompt must respect:
  * `$$…$$`, `\[…\]` ⇒ block math; `\(…\)` and `$…$` ⇒ inline math; `\$` ⇒ a literal dollar sign.
  * A single-`$` pair is inline math **only if** the content is non-empty, has no whitespace just inside either `$`, the character *before* the opening `$` is not `A-Za-z0-9`, the character *after* the closing `$` is not a digit, and the content is not purely digits/`.`/`,` (so "$5" or "costs $5 and $6" stay text). An Arabic letter before `$` is fine.
  * A single-`$` search never crosses a newline. Bare LaTeX runs containing `\command` (≥2 letters) are auto-detected as inline math even without `$`; a whole paragraph that "looks like" an equation becomes a block.
  * Doubled backslashes before `( [ ] { } , ; : !` or a command are collapsed (`fix`), which forgives JSON-escaping mistakes (`\\frac` → `\frac`).

## d. Existing mistake notebook («دفتر الأخطاء»)

Public API on `__WIRD_STUDY_APP__.repo` (mutex-serialised, emits `{type:'mistakes'}` so the open UI refreshes) — probe `e1`:
* `saveMistake({lessonId, errorDescription, rootCause, correctionRule, examWarningTag?, status?, recurrenceCount?, calloutId?})` → record keys: `id, lessonId, subjectId, unitId, errorDescription, rootCause, correctionRule, examWarningTag, recurrenceCount, status, createdAt, lastSeenAt`. **`lessonId` must exist** (looked up via `must("lessons", …)`).
* Statuses: **`open` → `improving` → `mastered`** (var `Jt`). `reseeMistake(id)` = `recurrenceCount+1`, `lastSeenAt=now`, and `mastered → open` — exactly the "repeated error" rule needed in Task 4.4. `setMistakeStatus(id, status)`, `deleteMistake(id)`, `listMistakes({lessonId?, …})`.
* **D5 default stands:** keep a separate quiz mistake pool in `wird_quiz_db`; offer an *optional* one-tap "سجّل في دفتر الأخطاء" that calls `repo.saveMistake` (only possible when the session has a `lessonId`). Never write the `mistakes` store directly.

## e. Settings locations (there is no global settings screen)

| Area | Entry | Content |
|---|---|---|
| App header ⚙ `#settingsBtn` → `#settingsOverlay` | static markup (line ~2034) | «إعدادات الخطة» — Quran daily amount / review ranges |
| Habits ⚙ (`#habitsRoot .hb-top [data-v="set"]`) → `hSettings()` (line 5198) | modal built by script | «نظام تقسيم الوقت» — time-block system only (probe `b4`) |
| Lessons workspace nav `⚙ الإعدادات` (`.ls-nav-btn`) | inside minified `ls-main` | lesson-workspace settings (contents not inspected in B1) |

**Conclusion:** adding rows to any of these means editing frozen/guarded code. **Plan amendment:** task and quiz preferences live in **module-owned settings sheets** opened from
the planner/execution screens (⚙) and from the quiz start sheet (⚙). **No settings hook is required.** (Roadmap Task 1.4's "settings hook owner" is therefore void; optional entry rows would need approval.)

## f. Timer, sound, haptic, share helpers

* `navigator.vibrate` is used directly (habit timer, Pomodoro chime) — available on Android Chrome/Brave; guard with `try/catch`.
* `pmAudio()` returns a shared `AudioContext` (resumes if suspended); `pmChime(kind, noVib)` honours `PM.sound` and plays Pomodoro-specific tones. **Do not reuse** (would couple task feedback to the Pomodoro setting). The new module creates its own lazy `AudioContext` on first user tap.
* Habit timer `HT` / `hTimer(h, sub)` is bound to a habit id. Task-step timer must be self-contained.
* Probe `f2` (desktop headless Chromium): `navigator.share` **undefined**, `navigator.clipboard.writeText` present, `navigator.storage.persist` present, `visualViewport` present ⇒ answer-sheet sharing needs Web Share with copy/download fallback; request persistent storage before storing images.

## g. UI helper signatures (all are globals; a new classic `<script>` can call them)

| Helper | Behaviour / caveat |
|---|---|
| `hModal(html)` | Creates `<div class="modal-overlay open"><div class="modal">html</div></div>` on `document.body`, closes on backdrop tap only; returns the overlay. **No Esc key, no focus trap.** CSS classes available: `.modal .desc .field-input .field-label .field-hint .hb-chips .btn .btn-primary .btn-ghost .btn-danger .panel-card`. |
| `showConfirm(title, message, onConfirm)` | One shared confirm overlay (`#confirmOverlay`), text only. |
| `showToast(msg)` | One shared toast, 2.6 s, **no action button** ⇒ the undo toast of Task 1.3 must be its own element. |
| `hUid(prefix)`, `escapeHtml`, `toArabicNum`, `todayISO()`, `el(id)` | Utilities (all `typeof === 'function'`, probe `a0`). `hUid=p=>p+'_'+Date.now().toString(36)+Math.random().toString(36).slice(2,6)` — prefix is required. |
| `hSave()`, `hRender()` | Persist `H` to `wird_habits_v1` / re-render the whole `#habitsRoot` (≈ `R.innerHTML=tabs+body`). |
| `H` | Global **lexical** binding: `typeof window.H === 'undefined'` but bare `H` is an `object` (verified) ⇒ new modules must reference `H` by bare name, never `window.H`. |

## h. Wizard step 2 (the user's circled area)

Probe `b3` (and screenshot `02-wizard-step2-chips.png`, which visually matches the user's screenshot): `#wt.hb-chips` is `display:flex; flex-wrap:wrap; gap:6px`.
Row 1 = «✅ عادية (بمستويات)» + «⏱ بالوقت (دقائق)», row 2 = «🔢 بالكمية (عدّات/صفحات…)» alone at the right; **free slot in row 2 = 164 px (x 21→185)** — wide enough for one more chip. So the area the user circled is precisely where a 4th chip would flow.

Why a 4th chip is **not** recommended: `w.type` has values `b | time | qty` and drives step routing, `meas()` and saving (`hb.type`); a new type touches `hWizard` in the guarded main script, the save path and every renderer that switches on `type`. The brief also says the wizard must stay intact and atomization is for *tasks*.
**D1 default stands** (task-card action + optional follow-up after creating a quick task). If the user still wants the chip, the least invasive form is an independent toggle (like the existing step-3/5 toggles) that only opens the planner after saving — to be scoped separately and approved.

## 9. Other findings that shape the plan

1. **Quick-task rows have a free tap target.** Row markup: `div.hb-task[data-id^="o_"] > button.hb-c[data-a=chk] + span.hb-n[data-a=open]`. Tapping the name of a quick task currently **does nothing** (probe `b2`: no modal opens). Quick-task record: `{id:'o_<ms>', name, s:<minute-of-day block>, cat:'main'|…, done:false}` in `H.oneoffs[todayISO()]`.
2. **Quick tasks can only be created for today** (`#hFab` handler uses `todayISO()`); `H.oneoffs[date]` exists for any date but there is no UI for future dates. ⇒ Task 1.1 must own future-day plans in `wird_tasks_v1` (new **decision D7**: standalone plans + optional link to a today quick task = default; materialising future plans into `H.oneoffs` is **not** done unless approved).
3. **`hRender()` re-renders the entire habits root** every time ⇒ any injected action must be re-applied (MutationObserver on `#habitsRoot` or capture-phase event delegation); the `#hFab` modal is created by `hModal()` so a "split into steps after saving" chip must be injected into that modal via observer.
4. **Storage footprint of a fresh profile after the probe:** localStorage `wird_habits_v1, wird_mig_v3, wird_quran_state_v1` (+ study keys once used); IndexedDB `wird_books_db@v3, wird_fnb_m@v1, wird_mig_db@v1, wird_study_db@v2`. **`wird_quiz_db` does not exist** ⇒ it must be created lazily and never bump these versions.
5. **Script scoping:** new `<script id="wird-tasks">` / `wird-quiz` blocks can call every helper above because classic scripts share the global lexical environment; each module must wrap itself in an IIFE and expose only `window.WirdTasks` / `window.WirdQuiz`.
6. **Perf headroom:** `perf.test.js` `openMs` at CPU×4 is 767 ms vs budget 800 ⇒ no work may be added to lesson opening (observer callbacks must be O(1) and ignore non-`section.wr` nodes).

## 10. Open questions for the user (carried into HANDOFF.md)

* **D2** confirm A or B (default B).  **D1**, **D3**, **D4**, **D5**, **D6** (defaults unchanged; D3 and D5 now evidence-backed).
* **D7 (new)** future-day plans: standalone in `wird_tasks_v1` (default) vs also writing quick tasks into `H.oneoffs[date]`.
