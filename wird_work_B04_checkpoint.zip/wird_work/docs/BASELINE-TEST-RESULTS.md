# Baseline test results (Task 0.1)

Executed on **2026-11-03** against a scratch copy of the untouched upload (`wird_work_updated.zip`, SHA-256
`6ad6ebc34c3c3c9d527ddad482b7c28f169ed73ba927e11f4c2d966ddb1c2a3f`). The project tree itself was never used as the
test working directory.

Environment: Python 3.12.3 · Node v22.22.2 · Playwright 1.56.0 · Chromium 141.0.7390.37 (headless, `PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers`).
Command pattern: `NODE_PATH=$(npm root -g) node tests/<suite>.test.js`. Raw logs: `docs/baseline-logs/`.

## Results of the six existing suites (the "before" state)

| Suite | Result | Exit code | Time | Notes |
|---|---|---|---|---|
| `update.test.js` | **64/64 checks passed** | 0 (run 2) | ~96 s | Run 1 also printed `64/64` but was launched by a background runner that was killed before recording its exit code; run 2 was done in the foreground and recorded exit 0. |
| `offline.test.js` | **1/1 passed** (page + pdf.js CDN served from SW cache, «منهجي» opens offline) | 0 | 6 s | |
| `unified.test.js` | **12/12 passed** | 0 | 84 s | |
| `resources.test.js` | **34/34 passed** | 0 | 59 s | The README mentions VID-3 failing on the original; it did **not** fail in this environment. |
| `courses.test.js` | **run 1: 31/32** · **run 2: 32/32** | 1, then 0 | 35 s / 36 s | Run 1 failed `18. أوفلاين أثناء جلب البيانات` (offline during data fetch; message `offline/err message`). It passed on the immediate re-run ⇒ **flaky test, not a product regression**. README-listed flaky items END-3 / 8-10-11 did not fail. |
| `perf.test.js` | **passed — within budget** | 0 | 10 s | Seeded 360 lessons / 2160 items / 200 books. CPU×1: renderMs 9, scrollStepMs 29, searchMs 0.7, openMs 513, heap 17 MB. CPU×4: renderMs 36, scrollStepMs 53, searchMs 1.5, openMs 767. Budget: rowsInDom 80, renderMs 250, scrollStepMs 60, searchMs 120, openMs 800. **`openMs` at CPU×4 (767) is close to its 800 budget** — later tasks must not add work to lesson opening. |

**Regression rule for every later batch:** a suite is "at baseline" if it reproduces the numbers above. `courses` test 18 may flake once; re-run before reporting a failure, and report both runs.

## Preservation tooling tests (also executed)

| Check | Result |
|---|---|
| `python3 -I tools/audit/test_verify_preservation.py` (27 mutation cases on scratch copies) | **27/27 passed**. One earlier run was 26/27 because of a wrong expected-string in the *test* (whitespace in a match string); the verifier itself had flagged the mutation correctly. Fixed in the test only. |
| `python3 -I tools/audit/verify_preservation.py` on the pristine upload (`--root`) | **PASS — OK=68** |
| Same on the B1 working tree | **PASS** (only additions: new files, no changed or removed existing file) |

## What was NOT tested in B1
Nothing was changed in the application, so no feature test applies yet. Real-device behaviour (Android Brave, keyboard,
camera capture, PWA install) is untested and remains untested until later batches.
