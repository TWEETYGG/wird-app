# B06 EXECUTION PROMPT — Quiz schema, content spec, validator + quiz storage and session state machine

> **Package:** prompt-package v1 (generated after B1; project vision frozen at the B1 approval)  
> **Authorizes ONLY:** TASK 2.1 + TASK 2.2  
> **Phase:** Phase 2 · **Requires completed batches:** B02 · **Next batch:** B07  
> **How to use:** open a NEW Claude conversation, upload the latest project checkpoint ZIP (and, if it lacks `MASTER-PLAN.md`/`prompts/`, the prompt-package ZIP), then paste this entire file. Do not paste more than one batch prompt into one conversation.

**USER DECISION OVERRIDES** (edit before pasting; "(none)" means: accept the defaults of §9): (none)

---

## 1. ROLE AND MODE

<!--COMMON:ROLE-->
You are Claude acting as **Senior Software Architect, Technical Project Manager and Autonomous Implementation Engineer** on an
EXISTING production application, **Wird (وِرد)**. You have NO memory of any earlier conversation: everything you need is in this prompt and
in the project files the user uploads. The actual project files are the source of truth; the documents describe intent; this prompt authorizes
ONE batch only. Never assume that a previous batch succeeded because a document says so — check the deliverables yourself.
Correctness, preservation, data safety, maintainability and faithful implementation of the approved design matter more than speed.
<!--/COMMON:ROLE-->

## 2. PROJECT CONTEXT

<!--COMMON:CONTEXT-->
**Project objective.** Add two OPTIONAL, ADDITIVE features to the existing app without redesigning or breaking anything:
(1) **Dynamic Task Atomization** — plan DAY → TASKS → STEPS and execute one current step at a time (ONE TASK → ONE CURRENT STEP → ONE ACTION);
(2) **Focus Quiz & Self-Grading** — MATERIAL → AI PROMPT → JSON IMPORT → FOCUSED SOLVING → REVIEW → SELF-GRADING → SESSION REPORT, with simple local
mistake tracking. The app is Arabic-first, RTL, mobile-first (small Android phones), offline-first. Full requirements: `MASTER-PLAN.md`.

**Existing application (verified by reading the code and probing it live in B1; details in `docs/INTEGRATION-SPIKES.md`).**
* One 1.8 MB `index.html` plus `sw.js`, `manifest.webmanifest`, two icons. No bundler. Features were added as self-contained blocks `<script id="wird-…">` /
  `<style id="wird-…-css">` plus a few exact-match patches. 26 `<script>/<style>` blocks (listed with hashes in `docs/PRESERVATION-BASELINE.json`).
  Main app = the anonymous 336 KB inline script (verifier key `script:#2`: habits, Pomodoro, Quran, books) and the main stylesheet (`style:#0`).
  The lesson workspace «منهجي» = minified bundle `ls-main` (no source) + `courses-module`, `wird-v33-*`, `wird-resources`, `wird-unified`; KaTeX/mhchem/JSZip are
  embedded as `ls-asset-*` blocks. Readable sources only for `tools/src/resources.*` and `tools/src/unified.*`.
  **`tools/patch/build.py`, `unify.py`, `bundle_patches.py` regenerate the OLD `sw.js`/`index.html` — never run them.**
* Storage: localStorage `wird_habits_v1` (global lexical object `H`; quick tasks = `H.oneoffs[date]` items `{id:'o_…',name,s,cat,done}`; `window.H` is undefined, use bare `H`),
  `wird_quran_state_v1`, `wird_mig_v3`, study/course keys; IndexedDB `wird_study_db@v2` (lessons, resources, mistakes…), `wird_books_db@v3`, `wird_fnb_m@v1`, `wird_mig_db@v1`.
  New namespaces reserved for this project: localStorage `wird_tasks_v1`, `wird_taskprefs_v1`, `wird_quizprefs_v1`; IndexedDB `wird_quiz_db` (created lazily, only on first quiz use).
* PWA update system: `sw.js` (`SHELL_VERSION = 5`) + blocks `wird-update` (contains the SW registration), `wird-update-css`, `wird-offline`, `wird-quran-font(-js)`.
* UI facts: tabs switch `.tab[data-view="view-habits"|"view-lessons"|…]`; habits root `#habitsRoot` is **re-rendered completely by `hRender()`**; quick-task rows
  `.hb-task[data-id^="o_"] > button.hb-c + span.hb-n[data-a=open]` (tapping the name currently does nothing); quick-task modal opened by `#hFab` (fields `#qn`, `#hok`);
  habit wizard `hWizard()` has 5 steps, step 2 = chips `#wt.hb-chips` (✅ عادية / ⏱ بالوقت / 🔢 بالكمية). Helpers callable from a new classic script: `hModal(html)`
  (overlay `.modal-overlay.open>.modal`, closes on backdrop tap only, no Esc/focus-trap), `showConfirm(title,msg,onConfirm)`, `showToast(msg)` (no action button),
  `hUid(prefix)`, `escapeHtml`, `toArabicNum`, `todayISO()`, `hSave()`, `hRender()`. Design tokens: `--gold --gold-soft --gold-bright --line --panel-raised --ink-dim --ink-faint --sage`;
  classes `.field-input .field-label .field-hint .hb-chips .btn .btn-primary .btn-ghost .btn-danger .panel-card .desc`.
* Lesson screen: `.ls-lesson-main > … + section.wr[data-lesson] + .ls-editor-wrap`; `section.wr` children `#wrHead` (rewritten by `renderHead()` — never append inside it or inside
  `.wr-foot`), `#wrTabs`, `#wrPanel`; anything inserted as a **sibling after `#wrHead` or `#wrTabs` survives** re-renders. Sidebar rows call `window.__wirdRow(row, el)` (wrappable).
  `__WIRD_STUDY_APP__.repo` is the public lesson-data API (`saveMistake`, `reseeMistake`, `setMistakeStatus`, `listMistakes`, `saveResource`…). `wirdResNorm` rejects unknown
  resource types. KaTeX is lazy (`typeof katex === 'undefined'` until a lesson editor loads it); an independent loader mirroring `ls-main` works in ~37 ms (assets
  `#ls-asset-katex`, `#ls-asset-mhchem`, `#ls-asset-katex-css`, style id `ls-katex-style`).
* Tests: Playwright 1.56 is installed globally (`NODE_PATH=$(npm root -g)`), Chromium 141 works; existing suites `tests/{update,offline,unified,resources,courses,perf}.test.js`.
* Preservation tooling (created in B1): `tools/audit/verify_preservation.py` (tiers FROZEN / GUARDED / APPEND-ONLY / NEW), `tools/audit/test_verify_preservation.py` (27 mutation cases),
  `tools/audit/probe_anchors.js` (live evidence probe), `docs/PRESERVATION-BASELINE.json` (frozen "before" state — never regenerate).
* Approved amendments A1–A8 (see `docs/ROADMAP.md`): module-owned settings sheets (A1); patch-free hooks by default via MutationObserver/delegation/`__wirdRow` wrapper (A2);
  no `quiz` resource type (A3); D7 (A4); O(1) observers because lesson `openMs` has only 33 ms of headroom (A5); Web Share fallback + `storage.persist()` (A6); bare `H`, IIFE modules (A7);
  verifier whitelist for new blocks `wird-tasks*`/`wird-quiz*` with forbidden-API scan (A8).
<!--/COMMON:CONTEXT-->

## 3. SESSION START — mandatory verification before any work

<!--COMMON:START-->
Before writing any code or file, in this order:
1. **Obtain the project.** The user uploads the latest checkpoint ZIP (folder `wird_work/`). Unzip it into a working folder. Work on that copy only.
2. **Read completely:** `MASTER-PLAN.md`, `PROJECT-STATUS.md`, `HANDOFF.md`, `CHANGELOG.md`, `docs/ROADMAP.md`, `BATCH-DEPENDENCY-MAP.md` (section for this batch), and the
   batch-specific documents named in §3. If `MASTER-PLAN.md`/`prompts/` are missing from the ZIP, ask the user for the prompt-package ZIP and copy its files to the project root
   (same relative paths) — do not proceed without them.
3. **Inspect the actual project state:** `python3 -I tools/audit/verify_preservation.py` must print `RESULT   PASS` (if an earlier batch had a user-approved guarded hook,
   HANDOFF.md records the exact `--allow-guarded` argument to use); `python3 -I tools/audit/test_verify_preservation.py` must print `27/27`.
4. **Verify the previous batch's deliverables really exist** using the checklist in §3 (files present, blocks present in `index.html`, tests run and pass). Run them — do not trust documents.
5. **Compare reality with the plan:** `PROJECT-STATUS.md`/`HANDOFF.md` vs the code vs `docs/ROADMAP.md`. Record every mismatch.
6. **Decide:** if everything matches → continue. If a prerequisite task is missing or broken → **STOP**, explain the blocking task, do NOT implement unrelated or predecessor work, and ask
   the user for approval to change the execution order. If this batch's tasks are already COMPLETED in `PROJECT-STATUS.md` → do not redo them: run VERIFY only and report.
7. **Authorization:** this prompt authorizes ONLY the tasks named in §4. Never start another task or the next batch. Bugs outside the scope are documented, not fixed (unless they block the
   current task — then explain and ask).
<!--/COMMON:START-->

### 3.1 Documents to read for this batch (in addition to those in the procedure above)

* `docs/ROADMAP.md` — the normative task cards (§4 embeds yours verbatim)
* `docs/INTEGRATION-SPIKES.md` — §c lesson content model and `wMathTok` rules, §d mistakes API, §f persistence
* `docs/MODULES.md`

### 3.2 Previous-batch deliverables to verify (run them; do not trust documents)

* B2 deliverables exist (injector, `wird-kit.js` with `openDb`/`ensureKatex`, `quiz-shell.js`, `docs/MODULES.md`); `index.html` contains the four blocks; verifier PASS; self-test 27/27.
* PROJECT-STATUS: 0.3 COMPLETED. (Phase 1 does not have to be finished: Phase 2 depends only on B2. If Phase 1 work is in progress elsewhere, you are on a separate working copy — see BATCH-DEPENDENCY-MAP.md.)
* Decision D4 (soft gate) read from MASTER-PLAN §8 / overrides. `grep -c 'wird_quiz_db' index.html` shows only the kit’s lazy opener string (no DB is created at load).

_File names mentioned in this prompt are conventions of the plan: if the previous batch chose different names, `HANDOFF.md` (sections "Completed work" and "Deviations") records them — use those._

## 4. AUTHORIZED SCOPE (exact)

**This batch authorizes: TASK 2.1 and TASK 2.2 — nothing else.** Goal: Define the versioned import format and its validator (pure logic) and the durable, additive storage and session state machine. No UI.

### 4.1 Task definitions (verbatim from `docs/ROADMAP.md`; do not reinterpret them)

<!--CARD:2.1-->
### TASK 2.1 — JSON schema, content spec, validator · M
- **Objective:** The versioned import format.
- **Scope:** Schema `wird.quiz/1`. Session fields: title, subject, lesson, source, instructions, questions. Question fields: id, type (the 14 types), number, stem, media, parts, options, input kind, optional answerKey (null = unavailable), explanation, solution, marks, topic, difficulty, gradingCriteria. The rich-text spec per **D4**, obeying the `wMathTok` rules. The validator returns structured Arabic errors and warnings with JSON paths; unknown fields are preserved, never fatal; unknown types are errors; media is never silently dropped; Markdown code fences from AI output are stripped with a warning. The answer-value serialization per type (identical in shape to the answerKey) is specified so widgets can be built independently.
- **Files/output:** `tools/src/quiz-schema.js`, fixtures for all types, `tests/quiz.schema.unit.test.js`, draft `docs/QUIZ-SCHEMA.md`.
- **Depends:** 0.3, 0.2.
- **Accept:** A valid fixture for every type; at least 25 invalid fixtures that give specific path errors; unknown fields survive.
- **Tests:** Node unit tests.
<!--/CARD:2.1-->

<!--CARD:2.2-->
### TASK 2.2 — Storage & session state machine · M
- **Objective:** Durable, additive persistence.
- **Scope:** New IDB `wird_quiz_db` v1 created lazily, with stores: sessions (full question snapshot, so later edits or deletes never alter history), answers (draft and submitted), images (blobs), gradings, reports, mistakes. State machine Prepared → In Progress ⇄ Paused → Ready for Review → Completed, with complete-once and no duplicate reports. Debounced draft autosave plus flush on `visibilitychange`/`pagehide`. Quota errors surfaced. `navigator.storage.persist()` requested [A6].
- **Files/output:** `tools/src/quiz-store.js`, tests.
- **Depends:** 2.1.
- **Accept:** Round trips work; images survive reload; completing twice yields one report; failed writes do not corrupt data; `wird_quiz_db` is not created until first use and no existing DB version changes.
- **Tests:** Playwright (IDB) plus Node logic tests.
<!--/CARD:2.2-->

Dependencies of these tasks: TASK 2.1 ← 0.3, 0.2; TASK 2.2 ← 2.1. Each dependency must be verified COMPLETED (§3) before you start; never assume.

## 5. IMPLEMENTATION REQUIREMENTS FOR THIS BATCH

**Schema `wird.quiz/1`** in `tools/src/quiz-schema.js` (dual-environment: Node `require` + `WirdQuiz.schema`). Define canonical type keys for the 14 required types and document them (suggested: `mcq_single`, `mcq_multi`, `true_false`, `short_text`, `long_text`, `numeric`, `math_expression`, `sci_problem`, `fill_blank`, `matching`, `ordering`, `multi_part`, `step_based`, plus media on any type via `media[]`). Session fields: title, subject, lesson, source (material info), instructions, questions. Question fields: id (stable, unique), type, number, stem (rich text), media[], parts[]/steps[], options[], input kind, optional answerKey (**null = unavailable**), explanation, solution, marks, topic, difficulty, gradingCriteria. Different shapes per type without forcing empty irrelevant fields.

**Rich-text spec (D4):** Markdown-style subset mapped to the existing lesson node types — `#`/`##`/`###` → heading 1–3, `-`/`1.` lists, blank-line paragraphs, pipe tables, `$…$` inline math, `$$…$$` block math, `\ce{}` chemistry, literal dollar `\$`; images/diagrams via `media[]` entries `{id, type:"image", src (data URI or null placeholder), alt, caption}` (simple diagrams may be given as an inline `data:image/svg+xml` URI). Obey the exact `wMathTok` rules documented in docs/INTEGRATION-SPIKES.md §c (inline `$` not adjacent to alphanumerics before/digits after, no whitespace just inside, content not purely numeric). Specify them in `docs/QUIZ-SCHEMA.md`.

**Answer-value serialization** (the same shape as `answerKey` per type) must be specified precisely in `docs/QUIZ-SCHEMA.md` because B9 (3.1) and B10 (3.2) implement widgets independently against it, and B12/B13 compare/display it.

**Validator:** returns `{ok, errors[], warnings[], session}` with errors as `{path, code, severity, message_ar}`; strips ```json fences with a warning; detects malformed JSON (position when available); unknown question types are ERRORS; unknown fields are preserved (kept under `extra`, never fatal); duplicate ids, missing options for choice types, answerKey shape mismatch, marks not numeric, media missing `src`, oversize payloads (documented limits) all produce path-specific errors; media and math are never dropped silently (warn when a `$` looks unbalanced). A media entry may be a **placeholder** (`src: null`, `alt` mandatory — an external AI cannot embed pixels of a figure): this is a WARNING ("image to attach"), never an error and never dropped. Arabic messages.

**Fixtures:** `tests/fixtures/quiz/valid-<type>.json` for every type plus a full-session fixture, and ≥ 25 invalid fixtures (each asserting the specific path/code).

**TASK 2.2 storage:** `tools/src/quiz-store.js`: IndexedDB `wird_quiz_db` v1 created lazily through the kit (`openDb`) with stores `sessions` (full question snapshot — later edits/deletes of an imported set never alter history), `answers` (draft vs submitted per question), `images` (Blob store keyed by id), `gradings`, `reports` (unique key = sessionId + attempt), `mistakes`. State machine Prepared → In Progress ⇄ Paused → Ready for Review → Completed with guards (`complete()` only once; no duplicate reports). Transactional writes; debounced draft autosave plus a flush on `visibilitychange`/`pagehide`; quota/blocked/aborted errors surfaced as typed errors, never swallowed; `navigator.storage.persist()` requested before the first image is stored (A6). Public API documented in `docs/QUIZ-SCHEMA.md` (or `docs/QUIZ-STORE.md`).

**Data safety:** the database is created ONLY on first quiz use; opening it must never touch other databases; `indexedDB.databases()` before/after must show existing DB names and versions unchanged.

## 6. FILES

**Expected to be created:**
* tools/src/quiz-schema.js
* tools/src/quiz-store.js
* tests/quiz.schema.unit.test.js
* tests/quiz.store.test.js
* tests/fixtures/quiz/*.json
* docs/QUIZ-SCHEMA.md (draft)
* docs/QUIZ-STORE.md
* docs/test-logs/B06/*

**Expected to be modified (and only these):**
* tools/src/quiz-shell.js (expose schema/store)
* index.html — only through the injector
* docs/MODULES.md (append)
* tracking docs

Anything else that changes is an undocumented change: list it, justify it, or revert it. Compare the final tree with the starting checkpoint by hash to prove the list is exact.

## 7. EXPLICIT EXCLUSIONS

**For this batch:**
* No UI, no prompt, no import screen (B8); no renderer (B7); no widgets (B9/B10); no solving flow (B11); no grading/report UI (B12+).
* No `quiz` resource type, no patch of the lesson bundle (D3).
* No manual question-creation UI; no network; no AI calls.

**Global:**

<!--COMMON:EXCLUSIONS-->
**Deferred — must NOT be implemented in any batch:** automatic AI recognition of task names; AI-generated task decomposition; keyword-triggered study templates; automatic AI coaching;
per-step mathematical scoring; continuous AI analysis; complicated reward systems (points, coins, competitive streaks); unnecessary new top-level navigation. Also not built:
manual question creation (not a priority), any `quiz` lesson resource type/tab (D3), any in-app server submission (D10), any change to the habit wizard unless the user approves D1(b).
**Optional features stay optional** (off or non-intrusive by default, configurable, persisted): task atomization itself; end-of-day prompt; skip step; edit during execution; timer;
progress indicator; completion sound; haptic feedback; micro-interactions; Mark for Review; Skip and Return; Previous Question; answer editing; the «اطلب تصحيح AI» workflow; mistake
categories; automatic revision suggestions. **Defaults are Minimal**: one step/question at a time, no score, no correctness feedback, no total-question counter, progress hidden.
<!--/COMMON:EXCLUSIONS-->

## 8. PRESERVATION CONSTRAINTS

<!--COMMON:PRESERVE-->
These rules apply to EVERY batch and override convenience:
* **Preserve the product.** No redesign of existing UI/UX, theme, colors, typography, icons, spacing, layouts, navigation or tabs; the app must stay visually and functionally identical
  outside the new, optional features. Do not modify unrelated features. New UI must use the existing design tokens/classes and feel native (RTL, Arabic).
* **Protected code (never edit):** `sw.js` (do NOT bump `SHELL_VERSION` — decision D6 is for the final batch only), the SW registration and the blocks `wird-update`, `wird-update-css`,
  `wird-offline`, `wird-quran-font`, `wird-quran-font-js`; every other existing `<script>/<style>` block of `index.html` (`ls-main`, `ls-css`, `ls-asset-*`, `courses-module`,
  `wird-learning-shim`, `wird-math-paste`, `wird-v33-*`, `wird-nb-recall*`, `wird-resources*`, `wird-unified*`, the pdf.js tag); `manifest.webmanifest`; icons; `tests/*` that already
  exist; `tools/orig`, `tools/phase2`, `tools/patch/{build,unify,bundle_patches,audit_blocks}.py`; existing docs (append-only, only in Task 5.3). **Guarded** (main inline script
  `script:#2`, main stylesheet `style:#0`, body markup): only through an exact-match hook that the USER approved, passed explicitly to the verifier with `--allow-guarded`.
* **Never run** `tools/patch/build.py`, `unify.py`, `bundle_patches.py` (they regenerate the old `sw.js`).
* **Protect user data.** Never delete, clear, recreate or migrate existing localStorage/IndexedDB data; never change versions of existing databases; write only to the new namespaces
  (`wird_tasks_v1`, `wird_taskprefs_v1`, `wird_quizprefs_v1`, IndexedDB `wird_quiz_db`, created lazily). Every record you add must be additive and backward compatible; edits/deletes of
  plans or imported question sets must never alter history. Never use `deleteDatabase`, `localStorage.clear`, `sessionStorage.clear`, `caches.*` or `serviceWorker` in new code.
* **Additive, isolated, reversible.** New code lives only in the new blocks (`wird-tasks-css`, `wird-tasks`, `wird-quiz-css`, `wird-quiz`, inserted by the injector from `tools/src/`) and new
  files. Hooks into existing screens are patch-free by default (MutationObserver with O(1) work per mutation, event delegation, `window.__wirdRow` wrapper, sibling insertion). Keep
  every observer cheap: lesson `openMs` is 767 ms vs a budget of 800 ms at CPU×4.
* **No external services:** no network calls, API keys, CDN additions or new dependencies (KaTeX is already embedded). Code must work offline.
* **Security:** build DOM with `createElement`/`textContent`; never inject imported or user-typed strings through `innerHTML` without escaping.
* **Honesty:** never claim a test passed unless you executed it in this session; never claim a ZIP exists unless you created and verified it; report untested scenarios explicitly.
* **No scope creep:** deferred features stay deferred (see the exclusion list); optional features stay optional.
<!--/COMMON:PRESERVE-->

## 9. DECISIONS (defaults in force)

<!--COMMON:DECISIONS-->
| ID | Topic | Default in force | Status | Gate | Needed by |
|---|---|---|---|---|---|
| D1 | Entry point of Task Atomization | (a). No 4th wizard chip: it would edit `hWizard` type logic in the guarded main script (`w.type` = b/time/qty drives routing, `meas()` and saving). | UNCONFIRMED (default in force) | SOFT | B3 |
| D2 | Meaning/location of "Add New Sheet" = anchor of the saved-prompt button | B. NOT confirmed by the user; no literal "Add New Sheet" control exists in the app. | UNCONFIRMED (default in force) | HARD | B8 |
| D3 | How quizzes appear inside a lesson | (a). Proven: `repo.saveResource({type:"quiz"})` is rejected ("Invalid resource"). | UNCONFIRMED (default in force) | SOFT | B8 |
| D4 | Rich-text format of quiz content | (a), obeying the `wMathTok` tokenizer rules. The brief assumed Markdown headings; the real lesson content is a JSON node tree. | UNCONFIRMED (default in force) | SOFT | B6 |
| D5 | Mistake tracking: pool, notebook integration, defaults | Separate pool + optional push through `repo.saveMistake` (needs a `lessonId`). Recording ON (passive, no popups); automatic revision suggestions OFF until enabled (threshold default 3 incorrect in one topic); status rule: correct once → improving, correct in two separate sessions → mastered; incorrect again → open and recurrence +1. | UNCONFIRMED (default in force) | SOFT | B14 |
| D6 | `sw.js` SHELL_VERSION bump at release | (a) until B17. The brief forbids modifying sw.js; the update guide says users still get updates through index.html change detection when the number is not bumped. | UNCONFIRMED (default in force) | HARD | B17 |
| D7 | Future-day plans storage | (a). No writes to `wird_habits_v1` for other days. | UNCONFIRMED (default in force) | SOFT | B2 |
| D8 | Link targets of a step plan | (a). Habits are recurring; atomizing them is not requested explicitly. | UNCONFIRMED (default in force) | SOFT | B3 |
| D9 | Scoring rules of the session report | Partial = 50 % of the question marks unless the user types awarded marks. If some questions have marks and others do not: the weighted score covers only the questions that have marks and the rest are listed separately ("بدون درجات"); with no marks at all every question weighs 1. Mastery % is shown only when no question is Awaiting Grading or Needs Review; otherwise show the graded-only score with its denominator, never labelled mastery. Unanswered counts as 0 once graded Unanswered. | UNCONFIRMED (default in force) | SOFT | B13 |
| D10 | Meaning of "submit the answers to a teacher" | (a). No backend exists and external services are excluded by the brief. | UNCONFIRMED (default in force) | SOFT | B13 |
| D11 | Location of settings (no global settings screen exists) | (a). | UNCONFIRMED (default in force) | SOFT | B5 |

**Rules.** (a) A line under "USER DECISION OVERRIDES" at the top of this prompt, or an explicit instruction from the user in this conversation, overrides the default; record it in `MASTER-PLAN.md` (Decision Register + Change log) at the end of the batch. (b) **HARD gate** (D2 before B8, D6 before B17): if the decision is still UNCONFIRMED when the dependent batch starts, STOP before implementing and ask the user to choose. (c) **SOFT gate**: proceed with the documented default, label it "ASSUMED DEFAULT" in code comments, docs and the final report, and ask the user to confirm. (d) Never invent a new decision silently: if you meet an unplanned ambiguity, pick the most conservative/preserving option, document it in HANDOFF.md and ask. Full option text: `MASTER-PLAN.md` §8.

Interpretations in force: **I1** The saved prompt is built into the app as a versioned constant (one-tap viewer + copy). It is not user-editable (editing was not requested). **I2** The brief lists three screenshots in a different order than the files received; they were identified by content: wizard step 1, wizard step 2, lesson page. Annotation marks (arrow on the lesson screenshot, circle in wizard step 2) are interpreted as in D1/D2 and are not treated as requirements. **I3** Undo window default is an implementation constant (suggested 8 s, adjustable) because the brief only says "brief". **I4** No automatic opening of the execution screen at app start; resume is offered through the planner/row actions (the brief requires exact resume but not auto-open). **I5** Real-device behaviour (Android Brave, camera capture, on-screen keyboard, installed PWA) cannot be tested in the container; it must be reported as NOT TESTED and listed for the user to try on a phone.
<!--/COMMON:DECISIONS-->

## 10. REQUIREMENTS COVERED BY THIS BATCH (from `MASTER-PLAN.md` §6; full register there)

**Implemented here (28):**
* **Q-06** [MANDATORY] Import supports pasting JSON, importing a JSON file, validation, a preview of the generated session, malformed-JSON detection, useful validation errors, and prevents invalid data from entering an active session.
* **Q-10** [MANDATORY] Imported content follows the existing Wird content framework (heading hierarchy, math, tables, media) rather than an invented formatting language (decision D4).
* **QT-01** [MANDATORY] Question type 1 must be supported in the first release: Single-choice MCQ (schema in 2.1, rendering in 2.3, answer widget in 3.1).
* **QT-02** [MANDATORY] Question type 2 must be supported in the first release: Multiple-select MCQ (schema in 2.1, rendering in 2.3, answer widget in 3.1).
* **QT-03** [MANDATORY] Question type 3 must be supported in the first release: True/False (schema in 2.1, rendering in 2.3, answer widget in 3.1).
* **QT-04** [MANDATORY] Question type 4 must be supported in the first release: Short text answers (schema in 2.1, rendering in 2.3, answer widget in 3.2).
* **QT-05** [MANDATORY] Question type 5 must be supported in the first release: Long written/essay answers (schema in 2.1, rendering in 2.3, answer widget in 3.2).
* **QT-06** [MANDATORY] Question type 6 must be supported in the first release: Numerical answers (schema in 2.1, rendering in 2.3, answer widget in 3.2).
* **QT-07** [MANDATORY] Question type 7 must be supported in the first release: Mathematical expressions and equations (schema in 2.1, rendering in 2.3, answer widget in 3.2).
* **QT-08** [MANDATORY] Question type 8 must be supported in the first release: Physics and chemistry problems (schema in 2.1, rendering in 2.3, answer widget in 3.2).
* **QT-09** [MANDATORY] Question type 9 must be supported in the first release: Fill in the blanks (schema in 2.1, rendering in 2.3, answer widget in 3.1).
* **QT-10** [MANDATORY] Question type 10 must be supported in the first release: Matching (schema in 2.1, rendering in 2.3, answer widget in 3.1).
* **QT-11** [MANDATORY] Question type 11 must be supported in the first release: Ordering and sequencing (schema in 2.1, rendering in 2.3, answer widget in 3.1).
* **QT-12** [MANDATORY] Question type 12 must be supported in the first release: Multi-part questions (schema in 2.1, rendering in 2.3, answer widget in 3.2).
* **QT-13** [MANDATORY] Question type 13 must be supported in the first release: Step-based problem statements (schema in 2.1, rendering in 2.3, answer widget in 3.2).
* **QT-14** [MANDATORY] Question type 14 must be supported in the first release: Questions containing images, diagrams or tables (schema in 2.1, rendering in 2.3, answer widget in 2.3/3.2).
* **QA-04** [MANDATORY] Image attachments persist reliably across application reloads.
* **S-01** [MANDATORY] Sessions survive interruptions: automatic saving, pause and resume, closing and reopening the application, returning after the phone is restarted.
* **S-02** [MANDATORY] Preserve the current question, previously submitted answers, unfinished input and attached images.
* **S-03** [MANDATORY] A session completes only once; duplicate reports are prevented.
* **S-04** [MANDATORY] Session states: Prepared, In Progress, Paused, Ready for Review, Completed; an unfinished session can be resumed without losing work.
* **M-03** [MANDATORY] The architecture stays extensible so detailed step-by-step marking can be added later (reserved `stepMarks`, not built).
* **D-02** [MANDATORY] Separate clearly named structures for task plans, day groups, task steps, task execution state, persistent preferences, imported quiz sessions, questions, submitted answers, attached answer images, grading records, session reports and mistake records.
* **D-03** [MANDATORY] Stable IDs; historical sessions are preserved when a task or imported question set is edited or deleted; no destructive updates.
* **D-04** [MANDATORY] A versioned, validated JSON import format supporting at least: session title, subject, lesson, source material info, instructions, questions, question IDs/types, rich content, media attachments, answer input type, options, optional answer key, explanation, solution, marks, topic, difficulty and grading criteria.
* **D-05** [MANDATORY] The format supports different question structures without forcing empty irrelevant fields.
* **D-06** [MANDATORY] Unknown fields never corrupt an import; invalid question types produce clear validation errors.
* **D-07** [MANDATORY] The application never silently discards media or mathematical notation.

**Verified here, implemented elsewhere (IDs):** (none)

**Cross-cutting constraints that apply to every batch:** PRES-01…PRES-07, PROC-01…PROC-05, TS-04.

## 11. VERIFICATION

**Acceptance criteria (all must be met by executed checks):**
* TASK 2.1: a valid fixture for every one of the 14 types; ≥ 25 invalid fixtures with specific path errors; unknown fields survive; fences stripped with a warning.
* TASK 2.2: round trips; images survive reload; completing twice yields one report; failed writes do not corrupt data; `wird_quiz_db` is not created until first use and no existing DB version changes.
* The answer-value serialization is fully specified in the schema doc.
* Existing suites at baseline; verifier PASS.

**Required tests**
* **Unit:** `tests/quiz.schema.unit.test.js` (Node): all fixtures; error paths/codes; fence stripping; malformed JSON; unknown fields preserved; id uniqueness; per-type answerKey shapes; `wMathTok`-rule warnings.
* **Integration:** `tests/quiz.store.test.js` (Playwright, real IndexedDB): lazy creation; store round trips; image Blob round trip across page reload and a persistent-context restart; state machine illegal transitions rejected; complete twice → one report; simulated abort/quota error → typed error and no partial record; `indexedDB.databases()` snapshot before/after.
* **Regression:** Six existing suites on a scratch copy at baseline; verifier PASS; seeded-old-data unchanged; perf budget.
* **Mobile / RTL:** Not applicable (no UI) — state it.

**Test protocol (common):**

<!--COMMON:TESTING-->
* **Where to run:** copy the project to a scratch folder (`cp -r wird_work /tmp/scratch_Bxx`) and run the existing suites there, in the **foreground**, one per command, e.g.
  `cd /tmp/scratch_Bxx/wird_work && NODE_PATH=$(npm root -g) node tests/update.test.js; echo exit=$?`. (A background runner was killed between tool calls in B1.) Save logs under
  `docs/test-logs/<batch>/`. New tests you write go in `tests/` (new files only) and must also pass from the scratch copy.
* **Baseline to compare with (B1, untouched app):** update 64/64 · offline 1/1 · unified 12/12 · resources 34/34 · courses 32/32 (test 18 «أوفلاين أثناء جلب البيانات» is flaky — if it
  fails, re-run once and report BOTH runs; do not call it a regression unless it fails twice) · perf within budget (openMs CPU×4 = 767 vs 800). Any other deviation = regression → fix
  within the batch scope or STOP and report.
* **Always run:** `python3 -I tools/audit/verify_preservation.py` (PASS required; NEW blocks/files are expected, FAIL/GUARDED without approval are not) and
  `python3 -I tools/audit/test_verify_preservation.py` (27/27) at the start and at the end.
* **Test layers:** unit tests (Node, pure logic) · integration tests (Playwright against the real `index.html`, `serviceWorkers:'block'`, external network aborted, locale `ar-EG`) ·
  regression (existing suites + seeded-old-data checks: seed realistic `wird_habits_v1`/study data, load, assert deep-equal unchanged) · for every UI task also **mobile and RTL
  checks**: viewports 360×640, 390×844, 412×915; `document.documentElement.scrollWidth <= innerWidth` (no horizontal overflow); interactive targets ≥ 44×44 CSS px via `boundingBox()`;
  Arabic text and mixed Arabic/English rendering; no console errors (`pageerror`); `prefers-reduced-motion` honoured for animations.
* **Honest reporting:** list every test as EXECUTED (with command, count, pass/fail, log path) or NOT EXECUTED (with reason). Real-device behaviour (Android/Brave, camera, on-screen keyboard,
  installed PWA) cannot be tested here — list it as NOT TESTED and give the user a short manual checklist. Do not write "should work"; write what was run.
* **IMPLEMENTED ≠ TESTED ≠ VERIFIED.** A task is COMPLETED only when every acceptance criterion in §4/§11 is met by an executed check.
<!--/COMMON:TESTING-->

## 12. PARALLELISM AND SHARED FILES

B6 may run in parallel with the Phase-1 chain (B3–B5) in a separate working copy (shared risk: `index.html`, regenerated by the injector; `tools/src/wird-kit.js` must not be edited by both — B6 only consumes it; if B6 needs a kit change, document it and coordinate). Inside Phase 2: B7 needs 2.1 from this batch, so B6 → B7 is sequential.

Graph and merge rules for the whole plan: `BATCH-DEPENDENCY-MAP.md`.

## 13. END-OF-BATCH HANDOFF

<!--COMMON:HANDOFF-->
At the end of the batch (do not skip, do not postpone):
1. Run the verifier and its self-test once more; run the regression suites required in §11; save logs.
2. **Update `MASTER-PLAN.md` only if necessary** (a user decision was confirmed, an approved clarification changed the plan): edit the Decision Register / add a dated entry to its
   "Change log". Never silently change requirements.
3. **Update `PROJECT-STATUS.md`:** task table (status + implemented / tested / verified columns + completion date), batch table, test status, files created/modified, known issues.
4. **Update `HANDOFF.md`:** all nine sections reflect the exact state — completed work with decisions and tests, working state, **the exact file names you created (so the next batch can
   find them), any deviation from this pre-generated prompt, user decisions still unconfirmed**, next tasks, warnings. The two status documents must agree.
5. **Update `CHANGELOG.md`:** one entry for this batch listing every file created / modified / deleted and the tests run. No undocumented change may exist: compare the final tree with the
   checkpoint you started from (hash diff) and make the list exact.
6. **Create the checkpoint ZIP** `wird_work_<Bxx>_checkpoint.zip` (top-level folder `wird_work/`; exclude `__pycache__` and `*.pyc`), then verify it: `unzip -t`, re-extract to a temp folder, run the verifier + self-test +
   one smoke suite there, compare the original 35 files byte-for-byte with the upload. Report its SHA-256. Never claim a ZIP you did not create and verify.
7. **Do not write a new next-batch prompt** — all prompts already exist in `prompts/`. Confirm that `prompts/<next>-EXECUTION-PROMPT.md` exists and say which decisions/names from your
   HANDOFF the next session must use. If you changed anything the next prompt assumes, record it in HANDOFF.md under "Deviations".
8. Present the final report (format in §14) and **STOP**. Never start the next batch; wait for the user's explicit approval.
<!--/COMMON:HANDOFF-->

**Batch-specific handoff content:**
* HANDOFF.md: final type keys, answer-value shapes, validator API, store API, fixture list, any change requested for `wird-kit.js`.

## 14. FINAL REPORT FORMAT

<!--COMMON:REPORT-->
Final report to the user (in this order, no omissions):
1. **Summary** — tasks executed, final status of each (NOT STARTED / IN PROGRESS / COMPLETED / BLOCKED / NEEDS VERIFICATION) with implemented / tested / verified.
2. **Files** — table of every file created / modified / deleted with the reason (must match CHANGELOG.md). State explicitly: "existing files modified: none" or list them with the approved hook.
3. **Tests** — table EXECUTED vs NOT EXECUTED: command, counts, pass/fail, log path; regression results against the baseline; mobile/RTL checks where relevant.
4. **Preservation confirmation** — verifier output; confirmation that the original 35 files (or the approved guarded hooks) are unchanged; confirmation no existing data store was touched.
5. **Decisions** — every default you used labelled "ASSUMED DEFAULT (Dn)", and the questions the user must answer next (only real blockers).
6. **Issues** — defects found, impact, and whether fixed (only if in scope) or documented.
7. **Checkpoint ZIP** — name, SHA-256, how it was verified.
8. **Next** — next batch id and prompt file; wait for approval.
<!--/COMMON:REPORT-->

## 15. NEXT BATCH

Next: **B07** — file `prompts/B07-EXECUTION-PROMPT.md` (tasks: TASK 2.3). **Do not start it.** Wait for the user’s explicit approval, then the user will open a new conversation with that prompt.
