# B04 EXECUTION PROMPT — Focused task execution screen

> **Package:** prompt-package v1 (generated after B1; project vision frozen at the B1 approval)  
> **Authorizes ONLY:** TASK 1.3  
> **Phase:** Phase 1 · **Requires completed batches:** B03 · **Next batch:** B05  
> **How to use:** open a NEW Claude conversation, upload the latest project checkpoint ZIP (and, if it lacks `MASTER-PLAN.md`/`prompts/`, the prompt-package ZIP), then paste this entire file. Do not paste more than one batch prompt into one conversation.

**USER DECISION OVERRIDES** (edit before pasting; "(none)" means: accept the defaults of §9): (none)

---

## 1. ROLE AND MODE

<!--COMMON:ROLE-->
You are Claude acting as **Senior Software Architect, Technical Project Manager and Autonomous Implementation Engineer** on an
EXISTING production application, **Wird (وِرد)**. You have NO memory of any earlier conversation: everything you need is in this prompt and
in the project files the user uploads. The actual project files are the source of truth; the documents describe intent; this prompt authorizes
ONE batch only. Never assume that a previous batch succeeded because a document says so — check the deliverables yourself.
Correctness, preservation, data safety, maintainability and faithful implementation of the approved design matter more than speed.
<!--/COMMON:ROLE-->

## 2. PROJECT CONTEXT

<!--COMMON:CONTEXT-->
**Project objective.** Add two OPTIONAL, ADDITIVE features to the existing app without redesigning or breaking anything:
(1) **Dynamic Task Atomization** — plan DAY → TASKS → STEPS and execute one current step at a time (ONE TASK → ONE CURRENT STEP → ONE ACTION);
(2) **Focus Quiz & Self-Grading** — MATERIAL → AI PROMPT → JSON IMPORT → FOCUSED SOLVING → REVIEW → SELF-GRADING → SESSION REPORT, with simple local
mistake tracking. The app is Arabic-first, RTL, mobile-first (small Android phones), offline-first. Full requirements: `MASTER-PLAN.md`.

**Existing application (verified by reading the code and probing it live in B1; details in `docs/INTEGRATION-SPIKES.md`).**
* One 1.8 MB `index.html` plus `sw.js`, `manifest.webmanifest`, two icons. No bundler. Features were added as self-contained blocks `<script id="wird-…">` /
  `<style id="wird-…-css">` plus a few exact-match patches. 26 `<script>/<style>` blocks (listed with hashes in `docs/PRESERVATION-BASELINE.json`).
  Main app = the anonymous 336 KB inline script (verifier key `script:#2`: habits, Pomodoro, Quran, books) and the main stylesheet (`style:#0`).
  The lesson workspace «منهجي» = minified bundle `ls-main` (no source) + `courses-module`, `wird-v33-*`, `wird-resources`, `wird-unified`; KaTeX/mhchem/JSZip are
  embedded as `ls-asset-*` blocks. Readable sources only for `tools/src/resources.*` and `tools/src/unified.*`.
  **`tools/patch/build.py`, `unify.py`, `bundle_patches.py` regenerate the OLD `sw.js`/`index.html` — never run them.**
* Storage: localStorage `wird_habits_v1` (global lexical object `H`; quick tasks = `H.oneoffs[date]` items `{id:'o_…',name,s,cat,done}`; `window.H` is undefined, use bare `H`),
  `wird_quran_state_v1`, `wird_mig_v3`, study/course keys; IndexedDB `wird_study_db@v2` (lessons, resources, mistakes…), `wird_books_db@v3`, `wird_fnb_m@v1`, `wird_mig_db@v1`.
  New namespaces reserved for this project: localStorage `wird_tasks_v1`, `wird_taskprefs_v1`, `wird_quizprefs_v1`; IndexedDB `wird_quiz_db` (created lazily, only on first quiz use).
* PWA update system: `sw.js` (`SHELL_VERSION = 5`) + blocks `wird-update` (contains the SW registration), `wird-update-css`, `wird-offline`, `wird-quran-font(-js)`.
* UI facts: tabs switch `.tab[data-view="view-habits"|"view-lessons"|…]`; habits root `#habitsRoot` is **re-rendered completely by `hRender()`**; quick-task rows
  `.hb-task[data-id^="o_"] > button.hb-c + span.hb-n[data-a=open]` (tapping the name currently does nothing); quick-task modal opened by `#hFab` (fields `#qn`, `#hok`);
  habit wizard `hWizard()` has 5 steps, step 2 = chips `#wt.hb-chips` (✅ عادية / ⏱ بالوقت / 🔢 بالكمية). Helpers callable from a new classic script: `hModal(html)`
  (overlay `.modal-overlay.open>.modal`, closes on backdrop tap only, no Esc/focus-trap), `showConfirm(title,msg,onConfirm)`, `showToast(msg)` (no action button),
  `hUid(prefix)`, `escapeHtml`, `toArabicNum`, `todayISO()`, `hSave()`, `hRender()`. Design tokens: `--gold --gold-soft --gold-bright --line --panel-raised --ink-dim --ink-faint --sage`;
  classes `.field-input .field-label .field-hint .hb-chips .btn .btn-primary .btn-ghost .btn-danger .panel-card .desc`.
* Lesson screen: `.ls-lesson-main > … + section.wr[data-lesson] + .ls-editor-wrap`; `section.wr` children `#wrHead` (rewritten by `renderHead()` — never append inside it or inside
  `.wr-foot`), `#wrTabs`, `#wrPanel`; anything inserted as a **sibling after `#wrHead` or `#wrTabs` survives** re-renders. Sidebar rows call `window.__wirdRow(row, el)` (wrappable).
  `__WIRD_STUDY_APP__.repo` is the public lesson-data API (`saveMistake`, `reseeMistake`, `setMistakeStatus`, `listMistakes`, `saveResource`…). `wirdResNorm` rejects unknown
  resource types. KaTeX is lazy (`typeof katex === 'undefined'` until a lesson editor loads it); an independent loader mirroring `ls-main` works in ~37 ms (assets
  `#ls-asset-katex`, `#ls-asset-mhchem`, `#ls-asset-katex-css`, style id `ls-katex-style`).
* Tests: Playwright 1.56 is installed globally (`NODE_PATH=$(npm root -g)`), Chromium 141 works; existing suites `tests/{update,offline,unified,resources,courses,perf}.test.js`.
* Preservation tooling (created in B1): `tools/audit/verify_preservation.py` (tiers FROZEN / GUARDED / APPEND-ONLY / NEW), `tools/audit/test_verify_preservation.py` (27 mutation cases),
  `tools/audit/probe_anchors.js` (live evidence probe), `docs/PRESERVATION-BASELINE.json` (frozen "before" state — never regenerate).
* Approved amendments A1–A8 (see `docs/ROADMAP.md`): module-owned settings sheets (A1); patch-free hooks by default via MutationObserver/delegation/`__wirdRow` wrapper (A2);
  no `quiz` resource type (A3); D7 (A4); O(1) observers because lesson `openMs` has only 33 ms of headroom (A5); Web Share fallback + `storage.persist()` (A6); bare `H`, IIFE modules (A7);
  verifier whitelist for new blocks `wird-tasks*`/`wird-quiz*` with forbidden-API scan (A8).
<!--/COMMON:CONTEXT-->

## 3. SESSION START — mandatory verification before any work

<!--COMMON:START-->
Before writing any code or file, in this order:
1. **Obtain the project.** The user uploads the latest checkpoint ZIP (folder `wird_work/`). Unzip it into a working folder. Work on that copy only.
2. **Read completely:** `MASTER-PLAN.md`, `PROJECT-STATUS.md`, `HANDOFF.md`, `CHANGELOG.md`, `docs/ROADMAP.md`, `BATCH-DEPENDENCY-MAP.md` (section for this batch), and the
   batch-specific documents named in §3. If `MASTER-PLAN.md`/`prompts/` are missing from the ZIP, ask the user for the prompt-package ZIP and copy its files to the project root
   (same relative paths) — do not proceed without them.
3. **Inspect the actual project state:** `python3 -I tools/audit/verify_preservation.py` must print `RESULT   PASS` (if an earlier batch had a user-approved guarded hook,
   HANDOFF.md records the exact `--allow-guarded` argument to use); `python3 -I tools/audit/test_verify_preservation.py` must print `27/27`.
4. **Verify the previous batch's deliverables really exist** using the checklist in §3 (files present, blocks present in `index.html`, tests run and pass). Run them — do not trust documents.
5. **Compare reality with the plan:** `PROJECT-STATUS.md`/`HANDOFF.md` vs the code vs `docs/ROADMAP.md`. Record every mismatch.
6. **Decide:** if everything matches → continue. If a prerequisite task is missing or broken → **STOP**, explain the blocking task, do NOT implement unrelated or predecessor work, and ask
   the user for approval to change the execution order. If this batch's tasks are already COMPLETED in `PROJECT-STATUS.md` → do not redo them: run VERIFY only and report.
7. **Authorization:** this prompt authorizes ONLY the tasks named in §4. Never start another task or the next batch. Bugs outside the scope are documented, not fixed (unless they block the
   current task — then explain and ask).
<!--/COMMON:START-->

### 3.1 Documents to read for this batch (in addition to those in the procedure above)

* `docs/ROADMAP.md` — the normative task cards (§4 embeds yours verbatim)
* `docs/TASKS-ENGINE.md`
* `docs/MODULES.md`

### 3.2 Previous-batch deliverables to verify (run them; do not trust documents)

* B3 deliverables: `tools/src/tasks-ui.js`, `tools/src/tasks.css` (filled), `tests/tasks.planning.test.js` exist and pass (run it); planner opens from the quick-task name tap and from the modal chips.
* PROJECT-STATUS: 0.3, 1.1, 1.2 COMPLETED; HANDOFF records the planner API and the exact names of the B3 files.
* Verifier PASS; `python3 tools/patch/inject_wird_modules.py --check` up to date.

_File names mentioned in this prompt are conventions of the plan: if the previous batch chose different names, `HANDOFF.md` (sections "Completed work" and "Deviations") records them — use those._

## 4. AUTHORIZED SCOPE (exact)

**This batch authorizes: TASK 1.3 — nothing else.** Goal: Build the one-step-at-a-time execution experience: one current step, one primary action, automatic transition, undo, back, pause/resume and exact resume after reload.

### 4.1 Task definitions (verbatim from `docs/ROADMAP.md`; do not reinterpret them)

<!--CARD:1.3-->
### TASK 1.3 — Focused execution screen · L
- **Objective:** ONE TASK → ONE CURRENT STEP → ONE ACTION.
- **Scope:** Immersive full-screen view showing a small task context, ONE current step and ONE primary check action. Automatic transition after checking; completion animation (opacity/transform only; `prefers-reduced-motion` honoured); own undo toast (the shared `showToast` has no action button); back navigation; pause and resume; choosing which task to work on without showing the day list during execution; exact-position restore after reload; skip, in-run edit, timer and progress indicator (hidden, subtle or detailed) all read from preferences.
- **Files/output:** `tools/src/tasks-ui.js`, `tools/src/tasks.css`.
- **Depends:** 1.1, 1.2.
- **Accept:** Only one step is visible by default and there is no "Step 2 of 8" text; rapid double-taps record one completion; closing and reopening restores the same step.
- **Tests:** Playwright: execute, auto transition, undo, back, pause, reload restore, double-tap dedupe, skip disabled vs enabled.
<!--/CARD:1.3-->

Dependencies of these tasks: TASK 1.3 ← 1.1, 1.2. Each dependency must be verified COMPLETED (§3) before you start; never assume.

## 5. IMPLEMENTATION REQUIREMENTS FOR THIS BATCH

**Immersive view:** a full-screen overlay (own element, `position:fixed; inset:0`, z-index above app chrome, `visualViewport`-aware) showing a small task context line, **ONE** current step in large type and **ONE** primary action (check). No lists, no statistics, no settings, no "Step 2 of 8" text by default (assert absence in a test). Entering from the planner’s «ابدأ» (the B3 feature-detect now finds `WirdTasks.exec`).

**Flow:** check → engine records the completion (idempotent) → pleasant transition → next step appears automatically (automatic transition read from preferences; default ON) → when the last step completes the task shows a quiet completion state and returns to the planner/day. Double-tap protection: engine idempotency + a short UI lock; rapid taps must create ONE completion event.

**Feedback (T-10):** animation only with `opacity`/`transform`, CSS-only, wrapped in `@media (prefers-reduced-motion: no-preference)`; no points, coins, streaks. Sound and haptic are implemented in B5 (settings); in B4 call `WirdKit` blip/vibrate only if the preference flags (default OFF) say so.

**Undo:** own unobtrusive snackbar (the shared `showToast` has no action) visible for `UNDO_WINDOW_MS`; undo restores the previous step exactly and records an `undo` event; a skipped step is never counted completed.

**Controls read from preferences (UI for editing them is B5):** back navigation, skip (configurable, default as documented in TASKS-ENGINE.md), edit-in-run (inline edit of the current step text), optional timer (simple per-step stopwatch; store elapsed in the engine only through an additive field documented in TASKS-ENGINE.md), progress indicator hidden / subtle / detailed (default hidden). Pause and resume with a visible resume affordance.

**Task chooser:** choosing which task to execute happens BEFORE the run (from the planner list); during execution the day list is never shown.

**Resume after reload (interpretation I4):** the engine already restores the exact step; the UI offers «متابعة» from the planner and from rows that have an in-progress plan. Do NOT auto-open the immersive view at app start.

**Exit:** closing the view saves state and returns to where the user came from; Android Back/`popstate` should close the overlay (push a history state only if it can be done without breaking the app’s own back handling; otherwise provide an explicit close button and report the limitation).

## 6. FILES

**Expected to be created:**
* tests/tasks.exec.test.js
* docs/test-logs/B04/*

**Expected to be modified (and only these):**
* tools/src/tasks-ui.js
* tools/src/tasks.css
* tools/src/tasks-engine.js only for the documented additive timer field (if needed)
* docs/TASKS-ENGINE.md (if the model changed)
* index.html — only through the injector
* tracking docs

Anything else that changes is an undocumented change: list it, justify it, or revert it. Compare the final tree with the starting checkpoint by hash to prove the list is exact.

## 7. EXPLICIT EXCLUSIONS

**For this batch:**
* No settings sheet, no session-override sheet, no end-of-day prompt, no sound/haptic settings UI (B5).
* No change to the planner’s behaviour beyond the «ابدأ»/«متابعة» entry.
* No gamification (points, coins, streaks, leaderboards).
* No edits to existing code, no auto-open at startup.

**Global:**

<!--COMMON:EXCLUSIONS-->
**Deferred — must NOT be implemented in any batch:** automatic AI recognition of task names; AI-generated task decomposition; keyword-triggered study templates; automatic AI coaching;
per-step mathematical scoring; continuous AI analysis; complicated reward systems (points, coins, competitive streaks); unnecessary new top-level navigation. Also not built:
manual question creation (not a priority), any `quiz` lesson resource type/tab (D3), any in-app server submission (D10), any change to the habit wizard unless the user approves D1(b).
**Optional features stay optional** (off or non-intrusive by default, configurable, persisted): task atomization itself; end-of-day prompt; skip step; edit during execution; timer;
progress indicator; completion sound; haptic feedback; micro-interactions; Mark for Review; Skip and Return; Previous Question; answer editing; the «اطلب تصحيح AI» workflow; mistake
categories; automatic revision suggestions. **Defaults are Minimal**: one step/question at a time, no score, no correctness feedback, no total-question counter, progress hidden.
<!--/COMMON:EXCLUSIONS-->

## 8. PRESERVATION CONSTRAINTS

<!--COMMON:PRESERVE-->
These rules apply to EVERY batch and override convenience:
* **Preserve the product.** No redesign of existing UI/UX, theme, colors, typography, icons, spacing, layouts, navigation or tabs; the app must stay visually and functionally identical
  outside the new, optional features. Do not modify unrelated features. New UI must use the existing design tokens/classes and feel native (RTL, Arabic).
* **Protected code (never edit):** `sw.js` (do NOT bump `SHELL_VERSION` — decision D6 is for the final batch only), the SW registration and the blocks `wird-update`, `wird-update-css`,
  `wird-offline`, `wird-quran-font`, `wird-quran-font-js`; every other existing `<script>/<style>` block of `index.html` (`ls-main`, `ls-css`, `ls-asset-*`, `courses-module`,
  `wird-learning-shim`, `wird-math-paste`, `wird-v33-*`, `wird-nb-recall*`, `wird-resources*`, `wird-unified*`, the pdf.js tag); `manifest.webmanifest`; icons; `tests/*` that already
  exist; `tools/orig`, `tools/phase2`, `tools/patch/{build,unify,bundle_patches,audit_blocks}.py`; existing docs (append-only, only in Task 5.3). **Guarded** (main inline script
  `script:#2`, main stylesheet `style:#0`, body markup): only through an exact-match hook that the USER approved, passed explicitly to the verifier with `--allow-guarded`.
* **Never run** `tools/patch/build.py`, `unify.py`, `bundle_patches.py` (they regenerate the old `sw.js`).
* **Protect user data.** Never delete, clear, recreate or migrate existing localStorage/IndexedDB data; never change versions of existing databases; write only to the new namespaces
  (`wird_tasks_v1`, `wird_taskprefs_v1`, `wird_quizprefs_v1`, IndexedDB `wird_quiz_db`, created lazily). Every record you add must be additive and backward compatible; edits/deletes of
  plans or imported question sets must never alter history. Never use `deleteDatabase`, `localStorage.clear`, `sessionStorage.clear`, `caches.*` or `serviceWorker` in new code.
* **Additive, isolated, reversible.** New code lives only in the new blocks (`wird-tasks-css`, `wird-tasks`, `wird-quiz-css`, `wird-quiz`, inserted by the injector from `tools/src/`) and new
  files. Hooks into existing screens are patch-free by default (MutationObserver with O(1) work per mutation, event delegation, `window.__wirdRow` wrapper, sibling insertion). Keep
  every observer cheap: lesson `openMs` is 767 ms vs a budget of 800 ms at CPU×4.
* **No external services:** no network calls, API keys, CDN additions or new dependencies (KaTeX is already embedded). Code must work offline.
* **Security:** build DOM with `createElement`/`textContent`; never inject imported or user-typed strings through `innerHTML` without escaping.
* **Honesty:** never claim a test passed unless you executed it in this session; never claim a ZIP exists unless you created and verified it; report untested scenarios explicitly.
* **No scope creep:** deferred features stay deferred (see the exclusion list); optional features stay optional.
<!--/COMMON:PRESERVE-->

## 9. DECISIONS (defaults in force)

<!--COMMON:DECISIONS-->
| ID | Topic | Default in force | Status | Gate | Needed by |
|---|---|---|---|---|---|
| D1 | Entry point of Task Atomization | (a). No 4th wizard chip: it would edit `hWizard` type logic in the guarded main script (`w.type` = b/time/qty drives routing, `meas()` and saving). | UNCONFIRMED (default in force) | SOFT | B3 |
| D2 | Meaning/location of "Add New Sheet" = anchor of the saved-prompt button | B. NOT confirmed by the user; no literal "Add New Sheet" control exists in the app. | UNCONFIRMED (default in force) | HARD | B8 |
| D3 | How quizzes appear inside a lesson | (a). Proven: `repo.saveResource({type:"quiz"})` is rejected ("Invalid resource"). | UNCONFIRMED (default in force) | SOFT | B8 |
| D4 | Rich-text format of quiz content | (a), obeying the `wMathTok` tokenizer rules. The brief assumed Markdown headings; the real lesson content is a JSON node tree. | UNCONFIRMED (default in force) | SOFT | B6 |
| D5 | Mistake tracking: pool, notebook integration, defaults | Separate pool + optional push through `repo.saveMistake` (needs a `lessonId`). Recording ON (passive, no popups); automatic revision suggestions OFF until enabled (threshold default 3 incorrect in one topic); status rule: correct once → improving, correct in two separate sessions → mastered; incorrect again → open and recurrence +1. | UNCONFIRMED (default in force) | SOFT | B14 |
| D6 | `sw.js` SHELL_VERSION bump at release | (a) until B17. The brief forbids modifying sw.js; the update guide says users still get updates through index.html change detection when the number is not bumped. | UNCONFIRMED (default in force) | HARD | B17 |
| D7 | Future-day plans storage | (a). No writes to `wird_habits_v1` for other days. | UNCONFIRMED (default in force) | SOFT | B2 |
| D8 | Link targets of a step plan | (a). Habits are recurring; atomizing them is not requested explicitly. | UNCONFIRMED (default in force) | SOFT | B3 |
| D9 | Scoring rules of the session report | Partial = 50 % of the question marks unless the user types awarded marks. If some questions have marks and others do not: the weighted score covers only the questions that have marks and the rest are listed separately ("بدون درجات"); with no marks at all every question weighs 1. Mastery % is shown only when no question is Awaiting Grading or Needs Review; otherwise show the graded-only score with its denominator, never labelled mastery. Unanswered counts as 0 once graded Unanswered. | UNCONFIRMED (default in force) | SOFT | B13 |
| D10 | Meaning of "submit the answers to a teacher" | (a). No backend exists and external services are excluded by the brief. | UNCONFIRMED (default in force) | SOFT | B13 |
| D11 | Location of settings (no global settings screen exists) | (a). | UNCONFIRMED (default in force) | SOFT | B5 |

**Rules.** (a) A line under "USER DECISION OVERRIDES" at the top of this prompt, or an explicit instruction from the user in this conversation, overrides the default; record it in `MASTER-PLAN.md` (Decision Register + Change log) at the end of the batch. (b) **HARD gate** (D2 before B8, D6 before B17): if the decision is still UNCONFIRMED when the dependent batch starts, STOP before implementing and ask the user to choose. (c) **SOFT gate**: proceed with the documented default, label it "ASSUMED DEFAULT" in code comments, docs and the final report, and ask the user to confirm. (d) Never invent a new decision silently: if you meet an unplanned ambiguity, pick the most conservative/preserving option, document it in HANDOFF.md and ask. Full option text: `MASTER-PLAN.md` §8.

Interpretations in force: **I1** The saved prompt is built into the app as a versioned constant (one-tap viewer + copy). It is not user-editable (editing was not requested). **I2** The brief lists three screenshots in a different order than the files received; they were identified by content: wizard step 1, wizard step 2, lesson page. Annotation marks (arrow on the lesson screenshot, circle in wizard step 2) are interpreted as in D1/D2 and are not treated as requirements. **I3** Undo window default is an implementation constant (suggested 8 s, adjustable) because the brief only says "brief". **I4** No automatic opening of the execution screen at app start; resume is offered through the planner/row actions (the brief requires exact resume but not auto-open). **I5** Real-device behaviour (Android Brave, camera capture, on-screen keyboard, installed PWA) cannot be tested in the container; it must be reported as NOT TESTED and listed for the user to try on a phone.
<!--/COMMON:DECISIONS-->

## 10. REQUIREMENTS COVERED BY THIS BATCH (from `MASTER-PLAN.md` §6; full register there)

**Implemented here (11):**
* **T-04** [MANDATORY] The planning interface may show the full editable list of steps; the execution interface shows only ONE current step by default (never the whole checklist).
* **T-07** [MANDATORY] The focused interface executes the selected task and its steps without displaying the full daily task list.
* **T-09** [MANDATORY] One-at-a-time execution: current task/context where useful, ONE current step, ONE primary completion action; flow: see step → complete → check → recorded → next step appears automatically with a pleasant transition; no "Step 2 of 8" by default; current step visually dominant; no lists, statistics or settings clutter.
* **T-10** [MANDATORY] Satisfying but restrained feedback: smooth fade/transition, brief completion animation, pleasant state change, optional haptic, optional subtle sound, optional micro-interaction — all configurable; no points, coins, artificial rewards or competitive streaks.
* **T-11** [MANDATORY] Execution controls (persistent): display mode (one step by default), automatic transition, back navigation, skip step (optional, configurable), edit during execution (optional, configurable), pause/resume, timer (optional), progress indicator (optional), completion animation (configurable), sound (optional), haptic (optional), end-of-day prompt (optional).
* **T-12** [MANDATORY] Undo protection: a brief, unobtrusive undo action after completion; a skipped step never automatically counts as completed.
* **T-13** [MANDATORY] Progress visibility setting: completely hidden / subtle indicator / detailed indicator; the default minimizes visual pressure.
* **GS-04** [MANDATORY] Subtle visual transitions only; optional haptic and sound only when supported and enabled; no animations that harm performance.
* **GS-05** [MANDATORY] Arabic-first: correct RTL, Arabic typography, mixed Arabic/English rendering, proper mathematical equation direction and layout.
* **GS-06** [MANDATORY] Mobile-first portrait design usable on small Android screens, proper keyboard behaviour, no horizontal overflow, accessible touch targets.
* **GS-07** [MANDATORY] The features feel like a native part of Wird (existing design system), not an embedded third-party page.

**Verified here, implemented elsewhere (IDs):** (none)

**Cross-cutting constraints that apply to every batch:** PRES-01…PRES-07, PROC-01…PROC-05, TS-04.

## 11. VERIFICATION

**Acceptance criteria (all must be met by executed checks):**
* TASK 1.3 acceptance: only one step visible by default and no "Step 2 of 8" text; rapid double-taps record one completion; closing and reopening restores the same step.
* Skipped steps never appear as completed; back returns to the previous step; undo works within the window and not after.
* Animations respect `prefers-reduced-motion`.
* Existing suites at baseline; verifier PASS.

**Required tests**
* **Unit:** Engine tests for any additive field; no UI logic in unit tests.
* **Integration:** `tests/tasks.exec.test.js` (Playwright): execute a 4-step plan; auto transition; undo inside/outside the window; back; pause/resume; reload mid-plan → same step (also with a persistent browser context to simulate a browser restart); double/triple tap dedupe (count events in `wird_tasks_v1`); skip disabled vs enabled by writing prefs; edit-in-run; timer on/off; progress hidden/subtle/detailed; text "Step"/"خطوة ٢ من" absent by default; `emulateMedia({reducedMotion:"reduce"})` removes transitions; day list never in DOM during a run.
* **Regression:** Planner tests from B3; all six existing suites on a scratch copy at baseline; perf budget; seeded-old-data unchanged.
* **Mobile / RTL:** 360×640 / 390×844 / 412×915 and landscape 844×390 sanity: the primary action remains reachable (≥ 44 px, thumb zone), long Arabic steps wrap without overflow, soft-keyboard open during in-run edit keeps the input visible.

**Test protocol (common):**

<!--COMMON:TESTING-->
* **Where to run:** copy the project to a scratch folder (`cp -r wird_work /tmp/scratch_Bxx`) and run the existing suites there, in the **foreground**, one per command, e.g.
  `cd /tmp/scratch_Bxx/wird_work && NODE_PATH=$(npm root -g) node tests/update.test.js; echo exit=$?`. (A background runner was killed between tool calls in B1.) Save logs under
  `docs/test-logs/<batch>/`. New tests you write go in `tests/` (new files only) and must also pass from the scratch copy.
* **Baseline to compare with (B1, untouched app):** update 64/64 · offline 1/1 · unified 12/12 · resources 34/34 · courses 32/32 (test 18 «أوفلاين أثناء جلب البيانات» is flaky — if it
  fails, re-run once and report BOTH runs; do not call it a regression unless it fails twice) · perf within budget (openMs CPU×4 = 767 vs 800). Any other deviation = regression → fix
  within the batch scope or STOP and report.
* **Always run:** `python3 -I tools/audit/verify_preservation.py` (PASS required; NEW blocks/files are expected, FAIL/GUARDED without approval are not) and
  `python3 -I tools/audit/test_verify_preservation.py` (27/27) at the start and at the end.
* **Test layers:** unit tests (Node, pure logic) · integration tests (Playwright against the real `index.html`, `serviceWorkers:'block'`, external network aborted, locale `ar-EG`) ·
  regression (existing suites + seeded-old-data checks: seed realistic `wird_habits_v1`/study data, load, assert deep-equal unchanged) · for every UI task also **mobile and RTL
  checks**: viewports 360×640, 390×844, 412×915; `document.documentElement.scrollWidth <= innerWidth` (no horizontal overflow); interactive targets ≥ 44×44 CSS px via `boundingBox()`;
  Arabic text and mixed Arabic/English rendering; no console errors (`pageerror`); `prefers-reduced-motion` honoured for animations.
* **Honest reporting:** list every test as EXECUTED (with command, count, pass/fail, log path) or NOT EXECUTED (with reason). Real-device behaviour (Android/Brave, camera, on-screen keyboard,
  installed PWA) cannot be tested here — list it as NOT TESTED and give the user a short manual checklist. Do not write "should work"; write what was run.
* **IMPLEMENTED ≠ TESTED ≠ VERIFIED.** A task is COMPLETED only when every acceptance criterion in §4/§11 is met by an executed check.
<!--/COMMON:TESTING-->

## 12. PARALLELISM AND SHARED FILES

Strict chain B3 → B4 → B5 (same files `tasks-ui.js`, `tasks.css`). Independent of Phase 2–4 chains (separate working copies + injector regeneration if run in parallel).

Graph and merge rules for the whole plan: `BATCH-DEPENDENCY-MAP.md`.

## 13. END-OF-BATCH HANDOFF

<!--COMMON:HANDOFF-->
At the end of the batch (do not skip, do not postpone):
1. Run the verifier and its self-test once more; run the regression suites required in §11; save logs.
2. **Update `MASTER-PLAN.md` only if necessary** (a user decision was confirmed, an approved clarification changed the plan): edit the Decision Register / add a dated entry to its
   "Change log". Never silently change requirements.
3. **Update `PROJECT-STATUS.md`:** task table (status + implemented / tested / verified columns + completion date), batch table, test status, files created/modified, known issues.
4. **Update `HANDOFF.md`:** all nine sections reflect the exact state — completed work with decisions and tests, working state, **the exact file names you created (so the next batch can
   find them), any deviation from this pre-generated prompt, user decisions still unconfirmed**, next tasks, warnings. The two status documents must agree.
5. **Update `CHANGELOG.md`:** one entry for this batch listing every file created / modified / deleted and the tests run. No undocumented change may exist: compare the final tree with the
   checkpoint you started from (hash diff) and make the list exact.
6. **Create the checkpoint ZIP** `wird_work_<Bxx>_checkpoint.zip` (top-level folder `wird_work/`; exclude `__pycache__` and `*.pyc`), then verify it: `unzip -t`, re-extract to a temp folder, run the verifier + self-test +
   one smoke suite there, compare the original 35 files byte-for-byte with the upload. Report its SHA-256. Never claim a ZIP you did not create and verify.
7. **Do not write a new next-batch prompt** — all prompts already exist in `prompts/`. Confirm that `prompts/<next>-EXECUTION-PROMPT.md` exists and say which decisions/names from your
   HANDOFF the next session must use. If you changed anything the next prompt assumes, record it in HANDOFF.md under "Deviations".
8. Present the final report (format in §14) and **STOP**. Never start the next batch; wait for the user's explicit approval.
<!--/COMMON:HANDOFF-->

**Batch-specific handoff content:**
* HANDOFF.md: execution API (`WirdTasks.exec.open(planId)`…), event names, preference keys read, additive engine fields, known limitation list (Android Back, auto-open).

## 14. FINAL REPORT FORMAT

<!--COMMON:REPORT-->
Final report to the user (in this order, no omissions):
1. **Summary** — tasks executed, final status of each (NOT STARTED / IN PROGRESS / COMPLETED / BLOCKED / NEEDS VERIFICATION) with implemented / tested / verified.
2. **Files** — table of every file created / modified / deleted with the reason (must match CHANGELOG.md). State explicitly: "existing files modified: none" or list them with the approved hook.
3. **Tests** — table EXECUTED vs NOT EXECUTED: command, counts, pass/fail, log path; regression results against the baseline; mobile/RTL checks where relevant.
4. **Preservation confirmation** — verifier output; confirmation that the original 35 files (or the approved guarded hooks) are unchanged; confirmation no existing data store was touched.
5. **Decisions** — every default you used labelled "ASSUMED DEFAULT (Dn)", and the questions the user must answer next (only real blockers).
6. **Issues** — defects found, impact, and whether fixed (only if in scope) or documented.
7. **Checkpoint ZIP** — name, SHA-256, how it was verified.
8. **Next** — next batch id and prompt file; wait for approval.
<!--/COMMON:REPORT-->

## 15. NEXT BATCH

Next: **B05** — file `prompts/B05-EXECUTION-PROMPT.md` (tasks: TASK 1.4 + TASK 1.5). **Do not start it.** Wait for the user’s explicit approval, then the user will open a new conversation with that prompt.
