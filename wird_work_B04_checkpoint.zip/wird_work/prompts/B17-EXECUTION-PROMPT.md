# B17 EXECUTION PROMPT — FINAL AUDIT and packaging

> **Package:** prompt-package v1 (generated after B1; project vision frozen at the B1 approval)  
> **Authorizes ONLY:** TASK 5.4  
> **Phase:** Phase 5 · **Requires completed batches:** B16 · **Next batch:** none (final batch)  
> **How to use:** open a NEW Claude conversation, upload the latest project checkpoint ZIP (and, if it lacks `MASTER-PLAN.md`/`prompts/`, the prompt-package ZIP), then paste this entire file. Do not paste more than one batch prompt into one conversation.

**USER DECISION OVERRIDES** (edit before pasting; "(none)" means: accept the defaults of §9): (none)

---

## 1. ROLE AND MODE

<!--COMMON:ROLE-->
You are Claude acting as **Senior Software Architect, Technical Project Manager and Autonomous Implementation Engineer** on an
EXISTING production application, **Wird (وِرد)**. You have NO memory of any earlier conversation: everything you need is in this prompt and
in the project files the user uploads. The actual project files are the source of truth; the documents describe intent; this prompt authorizes
ONE batch only. Never assume that a previous batch succeeded because a document says so — check the deliverables yourself.
Correctness, preservation, data safety, maintainability and faithful implementation of the approved design matter more than speed.
<!--/COMMON:ROLE-->

## 2. PROJECT CONTEXT

<!--COMMON:CONTEXT-->
**Project objective.** Add two OPTIONAL, ADDITIVE features to the existing app without redesigning or breaking anything:
(1) **Dynamic Task Atomization** — plan DAY → TASKS → STEPS and execute one current step at a time (ONE TASK → ONE CURRENT STEP → ONE ACTION);
(2) **Focus Quiz & Self-Grading** — MATERIAL → AI PROMPT → JSON IMPORT → FOCUSED SOLVING → REVIEW → SELF-GRADING → SESSION REPORT, with simple local
mistake tracking. The app is Arabic-first, RTL, mobile-first (small Android phones), offline-first. Full requirements: `MASTER-PLAN.md`.

**Existing application (verified by reading the code and probing it live in B1; details in `docs/INTEGRATION-SPIKES.md`).**
* One 1.8 MB `index.html` plus `sw.js`, `manifest.webmanifest`, two icons. No bundler. Features were added as self-contained blocks `<script id="wird-…">` /
  `<style id="wird-…-css">` plus a few exact-match patches. 26 `<script>/<style>` blocks (listed with hashes in `docs/PRESERVATION-BASELINE.json`).
  Main app = the anonymous 336 KB inline script (verifier key `script:#2`: habits, Pomodoro, Quran, books) and the main stylesheet (`style:#0`).
  The lesson workspace «منهجي» = minified bundle `ls-main` (no source) + `courses-module`, `wird-v33-*`, `wird-resources`, `wird-unified`; KaTeX/mhchem/JSZip are
  embedded as `ls-asset-*` blocks. Readable sources only for `tools/src/resources.*` and `tools/src/unified.*`.
  **`tools/patch/build.py`, `unify.py`, `bundle_patches.py` regenerate the OLD `sw.js`/`index.html` — never run them.**
* Storage: localStorage `wird_habits_v1` (global lexical object `H`; quick tasks = `H.oneoffs[date]` items `{id:'o_…',name,s,cat,done}`; `window.H` is undefined, use bare `H`),
  `wird_quran_state_v1`, `wird_mig_v3`, study/course keys; IndexedDB `wird_study_db@v2` (lessons, resources, mistakes…), `wird_books_db@v3`, `wird_fnb_m@v1`, `wird_mig_db@v1`.
  New namespaces reserved for this project: localStorage `wird_tasks_v1`, `wird_taskprefs_v1`, `wird_quizprefs_v1`; IndexedDB `wird_quiz_db` (created lazily, only on first quiz use).
* PWA update system: `sw.js` (`SHELL_VERSION = 5`) + blocks `wird-update` (contains the SW registration), `wird-update-css`, `wird-offline`, `wird-quran-font(-js)`.
* UI facts: tabs switch `.tab[data-view="view-habits"|"view-lessons"|…]`; habits root `#habitsRoot` is **re-rendered completely by `hRender()`**; quick-task rows
  `.hb-task[data-id^="o_"] > button.hb-c + span.hb-n[data-a=open]` (tapping the name currently does nothing); quick-task modal opened by `#hFab` (fields `#qn`, `#hok`);
  habit wizard `hWizard()` has 5 steps, step 2 = chips `#wt.hb-chips` (✅ عادية / ⏱ بالوقت / 🔢 بالكمية). Helpers callable from a new classic script: `hModal(html)`
  (overlay `.modal-overlay.open>.modal`, closes on backdrop tap only, no Esc/focus-trap), `showConfirm(title,msg,onConfirm)`, `showToast(msg)` (no action button),
  `hUid(prefix)`, `escapeHtml`, `toArabicNum`, `todayISO()`, `hSave()`, `hRender()`. Design tokens: `--gold --gold-soft --gold-bright --line --panel-raised --ink-dim --ink-faint --sage`;
  classes `.field-input .field-label .field-hint .hb-chips .btn .btn-primary .btn-ghost .btn-danger .panel-card .desc`.
* Lesson screen: `.ls-lesson-main > … + section.wr[data-lesson] + .ls-editor-wrap`; `section.wr` children `#wrHead` (rewritten by `renderHead()` — never append inside it or inside
  `.wr-foot`), `#wrTabs`, `#wrPanel`; anything inserted as a **sibling after `#wrHead` or `#wrTabs` survives** re-renders. Sidebar rows call `window.__wirdRow(row, el)` (wrappable).
  `__WIRD_STUDY_APP__.repo` is the public lesson-data API (`saveMistake`, `reseeMistake`, `setMistakeStatus`, `listMistakes`, `saveResource`…). `wirdResNorm` rejects unknown
  resource types. KaTeX is lazy (`typeof katex === 'undefined'` until a lesson editor loads it); an independent loader mirroring `ls-main` works in ~37 ms (assets
  `#ls-asset-katex`, `#ls-asset-mhchem`, `#ls-asset-katex-css`, style id `ls-katex-style`).
* Tests: Playwright 1.56 is installed globally (`NODE_PATH=$(npm root -g)`), Chromium 141 works; existing suites `tests/{update,offline,unified,resources,courses,perf}.test.js`.
* Preservation tooling (created in B1): `tools/audit/verify_preservation.py` (tiers FROZEN / GUARDED / APPEND-ONLY / NEW), `tools/audit/test_verify_preservation.py` (27 mutation cases),
  `tools/audit/probe_anchors.js` (live evidence probe), `docs/PRESERVATION-BASELINE.json` (frozen "before" state — never regenerate).
* Approved amendments A1–A8 (see `docs/ROADMAP.md`): module-owned settings sheets (A1); patch-free hooks by default via MutationObserver/delegation/`__wirdRow` wrapper (A2);
  no `quiz` resource type (A3); D7 (A4); O(1) observers because lesson `openMs` has only 33 ms of headroom (A5); Web Share fallback + `storage.persist()` (A6); bare `H`, IIFE modules (A7);
  verifier whitelist for new blocks `wird-tasks*`/`wird-quiz*` with forbidden-API scan (A8).
<!--/COMMON:CONTEXT-->

## 3. SESSION START — mandatory verification before any work

<!--COMMON:START-->
Before writing any code or file, in this order:
1. **Obtain the project.** The user uploads the latest checkpoint ZIP (folder `wird_work/`). Unzip it into a working folder. Work on that copy only.
2. **Read completely:** `MASTER-PLAN.md`, `PROJECT-STATUS.md`, `HANDOFF.md`, `CHANGELOG.md`, `docs/ROADMAP.md`, `BATCH-DEPENDENCY-MAP.md` (section for this batch), and the
   batch-specific documents named in §3. If `MASTER-PLAN.md`/`prompts/` are missing from the ZIP, ask the user for the prompt-package ZIP and copy its files to the project root
   (same relative paths) — do not proceed without them.
3. **Inspect the actual project state:** `python3 -I tools/audit/verify_preservation.py` must print `RESULT   PASS` (if an earlier batch had a user-approved guarded hook,
   HANDOFF.md records the exact `--allow-guarded` argument to use); `python3 -I tools/audit/test_verify_preservation.py` must print `27/27`.
4. **Verify the previous batch's deliverables really exist** using the checklist in §3 (files present, blocks present in `index.html`, tests run and pass). Run them — do not trust documents.
5. **Compare reality with the plan:** `PROJECT-STATUS.md`/`HANDOFF.md` vs the code vs `docs/ROADMAP.md`. Record every mismatch.
6. **Decide:** if everything matches → continue. If a prerequisite task is missing or broken → **STOP**, explain the blocking task, do NOT implement unrelated or predecessor work, and ask
   the user for approval to change the execution order. If this batch's tasks are already COMPLETED in `PROJECT-STATUS.md` → do not redo them: run VERIFY only and report.
7. **Authorization:** this prompt authorizes ONLY the tasks named in §4. Never start another task or the next batch. Bugs outside the scope are documented, not fixed (unless they block the
   current task — then explain and ask).
<!--/COMMON:START-->

### 3.1 Documents to read for this batch (in addition to those in the procedure above)

* `docs/ROADMAP.md` — the normative task cards (§4 embeds yours verbatim)
* `TRACEABILITY-MATRIX.md`
* `docs/QUIZ-TEST-REPORT.md`
* `docs/TASKS-TEST-REPORT.md`
* `all docs/*.md`
* `CHANGELOG.md`

### 3.2 Previous-batch deliverables to verify (run them; do not trust documents)

* PROJECT-STATUS: every task 0.1–5.3 is COMPLETED (or explicitly documented as unfixed defects with the user’s awareness). If anything is not COMPLETED, STOP and report — the final audit never implements missing work.
* Verifier PASS; self-test 27/27; injector `--check` up to date; all earlier test files present.
* **HARD GATE D6:** if D6 (bump `SHELL_VERSION` or not) is UNCONFIRMED, STOP and ask the user before touching anything. If the answer is "no bump", `sw.js` stays byte-identical. If "bump", change ONLY the single number in `sw.js`, run the `update` and `offline` suites, and record it as an **approved exception** in `docs/PRESERVATION-EXCEPTIONS.md` — never regenerate `docs/PRESERVATION-BASELINE.json`; the verifier will correctly report the `sw.js`/`SHELL_VERSION` difference, which you list as the approved exception.

_File names mentioned in this prompt are conventions of the plan: if the previous batch chose different names, `HANDOFF.md` (sections "Completed work" and "Deviations") records them — use those._

## 4. AUTHORIZED SCOPE (exact)

**This batch authorizes: TASK 5.4 — nothing else.** Goal: Verify the entire approved scope, run all regression and preservation checks, resolve decision D6 with the user, and package the final deliverables.

### 4.1 Task definitions (verbatim from `docs/ROADMAP.md`; do not reinterpret them)

<!--CARD:5.4-->
### TASK 5.4 — FINAL AUDIT & packaging · M
- **Objective:** Verify everything and ship.
- **Scope:** All old and new suites; the verifier (`sw.js` hash identical, frozen blocks identical, seeded old data intact); a requirement traceability matrix for Parts 0–14; decision **D6**; the final ZIP, file lists and final HANDOFF/PROJECT-STATUS.
- **Files/output:** Final ZIP and docs.
- **Depends:** all.
- **Accept:** Every requirement is mapped to code and a test result; nothing is labeled passed unless run.
- **Tests:** Everything.
<!--/CARD:5.4-->

Dependencies of these tasks: TASK 5.4 ← ALL. Each dependency must be verified COMPLETED (§3) before you start; never assume.

## 5. IMPLEMENTATION REQUIREMENTS FOR THIS BATCH

**FINAL AUDIT command semantics:** (1) run EVERY suite (six existing + all new ones) on a scratch copy and record results against the baselines; (2) run the verifier and prove: `sw.js` identical (or the approved D6 exception), every frozen block identical, only `wird-tasks*`/`wird-quiz*` blocks added, append-only docs intact, 35 original files unchanged except documented exceptions; (3) seeded-old-data integrity across a full tasks + quiz workflow; (4) update the **Traceability Matrix**: for each requirement ID record the evidence (file, test, result) and mark UNVERIFIED anything not executed — no requirement may be marked verified without an executed check; (5) confirm Deferred items are absent (search the code/UI for each) and Optional items are optional/off-by-default; (6) confirm every decision D1–D11 has a recorded final state; (7) confirm the Part-14 deliverables (list in §11).

**Packaging:** final ZIP `wird_work_final.zip` (folder `wird_work/`) with the complete project; `docs/FINAL-AUDIT-REPORT.md` containing the implementation and testing report, the list of EVERY created/modified/deleted file (derived from a hash diff against the original upload, must match CHANGELOG.md), the precise explanation of each modification, confirmations (features preserved, user data preserved), the final JSON schema reference, the fixed prompt reference, the import instructions, the task-atomization instructions, the deferred list, remaining known issues, and the manual real-device checklist. Verify the ZIP by re-extracting it and re-running verifier, self-test and a smoke suite.

If audit finds a defect: document it with severity; do not fix unless it is a trivial test-harness issue; ask the user whether to open a REPLAN/B16 follow-up. Never claim "all requirements verified" unless the matrix proves it with executed checks.

## 6. FILES

**Expected to be created:**
* docs/FINAL-AUDIT-REPORT.md
* docs/PRESERVATION-EXCEPTIONS.md (only if D6 bump approved)
* docs/test-logs/B17/*
* wird_work_final.zip (output)

**Expected to be modified (and only these):**
* TRACEABILITY-MATRIX.md (evidence columns)
* sw.js — ONLY the single `SHELL_VERSION` number and ONLY if D6 = bump was approved by the user
* tracking docs

Anything else that changes is an undocumented change: list it, justify it, or revert it. Compare the final tree with the starting checkpoint by hash to prove the list is exact.

## 7. EXPLICIT EXCLUSIONS

**For this batch:**
* No new features, refactors or fixes; no change to frozen blocks; no regeneration of the baseline.
* No claims beyond executed evidence.

**Global:**

<!--COMMON:EXCLUSIONS-->
**Deferred — must NOT be implemented in any batch:** automatic AI recognition of task names; AI-generated task decomposition; keyword-triggered study templates; automatic AI coaching;
per-step mathematical scoring; continuous AI analysis; complicated reward systems (points, coins, competitive streaks); unnecessary new top-level navigation. Also not built:
manual question creation (not a priority), any `quiz` lesson resource type/tab (D3), any in-app server submission (D10), any change to the habit wizard unless the user approves D1(b).
**Optional features stay optional** (off or non-intrusive by default, configurable, persisted): task atomization itself; end-of-day prompt; skip step; edit during execution; timer;
progress indicator; completion sound; haptic feedback; micro-interactions; Mark for Review; Skip and Return; Previous Question; answer editing; the «اطلب تصحيح AI» workflow; mistake
categories; automatic revision suggestions. **Defaults are Minimal**: one step/question at a time, no score, no correctness feedback, no total-question counter, progress hidden.
<!--/COMMON:EXCLUSIONS-->

## 8. PRESERVATION CONSTRAINTS

<!--COMMON:PRESERVE-->
These rules apply to EVERY batch and override convenience:
* **Preserve the product.** No redesign of existing UI/UX, theme, colors, typography, icons, spacing, layouts, navigation or tabs; the app must stay visually and functionally identical
  outside the new, optional features. Do not modify unrelated features. New UI must use the existing design tokens/classes and feel native (RTL, Arabic).
* **Protected code (never edit):** `sw.js` (do NOT bump `SHELL_VERSION` — decision D6 is for the final batch only), the SW registration and the blocks `wird-update`, `wird-update-css`,
  `wird-offline`, `wird-quran-font`, `wird-quran-font-js`; every other existing `<script>/<style>` block of `index.html` (`ls-main`, `ls-css`, `ls-asset-*`, `courses-module`,
  `wird-learning-shim`, `wird-math-paste`, `wird-v33-*`, `wird-nb-recall*`, `wird-resources*`, `wird-unified*`, the pdf.js tag); `manifest.webmanifest`; icons; `tests/*` that already
  exist; `tools/orig`, `tools/phase2`, `tools/patch/{build,unify,bundle_patches,audit_blocks}.py`; existing docs (append-only, only in Task 5.3). **Guarded** (main inline script
  `script:#2`, main stylesheet `style:#0`, body markup): only through an exact-match hook that the USER approved, passed explicitly to the verifier with `--allow-guarded`.
* **Never run** `tools/patch/build.py`, `unify.py`, `bundle_patches.py` (they regenerate the old `sw.js`).
* **Protect user data.** Never delete, clear, recreate or migrate existing localStorage/IndexedDB data; never change versions of existing databases; write only to the new namespaces
  (`wird_tasks_v1`, `wird_taskprefs_v1`, `wird_quizprefs_v1`, IndexedDB `wird_quiz_db`, created lazily). Every record you add must be additive and backward compatible; edits/deletes of
  plans or imported question sets must never alter history. Never use `deleteDatabase`, `localStorage.clear`, `sessionStorage.clear`, `caches.*` or `serviceWorker` in new code.
* **Additive, isolated, reversible.** New code lives only in the new blocks (`wird-tasks-css`, `wird-tasks`, `wird-quiz-css`, `wird-quiz`, inserted by the injector from `tools/src/`) and new
  files. Hooks into existing screens are patch-free by default (MutationObserver with O(1) work per mutation, event delegation, `window.__wirdRow` wrapper, sibling insertion). Keep
  every observer cheap: lesson `openMs` is 767 ms vs a budget of 800 ms at CPU×4.
* **No external services:** no network calls, API keys, CDN additions or new dependencies (KaTeX is already embedded). Code must work offline.
* **Security:** build DOM with `createElement`/`textContent`; never inject imported or user-typed strings through `innerHTML` without escaping.
* **Honesty:** never claim a test passed unless you executed it in this session; never claim a ZIP exists unless you created and verified it; report untested scenarios explicitly.
* **No scope creep:** deferred features stay deferred (see the exclusion list); optional features stay optional.
<!--/COMMON:PRESERVE-->

## 9. DECISIONS (defaults in force)

<!--COMMON:DECISIONS-->
| ID | Topic | Default in force | Status | Gate | Needed by |
|---|---|---|---|---|---|
| D1 | Entry point of Task Atomization | (a). No 4th wizard chip: it would edit `hWizard` type logic in the guarded main script (`w.type` = b/time/qty drives routing, `meas()` and saving). | UNCONFIRMED (default in force) | SOFT | B3 |
| D2 | Meaning/location of "Add New Sheet" = anchor of the saved-prompt button | B. NOT confirmed by the user; no literal "Add New Sheet" control exists in the app. | UNCONFIRMED (default in force) | HARD | B8 |
| D3 | How quizzes appear inside a lesson | (a). Proven: `repo.saveResource({type:"quiz"})` is rejected ("Invalid resource"). | UNCONFIRMED (default in force) | SOFT | B8 |
| D4 | Rich-text format of quiz content | (a), obeying the `wMathTok` tokenizer rules. The brief assumed Markdown headings; the real lesson content is a JSON node tree. | UNCONFIRMED (default in force) | SOFT | B6 |
| D5 | Mistake tracking: pool, notebook integration, defaults | Separate pool + optional push through `repo.saveMistake` (needs a `lessonId`). Recording ON (passive, no popups); automatic revision suggestions OFF until enabled (threshold default 3 incorrect in one topic); status rule: correct once → improving, correct in two separate sessions → mastered; incorrect again → open and recurrence +1. | UNCONFIRMED (default in force) | SOFT | B14 |
| D6 | `sw.js` SHELL_VERSION bump at release | (a) until B17. The brief forbids modifying sw.js; the update guide says users still get updates through index.html change detection when the number is not bumped. | UNCONFIRMED (default in force) | HARD | B17 |
| D7 | Future-day plans storage | (a). No writes to `wird_habits_v1` for other days. | UNCONFIRMED (default in force) | SOFT | B2 |
| D8 | Link targets of a step plan | (a). Habits are recurring; atomizing them is not requested explicitly. | UNCONFIRMED (default in force) | SOFT | B3 |
| D9 | Scoring rules of the session report | Partial = 50 % of the question marks unless the user types awarded marks. If some questions have marks and others do not: the weighted score covers only the questions that have marks and the rest are listed separately ("بدون درجات"); with no marks at all every question weighs 1. Mastery % is shown only when no question is Awaiting Grading or Needs Review; otherwise show the graded-only score with its denominator, never labelled mastery. Unanswered counts as 0 once graded Unanswered. | UNCONFIRMED (default in force) | SOFT | B13 |
| D10 | Meaning of "submit the answers to a teacher" | (a). No backend exists and external services are excluded by the brief. | UNCONFIRMED (default in force) | SOFT | B13 |
| D11 | Location of settings (no global settings screen exists) | (a). | UNCONFIRMED (default in force) | SOFT | B5 |

**Rules.** (a) A line under "USER DECISION OVERRIDES" at the top of this prompt, or an explicit instruction from the user in this conversation, overrides the default; record it in `MASTER-PLAN.md` (Decision Register + Change log) at the end of the batch. (b) **HARD gate** (D2 before B8, D6 before B17): if the decision is still UNCONFIRMED when the dependent batch starts, STOP before implementing and ask the user to choose. (c) **SOFT gate**: proceed with the documented default, label it "ASSUMED DEFAULT" in code comments, docs and the final report, and ask the user to confirm. (d) Never invent a new decision silently: if you meet an unplanned ambiguity, pick the most conservative/preserving option, document it in HANDOFF.md and ask. Full option text: `MASTER-PLAN.md` §8.

Interpretations in force: **I1** The saved prompt is built into the app as a versioned constant (one-tap viewer + copy). It is not user-editable (editing was not requested). **I2** The brief lists three screenshots in a different order than the files received; they were identified by content: wizard step 1, wizard step 2, lesson page. Annotation marks (arrow on the lesson screenshot, circle in wizard step 2) are interpreted as in D1/D2 and are not treated as requirements. **I3** Undo window default is an implementation constant (suggested 8 s, adjustable) because the brief only says "brief". **I4** No automatic opening of the execution screen at app start; resume is offered through the planner/row actions (the brief requires exact resume but not auto-open). **I5** Real-device behaviour (Android Brave, camera capture, on-screen keyboard, installed PWA) cannot be tested in the container; it must be reported as NOT TESTED and listed for the user to try on a phone.
<!--/COMMON:DECISIONS-->

## 10. REQUIREMENTS COVERED BY THIS BATCH (from `MASTER-PLAN.md` §6; full register there)

**Implemented here (10):**
* **TS-03** [MANDATORY] Regression: existing task management, habit tracking, lesson pages, Notes and Summary, study materials, Quran and Wird functionality, offline functionality all still work; no existing data deleted; the PWA update system is not broken; the app works on mobile.
* **DL-01** [MANDATORY] Final deliverable 1: The complete modified project as a ZIP.
* **DL-02** [MANDATORY] Final deliverable 2: A list of every modified, created and deleted file.
* **DL-03** [MANDATORY] Final deliverable 3: A precise explanation of every modification.
* **DL-04** [MANDATORY] Final deliverable 4: Confirmation that existing application features were preserved.
* **DL-05** [MANDATORY] Final deliverable 5: Confirmation that existing user data was preserved.
* **DL-06** [MANDATORY] Final deliverable 6: The final JSON schema.
* **DL-07** [MANDATORY] Final deliverable 7: The reusable fixed AI prompt.
* **DL-08** [MANDATORY] Final deliverable 8: The implementation and testing report.
* **DL-11** [MANDATORY] Final deliverable 11: A list of deferred features.

**Verified here, implemented elsewhere (IDs):** T-02, T-05, Q-02, Q-05, Q-07, QM-02, G-07, M-02, M-03, GS-07, DF-01, DF-02, DF-03, DF-04, DF-05, DF-06, DF-07, DF-08, DL-09, DL-10

**Cross-cutting constraints that apply to every batch:** PRES-01…PRES-07, PROC-01…PROC-05, TS-04.

## 11. VERIFICATION

**Acceptance criteria (all must be met by executed checks):**
* TASK 5.4: every requirement is mapped to code and a test result; nothing is labeled passed unless run; D6 resolved with the user; final ZIP verified; the Part-14 deliverables exist.

**Required tests**
* **Unit:** Run all unit tests of every batch.
* **Integration:** Run all Playwright suites of every batch.
* **Regression:** All six existing suites vs baseline; verifier; seeded-old-data; perf; PWA update/offline suites (`update`, `offline`).
* **Mobile / RTL:** Re-run the viewport matrix from B16; real devices NOT TESTED with a checklist.

**Part-13 Task Atomization tests (each must be reported EXECUTED or NOT EXECUTED):**
1. Create a task with multiple steps.
2. Edit a step.
3. Delete a step.
4. Reorder steps.
5. Execute one step.
6. Confirm automatic transition.
7. Return to the previous step.
8. Skip a step when skipping is enabled.
9. Pause and resume.
10. Close and reopen the app.
11. Confirm exact state restoration.
12. Finish all tasks scheduled for one day.
13. Confirm the optional next-day prompt.
14. Verify no duplicate completion records.
15. Verify all preferences persist.

**Part-13 Focus Quiz tests (each must be reported EXECUTED or NOT EXECUTED):**
1. Copy the saved AI Prompt.
2. Import valid JSON.
3. Import invalid JSON and verify clear errors.
4. Import all supported question types.
5. Render mathematical notation.
6. Display diagrams and images.
7. Attach a handwritten answer image.
8. Navigate questions.
9. Use Mark for Review.
10. Skip and return.
11. Confirm answers are preserved.
12. Close and reopen the app.
13. Resume an unfinished session.
14. Finish a session with an answer key.
15. Finish a session without an answer key.
16. Manually grade answers.
17. Leave answers awaiting grading.
18. Export the complete answer sheet.
19. Generate optional AI grading material.
20. Verify correct report calculations.
21. Verify mistake tracking.
22. Verify settings persist.

**Part-13 regression list:**
1. Existing task management still works.
2. Existing habit tracking still works.
3. Existing lesson pages still work.
4. Existing Notes and Summary functionality still works.
5. Existing study materials remain intact.
6. Existing Quran and Wird functionality still works.
7. Existing offline functionality still works.
8. No existing data is deleted.
9. The new features do not break the PWA update system.
10. The app works properly on mobile.

**Part-14 final deliverables (all must exist):**
1. The complete modified project as a ZIP.
2. A list of every modified, created and deleted file.
3. A precise explanation of every modification.
4. Confirmation that existing application features were preserved.
5. Confirmation that existing user data was preserved.
6. The final JSON schema.
7. The reusable fixed AI prompt.
8. The implementation and testing report.
9. Instructions for importing questions.
10. Instructions for using task atomization.
11. A list of deferred features.

**Test protocol (common):**

<!--COMMON:TESTING-->
* **Where to run:** copy the project to a scratch folder (`cp -r wird_work /tmp/scratch_Bxx`) and run the existing suites there, in the **foreground**, one per command, e.g.
  `cd /tmp/scratch_Bxx/wird_work && NODE_PATH=$(npm root -g) node tests/update.test.js; echo exit=$?`. (A background runner was killed between tool calls in B1.) Save logs under
  `docs/test-logs/<batch>/`. New tests you write go in `tests/` (new files only) and must also pass from the scratch copy.
* **Baseline to compare with (B1, untouched app):** update 64/64 · offline 1/1 · unified 12/12 · resources 34/34 · courses 32/32 (test 18 «أوفلاين أثناء جلب البيانات» is flaky — if it
  fails, re-run once and report BOTH runs; do not call it a regression unless it fails twice) · perf within budget (openMs CPU×4 = 767 vs 800). Any other deviation = regression → fix
  within the batch scope or STOP and report.
* **Always run:** `python3 -I tools/audit/verify_preservation.py` (PASS required; NEW blocks/files are expected, FAIL/GUARDED without approval are not) and
  `python3 -I tools/audit/test_verify_preservation.py` (27/27) at the start and at the end.
* **Test layers:** unit tests (Node, pure logic) · integration tests (Playwright against the real `index.html`, `serviceWorkers:'block'`, external network aborted, locale `ar-EG`) ·
  regression (existing suites + seeded-old-data checks: seed realistic `wird_habits_v1`/study data, load, assert deep-equal unchanged) · for every UI task also **mobile and RTL
  checks**: viewports 360×640, 390×844, 412×915; `document.documentElement.scrollWidth <= innerWidth` (no horizontal overflow); interactive targets ≥ 44×44 CSS px via `boundingBox()`;
  Arabic text and mixed Arabic/English rendering; no console errors (`pageerror`); `prefers-reduced-motion` honoured for animations.
* **Honest reporting:** list every test as EXECUTED (with command, count, pass/fail, log path) or NOT EXECUTED (with reason). Real-device behaviour (Android/Brave, camera, on-screen keyboard,
  installed PWA) cannot be tested here — list it as NOT TESTED and give the user a short manual checklist. Do not write "should work"; write what was run.
* **IMPLEMENTED ≠ TESTED ≠ VERIFIED.** A task is COMPLETED only when every acceptance criterion in §4/§11 is met by an executed check.
<!--/COMMON:TESTING-->

## 12. PARALLELISM AND SHARED FILES

Final batch; nothing runs in parallel with it.

Graph and merge rules for the whole plan: `BATCH-DEPENDENCY-MAP.md`.

## 13. END-OF-BATCH HANDOFF

<!--COMMON:HANDOFF-->
At the end of the batch (do not skip, do not postpone):
1. Run the verifier and its self-test once more; run the regression suites required in §11; save logs.
2. **Update `MASTER-PLAN.md` only if necessary** (a user decision was confirmed, an approved clarification changed the plan): edit the Decision Register / add a dated entry to its
   "Change log". Never silently change requirements.
3. **Update `PROJECT-STATUS.md`:** task table (status + implemented / tested / verified columns + completion date), batch table, test status, files created/modified, known issues.
4. **Update `HANDOFF.md`:** all nine sections reflect the exact state — completed work with decisions and tests, working state, **the exact file names you created (so the next batch can
   find them), any deviation from this pre-generated prompt, user decisions still unconfirmed**, next tasks, warnings. The two status documents must agree.
5. **Update `CHANGELOG.md`:** one entry for this batch listing every file created / modified / deleted and the tests run. No undocumented change may exist: compare the final tree with the
   checkpoint you started from (hash diff) and make the list exact.
6. **Create the checkpoint ZIP** `wird_work_<Bxx>_checkpoint.zip` (top-level folder `wird_work/`; exclude `__pycache__` and `*.pyc`), then verify it: `unzip -t`, re-extract to a temp folder, run the verifier + self-test +
   one smoke suite there, compare the original 35 files byte-for-byte with the upload. Report its SHA-256. Never claim a ZIP you did not create and verify.
7. **Do not write a new next-batch prompt** — all prompts already exist in `prompts/`. Confirm that `prompts/<next>-EXECUTION-PROMPT.md` exists and say which decisions/names from your
   HANDOFF the next session must use. If you changed anything the next prompt assumes, record it in HANDOFF.md under "Deviations".
8. Present the final report (format in §14) and **STOP**. Never start the next batch; wait for the user's explicit approval.
<!--/COMMON:HANDOFF-->

**Batch-specific handoff content:**
* Final HANDOFF.md/PROJECT-STATUS.md describe the released state; MASTER-PLAN.md gets a closing "Project complete" entry only if the audit passes.

## 14. FINAL REPORT FORMAT

<!--COMMON:REPORT-->
Final report to the user (in this order, no omissions):
1. **Summary** — tasks executed, final status of each (NOT STARTED / IN PROGRESS / COMPLETED / BLOCKED / NEEDS VERIFICATION) with implemented / tested / verified.
2. **Files** — table of every file created / modified / deleted with the reason (must match CHANGELOG.md). State explicitly: "existing files modified: none" or list them with the approved hook.
3. **Tests** — table EXECUTED vs NOT EXECUTED: command, counts, pass/fail, log path; regression results against the baseline; mobile/RTL checks where relevant.
4. **Preservation confirmation** — verifier output; confirmation that the original 35 files (or the approved guarded hooks) are unchanged; confirmation no existing data store was touched.
5. **Decisions** — every default you used labelled "ASSUMED DEFAULT (Dn)", and the questions the user must answer next (only real blockers).
6. **Issues** — defects found, impact, and whether fixed (only if in scope) or documented.
7. **Checkpoint ZIP** — name, SHA-256, how it was verified.
8. **Next** — next batch id and prompt file; wait for approval.
<!--/COMMON:REPORT-->

## 15. NEXT BATCH

This is the final batch. After the final report, stop and wait for the user.
