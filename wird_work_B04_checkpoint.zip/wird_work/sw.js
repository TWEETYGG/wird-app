// ورد — Service Worker: offline-first, with an explicit cache-ownership table and a user-approved update flow (see below).
'use strict';

/* =============================================================================
   RELEASE CHECKLIST — for every new release change ONLY the number on the SHELL_VERSION
   line just below: 5 → 6, next time 6 → 7, and so on. Nothing else in this file.
   Cache names, the precache and the clean-up of old shell caches all follow from it.
   NEVER set it to 1 — "wird-v1" is the Quran/Tafsir download cache (see below).
============================================================================= */
const SHELL_VERSION = 5;

/* -----------------------------------------------------------------------------
   CACHE OWNERSHIP — every cache this app knows about, and who may delete it
   ┌──────────────┬────────────────────────────────────────────────┬───────────┐
   │ wird-v<N>    │ App shell: index.html, manifest, icons.         │ replaced  │
   │              │ Versioned. Owned by this worker.                │ each      │
   │              │                                                 │ release   │
   ├──────────────┼────────────────────────────────────────────────┼───────────┤
   │ wird-v1      │ Quran + Tafsir pages (the "download Quran for   │ PROTECTED │
   │              │ offline" button writes it; this worker also     │ never     │
   │              │ fills it on a miss and reads it first).         │ deleted   │
   ├──────────────┼────────────────────────────────────────────────┼───────────┤
   │ wird-runtime │ Third-party static files (pdf.js, font files)   │ PROTECTED │
   │              │ + the last prayer-times answer.                 │ never     │
   │              │                                                 │ deleted   │
   ├──────────────┼────────────────────────────────────────────────┼───────────┤
   │ anything else│ Unknown → never touched.                        │ PROTECTED │
   └──────────────┴────────────────────────────────────────────────┴───────────┘
   Only the OLD SHELL caches wird-v2 … wird-v<N-1> are ever deleted, and only after
   their user content (Quran pages, runtime files) has been copied to the protected caches.
----------------------------------------------------------------------------- */
const SCOPE = self.registration.scope;                 // e.g. https://tweetygg.github.io/wird-app/
const ORIGIN = new URL(SCOPE).origin;
const SHELL_CACHE = 'wird-v' + SHELL_VERSION;
const QURAN_CACHE = 'wird-v1';
const RUNTIME_CACHE = 'wird-runtime';
const FIRST_SHELL_VERSION = 2;                         // wird-v1 is NOT a shell cache, so the list starts at 2
const QURAN_HOST = 'api.islamic.app';                  // QURAN_API_BASE in index.html

if (SHELL_CACHE === QURAN_CACHE) throw new Error('SHELL_VERSION must not be 1: wird-v1 holds the Quran downloads');

const OLD_SHELL_CACHES = [];                           // explicit, closed list: wird-v2 … wird-v<N-1>
for (let n = FIRST_SHELL_VERSION; n < SHELL_VERSION; n++) OLD_SHELL_CACHES.push('wird-v' + n);

// Exactly the files that exist in the project folder. Do not add a path unless the file is uploaded.
const SHELL = [
  { url: SCOPE + 'index.html',           type: /html/ },
  { url: SCOPE + 'manifest.webmanifest', type: null },
  { url: SCOPE + 'icon-192.png',         type: /^image\// },
  { url: SCOPE + 'icon-512.png',         type: /^image\// },
];
const SHELL_KEY = SCOPE + 'index.html';                // every navigation is answered with this page

/* ------------------------------ install ------------------------------------
   Downloads the whole new shell FIRST (bypassing the browser and CDN HTTP caches), writes it only
   if every file arrived intact. Any failure rejects → the worker is discarded and the installed
   version keeps running untouched. No skipWaiting() here: the page asks for activation (Update Now). */
self.addEventListener('install', e => e.waitUntil(precache()));

async function precache() {
  const bust = u => u + '?wird-v=' + SHELL_VERSION;    // new URL ⇒ never served from a stale CDN/HTTP copy
  const got = await Promise.all(SHELL.map(async ({ url, type }) => {
    const res = await fetch(new Request(bust(url), { cache: 'reload' }));
    if (!res.ok || res.redirected || (type && !type.test(res.headers.get('content-type') || ''))) {
      throw new Error('precache failed: ' + url + ' (' + res.status + ')');
    }
    const body = await res.blob();                      // read the body NOW: never hold half-read streams open while the other files download
    return [url, new Response(body, { status: res.status, statusText: res.statusText, headers: res.headers })];
  }));
  const cache = await caches.open(SHELL_CACHE);
  await Promise.all(got.map(([url, res]) => cache.put(url, res)));
}

/* ------------------------------ activate -----------------------------------
   Takes control, then tidies up. Never blocks for long and never throws: if tidying cannot finish
   it is simply retried later (next activation, or the page's idle WIRD_MAINTENANCE message). */
self.addEventListener('activate', e => e.waitUntil((async () => {
  await self.clients.claim();
  try { await maintain({ budgetMs: 3000 }); } catch (err) { /* legacy caches stay; nothing is lost */ }
})()));

/* maintain(): for each OLD SHELL cache that still exists:
     1) copy its non-shell entries (Quran pages → wird-v1, everything else cross-origin → wird-runtime),
        only those the protected caches do not already have;
     2) delete the old shell cache only after that finished without any error.
   Same-origin entries are shell files and are not copied (the new shell was precached fresh). */
let maintaining = null;
function maintain(opts) {
  return maintaining || (maintaining = runMaintenance(opts || {}).finally(() => { maintaining = null; }));
}
async function runMaintenance({ budgetMs }) {
  const deadline = budgetMs ? Date.now() + budgetMs : Infinity;
  const existing = new Set(await caches.keys());
  for (const name of OLD_SHELL_CACHES) {
    if (!existing.has(name)) continue;
    if (name === SHELL_CACHE || name === QURAN_CACHE || name === RUNTIME_CACHE) continue;   // belt and braces
    if (Date.now() > deadline) return false;
    if (await migrateOut(name, deadline)) await caches.delete(name);
    else return false;
  }
  return true;
}
async function migrateOut(name, deadline) {
  const src = await caches.open(name);
  const foreign = (await src.keys()).filter(r => new URL(r.url).origin !== ORIGIN);
  if (!foreign.length) return true;
  const quran = await caches.open(QURAN_CACHE), runtime = await caches.open(RUNTIME_CACHE);
  const have = { q: new Set((await quran.keys()).map(r => r.url)), r: new Set((await runtime.keys()).map(r => r.url)) };
  for (const req of foreign) {
    if (Date.now() > deadline) return false;
    const toQuran = new URL(req.url).hostname === QURAN_HOST;
    if ((toQuran ? have.q : have.r).has(req.url)) continue;                                   // already protected
    const res = await src.match(req);
    if (res) await (toQuran ? quran : runtime).put(req, res);                                 // throws on quota → legacy kept
  }
  return true;
}

/* ------------------------------ helpers ------------------------------------ */
// Read-only fallback: an old shell cache that has not been cleaned up yet can still answer.
async function legacyMatch(req) {
  for (const name of OLD_SHELL_CACHES) {
    const hit = await caches.match(req, { cacheName: name });
    if (hit) return hit;
  }
  return undefined;
}
const hex = buf => [...new Uint8Array(buf)].map(n => n.toString(16).padStart(2, '0')).join('');
const digest = async r => hex(await crypto.subtle.digest('SHA-256', await r.arrayBuffer()));
async function sameContent(a, b) {
  const ea = a.headers.get('etag'), eb = b.headers.get('etag');
  if (ea && eb && ea === eb) return true;
  const [x, y] = await Promise.all([digest(a.clone()), digest(b.clone())]);                  // a re-deploy of identical bytes is NOT an update
  return x === y;
}
async function notifyClients(msg) {
  const all = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
  all.forEach(c => c.postMessage(msg));
}

/* ------------------------------ strategies --------------------------------- */
// Stale-while-revalidate (same strategy as before). Same-origin files live in the shell cache,
// third-party files in wird-runtime so they survive releases.
async function swr(req, e) {
  const same = new URL(req.url).origin === ORIGIN;
  const c = await caches.open(same ? SHELL_CACHE : RUNTIME_CACHE);
  const hit = (await c.match(req)) || (await legacyMatch(req));
  const net = fetch(same ? new Request(req, { cache: 'no-cache' }) : req)                    // no-cache = revalidate, never a 10-minute-old copy
    .then(r => { if (r && (r.ok || r.type === 'opaque')) c.put(req, r.clone()).catch(() => {}); return r; })
    .catch(() => null);
  e.waitUntil(net);
  return hit || net.then(r => r || new Response('', { status: 504 }));
}

// Prayer times: network first, last good answer when offline (kept in wird-runtime, so it survives releases).
async function netFirst(req, e) {
  const c = await caches.open(RUNTIME_CACHE);
  try {
    const r = await fetch(req);
    if (r && r.ok) e.waitUntil(c.put(req, r.clone()).catch(() => {}));
    return r;
  } catch (err) {
    return (await c.match(req)) || (await legacyMatch(req)) || new Response('{}', { status: 504 });
  }
}

// Quran / Tafsir: cache first. The downloaded pages are answered straight from wird-v1 and are never
// overwritten here (a background refresh could replace a good page with an error body). On a miss the
// page is fetched, validated and stored for next time.
async function quranFirst(req, e) {
  const c = await caches.open(QURAN_CACHE);
  const hit = (await c.match(req)) || (await legacyMatch(req));
  if (hit) return hit;
  try {
    const r = await fetch(req);
    if (r && r.ok) {
      const forCheck = r.clone(), forStore = r.clone();       // clone BEFORE the body is handed to the page
      e.waitUntil((async () => {
        const body = await forCheck.json().catch(() => null);
        if (body && !(typeof body.code === 'number' && body.code >= 400)) await c.put(req, forStore);
      })().catch(() => {}));
    }
    return r;
  } catch (err) {
    return new Response('', { status: 504 });
  }
}

// Navigation: the page comes from the shell cache instantly (works offline). In the background it is
// compared with the server copy; if the file changed without a new SHELL_VERSION the new copy is stored
// and open tabs are told (so a forgotten version bump still reaches users, via the Update Now prompt).
async function revalidateShell(cache, old) {
  // A newer worker is installing or waiting: the new release brings its own copy of the page, so this
  // shell must stay exactly as it is (no half-old / half-new mix, and the page shows ONE clear prompt).
  if (self.registration.installing || self.registration.waiting) return null;
  try {
    const res = await fetch(new Request(SHELL_KEY, { cache: 'no-cache' }));
    if (!res.ok || res.redirected || !/html/.test(res.headers.get('content-type') || '')) return null;
    if (!old || !(await sameContent(old.clone(), res.clone()))) {
      await cache.put(SHELL_KEY, res.clone());
      if (old) await notifyClients({ type: 'WIRD_SHELL_UPDATED' });
    }
    return res;
  } catch (err) { return null; }
}
async function navigation(e) {
  const cache = await caches.open(SHELL_CACHE);
  const hit = await cache.match(SHELL_KEY);
  const bg = revalidateShell(cache, hit);
  e.waitUntil(bg);
  if (hit) return hit;
  const fresh = await bg;                                   // shell cache empty (should not happen): network
  if (fresh) return fresh;
  return (await caches.match(SHELL_KEY)) || new Response('', { status: 504 });   // last resort: any cache that has the page
}

/* ------------------------------ fetch routing ------------------------------
   Same order and same exclusions as before. */
self.addEventListener('fetch', e => {
  const r = e.request; if (r.method !== 'GET') return;
  const u = new URL(r.url);
  if (u.hostname === 'api.aladhan.com') { e.respondWith(netFirst(r, e)); return; }
  // YouTube: no interception, no caching of anything that comes from it (player, images, API) — always straight from the network
  if (/(^|\.)(youtube\.com|youtube-nocookie\.com|youtu\.be|ytimg\.com|googlevideo\.com|googleapis\.com|ggpht\.com)$/.test(u.hostname)) return;
  if (u.hostname === 'everyayah.com' || u.hostname === 'api.dictionaryapi.dev' || r.headers.has('range')) return;
  if (r.mode === 'navigate') { e.respondWith(navigation(e)); return; }
  if (u.hostname === QURAN_HOST) { e.respondWith(quranFirst(r, e)); return; }
  e.respondWith(swr(r, e));
});

/* ------------------------------ messages from the page --------------------- */
self.addEventListener('message', e => {
  const d = e.data || {};
  if (d.type === 'SKIP_WAITING') e.waitUntil(self.skipWaiting());           // sent only by the Update Now button
  else if (d.type === 'WIRD_MAINTENANCE') e.waitUntil(maintain().catch(() => {}));
  else if (d.type === 'WIRD_REVALIDATE') e.waitUntil((async () => { const c = await caches.open(SHELL_CACHE); await revalidateShell(c, await c.match(SHELL_KEY)); })());
  else if (d.type === 'GET_VERSION' && e.source) e.source.postMessage({ type: 'WIRD_VERSION', version: SHELL_VERSION, shell: SHELL_CACHE, quran: QURAN_CACHE, runtime: RUNTIME_CACHE });
});
