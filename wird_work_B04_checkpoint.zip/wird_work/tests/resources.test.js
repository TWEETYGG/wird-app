// اختبارات «مصادر الدرس» في منهجي — Playwright + مشغّل يوتيوب مزيّف + oEmbed مزيّف. بدون أي اتصال حقيقي.
// التشغيل:  NODE_PATH=$(npm root -g) node tests/resources.test.js [مسار index.html]
// اختياري:  ORIG_INDEX=/path/to/original-v1/index.html  ⇒ بيشغّل كمان اختبار الترقية على بيانات كتبها الإصدار القديم فعلاً.
const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
const ROOT = path.resolve(__dirname, '..');
const INDEX = path.resolve(process.argv[2] || path.join(ROOT, 'index.html'));
const T0 = new Date('2026-10-31T10:00:00+02:00');
const OEMBED = { title: 'الروابط الكيميائية — شرح', author_name: 'قناة الكيمياء', thumbnail_url: 'https://i.ytimg.com/vi/dQw4w9WgXcQ/hqdefault.jpg' };
const VID = 'dQw4w9WgXcQ', VID2 = 'aqz-KE-bpKQ';
const FAKE_YT = `
  window.__yt={players:[],dur:600,rate:1,seeks:[],destroyed:0,created:0,pauses:0,playing:false,base:0,since:0};
  // الوقت بيمشي مع الساعة المزيّفة (Date.now) وقت التشغيل بس — زي مشغّل حقيقي، فمفيش «قفزات» بتظهر كأنها سيك.
  // وعشان الاختبار يبقى حتمي (حتى تحت ضغط الجهاز) الوقت مبيمشيش إلا جوه play() ثم بيتجمّد (freeze)، مش بينجرف مع الوقت الحقيقي.
  Object.defineProperty(__yt,'t',{get(){return this.playing?this.base+(Date.now()-this.since)/1000*this.rate:this.base},set(v){this.base=v;this.since=Date.now()}});
  window.YT={Player:class{
    constructor(id,cfg){this.cfg=cfg;__yt.players.push(this);__yt.created++;
      const el=document.getElementById(id);const f=document.createElement('iframe');f.id=id;f.setAttribute('data-fake','1');el.replaceWith(f);
      setTimeout(()=>cfg.events.onReady({target:this}),0)}
    getCurrentTime(){return __yt.t} getDuration(){return __yt.dur} getPlaybackRate(){return __yt.rate}
    getVideoData(){return {title:'عنوان من المشغّل',author:'قناة المشغّل'}}
    seekTo(t){__yt.t=t;__yt.seeks.push(t)} playVideo(){this.cfg.events.onStateChange({data:1})} pauseVideo(){__yt.pauses++;this.st(2)} destroy(){__yt.destroyed++}
    st(s){const now=__yt.t;__yt.playing=(s===1);__yt.t=now;this.cfg.events.onStateChange({data:s})}}};`;
const STUB_READER = `
  window.__rd=[];
  window.openBookReader=async id=>{const b=booksState.list.find(x=>x.id===id);__rd.push(['open',id]);bookReaderState={bookId:id,book:b,pdfDoc:null,currentPage:b.currentPage||1}};
  window.renderBookPage=async n=>{__rd.push(['page',n]);bookReaderState.currentPage=n;const b=bookReaderState.book;if(b)b.currentPage=n};`;

/* ---------------- خادم ثابت صغير (عشان نقدر نبدّل إصدار index.html على نفس الأصل = نفس IndexedDB) ---------------- */
let currentIndex = INDEX;
const server = http.createServer((req, res) => {
  const u = decodeURIComponent(req.url.split('?')[0]);
  const f = u === '/' || u === '/index.html' ? currentIndex : path.join(ROOT, u);
  fs.readFile(f, (e, d) => {
    if (e) { res.writeHead(404); return res.end(); }
    const ext = path.extname(f);
    res.writeHead(200, { 'content-type': ext === '.html' ? 'text/html; charset=utf-8' : ext === '.js' ? 'text/javascript' : ext === '.png' ? 'image/png' : 'application/json' });
    res.end(d);
  });
});
let BASE, browser;
const results = [];
const eq = (a, b, m) => { if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error((m || 'eq') + ': expected ' + JSON.stringify(b) + ' got ' + JSON.stringify(a)); };
const ok = (c, m) => { if (!c) throw new Error(m || 'assertion failed'); };
const W = (page, fn, arg) => page.evaluate(fn, arg);

async function mk(opt = {}) {
  const ctx = opt.ctx || await browser.newContext({ viewport: opt.vp || { width: 360, height: 780 }, locale: 'ar-EG', timezoneId: 'Africa/Cairo', serviceWorkers: 'block' });
  const page = await ctx.newPage(); const errs = [], reqs = [];
  page.setDefaultTimeout(6000);
  page.on('pageerror', e => errs.push(String(e)));
  page.on('request', r => reqs.push(r.url()));
  await page.route(/^https?:\/\/(?!127\.0\.0\.1)/, r => {
    const u = r.request().url();
    if (opt.oembed !== false && /youtube\.com\/oembed/.test(u)) {
      if (opt.oembed === 404) return r.fulfill({ status: 404, body: 'Not Found' });
      if (opt.oembed === 'offline') return r.abort();
      return r.fulfill({ status: 200, contentType: 'application/json', headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify(OEMBED) });
    }
    return r.abort();
  });
  if (!opt.noYT) await page.addInitScript(FAKE_YT);
  if (!opt.noMark) await page.addInitScript(() => { try { if (!localStorage.getItem('wird_mig_v3')) localStorage.setItem('wird_mig_v3', JSON.stringify({ v: 3, ts: 1, reported: true, created: { subject: null, units: [], lessons: [], items: [] } })); } catch (e) {} });
  if (!opt.keepClock) await page.clock.install({ time: T0 });
  await page.goto(BASE + '/index.html'); await page.clock.runFor(300);
  return { ctx, page, errs, reqs };
}
async function T(name, fn, opt = {}) {
  if (process.env.ONLY && !name.includes(process.env.ONLY)) return;
  let h;
  try { h = await mk(opt); await fn(h.page, h); if (h.errs.length && !opt.allowErrors) throw new Error('page errors: ' + h.errs.join(' | ')); results.push([name, true]); }
  catch (e) { results.push([name, false, process.env.DEBUG ? e.stack.split('\n').slice(0, 8).join('\n      ') : e.message.split('\n')[0]]); }
  if (h && h.ctx && !opt.keepCtx) await h.ctx.close();
}

/* ---------------- مساعدات ---------------- */
// بنقدّم الساعة المزيّفة + وقفة حقيقية صغيرة، عشان عمليات IndexedDB/الشبكة المزيّفة الفعلية تخلص حتى والجهاز مضغوط
const tick = async (p, ms = 60) => { await p.clock.runFor(ms); await p.waitForTimeout(ms >= 200 ? 60 : 25); };
// استنّى لحد ما الشرط يتحقق في الصفحة (بدل وقت ثابت)
const until = async (p, fn, arg, tries = 80) => { for (let i = 0; i < tries; i++) { if (await p.evaluate(fn, arg)) return true; await p.waitForTimeout(25); await p.clock.runFor(50); } return false; };
// مادة ← وحدة ← درس بالمستودع مباشرة، وبعدين فتح الدرس في الواجهة
const seed = (p, o = {}) => p.evaluate(async o => {
  const a = __WIRD_STUDY_APP__; await a.init();
  const s = await a.repo.createSubject(o.subject || 'الكيمياء'), u = await a.repo.createUnit(s.id, o.unit || 'الوحدة الأولى');
  const l = await a.repo.createLesson({ subjectId: s.id, unitId: u.id, title: o.lesson || 'الروابط الكيميائية' });
  await a.reloadTree();
  if (o.open !== false) await a.open({ kind: 'lesson', id: l.id });
  return { s: s.id, u: u.id, l: l.id };
}, o);
const more = (p, ids, o = {}) => p.evaluate(async ([ids, o]) => {
  const a = __WIRD_STUDY_APP__;
  const l = await a.repo.createLesson({ subjectId: ids.s, unitId: o.unit || ids.u, title: o.lesson || 'درس آخر' }); await a.reloadTree(); return l.id;
}, [ids, o]);
const openLesson = async (p, id) => { await W(p, id => __WIRD_STUDY_APP__.open({ kind: 'lesson', id }), id); await tick(p, 300); };
const openApp = async p => { await p.click('.tab[data-view="view-lessons"]'); await tick(p, 100); };
const tab = async (p, t) => { await p.click('#wrt-' + t); await tick(p, 50); };
const dbDump = p => p.evaluate(() => new Promise((res, rej) => {
  const r = indexedDB.open('wird_study_db'); r.onerror = () => rej(r.error);
  r.onsuccess = () => { const db = r.result, out = { __v: db.version }, names = [...db.objectStoreNames]; let n = names.length; if (!n) return res(out);
    names.forEach(s => { const q = db.transaction(s).objectStore(s).getAll(); q.onsuccess = () => { out[s] = q.result; if (!--n) { db.close(); res(out) } } }) };
}));
const addVideoUI = async (p, { url = 'https://youtu.be/' + VID, start = '', end = '', title = '' } = {}) => {
  await tab(p, 'video'); await p.click('#wrList [data-a="add"]');
  await p.fill('#wrfUrl', url); if (title) await p.fill('#wrfTitle', title);
  await p.fill('#wrfStart', start); await p.fill('#wrfEnd', end);
  await p.click('.wr-form [data-a="submit"]');
  ok(await until(p, () => !document.querySelector('.wr-form') || /err/.test((document.querySelector('#wrfMsg') || {}).className || '')), 'form settled'); await tick(p, 100);
};
const resources = (p, lid) => p.evaluate(l => __WIRD_STUDY_APP__.repo.listResources(l), lid);
const addRes = (p, r) => p.evaluate(async r => __WIRD_STUDY_APP__.repo.saveResource(r), r);
const vidRes = (lid, o = {}) => ({ id: 'res_' + Math.random().toString(36).slice(2, 9), lessonId: lid, subjectId: '', type: 'video', title: o.title || 'فيديو', order: 0, status: o.status || 'todo', completedAt: null, createdAt: 1, updatedAt: 1, video: Object.assign({ youtubeVideoId: VID, metadataStatus: 'oembed' }, o.video || {}) });
const bookRes = (lid, o = {}) => ({ id: 'res_' + Math.random().toString(36).slice(2, 9), lessonId: lid, subjectId: '', type: 'book', title: o.title || 'كتاب', order: 0, status: o.status || 'todo', completedAt: null, createdAt: 1, updatedAt: 1, book: Object.assign({ bookId: 'b1' }, o.book || {}) });
const linkRes = (lid, o = {}) => ({ id: 'res_' + Math.random().toString(36).slice(2, 9), lessonId: lid, subjectId: '', type: 'link', title: o.title || 'رابط', order: 0, status: o.status || 'todo', completedAt: null, createdAt: 1, updatedAt: 1, link: { url: o.url || 'https://example.com/a' } });
const addBook = (p, o = {}) => p.evaluate(async o => { const rec = { id: o.id || 'b1', title: o.title || 'كتاب الكيمياء', totalPages: o.total == null ? 100 : o.total, currentPage: o.cur || 1, addedDate: '2026-10-01', dailyTarget: 5 }; await dbPut('books', rec); booksState.list.push(rec); return rec.id }, o);
const play = async (p, secs, startT) => {
  if (startT != null) await p.evaluate(t => { __yt.t = t; }, startT);
  await p.evaluate(() => __yt.players[__yt.players.length - 1].st(1));
  await p.clock.runFor(secs * 1000);
  await p.evaluate(() => { const n = __yt.t; __yt.playing = false; __yt.base = n; });   // freeze: مفيش انجراف مع الوقت الحقيقي بعد كده
};
const vrec = (p, id = VID) => p.evaluate(id => { const v = WirdCourses.C.videos[id]; return v ? { iv: v.iv, watched: v.watched, lastPos: v.lastPos, duration: v.duration, title: v.title } : null }, id);
// الفواصل الزمنية بتتقاس بساعة مزيّفة فبيبقى فيها كسور صغيرة: نقارن بتسامح ٠٫٣ث
const near = (iv, exp, m, tol = 0.3) => { ok(Array.isArray(iv) && iv.length === exp.length && iv.every((r, i) => Math.abs(r[0] - exp[i][0]) <= tol && Math.abs(r[1] - exp[i][1]) <= tol), (m || 'iv') + ': expected ≈' + JSON.stringify(exp) + ' got ' + JSON.stringify(iv)); };
const noHScroll = async (p, m) => { const o = await p.evaluate(() => ({ d: document.documentElement.scrollWidth, w: innerWidth, m: (document.querySelector('.ls-lesson-main') || {}).scrollWidth, mc: (document.querySelector('.ls-lesson-main') || {}).clientWidth })); ok(o.d <= o.w + 1, (m || '') + ' page overflow ' + JSON.stringify(o)); if (o.m) ok(o.m <= o.mc + 1, (m || '') + ' lesson overflow ' + JSON.stringify(o)); };
const smallTargets = (p, sel) => p.evaluate(sel => [...document.querySelectorAll(sel)].filter(e => e.offsetParent && (e.getBoundingClientRect().height < 43.5)).map(e => (e.textContent || e.getAttribute('aria-label') || '').trim().slice(0, 20) + ':' + Math.round(e.getBoundingClientRect().height)), sel);
const docOf = (p, lid) => p.evaluate(async l => (await __WIRD_STUDY_APP__.repo.loadLesson(l)).record.doc, lid);

(async () => {
  await new Promise(r => server.listen(0, '127.0.0.1', r)); BASE = 'http://127.0.0.1:' + server.address().port;
  browser = await chromium.launch(process.env.CHROME ? { executablePath: process.env.CHROME, args: ['--no-sandbox'] } : { args: ['--no-sandbox'] });

  /* ================= ترقية قاعدة البيانات v1 → v2 ================= */
  const V1_STORES = { subjects: [], units: ['subjectId'], lessons: ['subjectId', 'unitId'], docs: [], vmeta: ['lessonId'], versions: [], sectionTrash: ['lessonId'], media: [], blobs: ['mediaId'], mistakes: ['lessonId', 'subjectId'], concepts: [], templates: [], kv: [], index: [] };
  const seedV1 = p => p.evaluate(async STORES => {
    await new Promise((res, rej) => { const r = indexedDB.open('wird_study_db', 1); r.onerror = () => rej(r.error); r.onupgradeneeded = () => { for (const [s, ix] of Object.entries(STORES)) { const st = r.result.createObjectStore(s, { keyPath: 'id' }); ix.forEach(i => st.createIndex(i, i, { unique: false })) } };
      r.onsuccess = () => { const db = r.result, tx = db.transaction(Object.keys(STORES), 'readwrite'), put = (s, v) => tx.objectStore(s).put(v);
        const doc = { type: 'doc', content: [{ type: 'heading', attrs: { level: 1, sid: 'h1abcdef' }, content: [{ type: 'text', text: 'مقدمة' }] }, { type: 'paragraph', content: [{ type: 'text', text: 'نص قديم عن الروابط الأيونية' }] }] };
        put('subjects', { id: 'sub_old', name: 'فيزياء قديمة', order: 0, createdAt: 1000, updatedAt: 1000 });
        put('units', { id: 'unit_old', subjectId: 'sub_old', name: 'وحدة قديمة', order: 0, createdAt: 1000, updatedAt: 1000 });
        put('lessons', { id: 'les_old', subjectId: 'sub_old', unitId: 'unit_old', title: 'درس قديم', order: 0, dir: 'rtl', createdAt: 1000, updatedAt: 2000, wordCount: 6, imageCount: 0, rev: 3 });
        put('docs', { id: 'les_old', doc, toggleState: {}, rev: 3, schemaVersion: 2, hash: 'x1' });
        put('vmeta', { id: 'ver_old', lessonId: 'les_old', ts: 1500, reason: 'manual', title: 'درس قديم', wordCount: 3 });
        put('versions', { id: 'ver_old', doc });
        put('mistakes', { id: 'mis_old', lessonId: 'les_old', subjectId: 'sub_old', unitId: 'unit_old', createdAt: 1, lastSeenAt: 2, recurrenceCount: 1, examWarningTag: '', status: 'open' });
        put('templates', { id: 'tpl_old', name: 'قالب', isDefault: true, sections: [], createdAt: 1, updatedAt: 1 });
        put('kv', { id: 'schema', value: 2 });
        tx.oncomplete = () => { db.close(); res() }; tx.onerror = () => rej(tx.error) } });
  }, V1_STORES);
  await T('MIG-1. ترقية v1→v2: البيانات القديمة كما هي حرفيًا + متجر resources فاضي بفهارسه', async p => {
    await seedV1(p);
    const before = await dbDump(p); eq(before.__v, 1, 'seeded as v1'); ok(!('resources' in before));
    await p.reload(); await tick(p, 300); await openApp(p);
    await W(p, async () => { await __WIRD_STUDY_APP__.init() });
    const after = await dbDump(p); eq(after.__v, 2, 'db version');
    for (const s of Object.keys(V1_STORES)) { if (s === 'index') continue; eq(after[s], before[s], 'store ' + s + ' unchanged') }
    eq(after.resources, [], 'resources empty');
    const ix = await W(p, () => new Promise(res => { const r = indexedDB.open('wird_study_db'); r.onsuccess = () => { const st = r.result.transaction('resources').objectStore('resources'); const o = { kp: st.keyPath, ix: [...st.indexNames].sort() }; r.result.close(); res(o) } }));
    eq(ix, { kp: 'id', ix: ['lessonId', 'subjectId'] });
    const t = await W(p, () => ({ s: __WIRD_STUDY_APP__.tree.subjects.map(x => x.name), l: __WIRD_STUDY_APP__.tree.lessons.map(x => x.title) }));
    eq(t, { s: ['فيزياء قديمة'], l: ['درس قديم'] });
  });
  await T('MIG-2. الترقية idempotent: إعادة الفتح مرتين من غير تغيير + الدرس القديم بيتفتح ومعاه شريط المصادر', async p => {
    await seedV1(p); await p.reload(); await tick(p, 300); await openApp(p); await W(p, () => __WIRD_STUDY_APP__.init());
    const a = await dbDump(p); await p.reload(); await tick(p, 300); await openApp(p); await W(p, () => __WIRD_STUDY_APP__.init());
    const b = await dbDump(p); eq(b.__v, 2);
    for (const s of Object.keys(V1_STORES)) { if (s === 'index') continue; eq(b[s], a[s], s) }
    await W(p, () => __WIRD_STUDY_APP__.open({ kind: 'lesson', id: 'les_old' })); await tick(p, 300);
    eq(await p.locator('#wrTabs button').count(), 6);
    ok((await p.locator('.ls-editor-root').innerText()).includes('نص قديم عن الروابط الأيونية'), 'old note visible');
  });
  if (process.env.ORIG_INDEX) {
    await T('MIG-3. (النسخة الأصلية) بيانات كتبها الإصدار 1 الحقيقي ⇒ ترقية سليمة', async p => {
      currentIndex = path.resolve(process.env.ORIG_INDEX);
      const h = await mk({ keepClock: false }); const q = h.page;
      const ids = await seed(q, { subject: 'قديم', lesson: 'درس من v1' });
      await W(q, async l => { const a = __WIRD_STUDY_APP__; await a.repo.saveLessonDoc(l, { type: 'doc', content: [{ type: 'paragraph', content: [{ type: 'text', text: 'نص من النسخة القديمة' }] }] }, { snapshot: 'manual' }); await a.repo.saveMistake({ lessonId: l, subjectId: a.lesson(l).subjectId, unitId: a.lesson(l).unitId, title: 'خطأ', createdAt: 1, lastSeenAt: 1 }).catch(() => {}) }, ids.l);
      const before = await dbDump(q); eq(before.__v, 1);
      await q.close(); currentIndex = INDEX;
      const p2 = await h.ctx.newPage(); await p2.goto(BASE + '/index.html'); await p2.waitForTimeout(400);
      await p2.click('.tab[data-view="view-lessons"]'); await W(p2, () => __WIRD_STUDY_APP__.init());
      const after = await dbDump(p2); eq(after.__v, 2);
      for (const s of Object.keys(V1_STORES)) { if (s === 'index' || s === 'kv') continue; eq(after[s], before[s], 'store ' + s) }
      eq(after.resources, []);
      await h.ctx.close();
    }, { keepCtx: true });
    currentIndex = INDEX;
  }

  /* ================= دوال نقية ================= */
  await T('PURE-1. الشرائح: href ↔ parse + تقدّم الدرس/الوحدة/الحالة بشكل حتمي', async p => {
    const r = await W(p, () => {
      const H = WirdResources.helpers;
      const L = (st, o = {}) => Object.assign({ status: st, type: 'video', deletedAt: null }, o);
      const p1 = H.lessonProgress([L('done'), L('doing'), L('todo'), L('done', { type: 'book', book: { bookId: 'gone' } })], r => r.type === 'book');
      const p2 = H.lessonProgress([L('done')], () => false), p0 = H.lessonProgress([], () => false), pAll = H.lessonProgress([L('todo', { type: 'book' })], () => true);
      return {
        a: [H.anchorHref('res_x', { t: 754.9 }), H.anchorHref('res_x', { p: 12 }), H.parseAnchor('wird-res://res_x?t=754'), H.parseAnchor('wird-res://res_x?p=12'), H.parseAnchor('https://x.com'), H.parseAnchor('wird-res://r?t=-5'), H.parseAnchor('')],
        p1: [p1.eligible, p1.done, p1.doing, p1.missing, p1.pct], p0: [p0.eligible, p0.pct], pAll: [pAll.eligible, pAll.pct],
        ro: [H.rollup([p1, p2, p0]), H.rollup([p0]), H.rollup([])],
        st: [H.lessonStatus(p1, 0), H.lessonStatus(p2, 0), H.lessonStatus(p2, 2), H.lessonStatus(H.lessonProgress([L('todo')], () => false), 0), H.lessonStatus(H.lessonProgress([L('doing')], () => false), 0), H.lessonStatus(p0, 0)],
        rg: [H.validateRange(10, 5, 0).length, H.validateRange(0, 700, 600).length, H.validateRange(NaN, null, 0).length, H.validateRange(null, null, 600).length, H.validateRange(5, 100, 600).length],
        pg: [H.validatePages(5, 3, 100).length, H.validatePages(1, 101, 100).length, H.validatePages(null, null, 100).length, H.validatePages(0, null, 0).length],
        url: [H.parseHttpUrl('javascript:alert(1)').reason, H.parseHttpUrl('ftp://x.com/a').reason, H.parseHttpUrl('example.com/a').ok, H.parseHttpUrl('').reason, H.parseHttpUrl('https://exa mple.com').reason, H.parseHttpUrl('https://localhost').reason],
      };
    });
    eq(r.a, ['wird-res://res_x?t=754', 'wird-res://res_x?p=12', { id: 'res_x', t: 754 }, { id: 'res_x', p: 12 }, null, { id: 'res_x'.replace('res_x', 'r') }, null]);
    eq(r.p1, [3, 1, 1, 1, 33], 'lesson progress excludes missing'); eq(r.p0, [0, null]); eq(r.pAll, [0, null]);
    eq(r.ro, [{ pct: 67, lessons: 2, done: 1 }, { pct: null, lessons: 0, done: 0 }, { pct: null, lessons: 0, done: 0 }], 'rollup = average of lessons that have eligible resources');
    eq(r.st, ['doing', 'mastered', 'review', 'none', 'doing', null]);
    eq(r.rg, [1, 1, 1, 0, 0]); eq(r.pg, [1, 1, 0, 1]);
    eq(r.url, ['scheme', 'scheme', true, 'empty', 'malformed', 'malformed']);
  });

  /* ================= شاشة الدرس ================= */
  await T('UI-1. شريط التبويبات تحت العنوان: الملخص افتراضيًا + العدّادات + المحرر يختفي مع تبويبات المصادر', async p => {
    const ids = await seed(p); await tick(p, 300);
    eq(await p.locator('#wrTabs button').allTextContents().then(a => a.map(x => x.replace(/\s+/g, ' ').trim())), ['📝 الملخص', '🎬 فيديو ٠', '📚 كتاب ٠', '🔗 روابط ٠', '🎓 كورس ٠', '📓 نص ٠']);
    eq(await p.locator('#wrt-note').getAttribute('aria-selected'), 'true');
    ok(await p.locator('.ls-editor-wrap').isVisible(), 'editor visible by default');
    const order = await p.evaluate(() => { const m = document.querySelector('.ls-lesson-main'); return [...m.children].map(c => c.className.split(' ')[0]) });
    ok(order.indexOf('ls-title') < order.indexOf('wr') && order.indexOf('wr') < order.indexOf('ls-editor-wrap'), 'tabs sit under the title, above the note: ' + order);
    await tab(p, 'video'); ok(!(await p.locator('.ls-editor-wrap').isVisible()), 'editor hidden on resource tab'); eq(await p.locator('#wrt-video').getAttribute('aria-selected'), 'true');
    await tab(p, 'note'); ok(await p.locator('.ls-editor-wrap').isVisible());
    eq(await p.locator('#wrHead .wr-hint').count(), 1, 'empty hint');
  });
  await T('UI-2. أزرار النوت/الملخص الأصلية في شريط السياق لسه شغّالة (مفيش تغيير سلوك)', async p => {
    await seed(p); await tick(p, 300);
    eq(await p.locator('.ctx-seg button').count(), 2);
    await p.click('.ctx-seg [data-m="nb"]'); await tick(p, 300); ok(await p.evaluate(() => __WIRD_STUDY_APP__.root.classList.contains('nb-on')), 'notebook mode on');
    await p.click('.ctx-seg [data-m="sum"]'); await tick(p, 300); ok(!(await p.evaluate(() => __WIRD_STUDY_APP__.root.classList.contains('nb-on'))), 'summary mode back');
  });

  /* ================= الفيديو ================= */
  await T('VID-1. إضافة فيديو بالواجهة: رابط صالح + مدى، المخزّن مراجع بس، وأخطاء واضحة', async p => {
    const ids = await seed(p); await tick(p, 300); await tab(p, 'video');
    ok((await p.locator('#wrList .wr-empty').innerText()).includes('لسه مفيش فيديوهات'));
    for (const [url, start, end, re] of [['', '', '', 'الصق'], ['https://vimeo.com/123456789', '', '', 'مش من يوتيوب'], ['https://www.youtube.com/watch?v=short', '', '', 'معرّف'], ['not a url', '', '', 'مش مكتوب صح'], ['https://youtu.be/' + VID, '10:00', '05:00', 'بعد البداية'], ['https://youtu.be/' + VID, 'xx', '', 'غير صالح']]) {
      await p.click('#wrList [data-a="add"]'); await p.fill('#wrfUrl', url); await p.fill('#wrfStart', start); await p.fill('#wrfEnd', end);
      await p.click('.wr-form [data-a="submit"]'); await tick(p, 200);
      ok((await p.locator('#wrfMsg').innerText()).includes(re), 'error for ' + url + '/' + start + ' → ' + (await p.locator('#wrfMsg').innerText()));
      await p.click('.wr-form [data-a="cancel"]');
    }
    eq((await resources(p, ids.l)).length, 0, 'nothing saved on errors');
    await addVideoUI(p, { start: '00:30', end: '05:00' });
    const list = await resources(p, ids.l); eq(list.length, 1);
    const r = list[0];
    eq(Object.keys(r).sort(), ['completedAt', 'createdAt', 'deleteBatch', 'deletedAt', 'id', 'lessonId', 'order', 'rev', 'status', 'subjectId', 'title', 'type', 'updatedAt', 'video']);
    eq(r.video, { youtubeVideoId: VID, metadataStatus: 'oembed', startSec: 30, endSec: 300 }); eq(r.status, 'todo'); eq(r.title, OEMBED.title);
    eq(r.subjectId, ids.s, 'subjectId denormalised from lesson');
    ok((await p.locator('.wr-card').innerText()).includes(OEMBED.title)); eq(await p.locator('#wrt-video .wr-n').innerText(), '١');
    ok(!('watched' in r.video) && !('iv' in r.video) && !('lastPos' in r.video), 'no progress copied into the resource');
    await p.click('#wrList [data-a="add"]'); await p.fill('#wrfUrl', 'https://youtu.be/' + VID); await p.fill('#wrfStart', '00:30'); await p.fill('#wrfEnd', '05:00'); await p.click('.wr-form [data-a="submit"]'); await tick(p, 200);
    ok((await p.locator('#wrfMsg').innerText()).includes('مضاف بالفعل'), 'duplicate refused');
  });
  await T('VID-2. أوفلاين/404: إضافة يدوية بعنوان، ومفيش اختلاق للبيانات', async p => {
    const ids = await seed(p); await tick(p, 300); await tab(p, 'video');
    await p.click('#wrList [data-a="add"]'); await p.fill('#wrfUrl', 'https://youtu.be/' + VID); await p.click('.wr-form [data-a="submit"]'); await tick(p, 300);
    ok((await p.locator('#wrfMsg').innerText()).includes('خاص أو محذوف'), '404 message'); ok(await p.locator('[data-a="manual"]').isVisible());
    eq((await resources(p, ids.l)).length, 0);
    await p.click('[data-a="manual"]'); await tick(p, 200); ok((await p.locator('#wrfMsg').innerText()).includes('اكتب عنوان'));
    await p.fill('#wrfTitle', 'فيديو يدوي'); await p.click('[data-a="manual"]'); await tick(p, 300);
    const r = (await resources(p, ids.l))[0]; eq([r.title, r.video.metadataStatus], ['فيديو يدوي', 'manual']);
    const rec = await vrec(p); eq(rec.duration, undefined, 'duration not invented');
  }, { oembed: 404 });
  await T('VID-3. الشريحة العمودية: مدى ← مشغّل رسمي ← تقدّم محفوظ ← ملاحظة بوقت ← يعيش بعد إعادة التشغيل', async (p, h) => {
    const ids = await seed(p); await tick(p, 300);
    await addVideoUI(p, { start: '00:30', end: '05:00' });
    await p.click('[data-a="play"]'); await tick(p, 100);
    eq(await p.evaluate(() => __yt.players.length), 1, 'one official player'); ok(await p.locator('.wr-ytw iframe[data-fake]').count() === 1);
    eq(await p.evaluate(() => __yt.seeks), [30], 'starts at range start');
    eq(await p.locator('.wr-ytw').evaluate(e => e.children.length), 1, 'nothing overlays the player (only the iframe)');
    await play(p, 6, 30);
    let rec = await vrec(p); near(rec.iv, [[30, 36]], 'progress in the per-video record (courses source of truth)'); let ivSaved; ok(rec.watched >= 5.9);
    eq((await resources(p, ids.l))[0].status, 'doing', 'started = doing, never done');
    await p.fill('#wrPinTxt', 'قاعدة الثمانيات'); await p.click('[data-a="pin"]'); await tick(p, 300);
    await p.click('[data-a="pback"]'); await tab(p, 'note');
    const chip = p.locator('.ls-editor-root a.ls-link[href^="wird-res://"]'); eq(await chip.count(), 1);
    eq(await chip.innerText(), '▶ 00:36'); ok((await chip.getAttribute('href')).endsWith('?t=36'));
    ok((await p.locator('.ls-editor-root').innerText()).includes('قاعدة الثمانيات'));
    await W(p, () => WirdCourses.flush()); ivSaved = JSON.stringify((await vrec(p)).iv); near(JSON.parse(ivSaved), [[30, 36.5]], 'final', 0.6);
    // إعادة تشغيل التطبيق
    await p.reload(); await tick(p, 300); await openApp(p);
    await openLesson(p, ids.l); await tick(p, 300);
    eq((await resources(p, ids.l)).length, 1, 'resource survives restart');
    rec = await vrec(p); eq(JSON.stringify(rec.iv), ivSaved, 'progress survives restart exactly'); eq(Math.round(rec.lastPos), 36);
    const d = await docOf(p, ids.l); ok(JSON.stringify(d).includes('wird-res://') && JSON.stringify(d).includes('قاعدة الثمانيات'), 'anchored note survives restart');
    await tab(p, 'video'); ok((await p.locator('.wr-card').innerText()).includes('كمّل'), 'resume offered');
    await p.click('[data-a="play"]'); await tick(p, 100);
    eq(await p.evaluate(() => __yt.seeks.slice(-1)[0]), 36, 'resumes from saved position');
    // الشريحة بتقفز للوقت
    await p.click('[data-a="pback"]'); await tab(p, 'note');
    await p.locator('.ls-editor-root a.ls-link[href^="wird-res://"]').click(); await tick(p, 200);
    eq(await p.locator('#wrt-video').getAttribute('aria-selected'), 'true', 'chip opens the video tab'); eq(await p.evaluate(() => __yt.seeks.slice(-1)[0]), 36, 'chip seeks to anchored time');
    eq(await p.evaluate(() => [__yt.created, __yt.created - __yt.destroyed]), [2, 1], 'one player per play session, never two alive at once');
    ok(h.reqs.every(u => !/googlevideo|\/videoplayback|youtube\.com\/get_video/.test(u)), 'no media extraction');
  });
  await T('VID-4. نهاية المدى: بيقف ويقترح بس (مفيش إكمال تلقائي) + اقتراح ٩٠٪ + إكمال صريح وإلغاؤه', async p => {
    const ids = await seed(p); await tick(p, 300);
    await addVideoUI(p, { start: '00:10', end: '00:30' });
    await p.click('[data-a="play"]'); await tick(p, 100);
    await play(p, 25, 10); await tick(p, 300);
    ok(await p.evaluate(() => __yt.pauses) >= 1, 'paused at range end'); ok((await p.locator('#wrPrompt').innerText()).includes('نهاية المدى'));
    eq((await resources(p, ids.l))[0].status, 'doing', 'not auto-completed at the end');
    await p.click('[data-a="psugg-no"]'); eq(await p.locator('#wrPrompt').innerText(), '');
    const rec = await vrec(p); ok(rec.watched >= 19 && rec.watched <= 21, 'watched ' + rec.watched);
    // ٩٠٪ ← اقتراح بس
    await p.click('[data-a="pback"]'); eq((await resources(p, ids.l))[0].status, 'doing');
    ok(true);
    await p.click('[data-a="play"]'); await tick(p, 100);
    await p.click('[data-a="pdone"]'); await tick(p, 200);
    let r = (await resources(p, ids.l))[0]; eq(r.status, 'done'); ok(typeof r.completedAt === 'number');
    eq(await p.locator('[data-a="pdone"]').innerText(), '↩ إلغاء الإكتمال');
    await p.click('[data-a="pdone"]'); await tick(p, 200); r = (await resources(p, ids.l))[0]; eq([r.status, r.completedAt], ['doing', null], 'undo returns to doing (has progress)');
  });
  await T('VID-5. الاقتراح عند ٩٠٪ بيظهر بس ومبيكمّلش لوحده', async p => {
    const ids = await seed(p); await tick(p, 300);
    await addVideoUI(p);                       // الفيديو كله (المدة بتتعرف من المشغّل: ٦٠٠ث)
    await p.click('[data-a="play"]'); await tick(p, 100);
    await play(p, 5, 0); eq(await p.locator('#wrPrompt .wr-prompt').count(), 0, 'no suggestion at ~1%');
    await p.evaluate(() => { const v = WirdCourses.C.videos['dQw4w9WgXcQ']; v.iv = [[0, 560]]; v.watched = 560 }); await play(p, 2, 560); await tick(p, 100);
    ok((await p.locator('#wrPrompt').innerText()).includes('٩٠٪'), 'suggestion shown'); eq((await resources(p, ids.l))[0].status, 'doing', 'still not done');
    await p.click('[data-a="psugg-yes"]'); await tick(p, 200); eq((await resources(p, ids.l))[0].status, 'done', 'explicit accept completes');
  });
  await T('VID-6. فيديو ممنوع التضمين (101) + فشل تحميل مشغّل يوتيوب ⇒ «افتح في يوتيوب» والبيانات محفوظة', async p => {
    const ids = await seed(p); await tick(p, 300); await addVideoUI(p, { start: '01:00' });
    await p.click('[data-a="play"]'); await tick(p, 100);
    await p.evaluate(() => __yt.players[0].cfg.events.onError({ data: 101 })); await tick(p, 100);
    const a = p.locator('#wrStat a'); ok((await a.getAttribute('href')).startsWith('https://www.youtube.com/watch?v=' + VID)); eq(await a.getAttribute('rel'), 'noopener noreferrer'); eq(await a.getAttribute('target'), '_blank');
    ok((await p.locator('#wrStat').innerText()).includes('منع تشغيله'));
    eq((await resources(p, ids.l)).length, 1, 'resource kept'); ok((await vrec(p)) !== null, 'video record kept');
    await p.click('[data-a="pback"]'); ok((await p.locator('.wr-card').innerText()).includes('غير متاح'), 'flagged in list');
  });
  await T('VID-7. YT API مش بيتحمّل (أوفلاين) ⇒ رابط يوتيوب خارجي، مفيش مشغّل بديل', async p => {
    const ids = await seed(p); await tick(p, 300); await addVideoUI(p);
    await p.click('[data-a="play"]'); await tick(p, 13000);
    ok((await p.locator('#wrStat').innerText()).includes('مقدرناش نحمّل'), await p.locator('#wrStat').innerText()); ok((await p.locator('#wrStat a').getAttribute('href')).includes('youtube.com/watch'));
    eq(await p.locator('.wr-ytw iframe').count(), 0, 'no fallback embed');
  }, { noYT: true });
  await T('VID-8. مغادرة التبويب/الدرس بتوقف المشغّل وتحفظ التقدّم + مشغّل الكورسات متوقّف + حدث wird:view', async p => {
    const ids = await seed(p); await tick(p, 300); await addVideoUI(p);
    await p.click('[data-a="play"]'); await tick(p, 100); await play(p, 4, 0);
    await tab(p, 'note'); eq(await p.evaluate(() => __yt.destroyed), 1, 'tab switch destroys the player'); near((await vrec(p)).iv, [[0, 4]], 'after tab switch');
    await tab(p, 'video'); await p.click('[data-a="play"]'); await tick(p, 100); await play(p, 2, 4);
    const pauses = await p.evaluate(() => __yt.pauses); await p.evaluate(() => document.dispatchEvent(new CustomEvent('wird:view', { detail: { view: 'view-habits' } }))); await tick(p, 50);
    eq(await p.evaluate(() => __yt.pauses), pauses + 1, 'view change pauses');
    await W(p, () => __WIRD_STUDY_APP__.close()); await tick(p, 200); eq(await p.evaluate(() => __yt.destroyed), 2, 'closing the workspace destroys the player');
    near((await vrec(p)).iv, [[0, 6]], 'after closing workspace');
  });
  await T('VID-9. تعديل المدى + حذف بتأكيد (المرجع بس، وتقدّم الفيديو يفضل في سجله)', async p => {
    const ids = await seed(p); await tick(p, 300); await addVideoUI(p, { start: '00:10', end: '01:00' });
    await p.click('[data-a="play"]'); await tick(p, 100); await play(p, 3, 10); await p.click('[data-a="pback"]');
    await p.click('[data-a="edit"]'); await p.fill('#wrfEnd', '00:05'); await p.click('.wr-form [data-a="submit"]'); await tick(p, 100);
    ok((await p.locator('#wrfMsg').innerText()).includes('بعد البداية'), 'edit validates');
    await p.fill('#wrfEnd', '02:00'); await p.fill('#wrfTitle', 'عنوان جديد'); await p.click('.wr-form [data-a="submit"]'); await tick(p, 200);
    let r = (await resources(p, ids.l))[0]; eq([r.title, r.video.startSec, r.video.endSec, r.rev], ['عنوان جديد', 10, 120, 3], 'rev: create=1, started=2, edit=3');
    const ivBefore = JSON.stringify((await vrec(p)).iv); await p.click('[data-a="del"]'); await tick(p, 100); ok(await p.locator('#confirmOverlay.open').count() === 1, 'confirmation shown'); eq((await resources(p, ids.l)).length, 1, 'not deleted before confirm');
    await p.click('#confirmCancelBtn'); eq((await resources(p, ids.l)).length, 1);
    await p.click('[data-a="del"]'); await p.click('#confirmOkBtn'); await tick(p, 300);
    eq((await resources(p, ids.l)).length, 0, 'deleted after confirm'); eq(JSON.stringify((await vrec(p)).iv), ivBefore, 'video progress untouched'); near(JSON.parse(ivBefore), [[10, 13]], 'recorded');
  });

  await T('VID-2b. أوفلاين تمامًا (oEmbed مقطوع): رسالة واضحة + إضافة يدوية، وملف المصدر يتحفظ من غير اختلاق بيانات', async p => {
    const ids = await seed(p); await tick(p, 300); await tab(p, 'video');
    await p.click('#wrList [data-a="add"]'); await p.fill('#wrfUrl', 'https://youtu.be/' + VID); await p.click('.wr-form [data-a="submit"]'); await tick(p, 400);
    { const m = await p.locator('#wrfMsg').innerText(); ok(/مفيش اتصال|تعذّر جلب/.test(m), 'clear failure message: ' + m); ok(await p.locator('[data-a="manual"]').isVisible(), 'manual fallback offered'); }
    eq((await resources(p, ids.l)).length, 0, 'nothing saved before the user confirms a manual title');
    await p.fill('#wrfTitle', 'فيديو أوفلاين'); await p.click('[data-a="manual"]'); await tick(p, 300);
    eq((await resources(p, ids.l)).map(r => [r.title, r.video.metadataStatus]), [['فيديو أوفلاين', 'manual']]);
  }, { oembed: 'offline' });
  await T('VID-10. سجل الفيديو في الكورسات ضاع (نقل جهاز/استيراد): المصدر يفضل ظاهر، والتشغيل بيعيد إنشاء السجل بدل ما يتعطّل', async p => {
    const ids = await seed(p); await tick(p, 300); const r = await addRes(p, vidRes(ids.l, { title: 'فيديو من نسخة احتياطية' }));
    eq(await vrec(p), null, 'no per-video record on this device'); await openLesson(p, ids.l); await tab(p, 'video');
    ok((await p.locator('.wr-card').innerText()).includes('فيديو من نسخة احتياطية'), 'listed without a record'); eq(await p.locator('.wr-card.wr-missing').count(), 0, 'not flagged missing: the YouTube id is still valid');
    await p.click('[data-a="play"]'); await tick(p, 100); await play(p, 3, 0);
    ok((await vrec(p)) !== null, 'record recreated on play'); near((await vrec(p)).iv, [[0, 3]], 'progress recorded');
  });

  /* ================= الكتب ================= */
  await T('BOOK-1. كتاب من المكتبة + مدى صفحات (تحقق) + فتح عند الصفحة + تثبيت صفحة + شريحة تفتح الكتاب', async p => {
    await p.evaluate(STUB_READER); const ids = await seed(p); await addBook(p, { total: 100, cur: 5 }); await tick(p, 300); await tab(p, 'book');
    await p.click('#wrList [data-a="add"]'); await p.fill('#wrfFrom', '50'); await p.fill('#wrfTo', '20'); await p.click('.wr-form [data-a="submit"]'); await tick(p, 100);
    ok((await p.locator('#wrfMsg').innerText()).includes('بعد أول صفحة'));
    await p.fill('#wrfTo', '500'); await p.click('.wr-form [data-a="submit"]'); await tick(p, 100); ok((await p.locator('#wrfMsg').innerText()).includes('بعد نهاية الكتاب'));
    await p.fill('#wrfFrom', '١٠'); await p.fill('#wrfTo', '٣٠'); await p.click('.wr-form [data-a="submit"]'); await tick(p, 300);
    const r = (await resources(p, ids.l))[0]; eq(r.book, { bookId: 'b1', pageStart: 10, pageEnd: 30 }); eq(r.title, 'كتاب الكيمياء');
    await p.click('[data-a="open"]'); await tick(p, 100);
    eq(await p.evaluate(() => __rd), [['open', 'b1'], ['page', 10]], 'opens at range start when current page (5) is outside the range');
    eq((await resources(p, ids.l))[0].status, 'doing');
    await p.evaluate(() => { booksState.list[0].currentPage = 22 }); await p.evaluate(() => { __rd.length = 0 });
    await p.click('[data-a="open"]'); await tick(p, 100); eq(await p.evaluate(() => __rd), [['open', 'b1']], 'opens at current page when inside the range (book position is the book record\'s)');
    await p.click('[data-a="pinp"]'); await tick(p, 300); await tab(p, 'note');
    const chip = p.locator('.ls-editor-root a.ls-link[href*="?p=22"]'); eq(await chip.count(), 1); eq(await chip.innerText(), '📖 ص 22');
    await p.evaluate(() => { __rd.length = 0; booksState.list[0].currentPage = 3 }); await chip.click(); await tick(p, 200);
    eq(await p.evaluate(() => __rd), [['open', 'b1'], ['page', 22]], 'chip opens the book at the anchored page'); eq(await p.locator('#wrt-book').getAttribute('aria-selected'), 'true');
  });
  await T('BOOK-2. مصدر مفقود: الكتاب اتحذف من المكتبة ⇒ علامة واضحة، مش بيتحسب، ومفيش حذف بيانات', async p => {
    await p.evaluate(STUB_READER); const ids = await seed(p); await addBook(p, {}); await tick(p, 300);
    await addRes(p, bookRes(ids.l, { book: { bookId: 'b1', pageStart: 1, pageEnd: 10 }, status: 'done' })); await addRes(p, linkRes(ids.l, { status: 'todo' })); await tick(p, 300);
    ok((await p.locator('#wrHead').innerText()).includes('٥٠٪'), 'before: 1 of 2 done = 50%: ' + await p.locator('#wrHead').innerText());
    await W(p, async () => { await dbDelete('books', 'b1'); booksState.list = []; await WirdResources.reloadCache(); await __WIRD_STUDY_APP__.repo.emit({ type: 'resources', lessonId: null }) }); await tick(p, 300);
    await tab(p, 'book'); const card = p.locator('.wr-card.wr-missing'); eq(await card.count(), 1); ok((await card.innerText()).includes('مصدر مفقود'));
    eq(await card.locator('[data-a="open"]').count(), 0, 'no open button for missing source'); eq(await card.locator('[data-a="del"]').count(), 1, 'can still remove the reference');
    eq((await resources(p, ids.l)).length, 2, 'reference kept in storage');
    const head = await p.locator('#wrHead').innerText(); ok(head.includes('٠٪') && head.includes('٠ من ١'), 'missing source excluded from denominator: ' + head);
    await W(p, () => __WIRD_STUDY_APP__.open({ kind: 'lesson', id: __WIRD_STUDY_APP__.route.id })); await tick(p, 300); await tab(p, 'book'); eq(await p.locator('.wr-card.wr-missing').count(), 1, 'still flagged after reopening');
  });

  /* ================= الروابط ================= */
  await T('LINK-1. رابط خارجي: تحقق بروتوكول، يوتيوب ⇒ توجيه لتبويب الفيديو، فتح noopener، تعديل وحذف', async p => {
    const ids = await seed(p); await tick(p, 300); await tab(p, 'link');
    const tryUrl = async (u, re) => { await p.click('#wrList [data-a="add"]'); await p.fill('#wrfUrl', u); await p.click('.wr-form [data-a="submit"]'); await tick(p, 100); ok((await p.locator('#wrfMsg').innerText()).includes(re), u + ' → ' + await p.locator('#wrfMsg').innerText()); await p.click('.wr-form [data-a="cancel"]') };
    await tryUrl('javascript:alert(1)', 'http أو https'); await tryUrl('ftp://example.com/a', 'http أو https'); await tryUrl('https://youtu.be/' + VID, 'رابط يوتيوب'); await tryUrl('', 'الصق');
    eq((await resources(p, ids.l)).length, 0);
    await p.click('#wrList [data-a="add"]'); await p.fill('#wrfUrl', 'example.com/chem?q=1'); await p.click('.wr-form [data-a="submit"]'); await tick(p, 200);
    const r = (await resources(p, ids.l))[0]; eq([r.link.url, r.title], ['https://example.com/chem?q=1', 'example.com']);
    const a = p.locator('.wr-card a[data-a="visit"]'); eq(await a.getAttribute('rel'), 'noopener noreferrer'); eq(await a.getAttribute('target'), '_blank'); eq(await a.getAttribute('href'), 'https://example.com/chem?q=1');
    await p.click('[data-a="edit"]'); await p.fill('#wrfTitle', 'مرجع الكيمياء'); await p.click('.wr-form [data-a="submit"]'); await tick(p, 200);
    eq((await resources(p, ids.l))[0].title, 'مرجع الكيمياء'); await p.click('[data-a="done"]'); await tick(p, 200); eq((await resources(p, ids.l))[0].status, 'done');
    await p.click('[data-a="del"]'); await p.click('#confirmOkBtn'); await tick(p, 200); eq((await resources(p, ids.l)).length, 0);
  });

  /* ================= دورة حياة الدرس: سلة/استرجاع/حذف نهائي ================= */
  await T('TRASH-1. حذف الدرس ⇒ مصادره في نفس الدفعة، تختفي، والاسترجاع بيرجعها (وحذف الوحدة والمادة بالمثل)', async p => {
    const ids = await seed(p, { open: false }); const l2 = await more(p, ids);
    const r1 = await addRes(p, vidRes(ids.l)), r2 = await addRes(p, linkRes(ids.l)), r3 = await addRes(p, linkRes(l2, { url: 'https://example.com/z' }));
    const raw = () => p.evaluate(() => __WIRD_STUDY_APP__.backend.getAll('resources'));
    const batch = await W(p, l => __WIRD_STUDY_APP__.repo.deleteLesson(l), ids.l);
    let all = await raw(); const del = all.filter(r => r.deletedAt); eq(del.map(r => r.id).sort(), [r1.id, r2.id].sort()); ok(del.every(r => r.deleteBatch === batch), 'same delete batch as the lesson');
    eq(all.find(r => r.id === r3.id).deletedAt, null, 'other lessons untouched'); eq((await resources(p, ids.l)).length, 0, 'hidden while deleted');
    eq((await W(p, () => __WIRD_STUDY_APP__.repo.listAllResources())).length, 1);
    await W(p, b => __WIRD_STUDY_APP__.repo.restoreBatch(b), batch); all = await raw(); ok(all.every(r => !r.deletedAt && !r.deleteBatch), 'restored'); eq((await resources(p, ids.l)).length, 2);
    // حذف وحدة كاملة: دروسها كلها + مصادرها، وبعدين استرجاع
    const b2 = await W(p, u => __WIRD_STUDY_APP__.repo.deleteUnit(u), ids.u); all = await raw(); ok(all.length === 3 && all.every(r => r.deletedAt && r.deleteBatch === b2), 'unit delete cascades to resources');
    await W(p, b => __WIRD_STUDY_APP__.repo.restoreBatch(b), b2); ok((await raw()).every(r => !r.deletedAt), 'unit restore cascades');
    const b3 = await W(p, s => __WIRD_STUDY_APP__.repo.deleteSubject(s), ids.s); ok((await raw()).every(r => r.deletedAt && r.deleteBatch === b3), 'subject delete cascades');
    // الحذف السابق لدرس لوحده بيحتفظ بدفعته عند حذف وحدته لاحقًا
    await W(p, b => __WIRD_STUDY_APP__.repo.restoreBatch(b), b3);
    const bl = await W(p, l => __WIRD_STUDY_APP__.repo.deleteLesson(l), ids.l); await W(p, u => __WIRD_STUDY_APP__.repo.deleteUnit(u), ids.u);
    all = await raw(); eq(all.filter(r => r.lessonId === ids.l).map(r => r.deleteBatch), [bl, bl], 'earlier delete batch preserved');
    // حذف نهائي
    await W(p, b => __WIRD_STUDY_APP__.repo.purgeBatch(b), bl); all = await raw(); eq(all.map(r => r.lessonId).sort(), [l2], 'purge removes only that lesson\'s resources (the unit batch still holds l2)');
    await W(p, () => __WIRD_STUDY_APP__.repo.emptyTrash()); eq((await raw()).length, 0, 'empty trash removes the rest');
  });
  await T('TRASH-2. السلة في الواجهة: حذف الدرس من الشريط الجانبي ثم استرجاعه من سلة المحذوفات بيرجّع مصادره', async p => {
    const ids = await seed(p, { open: false }); await addRes(p, vidRes(ids.l)); await openLesson(p, ids.l);
    await W(p, async l => { await __WIRD_STUDY_APP__.repo.deleteLesson(l); await __WIRD_STUDY_APP__.reloadTree() }, ids.l); await tick(p, 300);
    const trash = await W(p, () => __WIRD_STUDY_APP__.repo.listTrash()); eq(trash.length, 1); eq(trash[0].kind, 'lesson');
    await W(p, b => __WIRD_STUDY_APP__.repo.restoreBatch(b), trash[0].batchId); await W(p, () => __WIRD_STUDY_APP__.reloadTree()); await openLesson(p, ids.l);
    eq(await p.locator('#wrt-video .wr-n').innerText(), '١', 'resource count back after restore');
  });
  await T('TRASH-3. نقل الدرس/الوحدة لمادة تانية بيحدّث subjectId للمصادر (زي دفتر الأخطاء)', async p => {
    const ids = await seed(p, { open: false }); await addRes(p, vidRes(ids.l));
    const s2 = await W(p, async () => { const a = __WIRD_STUDY_APP__, s = await a.repo.createSubject('مادة ثانية'), u = await a.repo.createUnit(s.id, 'وحدة ٢'); await a.reloadTree(); return { s: s.id, u: u.id } });
    await W(p, ([l, u]) => __WIRD_STUDY_APP__.repo.moveLesson(l, u, null), [ids.l, s2.u]);
    eq((await resources(p, ids.l))[0].subjectId, s2.s, 'moveLesson');
    await W(p, ([u, s]) => __WIRD_STUDY_APP__.repo.moveUnit(u, s, null), [s2.u, ids.s]);
    eq((await resources(p, ids.l))[0].subjectId, ids.s, 'moveUnit');
    eq(await W(p, async l => (await __WIRD_STUDY_APP__.repo.getLessonMeta(l)).rev, ids.l), 1, 'lesson rev untouched by resources');
  });

  /* ================= تصدير / استيراد ================= */
  const bk = {
    make: p => p.evaluate(async () => { const a = __WIRD_STUDY_APP__, z = await a.zip(); return Array.from(new Uint8Array(await (await __WIRD_STUDY__.backup.createBackup(a.repo, z, { includeMarkdown: true })).arrayBuffer())) }),
    apply: (p, bytes, mode, strip) => p.evaluate(async ([bytes, mode, strip]) => {
      const a = __WIRD_STUDY_APP__, z = await a.zip(), blob = new Blob([new Uint8Array(bytes)]);
      let src = blob; if (strip) { const rd = await z.reader(blob); src = { names: () => rd.names().filter(n => n !== 'data/resources.json'), has: n => n !== 'data/resources.json' && rd.has(n), readText: n => rd.readText(n), readBlob: (n, m) => rd.readBlob(n, m) } }
      const ins = await __WIRD_STUDY__.backup.inspectBackup(z, src); const out = await __WIRD_STUDY__.backup.applyBackup(a.repo, ins, { mode }); return { out, warnings: ins.warnings, n: (ins.data.resources || []).length }
    }, [bytes, mode, strip]),
    raw: p => p.evaluate(() => __WIRD_STUDY_APP__.backend.getAll('resources')),
  };
  await T('EXP-1. تصدير ثم استيراد (استبدال): المصادر والشرائح بترجع كما هي + الملف فيه data/resources.json', async p => {
    const ids = await seed(p, { open: false }); const v = await addRes(p, vidRes(ids.l, { video: { startSec: 5, endSec: 50 }, status: 'doing' })), b = await addRes(p, bookRes(ids.l, { book: { bookId: 'b1', pageStart: 1 } })), k = await addRes(p, linkRes(ids.l));
    await W(p, async ([l, href]) => { await __WIRD_STUDY_APP__.repo.saveLessonDoc(l, { type: 'doc', content: [{ type: 'paragraph', content: [{ type: 'text', text: '▶ 00:07', marks: [{ type: 'link', attrs: { href } }] }] }] }) }, [ids.l, 'wird-res://' + v.id + '?t=7']);
    const bytes = await bk.make(p); const names = await W(p, async bytes => { const z = await __WIRD_STUDY_APP__.zip(); return (await z.reader(new Blob([new Uint8Array(bytes)]))).names() }, bytes); ok(names.includes('data/resources.json'), 'archive has resources.json');
    const before = await bk.raw(p); await W(p, async () => { for (const r of await __WIRD_STUDY_APP__.repo.listAllResources()) await __WIRD_STUDY_APP__.repo.removeResource(r.id) }); eq((await bk.raw(p)).length, 0);
    const r = await bk.apply(p, bytes, 'replace'); eq(r.n, 3); eq((await bk.raw(p)).sort((x, y) => x.id < y.id ? -1 : 1), before.sort((x, y) => x.id < y.id ? -1 : 1), 'identical records after replace');
    ok(JSON.stringify(await docOf(p, ids.l)).includes('wird-res://' + v.id + '?t=7'), 'anchor kept');
  });
  await T('EXP-2. استيراد دمج: الأحدث يكسب، ومفيش حذف، والمصادر المحلية الأحدث بتفضل', async p => {
    const ids = await seed(p, { open: false }); const v = await addRes(p, vidRes(ids.l, { title: 'قديم' })), k = await addRes(p, linkRes(ids.l, { title: 'رابط أصلي' }));
    const bytes = await bk.make(p);
    await W(p, async ([id, id2]) => { const r = __WIRD_STUDY_APP__.repo; const a = await r.getResource(id); await r.saveResource({ ...a, title: 'محلي أحدث' }); const e = await r.getResource(id2); await r.removeResource(id2); await r.saveResource({ ...e, id: 'res_local_only', title: 'محلي فقط' }) }, [v.id, k.id]);
    const s = await W(p, () => { return null });
    await p.evaluate(() => new Promise(r => setTimeout(r, 30)));
    const r = await bk.apply(p, bytes, 'merge'); const all = await bk.raw(p);
    eq(all.find(x => x.id === v.id).title, 'محلي أحدث', 'local newer wins'); ok(all.some(x => x.id === 'res_local_only'), 'local-only kept (merge never deletes)'); ok(all.some(x => x.id === k.id), 'missing local record added from backup');
  });
  await T('EXP-3. نسخ (copy): معرّفات جديدة للمصادر والدروس، والشرائح داخل الملخص بتتعدّل لتشاور على النسخة الجديدة', async p => {
    const ids = await seed(p, { open: false }); const v = await addRes(p, vidRes(ids.l));
    await W(p, async ([l, href]) => { await __WIRD_STUDY_APP__.repo.saveLessonDoc(l, { type: 'doc', content: [{ type: 'paragraph', content: [{ type: 'text', text: '▶ 00:07', marks: [{ type: 'link', attrs: { href } }] }, { type: 'text', text: ' ملاحظة' }] }] }, { snapshot: 'manual' }) }, [ids.l, 'wird-res://' + v.id + '?t=7']);
    const bytes = await bk.make(p); await bk.apply(p, bytes, 'copy'); const all = await bk.raw(p); eq(all.length, 2);
    const nu = all.find(x => x.id !== v.id); ok(nu.lessonId !== ids.l, 'new lesson id'); ok(nu.subjectId !== ids.s, 'new subject id');
    const lessons = await W(p, async () => (await __WIRD_STUDY_APP__.repo.dump()).docs); const d = lessons.find(x => x.id === nu.lessonId);
    ok(JSON.stringify(d.doc).includes('wird-res://' + nu.id + '?t=7'), 'anchor remapped to the copied resource'); ok(!JSON.stringify(d.doc).includes(v.id), 'no pointer to the original resource');
    const orig = lessons.find(x => x.id === ids.l); ok(JSON.stringify(orig.doc).includes(v.id), 'original untouched');
    const vers = await W(p, async () => (await __WIRD_STUDY_APP__.repo.dump()).versions); ok(vers.some(x => JSON.stringify(x.doc).includes('wird-res://' + nu.id)), 'version history anchors remapped too');
  });
  await T('EXP-4. توافق: نسخة احتياطية قديمة من غير resources.json بتتفتح، ومصادر تالفة بتتخطّى بتحذير', async p => {
    const ids = await seed(p, { open: false }); await addRes(p, linkRes(ids.l)); const bytes = await bk.make(p);
    const r = await bk.apply(p, bytes, 'replace', true); eq(r.n, 0); ok((await bk.raw(p)).length === 0, 'old-format backup restores lessons without resources'); eq(await W(p, () => __WIRD_STUDY_APP__.repo.loadTree().then(t => t.lessons.length)), 1);
    // ملف resources.json فيه مصادر غلط
    const bad = await W(p, async ([lid]) => {
      const a = __WIRD_STUDY_APP__, z = await a.zip(), blob = new Blob([new Uint8Array(0)]); const rd = { names: () => ['manifest.json', 'data/resources.json'], has: () => true };
      return null }, [ids.l]);
    const out = await W(p, async ([lid]) => {
      const a = __WIRD_STUDY_APP__, z = await a.zip(), good = await __WIRD_STUDY__.backup.createBackup(a.repo, z, {}), rd0 = await z.reader(good);
      const bad = [{ id: 'ok1', lessonId: lid, type: 'link', title: 't', link: { url: 'https://example.com' } }, { id: 'x1', lessonId: lid, type: 'link', link: { url: 'javascript:alert(1)' } }, { id: 'x2', lessonId: 'nolesson', type: 'link', link: { url: 'https://a.com' } }, { id: 'x3', lessonId: lid, type: 'video', video: { youtubeVideoId: 'bad' } }, { id: 'x4', lessonId: lid, type: 'weird' }, { id: 'x5', lessonId: lid, type: 'book', book: {} }, 5, null];
      const src = { names: () => rd0.names(), has: n => rd0.has(n), readText: async n => n === 'data/resources.json' ? JSON.stringify(bad) : rd0.readText(n), readBlob: (n, m) => rd0.readBlob(n, m) };
      const ins = await __WIRD_STUDY__.backup.inspectBackup(z, src); return { ids: ins.data.resources.map(r => r.id), w: ins.warnings }
    }, [ids.l]);
    eq(out.ids, ['ok1']); ok(out.w.some(x => /Skipped 7 resource/.test(x)), JSON.stringify(out.w));
  });

  /* ================= التعارض / الإصدارات ================= */
  await T('REV-1. تعارض إصدارات المصدر (ConflictError) + إضافة مصدر مبتغيّرش rev الدرس + حفظ الملخص بـ expectedRev شغّال', async p => {
    const ids = await seed(p, { open: false }); const r = await addRes(p, linkRes(ids.l));
    const out = await W(p, async ([r]) => {
      const repo = __WIRD_STUDY_APP__.repo, a = await repo.saveResource({ ...r, title: 'ب' }, { expectedRev: r.rev });
      let err = null; try { await repo.saveResource({ ...r, title: 'ج' }, { expectedRev: r.rev }) } catch (e) { err = e.name }
      const forced = await repo.saveResource({ ...r, title: 'د' }, { force: true });
      let nf = null; try { await repo.saveResource({ ...r, id: 'x', lessonId: 'missing' }) } catch (e) { nf = e.name }
      let bad = null; try { await repo.saveResource({ ...r, link: { url: 'javascript:1' } }) } catch (e) { bad = e.message }
      return { revs: [r.rev, a.rev, forced.rev], err, nf, bad, title: (await repo.getResource(r.id)).title }
    }, [r]);
    eq(out.revs, [1, 2, 3]); eq(out.err, 'ConflictError'); eq(out.nf, 'NotFoundError'); eq(out.bad, 'Invalid resource'); eq(out.title, 'د');
    const doc = await W(p, async l => { const repo = __WIRD_STUDY_APP__.repo, m = await repo.getLessonMeta(l); const s = await repo.saveLessonDoc(l, { type: 'doc', content: [{ type: 'paragraph', content: [{ type: 'text', text: 'نص' }] }] }, { expectedRev: m.rev }); let e = null; try { await repo.saveLessonDoc(l, { type: 'doc', content: [] }, { expectedRev: m.rev }) } catch (x) { e = x.name } return { before: m.rev, after: s.rev, e } }, ids.l);
    eq(doc, { before: 1, after: 2, e: 'ConflictError' }, 'note conflict detection unchanged');
  });

  /* ================= تقدّم الدرس/الوحدة/المادة والشريط الجانبي ================= */
  await T('PROG-1. رأس الدرس: الجاهزية والحالة (لم يبدأ/جاري/مراجعة/متقن) بحساب حتمي + progressbar بعنوان', async p => {
    await p.evaluate(STUB_READER); const ids = await seed(p, { open: false }); await addBook(p, {});
    const v = await addRes(p, vidRes(ids.l)), k = await addRes(p, linkRes(ids.l)), bkr = await addRes(p, bookRes(ids.l)), k2 = await addRes(p, linkRes(ids.l, { url: 'https://example.com/b' }));
    await openLesson(p, ids.l); const head = () => p.locator('#wrHead').innerText();
    ok((await head()).includes('لم يبدأ') && (await head()).includes('٠٪'), await head());
    await addRes(p, { ...v, status: 'doing' }); await tick(p, 200); ok((await head()).includes('جاري'), 'doing');
    const bar = p.locator('#wrHead [role="progressbar"]'); eq(await bar.getAttribute('aria-valuenow'), '0'); ok((await bar.getAttribute('aria-label')).includes('جاهزية الدرس'));
    for (const r of [v, k, bkr]) { const cur = await W(p, id => __WIRD_STUDY_APP__.repo.getResource(id), r.id); await addRes(p, { ...cur, status: 'done' }); } await tick(p, 200);
    ok((await head()).includes('٧٥٪') && (await head()).includes('٣ من ٤'), await head()); eq(await bar.getAttribute('aria-valuenow'), '75');
    const cur = await W(p, id => __WIRD_STUDY_APP__.repo.getResource(id), k2.id); await addRes(p, { ...cur, status: 'done' }); await tick(p, 200);
    ok((await head()).includes('متقن') && (await head()).includes('١٠٠٪'), 'mastered: ' + await head());
    await W(p, async l => { const a = __WIRD_STUDY_APP__; await a.repo.saveMistake({ lessonId: l, subjectId: a.lesson(l).subjectId, unitId: a.lesson(l).unitId, title: 'خطأ مفتوح', createdAt: 5, lastSeenAt: 5, recurrenceCount: 1, examWarningTag: '', status: 'open' }) }, ids.l); await tick(p, 300);
    ok((await head()).includes('مراجعة'), 'open mistake ⇒ review: ' + await head());
    ok((await p.locator('#wrHead .wr-help').textContent()).includes('منفصل عن إحصائيات العادات'), 'rules documented in the UI');
  });
  await T('SIDE-1. الشريط الجانبي: شارات 🎬 ٢ 📚 ١ للدرس + تقدّم الوحدة والمادة (متوسط الدروس) بـ aria-label', async p => {
    await p.evaluate(STUB_READER); const ids = await seed(p, { open: false }); await addBook(p, {}); const l2 = await more(p, ids); const l3 = await more(p, ids, { lesson: 'درس بلا مصادر' });
    await addRes(p, vidRes(ids.l, { status: 'done' })); await addRes(p, vidRes(ids.l, { video: { startSec: 1 } })); await addRes(p, bookRes(ids.l)); await addRes(p, linkRes(l2, { status: 'done' }));
    await openLesson(p, ids.l); await W(p, () => WirdResources.reloadCache()); await tick(p, 300);
    await W(p, () => { const a = __WIRD_STUDY_APP__; ['subject', 'unit'].forEach(() => {}); a.sidebar.setExpanded(a.route.id && a.lesson(a.route.id).subjectId, true); a.sidebar.setExpanded(a.lesson(a.route.id).unitId, true); a.sidebar.render() }); await tick(p, 200);
    const badges = await p.evaluate(() => [...document.querySelectorAll('.ls-row .wr-bdg')].map(b => [b.closest('.ls-row').dataset.kind, b.textContent, b.getAttribute('aria-label')]));
    const by = k => badges.filter(b => b[0] === k);
    eq(by('lesson').map(b => b[1]).sort(), ['🎬 ٢ 📚 ١', '🔗 ١'].sort(), 'lesson badges'); ok(by('lesson').some(b => /3 مصادر.*جاهزية 33٪/.test(b[2])), JSON.stringify(by('lesson')));
    // درس١: ١ من ٣ (٣٣٪)، درس٢: ١ من ١ (١٠٠٪)، درس٣ بلا مصادر ⇒ مش بيدخل ⇒ المتوسط ٦٧٪
    eq(by('unit').map(b => b[1]), ['٦٧٪']); eq(by('subject').map(b => b[1]), ['٦٧٪']); ok(by('unit')[0][2].includes('67'), by('unit')[0][2]);
    eq(await W(p, ([u]) => WirdResources.treeProgress('unit', u).pct, [ids.u]), 67);
  });

  /* ================= المهام ================= */
  await T('TASK-1. «جدولة الدرس»: مهمة في نظام العادات بمرجع الدرس بس، مفيش تكرار، والإنجازين منفصلين', async p => {
    const ids = await seed(p); await tick(p, 300); const r = await addRes(p, linkRes(ids.l)); await tick(p, 200);
    await p.click('[data-a="sched"]'); await tick(p, 100);
    const t1 = await W(p, () => { const d = todayISO(); return JSON.parse(JSON.stringify(H.oneoffs[d] || [])) });
    eq(t1.length, 1); eq(t1[0].lessonRef, { lessonId: ids.l, resourceId: null }); ok(t1[0].name.includes('الروابط الكيميائية')); eq(t1[0].done, false);
    ok(!('lessonId' in t1[0]) && !('title' in t1[0]) && !('doc' in t1[0]), 'only a reference is stored on the task');
    await p.click('[data-a="sched"]'); await tick(p, 100); eq(await W(p, () => H.oneoffs[todayISO()].length), 1, 'no duplicate task');
    await W(p, () => { const o = H.oneoffs[todayISO()][0]; o.done = true; o.tier = 2; hSave() }); await tick(p, 100);
    eq((await resources(p, ids.l))[0].status, 'todo', 'task completion does not complete the lesson resources');
    await W(p, async id => { const repo = __WIRD_STUDY_APP__.repo, c = await repo.getResource(id); await repo.saveResource({ ...c, status: 'done' }) }, r.id);
    eq(await W(p, () => H.oneoffs[todayISO()].map(o => o.done)), [true], 'resource completion leaves the task record alone');
    await W(p, async ([l]) => { await __WIRD_STUDY_APP__.repo.renameLesson(l, 'اسم جديد'); await __WIRD_STUDY_APP__.reloadTree() }, [ids.l]); await tick(p, 300);
    ok((await W(p, () => H.oneoffs[todayISO()][0].name)).includes('اسم جديد'), 'task name follows lesson title');
  });

  /* ================= اللوحة الرئيسية ================= */
  await T('UNI-1. الشجرة الموحّدة: صف العنصر تحت درسه + البحث من الشريط الجانبي بيلاقي عناوين المصادر ويفتحها', async p => {
    const ids = await seed(p, { open: false }); await addRes(p, linkRes(ids.l, { title: 'مرجع منتهي', status: 'done' })); const v = await addRes(p, vidRes(ids.l, { title: 'شرح الروابط التساهمية', status: 'doing' }));
    await openLesson(p, ids.l); await W(p, () => __WIRD_STUDY_APP__.close()); await W(p, () => WirdResources.reloadCache()); await tick(p, 200);
    await p.click('.tab[data-view="view-lessons"]'); await tick(p, 900); ok(await p.locator('.ls-row-item').count() >= 2, 'item rows under the lesson'); ok(!(await p.locator('#lrnNav').count()), 'no hub bar');
    if (!(await W(p, () => __WIRD_STUDY_APP__.root.classList.contains('side-open')))) { await p.click('.ls-menu-btn'); await tick(p, 300) } // الشريط الجانبي درج على الموبايل: نفتحه الأول (لمسة واحدة)
    await p.click('.ls-side-search'); await p.fill('.ls-palette-input', 'التساهمية'); await tick(p, 300); const res = p.locator('.ls-palette-item', { hasText: '🎬' }); eq(await res.count(), 1);
    ok((await res.innerText()).includes('شرح الروابط التساهمية'));
    await res.click(); await tick(p, 500);
    ok(await W(p, () => __WIRD_STUDY_APP__.isOpen), 'workspace open'); eq(await W(p, () => __WIRD_STUDY_APP__.route.id), ids.l); eq(await p.locator('.wr-ytw').count(), 1, 'search result opens the lesson and the video');
    ok((await p.locator('#wrInfo').innerText()).includes('شرح الروابط التساهمية'));
  });

  /* ================= التسمية ================= */
  await T('REN-1. «دروسي» ⇒ «منهجي» في كل حتة ظاهرة (التبويب، العنوان، الترحيب، الشريط الجانبي، اللوحة الرئيسية)', async p => {
    eq(await p.locator('.tab[data-view="view-lessons"]').innerText(), '📖 منهجي');
    await openApp(p); await tick(p, 100);
    ok(true);
    ok(true);
    ok((await p.locator('.ls-landing h2').innerText()).startsWith('منهجي — '), await p.locator('.ls-landing h2').innerText());
    await W(p, () => __WIRD_STUDY_APP__.open()); await tick(p, 200);
    eq(await p.locator('.ls-side-brand').innerText(), '📖 منهجي'); eq(await p.locator('.ls-ws').getAttribute('aria-label'), 'منهجي');
    const txt = await p.evaluate(() => document.body.innerText + ' ' + [...document.querySelectorAll('[aria-label],[title],[placeholder]')].map(e => (e.getAttribute('aria-label') || '') + (e.title || '') + (e.placeholder || '')).join(' '));
    ok(!txt.includes('دروسي'), 'no remaining «دروسي» in visible text/attributes');
    const html = fs.readFileSync(INDEX, 'utf8'); ok(!html.includes('دروسي'), 'no «دروسي» left anywhere in index.html'); ok(!fs.readFileSync(path.join(ROOT, 'README-OFFLINE-AR.txt'), 'utf8').includes('دروسي'), 'README renamed');
  });

  /* ================= التصميم المتجاوب ================= */
  await T('LAY-1. ٣٦٠px: مفيش scroll أفقي في كل حالات الدرس (تبويبات/نماذج/مشغّل/مصدر مفقود) + أهداف اللمس ≥ ٤٤px', async p => {
    await p.evaluate(STUB_READER); const ids = await seed(p, { lesson: 'عنوان درس طويل جدًا جدًا جدًا لاختبار الالتفاف في الشاشات الصغيرة وعدم ظهور scroll أفقي' }); await addBook(p, { title: 'كتاب باسم طويل جدًا جدًا جدًا جدًا لاختبار الالتفاف في الشاشات الصغيرة' });
    await addRes(p, vidRes(ids.l, { title: 'عنوان فيديو طويل جدًا جدًا جدًا جدًا لاختبار الالتفاف في الشاشات الصغيرة بدون مشاكل', video: { startSec: 5, endSec: 3700 } })); await addRes(p, bookRes(ids.l, { book: { bookId: 'b1', pageStart: 1, pageEnd: 50 } })); await addRes(p, bookRes(ids.l, { book: { bookId: 'gone' } })); await addRes(p, linkRes(ids.l, { url: 'https://example.com/a/very/long/path/that/keeps/going/and/going/for/a/long/time?with=query&and=more', title: 'https://example.com/a/very/long/path/that/keeps/going' }));
    await W(p, () => WirdResources.reloadCache()); await tick(p, 400); await noHScroll(p, 'note');
    for (const t of ['video', 'book', 'link']) { await tab(p, t); await noHScroll(p, t); ok((await smallTargets(p, '.wr button, .wr a.ls-btn')).length === 0, t + ' small targets: ' + await smallTargets(p, '.wr button, .wr a.ls-btn')); await p.click('#wrList [data-a="add"]'); await noHScroll(p, t + ' form'); ok((await smallTargets(p, '.wr-form button, .wr-form input, .wr-form select')).length === 0, t + ' form targets: ' + await smallTargets(p, '.wr-form button, .wr-form input, .wr-form select')); await p.click('.wr-form [data-a="cancel"]') }
    await tab(p, 'video'); await p.click('[data-a="play"]'); await tick(p, 100); await noHScroll(p, 'player'); ok((await smallTargets(p, '.wr-player button, .wr-player a.ls-btn, .wr-player input')).length === 0, 'player targets ' + await smallTargets(p, '.wr-player button, .wr-player a.ls-btn, .wr-player input'));
    await p.setViewportSize({ width: 320, height: 640 }); await tick(p, 100); await noHScroll(p, '320px player');
  });

  /* ================= انحدار: ميزات الدروس الأصلية ================= */
  await T('REG-1. ميزات الدروس الأصلية شغّالة: إنشاء مادة/وحدة/درس من الواجهة + تعديل العنوان والنص + بحث Ctrl+K + سجل الإصدارات + تصدير', async p => {
    await openApp(p); await W(p, () => __WIRD_STUDY_APP__.open()); await tick(p, 300);
    const ask = async v => { await p.waitForSelector('.ls-modal input'); await p.fill('.ls-modal input', v); await p.keyboard.press('Enter'); await tick(p, 400) };
    const drawer = async () => { if (!(await p.evaluate(() => __WIRD_STUDY_APP__.root.classList.contains('side-open')))) { await p.click('.ls-menu-btn'); await tick(p, 300) } };
    await p.click('.ls-ws .ls-view button:has-text("مادة جديدة")'); await ask('الأحياء');                       // من شاشة الترحيب (مفيش مواد لسه)
    await drawer(); await p.click('.ls-row[data-kind="subject"] [data-act="add"]'); await ask('الخلية');
    await drawer(); await p.click('.ls-row[data-kind="unit"] [data-act="add"]'); await ask('الميتوكوندريا'); await tick(p, 500);
    eq(await p.evaluate(() => __WIRD_STUDY_APP__.tree.lessons.map(l => l.title)), ['الميتوكوندريا'], 'created via UI'); ok(await p.locator('#wrTabs').count() === 1, 'new lesson shows the segmented control');
    await p.fill('.ls-title', 'الميتوكوندريا — محطة الطاقة'); await p.keyboard.press('Enter'); await tick(p, 300);
    await p.click('.ctx-seg [data-m="sum"]'); await tick(p, 400);   // الدرس الجديد من الشريط الجانبي بيفتح في وضع النوت — نرجع للملخص زي المستخدم
    await p.click('.ls-editor-root'); await p.keyboard.type('الميتوكوندريا تنتج ATP'); await tick(p, 2500); await W(p, () => __WIRD_STUDY_APP__.view.flush());
    const m = await W(p, async () => { const a = __WIRD_STUDY_APP__, l = a.tree.lessons[0]; return { t: (await a.repo.getLessonMeta(l.id)).title, d: JSON.stringify((await a.repo.loadLesson(l.id)).record.doc) } });
    eq(m.t, 'الميتوكوندريا — محطة الطاقة'); ok(m.d.includes('تنتج ATP'), 'typed text saved');
    await p.keyboard.press('Control+s'); await tick(p, 500); const vs = await W(p, l => __WIRD_STUDY_APP__.repo.listVersions(l), await W(p, () => __WIRD_STUDY_APP__.tree.lessons[0].id)); ok(vs.length >= 1, 'snapshot created');
    await W(p, () => __WIRD_STUDY_APP__.view.openHistory()); await tick(p, 500); ok(await p.locator('.ls-history-body').count() === 1 && (await p.locator('.ls-history-body').innerText()).trim().length > 0, 'history dialog opens with saved versions'); await p.keyboard.press('Escape'); await tick(p, 200);
    await p.keyboard.press('Control+k'); await tick(p, 200); await p.fill('.ls-palette-input', 'محطة'); await tick(p, 800); ok(await p.locator('.ls-palette-item').count() >= 1, 'palette search finds the lesson'); await p.keyboard.press('Escape');
    const bytes = await bk.make(p); ok(bytes.length > 100, 'export works'); await tick(p, 100);
  });

  server.close();
  await browser.close();
  let pass = 0;
  for (const [n, o, m] of results) { console.log((o ? '✔ ' : '✘ ') + n + (o ? '' : '\n      → ' + m)); if (o) pass++ }
  console.log('\n' + pass + '/' + results.length + ' passed');
  process.exit(pass === results.length ? 0 : 1);
})().catch(e => { console.error(e); process.exit(2) });
