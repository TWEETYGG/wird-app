// اختبارات ميزة الكورسات — Playwright + مشغّل يوتيوب مزيّف (mock) + oEmbed مزيّف. بدون أي اتصال حقيقي بيوتيوب.
// التشغيل:  NODE_PATH=$(npm root -g) node tests/courses.test.js [مسار index.html]
const { chromium } = require('playwright');
const path = require('path');
const FILE = path.resolve(process.argv[2] || path.join(__dirname, '..', 'index.html'));
const CHROME = process.env.CHROME || undefined;   // لو مش متحدد، Playwright بيستخدم المتصفح المثبّت عنده
const T0 = new Date('2026-10-29T10:00:00+03:00');
const OEMBED = { title: 'Python للمبتدئين', author_name: 'قناة التعلم', thumbnail_url: 'https://i.ytimg.com/vi/dQw4w9WgXcQ/hqdefault.jpg' };
const FAKE_YT = `
  window.__yt={players:[],t:0,dur:600,rate:1,seeks:[],destroyed:0,created:0};
  window.YT={Player:class{
    constructor(id,cfg){this.cfg=cfg;__yt.players.push(this);__yt.created++;
      const el=document.getElementById(id);const f=document.createElement('iframe');f.id=id;f.setAttribute('data-fake','1');el.replaceWith(f);
      setTimeout(()=>cfg.events.onReady({target:this}),0)}
    getCurrentTime(){return __yt.t} getDuration(){return __yt.dur} getPlaybackRate(){return __yt.rate}
    getVideoData(){return {title:'عنوان من المشغّل',author:'قناة المشغّل'}}
    seekTo(t){__yt.t=t;__yt.seeks.push(t)} playVideo(){this.st(1)} pauseVideo(){__yt.pauses=(__yt.pauses||0)+1;this.st(2)} destroy(){__yt.destroyed++}
    st(s){this.cfg.events.onStateChange({data:s})}}};`;
const results = [];
async function T(name, fn, opt = {}) {
  if (process.env.ONLY && !name.includes(process.env.ONLY)) return;
  const ctx = await browser.newContext({ viewport: opt.vp || { width: 390, height: 844 }, locale: 'ar-EG', timezoneId: 'Africa/Cairo' });
  const page = await ctx.newPage(); const errs = []; page.setDefaultTimeout(5000);
  page.on('pageerror', e => errs.push(String(e)));
  await page.route(/^https?:\/\//, r => {
    const u = r.request().url();
    if (opt.oembed !== false && /youtube\.com\/oembed/.test(u)) {
      if (opt.oembed === 404) return r.fulfill({ status: 404, body: 'Not Found' });
      if (opt.oembed === 'offline') return r.abort();
      return r.fulfill({ status: 200, contentType: 'application/json', headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify(OEMBED) });
    }
    return r.abort();
  });
  if (!opt.noYT) await page.addInitScript(FAKE_YT);
  await page.addInitScript(() => { try { if (!localStorage.getItem('wird_mig_v3')) localStorage.setItem('wird_mig_v3', JSON.stringify({ v: 3, ts: 1, reported: true, created: { subject: null, units: [], lessons: [], items: [] } })); } catch (e) {} });
  await page.clock.install({ time: T0 });
  await page.goto('file://' + FILE); await page.clock.runFor(300);
  try { await fn(page); if (errs.length && !opt.allowErrors) throw new Error('page errors: ' + errs.join(' | ')); results.push([name, true]); }
  catch (e) { results.push([name, false, process.env.DEBUG ? e.message.split('\n').slice(0,9).join('\n      ') : e.message.split('\n')[0]]); }
  await ctx.close();
}
const eq = (a, b, m) => { if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error((m || 'eq') + ': expected ' + JSON.stringify(b) + ' got ' + JSON.stringify(a)); };
const ok = (c, m) => { if (!c) throw new Error(m || 'assertion failed'); };
const W = (page, fn, arg) => page.evaluate(fn, arg);
const openTab = async page => { await page.click('.tab[data-view="view-lessons"]'); await page.evaluate(() => WirdUnified.__host()); await page.clock.runFor(50); };
// كورس + فيديو جاهزين بدون واجهة
const seed = (page, o = {}) => page.evaluate(o => {
  const WC = window.WirdCourses, c = WC.createCourse({ title: o.title || 'كورس بايثون', dailyMin: o.dailyMin || 0 });
  const v = WC.upsertVideo({ id: 'dQw4w9WgXcQ', title: 'فيديو طويل', channel: 'قناة', duration: o.dur === 0 ? 0 : (o.dur || 600), metaStatus: 'oembed' });
  const ls = (o.segs || [[0, 0, 'video']]).map(s => { const l = WC.mkLesson({ vid: v.id, title: s[2] === 'video' ? 'الدرس كله' : 'جزء ' + s[0], type: s[2] === 'video' ? 'video' : 'range', start: s[0], end: s[1] }); c.lessons.push(l); return l; });
  WC.save(); return { cid: c.id, lids: ls.map(l => l.id) };
}, o);
const play = async (page, secs, startT = 0) => { // محاكاة تشغيل طبيعي ثانية بثانية
  await page.evaluate(t => { __yt.t = t; __yt.players[0].st(1); }, startT);
  for (let i = 0; i < secs; i++) { await page.evaluate(() => { __yt.t += 1; }); await page.clock.runFor(1000); }
};

let browser;
(async () => {
  browser = await chromium.launch({ ...(CHROME ? { executablePath: CHROME } : {}), args: ['--no-sandbox'] });

  /* ---------- دوال نقية ---------- */
  await T('1-3. محلل روابط يوتيوب: صالح/مرفوض', async p => {
    const f = u => W(p, u => WirdCourses.parseYouTubeUrl(u), u);
    for (const u of ['https://www.youtube.com/watch?v=dQw4w9WgXcQ', 'https://youtu.be/dQw4w9WgXcQ?si=abc', 'https://m.youtube.com/watch?v=dQw4w9WgXcQ&t=90s', 'https://www.youtube.com/shorts/dQw4w9WgXcQ', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'https://www.youtube.com/live/dQw4w9WgXcQ', 'youtube.com/watch?v=dQw4w9WgXcQ'])
      eq((await f(u)).id, 'dQw4w9WgXcQ', u);
    eq((await f('https://youtu.be/dQw4w9WgXcQ?t=1m30s')).start, 90, 'start');
    for (const [u, r] of [['', 'empty'], ['مرحبا بالعالم', 'malformed'], ['https://vimeo.com/123456789', 'domain'], ['https://youtube.com.evil.com/watch?v=dQw4w9WgXcQ', 'domain'], ['https://www.youtube.com/watch?v=short', 'noid'], ['https://www.youtube.com/@channel', 'noid'], ['https://www.youtube.com/playlist?list=PLabc', 'noid'], ['dQw4w9WgXcQ', 'domain'], ['ftp://youtu.be/dQw4w9WgXcQ', 'malformed'], ['javascript:alert(1)', 'malformed']])
      eq((await f(u)).reason, r, u);
  });
  await T('6-7. وقت وحدود الأجزاء والفصول', async p => {
    const r = await W(p, () => { const W = WirdCourses; return {
      t: [W.parseTime('1:30:00'), W.parseTime('15:00'), W.parseTime('٠٥:٣٠'), W.parseTime('90'), W.parseTime('1:75'), W.parseTime('x'), W.parseTime('')],
      f: [W.fmt(900), W.fmt(5400), W.fmt(5400, false), W.fmt(65, true)],
      ok: W.validateSegments([{ title: 'أ', start: 0, end: 900 }, { title: 'ب', start: 900, end: 1920 }], 5400).length,
      neg: W.validateSegments([{ title: 'أ', start: -1, end: 10 }], 100).length,
      rev: W.validateSegments([{ title: 'أ', start: 50, end: 50 }], 100).length,
      big: W.validateSegments([{ title: 'أ', start: 0, end: 200 }], 100).length,
      ovl: W.validateSegments([{ title: 'أ', start: 0, end: 60 }, { title: 'ب', start: 50, end: 100 }], 100).length,
      nan: W.validateSegments([{ title: 'أ', start: NaN, end: 10 }, { title: '', start: 0, end: 5 }], 100).length,
      ch: W.parseChapters('مقدمة\n00:00 مقدمة\n05:30 - الدرس الأول\n05:10 خطأ ترتيب\n1:00:00 بعد النهاية\n12:00 الخاتمة', 3000)
    }; });
    eq(r.t, [5400, 900, 330, 90, null, null, null]); eq(r.f, ['15:00', '1:30:00', '1:30:00', '0:01:05'].map((x, i) => i === 2 ? '1:30:00' : x));
    eq([r.ok, r.neg > 0, r.rev > 0, r.big > 0, r.ovl > 0, r.nan >= 2], [0, true, true, true, true, true]);
    eq(r.ch.chapters.map(c => [c.start, c.end]), [[0, 330], [330, 720], [720, 3000]]); ok(r.ch.warnings.length, 'warning expected');
  });
  await T('11. السحب للأمام لا يُحسب مشاهدة (trackStep)', async p => {
    const r = await W(p, () => { const W = WirdCourses; return [W.trackStep(10, 11, 1, 1), W.trackStep(10, 500, 1, 1), W.trackStep(100, 50, 1, 1), W.trackStep(10, 12, 1, 2), W.trackStep(null, 5, 1, 1), W.trackStep(10, 10, 1, 1)]; });
    eq(r[0].add, [10, 11]); eq(r[1].add, null); ok(r[1].seek); eq(r[2].add, null); eq(r[3].add, [10, 12]); eq(r[4].add, null); eq(r[5].add, null);
  });
  await T('12. حساب تقدّم الدرس/الموديول/الكورس (من غير حساب مرتين)', async p => {
    const r = await W(p, () => {
      const W = WirdCourses, v = { a: { id: 'a', duration: 100, iv: [[0, 50]] }, b: { id: 'b', duration: 300, iv: [] } };
      const L = (vid, s, e, done, type, mod) => ({ id: Math.random() + '', vid, type: type || 'range', start: s, end: e, done, moduleId: mod || null });
      const c1 = { modules: [{ id: 'm1' }], lessons: [L('a', 0, 50, true, 'range', 'm1'), L('a', 50, 100, false, 'range', 'm1'), L('b', 0, 0, false, 'video')] };
      const c2 = { modules: [], lessons: [L('a', 0, 60, true), L('a', 40, 100, true)] };               // متداخلين على 40-60
      const c3 = { modules: [], lessons: [L('a', 0, 50, true), L('zzz', 0, 10, false)] };               // فيديو مفقود مش بيتحسب
      const c4 = { modules: [], lessons: [L('a', 0, 100, true, 'video')] };
      const u = { a: { id: 'a', duration: 0 } };
      return { c1: W.courseProgress(c1, v), m1: W.moduleProgress(c1, v, 'm1'), c2: W.courseProgress(c2, v), c3: W.courseProgress(c3, v), c4: W.courseProgress(c4, v),
        cnt: W.courseProgress({ modules: [], lessons: [L('a', 0, 50, true, 'video'), L('a', 0, 50, false, 'video')] }, u), cov: W.lessonCoverage(c1.lessons[0], v), cov2: W.lessonCoverage(c1.lessons[1], v) };
    });
    eq([r.c1.method, r.c1.pct, r.c1.done, r.c1.total], ['duration', 13, 1, 3]); // 50 من 400 ثانية = 12.5٪ → 13
    eq(r.m1, { done: 1, total: 2, pct: 50 }); eq([r.c2.pct, r.c2.method], [100, 'duration']); eq([r.c3.total, r.c3.pct], [1, 100]);
    eq(r.c4.pct, 100); eq([r.cnt.method, r.cnt.pct], ['count', 50]); eq([r.cov, r.cov2], [1, 0]);
  });

  /* ---------- واجهة: إنشاء كورس وإضافة فيديو ---------- */
  await T('1-2. حالة فارغة + إنشاء كورس + تبويب جديد + باقي التبويبات سليمة', async p => {
    await openTab(p); ok(await p.isVisible('.cr-empty'), 'empty state');
    eq(await p.locator('.tabs .tab:not([hidden])').count(), 6, 'visible tabs'); ok(await p.locator('.tab[data-view="view-habits"]').count() === 1);
    await p.click('[data-a="newc"]'); await p.click('#cfOk'); ok((await p.textContent('.toast, #toastMsg')) !== null);
    ok(await p.isVisible('#cfT'), 'title required keeps modal open');
    await p.fill('#cfT', 'كورس بايثون'); await p.fill('#cfM', '30'); await p.click('#cfOk');
    ok((await p.textContent('.cr-head h2')).includes('كورس بايثون')); ok(await p.isVisible('.cr-empty'), 'empty course state');
    eq(await W(p, () => WirdCourses.C.courses.length), 1);
  });
  await T('3. إضافة فيديو من رابط صالح (oEmbed مزيّف) + كورس جديد حوله + تكرار + رابط غلط', async p => {
    await openTab(p); await p.click('[data-a="addv0"]');
    await p.fill('#avU', 'https://vimeo.com/1'); await p.click('#avGo'); ok((await p.textContent('#avOut')).includes('مش من يوتيوب'));
    await p.fill('#avU', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ'); await p.click('#avGo'); await p.clock.runFor(200);
    eq(await p.inputValue('#avT'), 'Python للمبتدئين'); ok((await p.textContent('#avOut')).includes('قناة التعلم'));
    ok(await p.isVisible('#avD'), 'duration unknown → optional field'); // oEmbed مفيهوش مدة: مفيش اختلاق
    await p.click('#avAdd'); await p.clock.runFor(100);
    const st = await W(p, () => { const C = WirdCourses.C, v = C.videos.dQw4w9WgXcQ; return [C.courses.length, C.courses[0].title, C.courses[0].lessons.length, v.duration || 0, v.metaStatus]; });
    eq(st, [1, 'Python للمبتدئين', 1, 0, 'oembed']);
    await p.click('[data-a="addv"]'); await p.fill('#avU', 'https://youtu.be/dQw4w9WgXcQ'); await p.click('#avGo'); await p.clock.runFor(100); await p.click('#avAdd');
    ok(await p.isVisible('#confirmOverlay.open'), 'duplicate confirm'); await p.click('#confirmCancelBtn');
    eq(await W(p, () => WirdCourses.C.courses[0].lessons.length), 1, 'no silent duplicate');
    await p.click('#avAdd'); await p.click('#confirmOkBtn'); eq(await W(p, () => WirdCourses.C.courses[0].lessons.length), 2, 'confirmed duplicate');
  });
  await T('16/18. فيديو غير متاح (404) + أوفلاين → إدخال يدوي برسالة واضحة', async p => {
    await openTab(p); await p.click('[data-a="addv0"]'); await p.fill('#avU', 'https://youtu.be/AAAAAAAAAAA'); await p.click('#avGo'); await p.clock.runFor(100);
    ok((await p.textContent('#avOut')).includes('خاص أو محذوف')); ok(await p.isVisible('#avT')); eq(await p.inputValue('#avT'), '');
    await p.fill('#avT', 'درس يدوي'); await p.fill('#avD', '10:00'); await p.click('#avAdd');
    eq(await W(p, () => { const v = WirdCourses.C.videos.AAAAAAAAAAA; return [v.title, v.duration, v.metaStatus]; }), ['درس يدوي', 600, 'manual']);
  }, { oembed: 404 });
  await T('18. أوفلاين أثناء جلب البيانات', async p => {
    await openTab(p); await p.click('[data-a="addv0"]'); await p.fill('#avU', 'https://youtu.be/BBBBBBBBBBB'); await p.click('#avGo'); await p.clock.runFor(100);
    ok((await p.textContent('#avOut')).match(/النت|اتصال|دلوقتي/), 'offline/err message'); ok(await p.isVisible('#avT'));
  }, { oembed: 'offline' });

  /* ---------- تقسيم ---------- */
  await T('6-7. محرّر الأجزاء: تقسيم بالتساوي + تحقق + حفظ + الحفاظ على الإكتمال', async p => {
    await openTab(p); const s = await seed(p, { dur: 5400 });
    await W(p, s => { const C = WirdCourses.C, c = C.courses[0]; WirdCourses.V.screen = 'course'; WirdCourses.V.cid = c.id; WirdCourses.render(); }, s);
    await p.click('[data-a="lmenu"]'); await p.click('.cr-menu [data-k="seg"]'); await p.click('#sgT [data-t="r"]'); await p.fill('#sgN', '3'); await p.click('#sgEq');
    eq(await p.locator('.sg-r').count(), 3); eq(await p.inputValue('.sg-r:nth-child(2) .s'), '0:30:00');
    await p.fill('.sg-r:nth-child(1) .e', '40:00'); await p.dispatchEvent('.sg-r:nth-child(1) .e', 'change'); // تداخل مع الجزء الثاني
    ok((await p.textContent('#sgErr')).includes('متداخلين')); ok(await p.isDisabled('#sgOk'), 'save disabled');
    await p.fill('.sg-r:nth-child(1) .e', '30:00'); await p.dispatchEvent('.sg-r:nth-child(1) .e', 'change'); await p.click('#sgOk'); await p.clock.runFor(50);
    eq(await W(p, () => WirdCourses.C.courses[0].lessons.map(l => [l.type, l.start, l.end])), [['range', 0, 1800], ['range', 1800, 3600], ['range', 3600, 5400]]);
    // تعليم الأول مكتمل ثم تغيير الحدود: لازم تحذير، والمطابق يحتفظ بحالته
    await W(p, () => { const c = WirdCourses.C.courses[0]; WirdCourses.setLessonDone(c, c.lessons[0], true, 'manual'); const v = WirdCourses.C.videos.dQw4w9WgXcQ; v.lastPos = 1234; WirdCourses.save(); });
    await p.click('.cr-ls:nth-child(2) [data-a="lmenu"]'); await p.click('.cr-menu [data-k="seg"]'); await p.click('#sgT [data-t="r"]');
    await p.fill('.sg-r:nth-child(1) .e', '25:00'); await p.dispatchEvent('.sg-r:nth-child(1) .e', 'change');
    await p.fill('.sg-r:nth-child(2) .s', '25:00'); await p.dispatchEvent('.sg-r:nth-child(2) .s', 'change'); await p.click('#sgOk');
    ok(await p.isVisible('#confirmOverlay.open'), 'warn before affecting progress'); ok((await p.textContent('#confirmMessage')).includes('إكتمال'));
    await p.click('#confirmOkBtn');
    const r = await W(p, () => { const c = WirdCourses.C.courses[0]; return { done: c.lessons.map(l => l.done), pos: WirdCourses.C.videos.dQw4w9WgXcQ.lastPos }; });
    eq(r.done, [false, false, false]); eq(r.pos, 1234, 'video position retained');
  });
  await T('5.1 فصول من وصف الفيديو: معاينة ثم قبول', async p => {
    await openTab(p); const s = await seed(p, { dur: 1800 });
    await W(p, () => { const c = WirdCourses.C.courses[0]; WirdCourses.V.screen = 'course'; WirdCourses.V.cid = c.id; WirdCourses.render(); });
    await p.click('[data-a="lmenu"]'); await p.click('.cr-menu [data-k="seg"]'); await p.fill('#sgD', '00:00 مقدمة\n10:00 المتغيرات\n20:00 الشروط'); await p.click('#sgP');
    ok((await p.textContent('#sgPv')).includes('3 فصل') || (await p.textContent('#sgPv')).includes('٣ فصل'));
    eq(await W(p, () => WirdCourses.C.courses[0].lessons.length), 1, 'no change before accept');
    await p.click('#sgUse'); eq(await p.locator('.sg-r').count(), 3); await p.click('#sgOk'); await p.clock.runFor(50);
    eq(await W(p, () => WirdCourses.C.courses[0].lessons.map(l => [l.type, l.title, l.start, l.end])), [['chapter', 'مقدمة', 0, 600], ['chapter', 'المتغيرات', 600, 1200], ['chapter', 'الشروط', 1200, 1800]]);
  });

  /* ---------- المشغّل والتقدّم ---------- */
  await T('8-10-11. المشغّل: نسخة واحدة، تتبّع، سحب ما بيتحسبش، حفظ واستكمال بعد إعادة التحميل', async p => {
    await openTab(p); const s = await seed(p, { dur: 600 });
    await W(p, s => WirdCourses.openPlayer(s.cid, s.lids[0], {}), s); await p.clock.runFor(100);
    eq(await W(p, () => __yt.created), 1, 'one player'); ok(await p.locator('iframe[data-fake]').count() === 1);
    ok(await p.isVisible('#plYT'), 'external link'); ok(await p.isVisible('#plInfo')); ok(await p.isVisible('[data-a="pdone"]'));
    await play(p, 10, 0);
    let v = await W(p, () => WirdCourses.C.videos.dQw4w9WgXcQ); eq([Math.round(v.watched), Math.round(v.lastPos)], [10, 10]);
    await W(p, () => { __yt.t = 590; }); await p.clock.runFor(1000);                          // قفزة لآخر الفيديو
    v = await W(p, () => WirdCourses.C.videos.dQw4w9WgXcQ); eq(Math.round(v.watched), 10, 'seek not counted'); eq(Math.round(v.lastPos), 590);
    ok(!(await W(p, () => WirdCourses.C.courses[0].lessons[0].done)), 'not auto-completed');
    await W(p, () => { __yt.t = 5; }); await p.clock.runFor(1000); await W(p, () => { __yt.players[0].st(2); });  // رجوع للخلف + pause
    v = await W(p, () => WirdCourses.C.videos.dQw4w9WgXcQ); eq(Math.round(v.watched), 10, 'seeking back keeps progress'); ok(v.iv.length >= 1);
    // إعادة التحميل = إعادة تشغيل التطبيق: التقدّم لازم يفضل
    await p.reload(); await p.clock.runFor(300);
    v = await W(p, () => WirdCourses.C.videos.dQw4w9WgXcQ); eq([Math.round(v.watched), Math.round(v.lastPos)], [10, 5], 'persisted');
    await openTab(p); await W(p, s => { WirdCourses.V.screen = 'course'; WirdCourses.V.cid = s.cid; WirdCourses.render(); }, s);
    await W(p, s => WirdCourses.openPlayer(s.cid, s.lids[0], {}), s); await p.clock.runFor(100);
    ok((await p.textContent('[data-a="presume"]')).includes('كمّل من'), 'resume action shown');
    await p.click('[data-a="presume"]'); eq(await W(p, () => __yt.seeks.slice(-1)[0]), 5);
  });
  await T('4.3 مدة الفيديو من المشغّل الرسمي + لا تُخترع قبل كده', async p => {
    await openTab(p); const s = await seed(p, { dur: 0 });
    eq(await W(p, () => WirdCourses.C.videos.dQw4w9WgXcQ.duration || 0), 0);
    await W(p, s => WirdCourses.openPlayer(s.cid, s.lids[0], {}), s); await p.clock.runFor(100);
    eq(await W(p, () => WirdCourses.C.videos.dQw4w9WgXcQ.duration), 600);
  });
  await T('5.2 اختيار جزء = seek لبدايته، نهاية الجزء = اقتراح من غير seek تلقائي', async p => {
    await openTab(p); const s = await seed(p, { dur: 600, segs: [[0, 100], [100, 300]] });
    await W(p, s => WirdCourses.openPlayer(s.cid, s.lids[0], {}), s); await p.clock.runFor(100);
    await p.click('.cr-seg:nth-child(3)'); eq(await W(p, () => __yt.seeks.slice(-1)[0]), 100); eq(await W(p, () => __yt.created), 1, 'same player reused');
    const n0 = await W(p, () => __yt.seeks.length);
    await W(p, () => { __yt.t = 296; __yt.players[0].st(1); });
    for (let t = 296; t < 302 && !(await W(p, () => __yt.pauses || 0)); t += 0.2) { await W(p, () => { __yt.t += 0.2; }); await p.clock.runFor(200); }
    ok(await p.isVisible('.cr-prompt'), 'segment end prompt'); eq(await W(p, () => __yt.seeks.length), n0, 'no auto-seek'); eq(await W(p, () => __yt.pauses), 1, 'default: pauses at segment end');
    ok(!(await W(p, () => WirdCourses.C.courses[0].lessons[1].done)), 'not auto-completed');
  });
  await T('4.4 إكتمال صريح + إلغاؤه، ومفيش إكتمال بمجرد الفتح', async p => {
    await openTab(p); const s = await seed(p, {});
    await W(p, s => WirdCourses.openPlayer(s.cid, s.lids[0], {}), s); await p.clock.runFor(100);
    eq(await W(p, () => WirdCourses.C.courses[0].lessons[0].done), false); await p.click('[data-a="pdone"]');
    eq(await W(p, () => WirdCourses.C.courses[0].lessons[0].done), true); await p.click('[data-a="pdone"]');
    eq(await W(p, () => WirdCourses.C.courses[0].lessons[0].done), false);
  });
  await T('12. فيديو غير متاح/مانع التضمين: بديل واضح والبيانات محفوظة', async p => {
    await openTab(p); const s = await seed(p, {}); await W(p, () => { WirdCourses.C.notes.push({ id: 'n1', courseId: WirdCourses.C.courses[0].id, lessonId: WirdCourses.C.courses[0].lessons[0].id, videoId: 'dQw4w9WgXcQ', t: 5, text: 'ملاحظة', created: 1, updated: 1 }); WirdCourses.save(); });
    await W(p, s => WirdCourses.openPlayer(s.cid, s.lids[0], {}), s); await p.clock.runFor(100);
    await W(p, () => __yt.players[0].cfg.events.onError({ data: 101 })); await p.clock.runFor(50);
    ok((await p.textContent('#plStatus')).includes('منع تشغيله')); ok(await p.locator('#plStatus a[href*="youtube.com/watch?v=dQw4w9WgXcQ"]').count() === 1);
    eq(await W(p, () => [WirdCourses.C.courses[0].lessons.length, WirdCourses.C.notes.length, WirdCourses.C.videos.dQw4w9WgXcQ.unavailable]), [1, 1, true]);
  });
  await T('12. فشل تحميل مشغّل يوتيوب (أوفلاين) → رابط خارجي، مفيش مشغّل غير رسمي', async p => {
    await openTab(p); const s = await seed(p, {});
    await W(p, s => WirdCourses.openPlayer(s.cid, s.lids[0], {}), s); await p.clock.runFor(13000);
    ok((await p.textContent('#plStatus')).includes('مشغّل يوتيوب')); ok(await p.locator('#plStatus a[target="_blank"]').count() === 1);
    eq(await p.locator('video, audio').count(), 0, 'no unofficial player');
  }, { noYT: true });


  /* ---------- مزامنة الجزء النشط + سلوك نهاية الجزء ---------- */
  const SEG3 = { dur: 600, segs: [[0, 100], [100, 200], [200, 300]] };
  const openSeg = async p => { await openTab(p); const s = await seed(p, SEG3); await W(p, s => WirdCourses.openPlayer(s.cid, s.lids[0], {}), s); await p.clock.runFor(100); return s; };
  const playFine = async (p, from, to) => { await W(p, t => { __yt.t = t; __yt.players[0].st(1); }, from);
    for (let t = from; t < to; t += 0.2) { if (await W(p, () => __yt.pauses || 0)) break; await W(p, () => { __yt.t += 0.2; }); await p.clock.runFor(200); } };
  const activeLid = p => W(p, () => WirdCourses.P.lid);
  await T('SYNC-1. سحب لقدّام أثناء التشغيل ⇒ الجزء النشط بيتبع الموضع والتقدّم يتحدّث', async p => {
    const s = await openSeg(p); await play(p, 3, 0);
    await W(p, () => { __yt.t = 250; }); await p.clock.runFor(1000);
    eq(await activeLid(p), s.lids[2], 'active = segment 3'); ok((await p.textContent('#plInfo .cr-pt')).includes('جزء 200'), 'title updated');
    ok(await p.locator('#plInfo .cr-seg.on').count() === 1 && (await p.locator('#plInfo .cr-seg.on').getAttribute('data-id')) === s.lids[2], 'list highlight');
    const v = await W(p, () => WirdCourses.C.videos.dQw4w9WgXcQ); eq([Math.round(v.watched), Math.round(v.lastPos)], [3, 250], 'seek not counted as watched');
    eq(await W(p, () => WirdCourses.C.courses[0].lastLessonId), s.lids[2]);
    await play(p, 4, 250);                                                            // مشاهدة في الجزء الجديد بتزوّد تغطيته هو
    const cov = await W(p, s => { const c = WirdCourses.C.courses[0]; return c.lessons.map(l => Math.round(WirdCourses.lessonCoverage(l, WirdCourses.C.videos) * 100)); }, s);
    eq(cov, [3, 0, 4]);
  });
  await T('SYNC-2. سحب والفيديو واقف (pause) ⇒ بردو بيتزامن', async p => {
    const s = await openSeg(p); await W(p, () => { __yt.t = 3; __yt.players[0].st(2); });
    await W(p, () => { __yt.t = 150; __yt.players[0].st(3); __yt.players[0].st(2); }); await p.clock.runFor(50);
    eq(await activeLid(p), s.lids[1]);
  });
  await T('END-1. الافتراضي: يوقف عند نهاية الجزء بدقة ومينتقلش لحد ما تكمّل', async p => {
    const s = await openSeg(p); eq(await p.getAttribute('#plEnd button.on', 'data-m'), 'pause', 'default is pause');
    await playFine(p, 95, 103);
    eq(await W(p, () => __yt.pauses), 1, 'paused once'); ok(await W(p, () => __yt.t) < 100.6, 'stopped within ~0.5s of boundary: ' + await W(p, () => __yt.t));
    eq(await activeLid(p), s.lids[0], 'still on finished segment'); ok(await p.locator('.cr-prompt[data-kind="pause"]').count() === 1);
    eq(await W(p, () => WirdCourses.C.courses[0].lessons[0].done), false, 'not auto-completed');
    await p.click('.cr-prompt [data-a="pcont"]'); await p.clock.runFor(50);
    eq(await activeLid(p), s.lids[1], 'moved to next on continue'); eq(await W(p, () => __yt.seeks.slice(-1)[0]), 100); eq(await p.locator('.cr-prompt').count(), 0);
  });
  await T('END-1b. تشغيل يدوي بعد الوقوف ⇒ الجزء التالي بقى نشط', async p => {
    const s = await openSeg(p); await playFine(p, 95, 103); eq(await activeLid(p), s.lids[0]);
    await W(p, () => { __yt.players[0].st(1); }); for (let i = 0; i < 2; i++) { await W(p, () => { __yt.t += 1; }); await p.clock.runFor(1000); }
    eq(await activeLid(p), s.lids[1]); eq(await p.locator('.cr-prompt[data-kind="pause"]').count(), 0, 'pause prompt cleared');
  });
  await T('END-2. وضع «كمّل»: مفيش وقوف، بينتقل للجزء التالي، والإكمال بيخص الجزء اللي خلص', async p => {
    const s = await openSeg(p); await p.click('#plEnd [data-m="continue"]');
    eq(await W(p, () => WirdCourses.C.prefs.endMode), 'continue'); eq(await p.getAttribute('#plEnd button.on', 'data-m'), 'continue');
    await playFine(p, 95, 103);
    eq(await W(p, () => __yt.pauses || 0), 0, 'never paused'); await p.clock.runFor(1000); eq(await activeLid(p), s.lids[1], 'auto-moved');
    eq(await p.getAttribute('.cr-prompt[data-kind="soft"]', 'data-id'), s.lids[0], 'prompt is about the finished segment');
    await p.click('.cr-prompt [data-a="pdone"]');
    eq(await W(p, () => WirdCourses.C.courses[0].lessons.map(l => l.done)), [true, false, false], 'only finished segment completed');
  });
  await T('END-3. اختيار «أوقف/كمّل» بيتحفظ بعد إعادة التحميل', async p => {
    await openSeg(p); await p.click('#plEnd [data-m="continue"]'); await p.evaluate(() => WirdCourses.flush()); await p.reload(); await p.clock.runFor(300);
    eq(await W(p, () => WirdCourses.C.prefs.endMode), 'continue');
  });
  /* ---------- المهام ---------- */
  await T('13/14/15. ربط المهام: مدة ≠ إكمال الدرس، درس ⇒ إكمال المهمة، من غير تكرار، وإلغاء المستخدم محترم', async p => {
    await openTab(p); const s = await seed(p, { dur: 600, segs: [[0, 100], [100, 200]] });
    const r = await W(p, async s => {
      const WC = window.WirdCourses, c = WC.C.courses[0], today = todayISO(), B = hBlocks(), out = {};
      const a = WC.createLink({ courseId: c.id, type: 'time', minutes: 1, s: B[0].s, date: today });
      const b = WC.createLink({ courseId: c.id, type: 'lesson', lessonId: s.lids[0], s: B[0].s, date: today });
      const one = lk => H.oneoffs[today].find(o => o.id === lk.ref);
      out.start = [one(a).done, one(b).done, one(a).name, one(b).name];
      WC.addSession(c.id, 61); WC.syncTasks(); WC.syncTasks();                                // دقيقة دراسة فعلية — مرتين
      out.time = [!!one(a).done, !!one(b).done, c.lessons[0].done];                          // المهمة (مدة) خلصت، الدرس لأ
      WC.setLessonDone(c, c.lessons[0], true, 'manual'); WC.setLessonDone(c, c.lessons[0], true, 'manual'); WC.syncTasks();
      out.lesson = [!!one(b).done, C_acts()];
      function C_acts() { return WC.C.activity.filter(x => x.type === 'lesson_done').length; }
      one(a).done = false; delete one(a).tier; WC.syncTasks();                                // المستخدم يلغي إنجاز مهمة المدة
      out.undo = [!!one(a).done, a.undone[today]];
      c.title = 'اسم جديد'; WC.syncTasks(); out.renamed = one(a).name; out.linkKept = !!WC.C.links.length;
      return out;
    }, s);
    eq(r.start, [false, false, '🎓 ذاكر كورس بايثون (١ د)', '🎓 خلّص الدرس: جزء 0']);
    eq(r.time, [true, false, false], 'duration task done, lesson untouched'); eq(r.lesson, [true, 1], 'lesson task done once, one activity');
    eq(r.undo, [false, true], 'undo respected'); ok(r.renamed.includes('اسم جديد'), 'name follows rename'); ok(r.linkKept);
    eq(await W(p, () => { const t = todayISO(); return H.oneoffs[t].length; }), 2, 'no duplicate tasks');
  });
  await T('7.2. جدولة من الواجهة: مهمة اليوم + روتين متكرر (عادة) + منع روتين لدرس واحد', async p => {
    await openTab(p); const s = await seed(p, {}); await W(p, s => { WirdCourses.V.screen = 'course'; WirdCourses.V.cid = s.cid; WirdCourses.render(); }, s);
    const before = await W(p, () => [H.habits.length, JSON.stringify(H.logs)]);
    await p.click('[data-a="sched"]'); await p.fill('#scM', '25'); await p.click('#scOk');
    eq(await W(p, () => { const o = H.oneoffs[todayISO()]; return [o.length, o[0].name]; }), [1, '🎓 ذاكر كورس بايثون (٢٥ د)']);
    await p.click('[data-a="sched"]'); await p.click('#scT [data-t="lessons"]'); await p.click('#scR [data-r="1"]'); await p.click('#scOk');
    const h = await W(p, () => H.habits.map(x => [x.type, x.days.length, x.name]));
    eq(h.length, before[0] + 1); eq(h[h.length - 1][0], 'b'); eq(h[h.length - 1][1], 7);
    await p.click('[data-a="sched"]'); await p.click('#scT [data-t="lesson"]'); await p.click('#scR [data-r="1"]'); ok((await p.locator('#scR [data-r="1"].on').count()) === 0, 'recurring lesson rejected');
  });
  await T('17. العادات والمهام الموجودة تشتغل (جدول اليوم + إكمال يدوي)', async p => {
    await p.click('.tab[data-view="view-habits"]'); await p.clock.runFor(100);
    const r = await W(p, () => { const t = todayISO(); H.habits.push({ id: 'hx', name: 'عادة قديمة', cat: 'main', type: 'b', target: 0, unit: '', nailPct: 120, subs: [], days: [0, 1, 2, 3, 4, 5, 6], startMin: hBlocks()[0].s, created: '2026-01-01', cycleStart: '2026-01-01', cycle: 1, prog: null });
      const a = hTasks(t).t.find(x => x.key === 'hx'); hSetLog(t, H.habits[0], null, 2, 0); hSave(); hRender(); return [!!a, hDaySum(t).dn, document.querySelector('#habitsRoot').textContent.includes('عادة قديمة')]; });
    eq(r, [true, 1, true]);
  });

  /* ---------- ملاحظات / إحصائيات / حذف ---------- */
  await T('9. ملاحظات بوقت داخل الفيديو + بقاءها بعد حذف الدرس + القفز للوقت', async p => {
    await openTab(p); const s = await seed(p, { dur: 600, segs: [[0, 100], [100, 200]] });
    await W(p, s => WirdCourses.openPlayer(s.cid, s.lids[0], {}), s); await p.clock.runFor(100);
    await W(p, () => { __yt.t = 42; }); await p.fill('#plNT', 'نقطة مهمة'); await p.click('[data-a="pnadd"]');
    eq(await W(p, () => WirdCourses.C.notes.map(n => [n.t, n.text, n.lessonId !== null])), [[42, 'نقطة مهمة', true]]);
    await p.click('[data-a="pngo"]'); eq(await W(p, () => __yt.seeks.slice(-1)[0]), 42);
    await W(p, s => { const c = WirdCourses.C.courses[0]; WirdCourses.V.screen = 'course'; WirdCourses.V.cid = c.id; WirdCourses.render(); }, s);
    await p.click('.cr-ls:nth-child(1) [data-a="lmenu"]'); await p.click('.cr-menu [data-k="del"]'); await p.click('#confirmOkBtn');
    eq(await W(p, () => [WirdCourses.C.courses[0].lessons.length, WirdCourses.C.notes.length, WirdCourses.C.notes[0].lessonId]), [1, 1, null], 'note kept');
  });
  await T('8. الإحصائيات: حالة فارغة ثم بيانات (وقت فعلي مش وقت الفتح)', async p => {
    await openTab(p); await p.click('[data-a="stats"]'); ok((await p.textContent('#coursesRoot')).includes('لسه مفيش وقت تشغيل'));
    const s = await seed(p, { dur: 600, dailyMin: 1 }); await W(p, s => WirdCourses.openPlayer(s.cid, s.lids[0], {}), s); await p.clock.runFor(100);
    await W(p, () => { __yt.t = 0; __yt.players[0].st(1); }); await p.clock.runFor(5000); // مفتوح وواقف على 0: مش وقت دراسة
    eq(Math.round(await W(p, () => (WirdCourses.C.sessions[todayISO()] || { sec: 0 }).sec)), 0, 'idle open video ≠ study time');
    await play(p, 65, 0); await W(p, () => { WirdCourses.V.screen = 'stats'; WirdCourses.render(); });
    const txt = await p.textContent('#coursesRoot'); ok(txt.includes('١') && txt.includes('كورسات'));
    eq(await W(p, () => Math.round(WirdCourses.C.sessions[todayISO()].sec / 60)), 1);
  });
  await T('3.1 البحث والفلتر والترتيب + أرشفة/حذف بتأكيد + المهام تفضل بعد حذف الكورس', async p => {
    await openTab(p); await seed(p, { title: 'ألف' }); await seed(p, { title: 'باء' }); await W(p, () => WirdCourses.render());
    eq(await p.locator('.cr-card').count(), 2); await p.fill('#crQ', 'باء'); eq(await p.locator('.cr-card').count(), 1);
    await p.fill('#crQ', ''); await p.selectOption('#crSo', 'alpha'); ok((await p.locator('.cr-title').first().textContent()).includes('ألف'));
    await p.click('#crSt [data-s="completed"]'); ok(await p.isVisible('.cr-empty'));
    await p.click('#crSt [data-s="all"]');
    const id = await W(p, () => { const c = WirdCourses.C.courses.find(x => x.title === 'ألف'); WirdCourses.createLink({ courseId: c.id, type: 'custom', title: 'هدف', s: hBlocks()[0].s, date: todayISO() }); return c.id; });
    await p.locator('.cr-card').first().locator('[data-a="cmenu"]').click(); await p.click('.cr-menu [data-k="del"]'); ok(await p.isVisible('#confirmOverlay.open')); await p.click('#confirmOkBtn');
    eq(await W(p, () => [WirdCourses.C.courses.length, H.oneoffs[todayISO()].length, WirdCourses.C.links[0].orphan]), [1, 1, true]);
  });


  /* ---------- مركز التعلّم داخل «منهجي» ---------- */
  const seedHub = p => p.evaluate(() => {
    booksState.list.push({ id: 'b1', title: 'كتاب التوحيد', totalPages: 200, currentPage: 50, dailyTarget: 10, todayStartPage: 40, todayDate: todayISO(), lastReadAt: Date.now() - 864e5 });
    const id = stCreate('رياضيات', 'المشتقة هي معدل التغير. التكامل عكس التفاضل.', 'sent'); ST.sessions[id].items[0].status = 'red'; ST.sessions[id].items[1].status = 'yellow'; stSave();
    const WC = WirdCourses, c = WC.createCourse({ title: 'أساسيات الكيمياء' }), v = WC.upsertVideo({ id: 'dQw4w9WgXcQ', title: 'الذرة', duration: 600 });
    c.lessons.push(WC.mkLesson({ vid: v.id, title: 'التفاعلات الكيميائية' })); c.lastStudiedAt = Date.now(); WC.C.notes.push({ id: 'n1', courseId: c.id, lessonId: null, videoId: v.id, t: null, text: 'ملاحظة عن الإلكترونات', created: 1, updated: 1 }); WC.save();
    WirdLearning.renderHub(); return c.id;
  });
  await T('UNI-C1. «منهجي» = مساحة عمل واحدة: مفيش شريط أقسام ولا شاشات قديمة، وباقي التبويبات شغّالة', async p => {
    eq(await p.locator('.tabs .tab:not([hidden])').allTextContents(), ['اليوم', 'السجل', '🎯 عادات', '⏱ بومودورو', '🤲 عبادات', '📖 منهجي']);
    eq(await p.locator('#lrnNav, #view-lrn, #view-courses.active').count(), 0, 'no hub / no standalone courses screen');
    await p.click('.tab[data-view="view-lessons"]');
    // الورشة بتتركّب بعد شغل IndexedDB حقيقي (الساعة المزيّفة مبتقدّمهوش) ⇒ ننتظر بانتظام بدل ما نفترض ٣٠٠ms مزيّفة
    for (let i = 0; i < 40 && !(await W(p, () => !!(window.__WIRD_STUDY_APP__ && __WIRD_STUDY_APP__.isOpen))); i++) { await p.waitForTimeout(100); await p.clock.runFor(50); }
    ok(await W(p, () => __WIRD_STUDY_APP__.isOpen) && await p.locator('.ls-ws').count() === 1, 'workspace opens directly');
    // الورشة طبقة كاملة الشاشة (سلوك تطبيق الدروس الأصلي): ✕ بلمسة واحدة بترجّعك لشريط التبويبات
    await p.click('.ls-exit'); for (let i = 0; i < 20 && await W(p, () => __WIRD_STUDY_APP__.isOpen); i++) { await p.waitForTimeout(100); await p.clock.runFor(50); }
    ok(!(await W(p, () => __WIRD_STUDY_APP__.isOpen)), 'closing the workspace returns to the tab bar');
    for (const v of ['view-home', 'view-log', 'view-habits', 'view-pomo', 'view-ibadat']) {
      await p.click(`.tab[data-view="${v}"]`); await p.clock.runFor(30);
      eq(await p.locator('.view.active').evaluateAll(e => e.map(x => x.id)), [v], v); eq(await p.locator('.tab.active').evaluateAll(e => e.map(x => x.dataset.view)), [v]);
    }
  });
  await T('UNI-C2. لوحة الكورس داخل مساحة العمل: إغلاقها بيوقف الفيديو وإعادة فتحها مبتنشئش مشغّل جديد', async p => {
    const s = await openSeg(p); eq(await W(p, () => __yt.created), 1);
    await W(p, () => { __yt.t = 5; __yt.players[0].st(1); }); await p.clock.runFor(1000);
    await p.click('.wu-back'); eq(await W(p, () => __yt.pauses || 0), 1, 'paused on leaving the panel');
    await W(p, () => WirdUnified.__host()); await p.clock.runFor(100); eq(await W(p, () => __yt.created), 1, 'player not recreated');
  });

  /* ---------- جودة وامتثال ---------- */
  await T('19. الموبايل: مفيش scroll أفقي في القائمة/الكورس/المشغّل/الإحصائيات (٣٦٠px)', async p => {
    await openTab(p); const s = await seed(p, { title: 'عنوان طويل جداً جداً جداً جداً جداً جداً جداً جداً جداً جداً جداً جداً', dur: 5400, segs: [[0, 1800], [1800, 5400]] });
    const wide = () => W(p, () => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    await W(p, () => WirdCourses.render()); ok((await wide()) <= 1, 'list overflow ' + await wide());
    await W(p, s => { WirdCourses.V.screen = 'course'; WirdCourses.V.cid = s.cid; WirdCourses.render(); }, s); ok((await wide()) <= 1, 'course overflow');
    await W(p, s => WirdCourses.openPlayer(s.cid, s.lids[0], {}), s); await p.clock.runFor(100); ok((await wide()) <= 1, 'player overflow');
    const box = await p.locator('.cr-ytw').boundingBox(); ok(Math.abs(box.width / box.height - 16 / 9) < 0.05, 'player 16:9'); ok(box.width <= 360);
    await W(p, () => { WirdCourses.V.screen = 'stats'; WirdCourses.render(); }); ok((await wide()) <= 1, 'stats overflow');
    const small = await p.evaluate(() => [...document.querySelectorAll('#view-courses button, #view-courses a.btn')].filter(b => b.offsetParent && (b.getBoundingClientRect().height < 40)).map(b => b.className + ':' + b.textContent.trim().slice(0, 12))); eq(small, [], 'touch targets ≥ 40px');
  }, { vp: { width: 360, height: 640 } });
  await T('20. الامتثال: مفيش تحميل/استخراج/تغطية للمشغّل، progressbar بعناوين', async p => {
    const src = await W(p, () => document.getElementById('courses-module').textContent);
    for (const bad of ['googlevideo', 'youtube-dl', 'yt-dlp', 'ytdl', 'getAudioTrack', 'controls:0', 'controls=0', 'disablekb', 'adblock', 'URL.createObjectURL', 'new Audio', '<video', '<audio', 'caches.']) ok(!src.includes(bad), 'forbidden: ' + bad);
    ok(src.includes('https://www.youtube.com/iframe_api') && src.includes('new API.Player'), 'official IFrame API');
    ok(/fetch\(\s*'https:\/\/(www\.googleapis\.com\/youtube|www\.youtube\.com\/oembed)/.test(src.replace(/\s+/g, ' ')) || src.includes("googleapis.com/youtube/v3/videos") , 'only official endpoints');
    await openTab(p); const s = await seed(p, {}); await W(p, () => WirdCourses.render());
    ok(await p.locator('.cr-bar[role="progressbar"][aria-valuenow][aria-label]').count() >= 1, 'progressbar a11y');
    const sw = require('fs').readFileSync(path.join(path.dirname(FILE), 'sw.js'), 'utf8'); ok(sw.includes('youtube\\.com') && sw.includes('ytimg\\.com') && sw.includes('googlevideo\\.com'), 'SW bypasses YouTube');
    eq(await W(p, () => document.getElementById('ytBox') === null), true);
  });

  await browser.close();
  let bad = 0; for (const r of results) { console.log((r[1] ? '✔ ' : '✘ ') + r[0] + (r[1] ? '' : '\n    → ' + r[2])); if (!r[1]) bad++; }
  console.log(`\n${results.length - bad}/${results.length} passed`); process.exit(bad ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
