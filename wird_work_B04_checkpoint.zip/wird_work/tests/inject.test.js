// Integration test of the module injector, the shells and WirdKit (B2 / TASK 0.3).
//   Part A  injector behaviour on scratch copies of the project (python3, no browser)
//   Part B  the injected page in real Chromium compared with a pristine page (needs Playwright)
// Run:  NODE_PATH=$(npm root -g) node tests/inject.test.js          (WIRD_SKIP_BROWSER=1 runs Part A only)
// Nothing in the project tree is modified: every scenario runs on a fresh copy under the OS temp directory.
'use strict';
const { spawnSync } = require('child_process');
const fs = require('fs'), path = require('path'), os = require('os'), crypto = require('crypto');
const ROOT = path.resolve(__dirname, '..');
const INJ = path.join('tools', 'patch', 'inject_wird_modules.py');
const IDS = ['wird-tasks-css', 'wird-tasks', 'wird-quiz-css', 'wird-quiz'];
const ANCHOR = '<script id="wird-offline">';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'wird-inject-test-'));
let passed = 0; const failed = [];
async function step(name, fn) { try { await fn(); passed++; console.log('  ✔ ' + name); } catch (e) { failed.push(name + '\n      ' + String(e && e.message || e).split('\n').slice(0, 8).join('\n      ')); console.log('  ✘ ' + name); } }
function assert(c, m) { if (!c) throw new Error(m || 'assertion failed'); }
function eq(a, b, m) { const x = JSON.stringify(a), y = JSON.stringify(b); if (x !== y) throw new Error((m || 'not equal') + '\n        got      ' + x + '\n        expected ' + y); }

// ------------------------------------------------------------------------------------------------ helpers
const regionStart = t => t.indexOf('<style id="wird-tasks-css">');
function pristineOf(text) { const s = regionStart(text); return s < 0 ? text : text.slice(0, s) + text.slice(text.indexOf(ANCHOR)); }
let copies = 0;
function makeProject(opts) {
  const dst = path.join(TMP, 'p' + (++copies)); fs.mkdirSync(dst, { recursive: true });
  fs.cpSync(ROOT, dst, { recursive: true, filter: p => !/[\\/](\.git|node_modules)([\\/]|$)/.test(p) });
  const ip = path.join(dst, 'index.html');
  if (!opts || opts.pristine !== false) fs.writeFileSync(ip, pristineOf(fs.readFileSync(ip, 'utf8')));
  return dst;
}
const inject = (dir, ...args) => spawnSync('python3', ['-I', path.join(dir, INJ), '--root', dir, ...args], { encoding: 'utf8' });
const readIndex = d => fs.readFileSync(path.join(d, 'index.html'));
function walk(dir, base, out) { out = out || {}; base = base || dir; fs.readdirSync(dir, { withFileTypes: true }).forEach(e => { const p = path.join(dir, e.name); if (e.isDirectory()) walk(p, base, out); else out[path.relative(base, p).split(path.sep).join('/')] = sha(fs.readFileSync(p)); }); return out; }
function blockOrder(text) { return [...text.matchAll(/<(script|style)\b[^>]*\bid="([^"]+)"/g)].map(m => m[2]); }
function verify(dir) { const r = spawnSync('python3', ['-I', path.join(dir, 'tools', 'audit', 'verify_preservation.py'), '--root', dir], { encoding: 'utf8' }); return { code: r.status, out: r.stdout }; }
const noTemp = d => !fs.readdirSync(d).some(n => /^\.index\.html\..*\.tmp$/.test(n));

// ========================================================================================== PART A
(async () => {
  console.log('PART A — injector on scratch copies');
  const base = makeProject();                                              // pristine (no blocks yet)
  const pristineBytes = readIndex(base), pristineFiles = walk(base);
  let injectedSha, injectedText;

  await step('pristine copy: --check reports not injected (exit 1), nothing written', () => {
    const r = inject(base, '--check'); eq(r.status, 1, r.stdout + r.stderr); assert(/not injected yet/.test(r.stdout), r.stdout); eq(sha(readIndex(base)), sha(pristineBytes));
  });
  await step('first injection: exit 0, four blocks in the fixed order directly before the anchor, verifier PASS', () => {
    const r = inject(base); eq(r.status, 0, r.stdout + r.stderr); assert(/RESULT\s+WRITTEN/.test(r.stdout) && /verifier: RESULT\s+PASS/.test(r.stdout), r.stdout);
    injectedText = readIndex(base).toString('utf8'); injectedSha = sha(readIndex(base));
    const ord = blockOrder(injectedText), i = ord.indexOf('wird-tasks-css'); eq(ord.slice(i, i + 5), IDS.concat(['wird-offline']), 'order');
    eq(IDS.map(id => injectedText.split('id="' + id + '"').length - 1), [1, 1, 1, 1], 'each id exactly once');
    assert(injectedText.indexOf('<style id="wird-tasks-css">') < injectedText.indexOf('<script id="wird-tasks">') && injectedText.indexOf('<script id="wird-quiz">') < injectedText.indexOf(ANCHOR), 'positions');
    const v = verify(base); eq(v.code, 0, v.out); assert(/NEW=4\b|NEW=\d+/.test(v.out) && /PASS/.test(v.out), v.out); assert(/NEW\s+block\s+style:wird-tasks-css/.test(v.out) && /NEW\s+block\s+script:wird-quiz\b/.test(v.out), 'the four blocks are reported as NEW');
    assert(noTemp(base), 'no temp file left behind');
  });
  await step('nothing but index.html changed: every other file is byte-identical (sw.js, manifest, icons, tools, tests, docs)', () => {
    const now = walk(base); const changed = Object.keys(pristineFiles).filter(k => now[k] !== pristineFiles[k]); eq(changed, ['index.html']); eq(Object.keys(now).sort(), Object.keys(pristineFiles).sort(), 'no file added or removed');
  });
  await step('bytes outside the four blocks are preserved exactly (cutting the region restores the original bytes)', () => {
    const cut = pristineOf(injectedText); eq(sha(cut), sha(pristineBytes)); const s = regionStart(injectedText), e = injectedText.indexOf(ANCHOR); eq(injectedText.slice(0, s) + injectedText.slice(e), pristineBytes.toString('utf8'));
    eq(readIndex(base).length > pristineBytes.length, true);
    if (process.env.WIRD_ORIGINAL_INDEX) eq(sha(Buffer.from(cut)), sha(fs.readFileSync(process.env.WIRD_ORIGINAL_INDEX)), 'equals the index.html this batch started from');
  });
  await step('second run is idempotent: byte-identical, file not rewritten, --check passes', () => {
    const m0 = fs.statSync(path.join(base, 'index.html')).mtimeMs; const r = inject(base); eq(r.status, 0); assert(/UNCHANGED/.test(r.stdout), r.stdout);
    eq(sha(readIndex(base)), injectedSha); eq(fs.statSync(path.join(base, 'index.html')).mtimeMs, m0, 'mtime untouched'); const c = inject(base, '--check'); eq(c.status, 0, c.stdout);
  });
  await step('refresh: a changed source updates only its own block; reverting it restores the exact bytes', () => {
    const css = path.join(base, 'tools', 'src', 'tasks.css'), orig = fs.readFileSync(css);
    fs.appendFileSync(css, '.wird-probe{color:red}\n'); const c = inject(base, '--check'); eq(c.status, 1); assert(/STALE.*wird-tasks-css/.test(c.stdout) && !/wird-quiz/.test(c.stdout), c.stdout);
    const r = inject(base); eq(r.status, 0, r.stderr); assert(/wird-tasks-css\s+\d+ bytes\s+UPDATED/.test(r.stdout) && (r.stdout.match(/unchanged\n/g) || []).length >= 3, r.stdout);
    assert(readIndex(base).toString('utf8').includes('.wird-probe{color:red}'), 'new rule present');
    fs.writeFileSync(css, orig); eq(inject(base).status, 0); eq(sha(readIndex(base)), injectedSha, 'back to the exact injected bytes');
    const js = path.join(base, 'tools', 'src', 'tasks-shell.js'), jo = fs.readFileSync(js); fs.writeFileSync(js, Buffer.concat([jo, Buffer.from('\n// touched\n')]));
    const c2 = inject(base, '--check'); eq(c2.status, 1); assert(/STALE.*wird-tasks\b/.test(c2.stdout) && !/wird-quiz/.test(c2.stdout), c2.stdout); fs.writeFileSync(js, jo); eq(inject(base, '--check').status, 0);
  });
  await step('CRLF / BOM / missing final newline in a source do not change the output', () => {
    const js = path.join(base, 'tools', 'src', 'quiz-shell.js'), jo = fs.readFileSync(js, 'utf8');
    fs.writeFileSync(js, '\ufeff' + jo.replace(/\n/g, '\r\n').replace(/\r\n$/, '')); eq(inject(base, '--check').status, 0, 'normalised output is identical'); fs.writeFileSync(js, jo);
  });
  await step('source order rule: kit, shell, M-core*.js, then the other M-*.js, all in file-name order; CSS: M.css then M-*.css', () => {
    const p = makeProject(); const s = path.join(p, 'tools', 'src');
    ['tasks-core-b.js', 'tasks-core.js', 'tasks-zeta.js', 'tasks-alpha.js', 'quiz-core1.js', 'quiz-b.js', 'tasks.js', 'tasks-note.txt', 'other-module.js'].forEach(n => fs.writeFileSync(path.join(s, n), '/* ' + n + ' */\n'));
    ['tasks-extra.css', 'quiz-b.css', 'quiz-a.css'].forEach(n => fs.writeFileSync(path.join(s, n), '/* ' + n + ' */\n'));
    const r = inject(p, '--list'); eq(r.status, 0, r.stderr);
    eq(r.stdout.trim().split('\n').map(l => l.replace(/\s+/g, ' ')), [
      'wird-tasks-css tasks.css + tasks-extra.css',
      'wird-tasks wird-kit.js + tasks-shell.js + tasks-core-b.js + tasks-core.js + tasks-alpha.js + tasks-engine.js + tasks-zeta.js',
      'wird-quiz-css quiz.css + quiz-a.css + quiz-b.css',
      'wird-quiz wird-kit.js + quiz-shell.js + quiz-core1.js + quiz-b.js']);
    const w = inject(p); eq(w.status, 0, w.stdout + w.stderr); const t = readIndex(p).toString('utf8');
    assert(t.indexOf('/* tasks-core-b.js */') < t.indexOf('/* tasks-core.js */') && t.indexOf('/* tasks-core.js */') < t.indexOf('/* tasks-alpha.js */') && t.indexOf('/* tasks-alpha.js */') < t.indexOf('/* tasks-zeta.js */'), 'order in the file');
    assert(!t.includes('/* tasks.js */') && !t.includes('/* other-module.js */') && !t.includes('tasks-note.txt */'), 'files outside the naming rule are ignored');
    eq(w.stdout.includes('verifier: RESULT   PASS'), true);
  });
  await step('a later batch adds a file and re-runs the SAME injector: it appears in the block, nothing else changes', () => {
    const p = makeProject(); inject(p); const before = readIndex(p).toString('utf8'); fs.writeFileSync(path.join(p, 'tools', 'src', 'tasks-planner.js'), '(function(){window.__plannerMarker = 1;})();\n');
    const r = inject(p); eq(r.status, 0, r.stderr); const after = readIndex(p).toString('utf8'); assert(after.includes('window.__plannerMarker = 1'), 'new file injected');
    const chunk = '\n/* ---- tools/src/tasks-planner.js ---- */\n(function(){window.__plannerMarker = 1;})();\n', norm = x => x.replace(/\(wird-kit\.js, tasks-shell\.js[^)]*\)/, '(LIST)');
    eq(after.split(chunk).length, 2, 'the new chunk is present exactly once, formatted like the others'); eq(norm(after.replace(chunk, '')) === norm(before), true, 'only the new chunk and the banner file list differ');
  });

  console.log('  refusals (exit 2, index.html untouched, no temp file):');
  async function refuses(name, prep, rx, expectCode) {
    await step('refuses: ' + name, () => {
      const p = makeProject(); const pre = prep(p) || {}; const before = sha(readIndex(p)); const r = inject(p);
      eq(r.status, expectCode || 2, r.stdout + r.stderr); assert(rx.test(r.stderr + r.stdout), 'message ' + rx + ' not in: ' + r.stderr); eq(sha(readIndex(p)), before, 'index.html must be untouched'); assert(noTemp(p), 'temp file left');
      if (pre.after) pre.after(p);
    });
  }
  const edit = (p, fn) => { const f = path.join(p, 'index.html'); fs.writeFileSync(f, fn(fs.readFileSync(f, 'utf8'))); };
  await refuses('a frozen block was changed (ls-css)', p => edit(p, t => t.replace('<style id="ls-css">', '<style id="ls-css">/* tampered */')), /frozen block\(s\) differ.*style:ls-css \(changed\)/);
  await refuses('a frozen block is missing', p => edit(p, t => t.replace('<style id="wird-unified-css">', '<style id="wird-unified-css-renamed">')), /frozen block\(s\) differ.*wird-unified-css/);
  await refuses('the anchor is missing (it is the frozen wird-offline block, so the frozen check reports it)', p => edit(p, t => t.replace(ANCHOR, '<script id="wird-offline-x">')), /frozen block\(s\) differ.*wird-offline|anchor .* exactly once \(found 0\)/);
  await refuses('the anchor occurs twice', p => edit(p, t => t.replace(ANCHOR, ANCHOR + '</script>\n' + ANCHOR)), /anchor .* exactly once \(found 2\)/);
  await refuses('a duplicate id', p => { inject(p); edit(p, t => t.replace('<script id="wird-offline">', '<script id="wird-quiz">/*dup*/</script>\n<script id="wird-offline">')); }, /duplicate id "wird-quiz"/);
  await refuses('a partial insertion', p => { inject(p); edit(p, t => { const s = t.indexOf('<style id="wird-quiz-css">'), e = t.indexOf(ANCHOR); return t.slice(0, s) + t.slice(e); }); }, /partial insertion/);
  await refuses('a region that is not directly in front of the anchor', p => { inject(p); edit(p, t => { const s = t.indexOf('<style id="wird-tasks-css">'), e = t.indexOf(ANCHOR), reg = t.slice(s, e), rest = t.slice(0, s) + t.slice(e); return rest.replace('<script id="wird-update">', reg + '<script id="wird-update">'); }); }, /not directly in front of the anchor/);
  await refuses('an altered separator inside the region', p => { inject(p); edit(p, t => t.replace('</style>\n\n<script id="wird-tasks">', '</style>\n<script id="wird-tasks">')); }, /unexpected separator after block wird-tasks-css/);
  await refuses('a missing baseline', p => fs.unlinkSync(path.join(p, 'docs', 'PRESERVATION-BASELINE.json')), /PRESERVATION-BASELINE\.json is missing/);
  await refuses('a missing required source (tasks-shell.js)', p => fs.unlinkSync(path.join(p, 'tools', 'src', 'tasks-shell.js')), /required source missing: tools\/src\/tasks-shell\.js/);
  await refuses('a missing kit', p => fs.unlinkSync(path.join(p, 'tools', 'src', 'wird-kit.js')), /required source missing: tools\/src\/wird-kit\.js/);
  await refuses('a missing CSS placeholder', p => fs.unlinkSync(path.join(p, 'tools', 'src', 'quiz.css')), /required source missing: tools\/src\/quiz\.css/);
  for (const [label, file, content, needle] of [['</script inside a JS source', 'tasks-evil.js', "var s = '</SCRIPT><img src=x>';\n", '</script'], ['<!-- inside a JS source', 'quiz-evil.js', "var s = '<!--';\n", '<!--'], ['<script inside a JS source', 'tasks-evil2.js', "var s = '<script>';\n", '<script'], ['</style inside a CSS source', 'tasks-evil.css', '/* </style> */\n', '</style']])
    await refuses(label, p => fs.writeFileSync(path.join(p, 'tools', 'src', file), content), new RegExp('contains .*' + needle.replace(/[<\/!-]/g, m => '\\' + m)));
  await refuses('a source that is not UTF-8', p => fs.writeFileSync(path.join(p, 'tools', 'src', 'tasks-bin.js'), Buffer.from([0x61, 0xff, 0xfe, 0x0a])), /cannot read tasks-bin\.js as UTF-8/);
  await refuses('index.html that is not UTF-8', p => fs.writeFileSync(path.join(p, 'index.html'), Buffer.from([0xff, 0xfe, 0x00])), /cannot read index\.html as UTF-8/);
  await refuses('the verifier is missing', p => fs.unlinkSync(path.join(p, 'tools', 'audit', 'verify_preservation.py')), /verify_preservation\.py is missing/);
  await step('verifier failure after writing: original restored byte for byte, exit 3', () => {
    const p = makeProject(); const before = sha(readIndex(p)); fs.writeFileSync(path.join(p, 'tools', 'src', 'tasks-bad.js'), "(function(){ try { localStorage.setItem('wird_habits_v1', '{}'); } catch (e) {} })();\n");
    const r = inject(p); eq(r.status, 3, r.stdout + r.stderr); assert(/writes a storage key outside/.test(r.stderr) && /original index\.html restored/.test(r.stderr), r.stderr); eq(sha(readIndex(p)), before); assert(noTemp(p), 'temp file left');
  });
  await step('the injector reads the same block definitions as the verifier (hash + key cross-check on the real index.html)', () => {
    const p = makeProject({ pristine: false }); const py = `
import importlib.util, sys
def load(n, f):
    s = importlib.util.spec_from_file_location(n, f); m = importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
v = load('v', sys.argv[1] + '/tools/audit/verify_preservation.py'); i = load('i', sys.argv[1] + '/tools/patch/inject_wird_modules.py')
t = open(sys.argv[1] + '/index.html', encoding='utf-8').read()
a = [(k, v.block_hash(at, b)) for k, at, b, _ in v.parse_index(t)]; b = [(k, i.block_hash(at, b)) for k, at, b in i.parse_blocks(t)]
print('SAME' if a == b and len(a) > 20 else 'DIFFERENT %d %d' % (len(a), len(b)))`;
    const r = spawnSync('python3', ['-I', '-c', py, p], { encoding: 'utf8' }); assert(r.stdout.trim() === 'SAME', r.stdout + r.stderr);
  });
  await step('the project index.html is itself current (the injector would change nothing)', () => { const r = inject(ROOT, '--check'); eq(r.status, 0, 'run tools/patch/inject_wird_modules.py: ' + r.stdout + r.stderr); });
  await step('every injected source is free of the forbidden-API patterns the verifier scans for', () => {
    const t = readIndex(ROOT).toString('utf8'); const s = regionStart(t), e = t.indexOf(ANCHOR), region = t.slice(s, e);
    [/deleteDatabase/, /localStorage\s*\.\s*clear/, /sessionStorage/, /\bcaches\s*\./, /serviceWorker/, /\.clear\(\)/].forEach(rx => assert(!rx.test(region), 'forbidden pattern ' + rx));
  });

  await step('every injected JS block parses as a classic script, and no source holds a raw line/paragraph separator or invisible character', () => {
    const vm = require('vm'); const t = readIndex(ROOT).toString('utf8');
    ['wird-tasks', 'wird-quiz'].forEach(id => { const m = t.match(new RegExp('<script id="' + id + '">([\\s\\S]*?)</script>')); assert(m, id + ' block found'); try { new vm.Script(m[1], { filename: id + '.js' }); } catch (e) { throw new Error(id + ' does not parse: ' + e.message); } });
    const bad = [8232, 8233, 65279, 8203, 8204, 8205, 8206, 8207, 160, 133];
    fs.readdirSync(path.join(ROOT, 'tools', 'src')).filter(n => /^(wird-kit|tasks|quiz)[-.]/.test(n) && /\.(js|css)$/.test(n)).forEach(n => { const x = fs.readFileSync(path.join(ROOT, 'tools', 'src', n), 'utf8'); for (const c of x) assert(!bad.includes(c.codePointAt(0)), n + ' contains the invisible character U+' + c.codePointAt(0).toString(16) + ' (write it as an escape)'); });
  });

  // ====================================================================================== PART B
  if (process.env.WIRD_SKIP_BROWSER === '1') return finish();
  let chromium; try { ({ chromium } = require('playwright')); } catch (e) { failed.push('Playwright is not available (set NODE_PATH=$(npm root -g) or WIRD_SKIP_BROWSER=1): ' + e.message); return finish(); }
  console.log('PART B — injected page versus pristine page in Chromium');
  const pDir = makeProject(), iDir = makeProject(); assert(inject(iDir).status === 0, 'inject for Part B');
  const browser = await chromium.launch({ args: ['--no-sandbox'] });
  const errs = [];
  async function open(dir, o) {
    o = o || {};
    const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, locale: 'ar-EG', timezoneId: 'Africa/Cairo', serviceWorkers: 'block' });
    await ctx.route(/^https?:\/\//, r => r.abort());
    const page = await ctx.newPage(); const own = [];
    page.on('pageerror', e => own.push('pageerror: ' + String(e))); page.on('console', m => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) own.push('console: ' + m.text()); });
    await page.addInitScript(() => {                                   // counts what the page creates while loading
      const c = window.__load = { mo: 0, io: 0, ro: 0, interval: 0, listeners: 0 };
      ['MutationObserver', 'IntersectionObserver', 'ResizeObserver'].forEach(n => { const K = window[n]; if (!K) return; const key = { MutationObserver: 'mo', IntersectionObserver: 'io', ResizeObserver: 'ro' }[n]; window[n] = function (...a) { c[key]++; return new K(...a); }; window[n].prototype = K.prototype; });
      const si = window.setInterval; window.setInterval = function (...a) { c.interval++; return si.apply(this, a); };
      const ael = EventTarget.prototype.addEventListener; EventTarget.prototype.addEventListener = function (...a) { if (this === window || this === document || this === document.body || this === document.documentElement) c.listeners++; return ael.apply(this, a); };
      if (window.__seed) Object.keys(window.__seed).forEach(k => localStorage.setItem(k, window.__seed[k]));
    });
    if (o.seed) await page.addInitScript(s => { Object.keys(s).forEach(k => { try { localStorage.setItem(k, s[k]); } catch (e) {} }); }, o.seed);
    if (o.katexCounter) await page.addInitScript(() => { let v; window.__katexSets = 0; Object.defineProperty(window, 'katex', { configurable: true, get() { return v; }, set(x) { window.__katexSets++; v = x; } }); });
    await page.goto('file://' + path.join(dir, 'index.html')); await sleep(o.settle || 1500);
    return { ctx, page, own };
  }
  const snap = page => page.evaluate(async () => {
    const ls = {}; for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); ls[k] = localStorage.getItem(k); }
    const dbs = indexedDB.databases ? (await indexedDB.databases()).map(d => d.name).sort() : null;
    return { ls, dbs, ids: [...document.querySelectorAll('[id]')].map(e => e.id).sort(), elements: document.getElementsByTagName('*').length, load: Object.assign({}, window.__load), globals: Object.keys(window).filter(k => !/^(on|webkit)/.test(k)).sort() };
  });

  let P1, P2, I1, seed;
  await step('boot: no page errors; only WirdKit, WirdTasks, WirdQuiz are added to window; the four blocks are the only new elements', async () => {
    const p1 = await open(pDir); P1 = await snap(p1.page); errs.push(...p1.own);
    const p2 = await open(pDir); P2 = await snap(p2.page);
    seed = Object.assign({}, P1.ls, { wird_reader_prefs: '{"legacy":true}', wird_nb_ui: '{"x":1}' });
    const i1 = await open(iDir); I1 = await snap(i1.page); errs.push(...i1.own);
    eq(i1.own, [], 'injected page errors'); eq(p1.own, [], 'pristine page errors');
    eq(I1.globals.filter(g => !P1.globals.includes(g)), ['WirdKit', 'WirdQuiz', 'WirdTasks'], 'new globals'); eq(P1.globals.filter(g => !I1.globals.includes(g)), [], 'no global removed');
    eq(I1.ids.filter(x => !P1.ids.includes(x)), ['wird-quiz', 'wird-quiz-css', 'wird-tasks', 'wird-tasks-css'], 'new ids'); eq(I1.elements - P1.elements, 4, 'new elements');
    const kinds = await i1.page.evaluate(() => ({ kit: typeof WirdKit, tasks: typeof WirdTasks, quiz: typeof WirdQuiz, kv: WirdKit.version, tv: WirdTasks.version, qv: WirdQuiz.version, same: WirdTasks.kit === WirdKit && WirdQuiz.kit === WirdKit, ext: [Object.keys(WirdTasks.ext).length, Object.keys(WirdQuiz.ext).length], engine: typeof WirdTasks.engine.createEngine, getEngine: typeof WirdTasks.getEngine, tk: Object.keys(WirdTasks).sort(), qk: Object.keys(WirdQuiz).sort() }));
    eq(kinds, { kit: 'object', tasks: 'object', quiz: 'object', kv: 1, tv: 1, qv: 1, same: true, ext: [0, 0], engine: 'function', getEngine: 'function', tk: ['engine', 'ext', 'getEngine', 'kit', 'readHabits', 'version'], qk: ['ext', 'kit', 'version'] });
    await p1.ctx.close(); await p2.ctx.close(); await i1.ctx.close();
  });
  await step('no side effects at load: same storage keys and values, same databases, same observers / intervals / listeners as the pristine page', async () => {
    eq(Object.keys(I1.ls).sort(), Object.keys(P1.ls).sort(), 'localStorage keys'); eq(Object.keys(I1.ls).filter(k => /^wird_(tasks|taskprefs|quiz)/.test(k)), [], 'no module key written');
    Object.keys(P1.ls).filter(k => P1.ls[k] === P2.ls[k]).forEach(k => eq(I1.ls[k], P1.ls[k], 'value of ' + k));
    eq(I1.dbs, P1.dbs, 'IndexedDB databases'); assert(!(I1.dbs || []).includes('wird_quiz_db'), 'wird_quiz_db must not exist');
    eq(I1.load, P1.load, 'observers/intervals/listeners created while loading');
  });
  await step('existing (legacy) user data is read and left exactly as the pristine page leaves it', async () => {
    const a = await open(pDir, { seed }), b = await open(pDir, { seed }), c = await open(iDir, { seed }); const A = await snap(a.page), B = await snap(b.page), C = await snap(c.page);
    const stable = Object.keys(A.ls).filter(k => A.ls[k] === B.ls[k]); assert(stable.length >= Object.keys(seed).length - 3, 'enough deterministic keys to compare: ' + stable.length);
    stable.forEach(k => eq(C.ls[k], A.ls[k], 'value of ' + k)); eq(Object.keys(C.ls).sort(), Object.keys(A.ls).sort()); eq(C.ls.wird_reader_prefs, A.ls.wird_reader_prefs);
    eq(a.own.concat(c.own), [], 'errors with seeded data'); await a.ctx.close(); await b.ctx.close(); await c.ctx.close();
  });

  let ctx, page;
  ({ ctx, page } = await open(iDir, { katexCounter: true }));
  await step('KaTeX loader: concurrent calls evaluate KaTeX exactly once, style once, mhchem and lesson macros work, later calls are free', async () => {
    const r = await page.evaluate(async () => { const before = typeof katex; const [a, b] = await Promise.all([WirdKit.ensureKatex(), WirdKit.katex.ensure()]); const c = await WirdKit.ensureKatex(); const o = WirdKit.katex.options(false);
      return { before, same: a === b && b === c && a === window.katex, sets: window.__katexSets, styles: document.querySelectorAll('#ls-katex-style').length, ce: !a.renderToString('\\ce{H2O}', { throwOnError: true }).includes('katex-error'), R: a.renderToString('\\R + \\vect{v}', o).includes('mathbb') || a.renderToString('\\R', o).length > 20, fresh: WirdKit.katex.options(true).macros !== WirdKit.katex.options(true).macros, display: WirdKit.katex.options(true).displayMode, throwOn: o.throwOnError, macros: Object.keys(o.macros).length, direct: typeof WirdKit.katex.macros()['\\vect'] }; });
    eq(r, { before: 'undefined', same: true, sets: 1, styles: 1, ce: true, R: true, fresh: true, display: true, throwOn: true, macros: 11, direct: 'string' });
  });
  await step('IndexedDB: nothing exists until first use; only wird_quiz_db may be opened; memoised; upgrade runs once', async () => {
    const r = await page.evaluate(async () => {
      const out = {}; out.existsBefore = await WirdKit.quizDbExists(); out.dbsBefore = (await indexedDB.databases()).map(d => d.name).includes('wird_quiz_db');
      try { await WirdKit.openDb('wird_study_db', 1); out.other = 'opened!'; } catch (e) { out.other = e.name; }
      try { await WirdKit.openDb('wird_quiz_db_other', 1); out.other2 = 'opened!'; } catch (e) { out.other2 = e.name; }
      out.stillAbsent = !(await indexedDB.databases()).map(d => d.name).includes('wird_quiz_db'); let upgrades = 0;
      const p1 = WirdKit.openQuizDb(db => { upgrades++; db.createObjectStore('sessions', { keyPath: 'id' }); }), p2 = WirdKit.openQuizDb(); const [d1, d2] = await Promise.all([p1, p2]);
      out.same = d1 === d2; out.upgrades = upgrades; out.stores = [...d1.objectStoreNames]; out.existsAfter = await WirdKit.quizDbExists(); out.version = d1.version; d1.close();
      await new Promise(res => { const q = indexedDB.deleteDatabase('wird_quiz_db'); q.onsuccess = q.onerror = q.onblocked = res; });
      out.failedUpgrade = await WirdKit.openQuizDb(() => { throw new Error('boom'); }, 2).then(() => 'opened', e => e.name || 'rejected'); out.afterFail = (await indexedDB.databases()).map(d => d.name).includes('wird_quiz_db');
      return out; });
    eq(r.existsBefore, false); eq(r.dbsBefore, false); eq(r.other, 'DbNameNotAllowed'); eq(r.other2, 'DbNameNotAllowed'); eq(r.stillAbsent, true); eq(r.same, true); eq(r.upgrades, 1); eq(r.stores, ['sessions']); eq(r.existsAfter, true); eq(r.version, 1); assert(r.failedUpgrade !== 'opened', 'a throwing upgrade must reject'); eq(r.afterFail, false, 'an aborted first upgrade leaves no database behind');
  });
  await step('storage helpers: only wird_tasks* / wird_taskprefs* / wird_quiz* are writable; quota and blocked storage never throw', async () => {
    const r = await page.evaluate(() => {
      const L = WirdKit.ls, out = {}; localStorage.setItem('wird_habits_probe', 'keep');
      out.okTasks = L.set('wird_tasks_v1_probe', '1').ok && L.set('wird_tasksx', '1').ok; out.okPrefs = L.set('wird_taskprefs_probe', '1').ok; out.okQuiz = L.set('wird_quiz_probe', '1').ok;
      out.denied = ['wird_habits_probe', 'other', 'wird_task_x', 'WIRD_TASKS', '', null, undefined].map(k => { const x = L.set(k, 'x'); return x.ok === false && x.error.name; }); out.habitsKept = localStorage.getItem('wird_habits_probe');
      out.json = [L.setJson('wird_quiz_json', { a: [1, 2] }).ok, JSON.stringify(L.getJson('wird_quiz_json', null)), L.getJson('missing_key', 'fb'), (() => { localStorage.setItem('wird_quiz_bad', '{x'); return L.getJson('wird_quiz_bad', 'fb'); })(), (() => { const c = {}; c.c = c; const x = L.setJson('wird_quiz_c', c); return x.ok === false; })()];
      const so = Storage.prototype.setItem; Storage.prototype.setItem = function () { throw new DOMException('full', 'QuotaExceededError'); }; const q = L.set('wird_quiz_q', '1'); out.quota = [q.ok, q.error.name, q.error.quota, L.isQuotaError(new DOMException('x', 'QuotaExceededError')), L.isQuotaError(new Error('plain'))];
      let ad; try { ad = L.adapter(); ad.setItem('wird_tasks_v1', 'x'); out.adapterQuota = 'no throw'; } catch (e) { out.adapterQuota = e.name; } Storage.prototype.setItem = so;
      try { L.adapter().setItem('wird_habits_v1', 'x'); out.adapterDenied = 'no throw'; } catch (e) { out.adapterDenied = e.name; } out.habitsStill = localStorage.getItem('wird_habits_v1') !== 'x';
      const go = Storage.prototype.getItem; Storage.prototype.getItem = function () { throw new Error('blocked'); }; out.getBlocked = [L.get('wird_tasks_v1'), L.getJson('wird_tasks_v1', 'fb'), L.lastError && L.lastError.message]; try { L.adapter().getItem('wird_tasks_v1'); out.adapterGet = 'no throw'; } catch (e) { out.adapterGet = 'throws'; } Storage.prototype.getItem = go;
      out.avail = L.available(); return out; });
    eq(r, { okTasks: true, okPrefs: true, okQuiz: true, denied: ['KeyNotAllowed', 'KeyNotAllowed', 'KeyNotAllowed', 'KeyNotAllowed', 'KeyNotAllowed', 'KeyNotAllowed', 'KeyNotAllowed'], habitsKept: 'keep', json: [true, '{"a":[1,2]}', 'fb', 'fb', true], quota: [false, 'QuotaExceededError', true, true, false], adapterQuota: 'QuotaExceededError', adapterDenied: 'KeyNotAllowed', habitsStill: true, getBlocked: [null, 'fb', 'blocked'], adapterGet: 'throws', avail: true });
  });
  await step('uid: unique, prefixed, sanitised', async () => {
    const r = await page.evaluate(() => { const s = new Set(); for (let i = 0; i < 20000; i++) s.add(WirdKit.uid('t')); return { n: s.size, fmt: /^t_[a-z0-9]+_[a-z0-9]+$/.test(WirdKit.uid('t')), clean: WirdKit.uid('a b/<c>').startsWith('abc_'), dflt: WirdKit.uid().startsWith('id_') && WirdKit.uid('').startsWith('id_') && WirdKit.uid(null).startsWith('id_') }; });
    eq(r, { n: 20000, fmt: true, clean: true, dflt: true });
  });
  await step('DOM builder: text is never markup; handlers must be functions; dangerous attributes and tags are refused', async () => {
    const r = await page.evaluate(() => {
      const h = WirdKit.h, o = {}; let hit = 0; window.__x = 0;
      const a = h('div', { class: 'a b', dataset: { k: 'v' }, style: { color: 'red', 'font-size': '12px' }, 'aria-label': 'L', hidden: true, innerHTML: '<img src=x onerror="window.__x=1">', onclick: 'window.__x=2', onfocus: () => hit++ }, ['<b>t</b>', 7, null, undefined, false, [h('span', 'n1'), [h('i', null, 'n2')]]]);
      document.body.appendChild(a); a.dispatchEvent(new Event('click')); a.dispatchEvent(new Event('focus')); a.remove();
      o.cls = a.className; o.data = a.dataset.k; o.color = a.style.color; o.fs = a.style.fontSize; o.aria = a.getAttribute('aria-label'); o.hidden = a.hasAttribute('hidden'); o.noInner = a.querySelector('img') === null && a.querySelector('b') === null; o.text = a.textContent; o.handlerFn = hit; o.noStringHandler = window.__x === 0 && !a.hasAttribute('onclick');
      o.href = ['javascript:alert(1)', ' JaVa\tScRiPt:alert(1)', 'vbscript:x', 'data:text/html,<b>', 'https://example.com/x', '/rel', '#frag', 'data:image/png;base64,AAAA', 'mailto:a@b.c'].map(u => h('a', { href: u }).getAttribute('href'));
      o.src = h('img', { src: 'javascript:1' }).hasAttribute('src'); o.srcdoc = h('div', { srcdoc: 'x' }).hasAttribute('srcdoc');
      o.forbidden = ['script', 'style', 'iframe', 'object', 'embed', 'link', 'meta', 'base', 'template', 'frame', '<img>', 'a b', '1a'].map(t => { try { h(t); return 'created'; } catch (e) { return e.name; } });
      o.short = [h('p', 'plain').textContent, h('p', ['x', 'y']).textContent, h('p', { text: '<u>q</u>' }).textContent, h().tagName, h('p', { textContent: 'tc' }).textContent];
      const e = h('div', null, [h('b', 'x'), h('i', 'y')]); WirdKit.dom.empty(e); o.empty = e.childNodes.length; o.emptyNull = WirdKit.dom.empty(null) === null; return o; });
    eq(r, { cls: 'a b', data: 'v', color: 'red', fs: '12px', aria: 'L', hidden: true, noInner: true, text: '<b>t</b>7n1n2', handlerFn: 1, noStringHandler: true,
      href: [null, null, null, null, 'https://example.com/x', '/rel', '#frag', 'data:image/png;base64,AAAA', 'mailto:a@b.c'], src: false, srcdoc: false,
      forbidden: Array(11).fill('TypeError').concat(['TypeError', 'TypeError']), short: ['plain', 'xy', '<u>q</u>', 'DIV', 'tc'], empty: 0, emptyNull: true });
  });
  await step('audio / vibrate are lazy and never throw; unlockOnFirstTap registers nothing until called and can be cancelled', async () => {
    const r = await page.evaluate(() => { const A = WirdKit.audio, o = {}; o.ctxAtLoad = A.ctx;
      const off1 = A.unlockOnFirstTap(); off1(); document.dispatchEvent(new Event('pointerdown')); o.afterCancelled = A.ctx;
      const off2 = A.unlockOnFirstTap(); document.dispatchEvent(new Event('pointerdown')); o.afterTap = !!A.ctx || A.context() === null; document.dispatchEvent(new Event('keydown')); off2();
      o.blip = typeof A.blip({ freq: 440, ms: 20, gain: 0.01 }); o.blipBad = typeof A.blip({ freq: -5, ms: 'x', gain: 99 }); o.unlock = typeof A.unlock(); o.vib = typeof WirdKit.vibrate(5); o.vibNone = typeof WirdKit.vibrate(); const nv = navigator.vibrate; navigator.vibrate = () => { throw new Error('x'); }; o.vibThrows = WirdKit.vibrate(1); navigator.vibrate = nv; return o; });
    eq(r, { ctxAtLoad: null, afterCancelled: null, afterTap: true, blip: 'boolean', blipBad: 'boolean', unlock: 'boolean', vib: 'boolean', vibNone: 'boolean', vibThrows: false });
  });
  await step('habits: read lazily through the bare name H only (window.H stays undefined); engine runs on the kit adapter and never touches foreign keys', async () => {
    const r = await page.evaluate(() => {
      const before = {}, kb = Object.keys(localStorage).filter(k => /^wird_(tasks|taskprefs|quiz)/.test(k)); for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (!/^wird_(tasks|taskprefs|quiz)/.test(k)) before[k] = localStorage.getItem(k); }
      const o = { windowH: typeof window.H, bare: typeof WirdTasks.readHabits(), hasOneoffs: !!(WirdTasks.readHabits() && WirdTasks.readHabits().oneoffs) };
      const e = WirdTasks.getEngine(); o.single = WirdTasks.engine.getEngine() === e; const t = e.createTask(e.todayKey(), 'اختبار المتصفح', { steps: ['أ', 'ب'] }).task; e.start(t.id); e.complete(t.steps[0].id); e.setPrefs({ progress: 'subtle' });
      const after = {}; for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (!/^wird_(tasks|taskprefs|quiz)/.test(k)) after[k] = localStorage.getItem(k); }
      o.foreignUnchanged = JSON.stringify(before) === JSON.stringify(after); o.keys = Object.keys(localStorage).filter(k => /^wird_(tasks|taskprefs|quiz)/.test(k) && !kb.includes(k)).sort(); o.status = e.status().loadedFrom + '/' + e.status().degraded; o.tid = t.id; return o; });
    eq({ windowH: r.windowH, bare: r.bare, hasOneoffs: r.hasOneoffs, single: r.single, foreignUnchanged: r.foreignUnchanged, keys: r.keys, status: r.status }, { windowH: 'undefined', bare: 'object', hasOneoffs: true, single: true, foreignUnchanged: true, keys: ['wird_taskprefs_v1', 'wird_tasks_v1'], status: 'empty/false' });
    await page.reload(); await sleep(1200);
    const r2 = await page.evaluate(tid => { const e = WirdTasks.getEngine(), v = e.getTask(tid); return { loaded: e.status().loadedFrom, status: v.status, states: v.steps.map(s => s.state), prefs: e.getPrefs().progress, days: e.listDays().length }; }, r.tid);
    eq(r2, { loaded: 'storage', status: 'in_progress', states: ['completed', 'in_progress'], prefs: 'subtle', days: 1 });
  });
  await ctx.close();

  ({ ctx, page } = await open(iDir, { katexCounter: true }));
  await step('KaTeX loader: when the lessons bundle loaded KaTeX first, the kit reuses it (no second evaluation, one style element)', async () => {
    await page.click('.tab[data-view="view-lessons"]'); await page.waitForFunction(() => window.__WIRD_STUDY_APP__ && __WIRD_STUDY_APP__.isOpen, null, { timeout: 20000 }); await sleep(600);
    const ids = await page.evaluate(async () => { const a = __WIRD_STUDY_APP__, r = a.repo; await a.init(); const s = await r.createSubject('فيزياء'), u = await r.createUnit(s.id, 'الحركة'), l = await r.createLesson({ subjectId: s.id, unitId: u.id, title: 'درس KaTeX' }); return { l: l.id }; }); await sleep(500);
    await page.evaluate(() => { const a = __WIRD_STUDY_APP__; a.tree.subjects.forEach(x => a.sidebar.setExpanded(x.id, true)); a.tree.units.forEach(x => a.sidebar.setExpanded(x.id, true)); a.sidebar.render(); a.root.classList.add('side-open'); }); await sleep(400);
    await page.evaluate(() => { const row = [...document.querySelectorAll('.ls-row')].find(r => r.textContent.includes('درس KaTeX')); row && row.click(); }); await page.waitForSelector('.wr[data-lesson]'); await sleep(1500);
    const pre = await page.evaluate(() => ({ defined: typeof katex, sets: window.__katexSets }));
    const r = await page.evaluate(async () => { const k = await WirdKit.ensureKatex(); return { same: k === window.katex, sets: window.__katexSets, styles: document.querySelectorAll('#ls-katex-style').length, ce: !k.renderToString('\\ce{H2O}', { throwOnError: true }).includes('katex-error') }; });
    eq(pre.defined, 'object', 'the lessons bundle loaded KaTeX when the lesson opened'); eq(pre.sets, 1); eq(r, { same: true, sets: 1, styles: 1, ce: true });
  });
  await ctx.close();
  ({ ctx, page } = await open(iDir));
  await step('KaTeX loader: missing assets resolve null (never reject, never throw) and a later call may retry', async () => {
    const r = await page.evaluate(async () => { document.getElementById('ls-asset-katex').remove(); const a = await WirdKit.ensureKatex(); const b = await WirdKit.ensureKatex(); return { a, b, defined: typeof katex }; });
    eq(r, { a: null, b: null, defined: 'undefined' });
  });
  await step('the app still works with the modules present (tabs switch, Manhaji opens)', async () => {
    await page.click('.tab[data-view="view-lessons"]'); await page.waitForFunction(() => window.__WIRD_STUDY_APP__ && __WIRD_STUDY_APP__.isOpen, null, { timeout: 20000 }); eq(await page.evaluate(() => !!document.querySelector('.tabs') && !!window.WirdUnified), true);
  });
  await ctx.close(); await browser.close();
  finish();
})().catch(e => { console.error(e); process.exit(2); });

function finish() {
  try { fs.rmSync(TMP, { recursive: true, force: true }); } catch (e) { /* ignore */ }
  console.log(failed.length ? '\n✘ ' + failed.length + ' FAILED:\n  - ' + failed.join('\n  - ') : '\n✔ injector / shells / kit: ' + passed + ' checks passed');
  console.log('  checks: ' + (passed + failed.length) + ' | passed: ' + passed + ' | failed: ' + failed.length);
  process.exit(failed.length ? 1 : 0);
}
