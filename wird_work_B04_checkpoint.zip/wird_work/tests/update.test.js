// Update-system test (real Chromium + real Service Worker). Run:  NODE_PATH=$(npm root -g) node tests/update.test.js
// A local server imitates GitHub Pages: everything lives under /wird-app/, "Cache-Control: max-age=600" + ETag, 404 outside the prefix.
// External hosts (Quran API, prayer API, pdf.js CDN, fonts) are stubbed — no real network is used.
// The "v4" baseline is rebuilt from the current files (old registration line + original v4 sw.js in tests/fixtures/sw-v4.js).
process.env.PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS = '1';   // makes Playwright route requests that the SERVICE WORKER itself makes (needed to stub the Quran API / CDN)
const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path'), os = require('os');
const ROOT = path.resolve(__dirname, '..'), PREFIX = '/wird-app/';
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'wird-upd-'));
const sleep = ms => new Promise(r => setTimeout(r, ms));
const FILES = ['index.html', 'sw.js', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png'];
const results = []; const check = (name, cond, detail) => { results.push([name, !!cond, detail]); console.log((cond ? '  ✔ ' : '  ✘ ') + name + (!cond && detail !== undefined ? '   ← ' + JSON.stringify(detail).slice(0, 300) : '')); };
const section = t => console.log('\n' + t);
async function waitFor(fn, ms = 20000, step = 150) { const t = Date.now(); for (;;) { try { const v = await fn(); if (v) return v; } catch (e) {} if (Date.now() - t > ms) return false; await sleep(step); } }

/* ---------- releases (what is "uploaded to GitHub") ---------- */
function release(name, { version = 5, old = false, mutate, missing = [] } = {}) {
  const dir = path.join(TMP, name); fs.mkdirSync(dir, { recursive: true });
  let html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
  let sw = fs.readFileSync(path.join(ROOT, 'sw.js'), 'utf8');
  if (old) {   // v4 = original page (no update module, bare register) + original v4 service worker
    html = html.replace(/<style id="wird-update-css">[\s\S]*?<script id="wird-update">[\s\S]*?<\/script>\n?/, '');
    html = html.replace('// service-worker registration + update flow: moved to the "wird-update" block at the end of the body\n', "if('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) addEventListener('load',()=>navigator.serviceWorker.register('sw.js').catch(()=>{}));\n");
    sw = fs.readFileSync(path.join(__dirname, 'fixtures', 'sw-v4.js'), 'utf8');
  } else { const re = /^const SHELL_VERSION = 5;/m; if (!re.test(sw)) throw new Error('SHELL_VERSION declaration not found'); sw = sw.replace(re, 'const SHELL_VERSION = ' + version + ';'); }
  html = html.replace('<head>', '<head><script>window.__RELEASE=' + JSON.stringify(name) + '</script>');
  if (mutate) html = mutate(html);
  fs.writeFileSync(path.join(dir, 'index.html'), html); fs.writeFileSync(path.join(dir, 'sw.js'), sw);
  for (const f of ['manifest.webmanifest', 'icon-192.png', 'icon-512.png']) fs.copyFileSync(path.join(ROOT, f), path.join(dir, f));
  fs.writeFileSync(path.join(dir, 'range-test.bin'), Buffer.alloc(64, 7));
  for (const m of missing) fs.rmSync(path.join(dir, m), { force: true });
  return dir;
}
const clone = (from, to) => { const d = path.join(TMP, to); fs.cpSync(path.join(TMP, from), d, { recursive: true }); return d; };   // same bytes, new mtime ⇒ new ETag

/* ---------- GitHub-Pages-like server ---------- */
let current = null; const outside = []; const hits = [];
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.png': 'image/png', '.webmanifest': 'application/manifest+json', '.bin': 'application/octet-stream' };
const server = http.createServer((req, res) => {
  const u = decodeURIComponent(req.url.split('?')[0]); hits.push(u);
  if (!u.startsWith(PREFIX)) { outside.push(u); res.writeHead(404); return res.end('not found'); }
  const rel = u.slice(PREFIX.length) || 'index.html'; const f = path.join(current, rel === '' ? 'index.html' : rel);
  fs.stat(f, (e, st) => {
    if (e || !st.isFile()) { res.writeHead(404, { 'content-type': 'text/html' }); return res.end('404'); }
    const etag = '"' + st.mtimeMs.toString(16) + '-' + st.size.toString(16) + '"';
    const h = { 'content-type': MIME[path.extname(f)] || 'application/octet-stream', 'cache-control': 'public, max-age=600', etag };
    if (req.headers['if-none-match'] === etag) { res.writeHead(304, h); return res.end(); }
    res.writeHead(200, h); fs.createReadStream(f).pipe(res);
  });
});

/* ---------- external stubs ---------- */
let online = true, quranMode = 'ok'; const stubHits = [];
const CORS = { 'access-control-allow-origin': '*' };
async function wireNetwork(ctx) {
  await ctx.route(/^https?:\/\/(?!127\.0\.0\.1)/, r => {
    const u = new URL(r.request().url()); stubHits.push(u.hostname);
    if (!online) return r.abort();
    if (u.hostname === 'api.islamic.app') {
      if (quranMode === 'fail') return r.fulfill({ status: 500, headers: CORS, contentType: 'application/json', body: '{}' });
      const m = u.pathname.match(/by_page\/(\d+)/); const n = m ? m[1] : '0';
      const body = quranMode === 'errorbody' ? '{"code":500,"message":"boom"}' : JSON.stringify({ data: { verses: [{ verse_key: n + ':1', text_uthmani: 'page ' + n + ' ' + u.search }] } });
      return r.fulfill({ status: 200, headers: CORS, contentType: 'application/json', body });
    }
    if (u.hostname === 'api.aladhan.com') return r.fulfill({ status: 200, headers: CORS, contentType: 'application/json', body: '{"code":200,"data":{"timings":{"Fajr":"04:11"}}}' });
    if (/cdnjs\.cloudflare\.com/.test(u.hostname) && /pdf\.min\.js/.test(u.pathname)) return r.fulfill({ status: 200, contentType: 'text/javascript', headers: CORS, body: 'window.__PDFJS_STUB=1;window.pdfjsLib={GlobalWorkerOptions:{}};' });
    if (u.hostname === 'fonts.gstatic.com') return r.fulfill({ status: 200, headers: CORS, contentType: 'font/woff2', body: 'FONTBYTES' });
    if (u.hostname === 'www.youtube.com') return r.fulfill({ status: 200, headers: CORS, contentType: 'text/javascript', body: '/* yt */' });
    return r.abort();
  });
}

/* ---------- page helpers ---------- */
const URL_BASE = () => 'http://127.0.0.1:' + server.address().port + PREFIX;
const caches_ = p => p.evaluate(async () => { const o = {}; for (const k of await caches.keys()) { const c = await caches.open(k); o[k] = (await c.keys()).map(r => r.url); } return o; });
const ready = p => p.evaluate(() => navigator.serviceWorker.ready.then(r => !!r.active));
const rel = p => p.evaluate(() => window.__RELEASE);
const ver = p => p.evaluate(() => window.WirdUpdate && window.WirdUpdate.version());
const status = p => p.evaluate(() => window.WirdUpdate && window.WirdUpdate.status());
const banner = p => p.evaluate(() => { const b = document.getElementById('wirdUpdate'); return b && !b.hidden ? { title: b.querySelector('b').textContent, sub: b.querySelector('span').textContent, btn: b.querySelector('.wupd-go').textContent } : null; });
function track(p) { const t = { navs: 0 }; p.on('framenavigated', f => { if (f === p.mainFrame()) t.navs++; }); p.on('pageerror', e => (t.errs = t.errs || []).push(String(e))); return t; }
async function openApp(ctx) { const p = await ctx.newPage(); const t = track(p); await p.goto(URL_BASE()); await ready(p); await sleep(400); return [p, t]; }
const QV = [p => `https://api.islamic.app/v1/verses/by_page/${p}?fields=text_uthmani&tafsirs=ar-tafsir-muyassar,ar-tafsir-ibn-kathir`];
const quranUrl = n => `https://api.islamic.app/v1/verses/by_page/${n}?fields=text_uthmani&tafsirs=ar-tafsir-muyassar,ar-tafsir-ibn-kathir`;
const clearGuard = p => p.evaluate(() => sessionStorage.removeItem('wird_upd_reload'));   // real users never update twice within 15 s; the chained test does
const pageFetch = (p, u, init) => p.evaluate(async ([u, init]) => { try { const r = await fetch(u, init); return { status: r.status, text: (await r.text()).slice(0, 200) }; } catch (e) { return { err: String(e) }; } }, [u, init || null]);

(async () => {
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  const browser = await chromium.launch({ args: ['--no-sandbox'] });
  const fresh = async () => { const ctx = await browser.newContext({ serviceWorkers: 'allow', locale: 'ar-EG' }); await wireNetwork(ctx); return ctx; };

  /* ===================== A. fresh install (v5) ===================== */
  section('A. Fresh installation (v5, GitHub-Pages sub-path /wird-app/)');
  current = release('v5-fresh', { version: 5 });
  { const ctx = await fresh(); const [p, t] = await openApp(ctx); await sleep(800);
    const reg = await p.evaluate(async () => { const r = await navigator.serviceWorker.getRegistration(); return { scope: r.scope, script: r.active && r.active.scriptURL, upd: r.updateViaCache }; });
    check('SW registered inside /wird-app/ scope', reg.scope === URL_BASE() && reg.script === URL_BASE() + 'sw.js', reg);
    check('registered with updateViaCache:"none"', reg.upd === 'none', reg.upd);
    const c = await caches_(p);
    check('only wird-v5 exists after a fresh install (no wird-v1 / runtime junk yet is fine)', Object.keys(c).includes('wird-v5'), Object.keys(c));
    check('shell precache = exactly the 4 existing files (no duplicate ./ entry)', JSON.stringify((c['wird-v5'] || []).map(u => u.replace(URL_BASE(), '').replace(/\?.*$/, '')).sort()) === JSON.stringify(['icon-192.png', 'icon-512.png', 'index.html', 'manifest.webmanifest']), c['wird-v5']);
    check('first install: no reload and no update banner', t.navs === 1 && !(await banner(p)), { navs: t.navs });
    check('controller present after first claim (offline-ready without a reload)', await p.evaluate(() => !!navigator.serviceWorker.controller));
    await p.reload(); await sleep(1200);
    const c2 = await caches_(p);
    check('pdf.js (CDN) cached in wird-runtime, not in the shell', (c2['wird-runtime'] || []).some(u => /pdf\.min\.js/.test(u)) && !(c2['wird-v5'] || []).some(u => /pdf\.min\.js/.test(u)), Object.keys(c2));
    online = false; await ctx.setOffline(true); await p.reload(); await sleep(1500);
    check('offline launch works after fresh install', (await rel(p)) === 'v5-fresh' && await p.evaluate(() => !!document.querySelector('.tabs') && window.__PDFJS_STUB === 1));
    online = true; await ctx.setOffline(false);
    const man = await p.evaluate(async () => { const r = await fetch(document.querySelector('link[rel=manifest]').href); const j = await r.json(); return { ok: r.ok, start: j.start_url, scope: j.scope, icons: await Promise.all(j.icons.map(async i => (await fetch(new URL(i.src, document.baseURI))).ok)) }; });
    check('manifest + icons resolve inside /wird-app/', man.ok && man.icons.every(Boolean), man);
    check('page has no JS errors', !(t.errs || []).length, t.errs);
    await ctx.close(); }

  /* ===================== B. existing v4 install → v5 ===================== */
  section('B. Existing installation updating v4 → v5 (with user data, real Quran download)');
  current = release('v4', { old: true });
  const ctx = await fresh();
  let [p, t] = await openApp(ctx); await p.reload(); await sleep(1200);
  check('v4 baseline is running (no update module, old worker)', (await rel(p)) === 'v4' && (await p.evaluate(() => !window.WirdUpdate)) && (await caches_(p))['wird-v4']);
  // user data
  const seed = await p.evaluate(async () => {
    localStorage.setItem('wird_test_habits', '{"streak":42,"notes":["أ","ب"]}'); localStorage.setItem('wird_courses_v1', '{"keep":"me"}');
    const open = (n, v) => new Promise((ok, no) => { const q = v ? indexedDB.open(n, v) : indexedDB.open(n); q.onsuccess = () => ok(q.result); q.onerror = () => no(q.error); });
    const fnb = await open('wird_fnb_m'); await new Promise(r => { const tx = fnb.transaction('m', 'readwrite'); tx.objectStore('m').put({ note: 'hello', n: 7 }, 'testrec'); tx.oncomplete = r; });
    const bk = await open('wird_books_db'); const stores = [...bk.objectStoreNames];
    await new Promise(r => { const tx = bk.transaction('books', 'readwrite'); tx.objectStore('books').put({ id: 'bk1', title: 'كتاب الاختبار' }); tx.oncomplete = r; });
    return { fnbV: fnb.version, bkV: bk.version, stores };
  });
  check('IndexedDB seeded (real app databases opened)', seed.fnbV === 1 && seed.bkV === 3 && seed.stores.includes('books'), seed);
  // real Quran/Tafsir download through the real button handler
  const t0 = Date.now(); await p.evaluate(() => document.getElementById('offlinePack').click());
  const packed = await waitFor(async () => { const c = await caches_(p); return (c['wird-v1'] || []).length >= 1812 && !(await p.evaluate(() => document.getElementById('offlinePack').dataset.run)); }, 180000, 500);
  const before = await caches_(p); console.log('    (pack finished in ' + Math.round((Date.now() - t0) / 1000) + 's)');
  check('Quran/Tafsir pack downloaded into wird-v1 (1812 entries)', packed && before['wird-v1'].length === 1812, before['wird-v1'] && before['wird-v1'].length);
  check('(v4 behaviour confirmed) the same pages are ALSO duplicated in wird-v4 by the old worker', before['wird-v4'].filter(u => /islamic\.app/.test(u)).length === 1812);
  await pageFetch(p, quranUrl(700)); await pageFetch(p, 'https://api.aladhan.com/v1/timingsByCity?city=Cairo&country=EG'); await sleep(500);
  const mid = await caches_(p);
  check('organic page (viewed, not downloaded) exists only in wird-v4', mid['wird-v4'].includes(quranUrl(700)) && !mid['wird-v1'].includes(quranUrl(700)));
  await p.evaluate(async () => { const c = await caches.open('some-unknown-cache'); await c.put('/wird-app/unknown-entry', new Response('keep')); const o = await caches.open('wird-v3'); await o.put('/wird-app/index.html', new Response('old shell')); });
  const v1Before = new Set(mid['wird-v1']), allQuranBefore = new Set([...mid['wird-v1'], ...mid['wird-v4'].filter(u => /islamic\.app/.test(u))]);

  // deploy v5 while the v4 page is open
  current = release('v5', { version: 5 }); const navBefore = t.navs;
  await p.evaluate(() => navigator.serviceWorker.getRegistration().then(r => r.update()));
  const waiting = await waitFor(() => p.evaluate(async () => !!(await navigator.serviceWorker.getRegistration()).waiting), 15000);
  const dur = await caches_(p);
  check('v5 downloaded + installed in the background and is WAITING (not forced)', waiting);
  check('the open v4 tab is untouched (no reload) and old caches are still intact during the wait', t.navs === navBefore && dur['wird-v4'] && dur['wird-v1'].length === 1812 && dur['wird-v5']);
  const shell5 = await p.evaluate(async () => { const c = await caches.open('wird-v5'); const r = await c.match(new URL('index.html', document.baseURI)); return (await r.text()).includes('__RELEASE="v5"'); });
  check('v5 precache holds the NEW index.html even though HTTP cache says max-age=600', shell5);

  // all windows closed → waiting worker activates → next launch is v5
  await p.close(); await sleep(1500);
  [p, t] = await openApp(ctx); await sleep(1000);
  check('after closing and reopening the app the v5 page is served', (await rel(p)) === 'v5' && (await p.evaluate(() => !!window.WirdUpdate)));
  check('v5 worker is now the active controller', (await ver(p) || {}).version === 5, await ver(p));
  const cleaned = await waitFor(async () => !(await caches_(p))['wird-v4'], 25000, 400);
  const after = await caches_(p);
  check('obsolete shell caches wird-v4 and wird-v3 deleted', cleaned && !after['wird-v3'], Object.keys(after));
  check('wird-v1 (Quran/Tafsir downloads) PRESERVED — all 1812 entries', [...v1Before].every(u => after['wird-v1'].includes(u)), after['wird-v1'] && after['wird-v1'].length);
  check('page viewed offline-only in v4 was MIGRATED into wird-v1', after['wird-v1'].includes(quranUrl(700)));
  check('every Quran URL that was cached before is still cached (no loss, no dup)', [...allQuranBefore].every(u => after['wird-v1'].includes(u)) && new Set(after['wird-v1']).size === after['wird-v1'].length && !Object.entries(after).some(([k, v]) => k !== 'wird-v1' && v.some(u => /islamic\.app/.test(u))));
  check('prayer-times answer + pdf.js migrated to wird-runtime', (after['wird-runtime'] || []).some(u => /aladhan/.test(u)) && (after['wird-runtime'] || []).some(u => /pdf\.min\.js/.test(u)), after['wird-runtime']);
  check('unknown cache left alone', (after['some-unknown-cache'] || []).length === 1);
  check('shell cache wird-v5 contains only shell files (no Quran/runtime data)', after['wird-v5'].every(u => u.startsWith(URL_BASE())));
  const data = await p.evaluate(async () => {
    const open = n => new Promise((ok, no) => { const q = indexedDB.open(n); q.onsuccess = () => ok(q.result); q.onerror = () => no(q.error); });
    const fnb = await open('wird_fnb_m'), bk = await open('wird_books_db');
    const rec = await new Promise(r => { const g = fnb.transaction('m').objectStore('m').get('testrec'); g.onsuccess = () => r(g.result); });
    const book = await new Promise(r => { const g = bk.transaction('books').objectStore('books').get('bk1'); g.onsuccess = () => r(g.result); });
    return { ls: localStorage.getItem('wird_test_habits'), courses: localStorage.getItem('wird_courses_v1'), rec, book, fnbV: fnb.version, bkV: bk.version, dbs: (indexedDB.databases ? (await indexedDB.databases()).map(d => d.name).sort() : []) };
  });
  check('localStorage preserved byte-for-byte', data.ls === '{"streak":42,"notes":["أ","ب"]}' && data.courses === '{"keep":"me"}', data);
  check('IndexedDB records preserved, versions unchanged (no re-creation)', data.rec && data.rec.n === 7 && data.book && data.book.id === 'bk1' && data.fnbV === 1 && data.bkV === 3, data);
  // offline after the update
  online = false; await ctx.setOffline(true);
  const offQ = await pageFetch(p, quranUrl(5)), offQ2 = await pageFetch(p, quranUrl(700)), offPray = await pageFetch(p, 'https://api.aladhan.com/v1/timingsByCity?city=Cairo&country=EG');
  check('offline: downloaded Quran page served from wird-v1', offQ.status === 200 && /page 5 /.test(offQ.text), offQ);
  check('offline: previously-viewed (migrated) page served', offQ2.status === 200 && /page 700/.test(offQ2.text), offQ2);
  check('offline: prayer times fall back to the last saved answer', offPray.status === 200 && /04:11/.test(offPray.text), offPray);
  const offMissing = await pageFetch(p, quranUrl(9999));
  check('offline: a never-cached Quran page fails cleanly (504), like before', offMissing.status === 504, offMissing);
  await p.reload(); await sleep(1500);
  check('offline launch AFTER the update works (page + pdf.js)', (await rel(p)) === 'v5' && await p.evaluate(() => !!document.querySelector('.tabs') && window.__PDFJS_STUB === 1));
  online = true; await ctx.setOffline(false);

  /* ===================== C. excluded hosts + strategy checks ===================== */
  section('C. Preserved network rules');
  const preC = await caches_(p);
  await pageFetch(p, 'https://www.youtube.com/iframe_api', { mode: 'no-cors' });
  await pageFetch(p, '/wird-app/range-test.bin', { headers: { Range: 'bytes=0-9' } });
  await pageFetch(p, 'https://everyayah.com/data/x.mp3', { mode: 'no-cors' }); await pageFetch(p, 'https://api.dictionaryapi.dev/api/v2/entries/en/test', { mode: 'no-cors' }); await sleep(400);
  const postC = await caches_(p); const flat = Object.values(postC).flat();
  check('YouTube / audio / dictionary / Range requests are NOT intercepted or cached', !flat.some(u => /youtube|ytimg|everyayah|dictionaryapi|range-test/.test(u)));
  quranMode = 'errorbody'; const bad = await pageFetch(p, quranUrl(801)); await sleep(500);
  check('a Quran API 200-with-error-body is returned but NOT stored', bad.status === 200 && !(await caches_(p))['wird-v1'].includes(quranUrl(801)));
  quranMode = 'ok'; const good = await pageFetch(p, quranUrl(802)); await sleep(500);
  check('a good page missed in the cache is fetched and stored for offline use', good.status === 200 && (await caches_(p))['wird-v1'].includes(quranUrl(802)));
  quranMode = 'errorbody'; const still = await pageFetch(p, quranUrl(5));
  check('a downloaded page is never overwritten by a later bad response', /page 5 /.test(still.text), still); quranMode = 'ok';

  /* ===================== D. update while the app is open (v5 → v6) ===================== */
  section('D. Update while the app is open: v5 → v6 (banner, Update Now, single reload)');
  await p.evaluate(() => { window.__alive = 'original-tab-state'; }); const nav0 = t.navs;
  current = release('v6', { version: 6 }); await p.evaluate(() => window.WirdUpdate.check());
  const b6 = await waitFor(() => banner(p), 15000);
  check('banner appears with "تحديث الآن" and the app keeps running (no reload)', b6 && /تحديث الآن/.test(b6.btn) && t.navs === nav0 && (await p.evaluate(() => window.__alive)) === 'original-tab-state', b6);
  check('RTL Arabic banner text is a clear notification', b6 && /نسخة جديدة/.test(b6.title) && /محفوظة/.test(b6.sub), b6);
  const st6 = await status(p), c6 = await caches_(p);
  check('v6 is waiting; v5 still active; v5 caches untouched', st6.hasWaiting && (await ver(p)).version === 5 && c6['wird-v6'] && c6['wird-v5'] && c6['wird-v1'].length >= 1812, { st6, keys: Object.keys(c6) });
  await p.click('#wirdUpdateNow');
  const reloaded = await waitFor(async () => t.navs === nav0 + 1 && (await rel(p)) === 'v6', 20000);
  check('Update Now → exactly one reload, new page is v6', reloaded && t.navs === nav0 + 1, { navs: t.navs - nav0 });
  await sleep(1500); check('v6 worker is the controller after reload', ((await ver(p)) || {}).version === 6);
  const gone5 = await waitFor(async () => !(await caches_(p))['wird-v5'], 20000, 300); const c6b = await caches_(p);
  check('wird-v5 (old shell) removed; wird-v1, wird-runtime, unknown cache preserved', gone5 && c6b['wird-v1'].length >= 1812 && c6b['wird-runtime'] && c6b['some-unknown-cache'], Object.keys(c6b));
  await sleep(4000); check('no reload loop (still one navigation 4 s later) and no leftover banner', t.navs === nav0 + 1 && !(await banner(p)));
  const d6 = await p.evaluate(() => ({ ls: localStorage.getItem('wird_test_habits') })); check('user data intact after the v6 update', d6.ls === '{"streak":42,"notes":["أ","ب"]}');

  /* ===================== E. two tabs ===================== */
  section('E. Multiple tabs: v6 → v7');
  const tA = { p, t }; const [pB, tB] = await openApp(ctx); await pB.evaluate(() => { window.__alive = 'tabB'; });
  current = release('v7', { version: 7 });
  await Promise.all([p.evaluate(() => window.WirdUpdate.check()), pB.evaluate(() => window.WirdUpdate.check())]);
  const bothBanner = await waitFor(async () => (await banner(p)) && (await banner(pB)), 15000);
  check('both open tabs show the update banner', bothBanner);
  const navA = tA.t.navs, navB = tB.navs; await clearGuard(p); await p.click('#wirdUpdateNow');
  await waitFor(async () => tA.t.navs === navA + 1 && (await rel(p)) === 'v7', 20000);
  const bB = await waitFor(async () => { const b = await banner(pB); return b && /اتفعّلت/.test(b.title) ? b : null; }, 10000);
  check('tab A reloads once into v7', tA.t.navs === navA + 1 && (await rel(p)) === 'v7');
  check('tab B is NOT force-reloaded; it is offered "إعادة التحميل"', bB && tB.navs === navB && (await pB.evaluate(() => window.__alive)) === 'tabB', bB);
  await pB.click('#wirdUpdateNow'); await waitFor(async () => tB.navs === navB + 1 && (await rel(pB)) === 'v7', 15000);
  check('tab B reloads once into v7 when the user agrees', tB.navs === navB + 1 && (await rel(pB)) === 'v7');
  await sleep(3000); check('no further navigations in either tab (no loops)', tA.t.navs === navA + 1 && tB.navs === navB + 1);
  await pB.close();

  /* ===================== F. failed update + recovery ===================== */
  section('F. Failed update (index.html missing on the server) and recovery: v7 → v8');
  const navF = t.navs; current = release('v8-broken', { version: 8, missing: ['index.html'] });
  await p.evaluate(() => window.WirdUpdate.check()); await sleep(3000);
  const stF = await status(p), cF = await caches_(p);
  check('install failed cleanly: no banner, nothing waiting, no half-written wird-v8', !(await banner(p)) && !stF.hasWaiting && !cF['wird-v8'], { stF, keys: Object.keys(cF) });
  check('app keeps running on v7 (still controlled, no reload)', (await ver(p)).version === 7 && t.navs === navF);
  online = false; await ctx.setOffline(true); await p.reload(); await sleep(1500);
  check('offline launch still works after the failed update', (await rel(p)) === 'v7' && await p.evaluate(() => !!document.querySelector('.tabs'))); online = true; await ctx.setOffline(false);
  current = release('v8', { version: 8 }); await p.evaluate(() => window.WirdUpdate.check());
  check('fixed upload is detected on the next check (automatic retry)', await waitFor(() => banner(p), 15000));

  /* ===================== G. update timeout path ===================== */
  section('G. Activation does not complete → app stays usable');
  await p.evaluate(() => { ServiceWorker.prototype.postMessage = function () {}; });   // simulate a worker that never answers
  await p.click('#wirdUpdateNow'); const navG = t.navs;
  const errB = await waitFor(async () => { const b = await banner(p); return b && /تعذّر/.test(b.title) ? b : null; }, 15000);
  check('after 10 s an honest error is shown, no reload, app still usable', errB && t.navs === navG && (await p.evaluate(() => !!document.querySelector('.tabs'))), errB);
  await p.reload(); await sleep(1500);   // restore the real postMessage

  /* ===================== H. content-only change (forgotten SHELL_VERSION bump) ===================== */
  section('H. index.html changed but SHELL_VERSION forgotten');
  await waitFor(async () => (await rel(p)) === 'v8' || (await banner(p)), 10000);        // a reload of the only open tab lets a waiting worker activate (Chromium); otherwise the banner is still there
  const viaBanner = !!(await banner(p)); if (viaBanner) { await clearGuard(p); await p.click('#wirdUpdateNow'); }
  await waitFor(async () => (await rel(p)) === 'v8', 20000); await sleep(1500);
  console.log('    (pending v8 was applied ' + (viaBanner ? 'from the banner' : 'by the page reload itself') + ')');
  check('pending v8 update ends up applied cleanly (page + worker both v8, no leftover banner)', (await rel(p)) === 'v8' && !(await banner(p)) && ((await ver(p)) || {}).version === 8);
  current = release('v8-hotfix', { version: 8 }); await p.evaluate(() => window.WirdUpdate.check());
  const bH = await waitFor(async () => { const b = await banner(p); return b && /ملفات ورد|نسخة جديدة/.test(b.title) ? b : null; }, 15000);
  check('changed index.html without a new SHELL_VERSION is still detected (same sw.js bytes)', !!bH && /ملفات ورد/.test(bH.title), bH);
  current = clone('v8-hotfix', 'v8-hotfix-same'); await p.reload(); await sleep(1500);   // adopt the hotfix first
  const navH = t.navs; current = clone('v8-hotfix', 'v8-hotfix-redeploy'); await p.evaluate(() => window.WirdUpdate.check()); await sleep(2500);
  check('re-deploying identical bytes (new ETag) does NOT raise a banner', !(await banner(p)) && t.navs === navH);

  /* ===================== I. busy guard + loop guard ===================== */
  section('I. Safety guards');
  current = release('v9', { version: 9 }); await p.evaluate(() => window.WirdUpdate.check()); await waitFor(() => banner(p), 15000);
  await p.evaluate(() => { const ta = document.createElement('textarea'); ta.id = 'wtest'; document.body.appendChild(ta); }); await p.fill('#wtest', 'نص مهم لسه بكتبه');
  const navI = t.navs; await clearGuard(p); await p.click('#wirdUpdateNow'); await sleep(800);
  const bI = await banner(p);
  check('typing in progress → Update Now asks again instead of reloading', bI && /اضغط تاني/.test(bI.sub) && t.navs === navI, bI);
  await p.click('#wirdUpdateNow'); await waitFor(async () => (await rel(p)) === 'v9', 20000);
  check('second explicit tap applies the update (v9)', (await rel(p)) === 'v9' && t.navs === navI + 1);
  await sleep(1500); const navL = t.navs;
  await p.evaluate(() => sessionStorage.setItem('wird_upd_reload', String(Date.now())));
  current = clone('v9', 'v9b'); fs.appendFileSync(path.join(TMP, 'v9b', 'index.html'), '\n<!-- changed -->'); await p.evaluate(() => window.WirdUpdate.check());
  await waitFor(() => banner(p), 15000); await p.click('#wirdUpdateNow'); await sleep(1200);
  const bL = await banner(p);
  check('reload-loop guard blocks a second reload within 15 s and reports it', t.navs === navL && bL && /تعذّر/.test(bL.title), bL);

  /* ===================== J. subdirectory ===================== */
  section('J. GitHub Pages sub-path');
  check('no request ever went outside /wird-app/ (no root-relative leaks)', outside.length === 0, outside.slice(0, 5));
  check('no console/page errors across the whole run', !(t.errs || []).length, t.errs);
  await ctx.close(); await browser.close(); server.close();
  const failed = results.filter(r => !r[1]);
  console.log('\n' + (results.length - failed.length) + '/' + results.length + ' checks passed' + (failed.length ? '  — FAILED: ' + failed.map(f => f[0]).join(' | ') : ''));
  process.exit(failed.length ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
