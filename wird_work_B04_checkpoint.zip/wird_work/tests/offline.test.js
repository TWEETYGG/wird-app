// فحص أوفلاين حقيقي بـ Service Worker: بعد زيارة واحدة أونلاين، هل بيتخدّم pdf.js (من CDN) وباقي الصفحة من الكاش لما النت يتقطع؟
// الـCDN متحوّل لرد مزيّف (مفيش اتصال حقيقي). التشغيل:  NODE_PATH=$(npm root -g) node tests/offline.test.js
process.env.PW_EXPERIMENTAL_SERVICE_WORKER_NETWORK_EVENTS = '1';   // route the requests the service worker itself makes
const { chromium } = require('playwright'); const http = require('http'), fs = require('fs'), path = require('path');
const ROOT = path.resolve(__dirname, '..'); const sleep = ms => new Promise(r => setTimeout(r, ms));
const server = http.createServer((req, res) => { const u = decodeURIComponent(req.url.split('?')[0]); const f = path.join(ROOT, u === '/' ? 'index.html' : u);
  fs.readFile(f, (e, d) => { if (e) { res.writeHead(404); return res.end() } const x = path.extname(f); res.writeHead(200, { 'content-type': x === '.html' ? 'text/html; charset=utf-8' : x === '.js' ? 'text/javascript' : x === '.png' ? 'image/png' : x === '.webmanifest' ? 'application/manifest+json' : 'text/plain', 'cache-control': 'no-store' }); res.end(d) }) });
(async () => {
  await new Promise(r => server.listen(0, '127.0.0.1', r)); const BASE = 'http://127.0.0.1:' + server.address().port;
  const browser = await chromium.launch({ args: ['--no-sandbox'] }); const ctx = await browser.newContext({ serviceWorkers: 'allow', locale: 'ar-EG' });
  let online = true; const cdnHits = []; const errs = [];
  await ctx.route(/^https?:\/\/(?!127\.0\.0\.1)/, r => { const u = r.request().url();
    if (/cdnjs\.cloudflare\.com\/ajax\/libs\/pdf\.js\/.*pdf\.min\.js/.test(u)) { cdnHits.push(u); return online ? r.fulfill({ status: 200, contentType: 'text/javascript', headers: { 'access-control-allow-origin': '*' }, body: 'window.__PDFJS_STUB=1;window.pdfjsLib={GlobalWorkerOptions:{},getDocument(){}};' }) : r.abort() }
    return r.abort() });
  const p = await ctx.newPage(); p.on('pageerror', e => errs.push(String(e)));
  const res = {};
  await p.goto(BASE + '/index.html'); await p.evaluate(() => navigator.serviceWorker.ready.then(() => 1)); await sleep(800);
  await p.reload(); await sleep(1200);                                          // تحت سيطرة الـSW ⇒ بيتخزّن
  res.controlled = await p.evaluate(() => !!navigator.serviceWorker.controller);
  res.cacheName = await p.evaluate(async () => (await caches.keys()).join(','));
  res.cdnCached = await p.evaluate(async () => { const c = await caches.open('wird-runtime'); return (await c.keys()).map(r => r.url).filter(u => /pdf\.min\.js/.test(u)).length });   // third-party files live in wird-runtime since the v5 cache layout
  res.stubOnline = await p.evaluate(() => window.__PDFJS_STUB === 1);
  online = false; await ctx.setOffline(true); await p.reload(); await sleep(1500);
  res.offlinePageLoaded = await p.evaluate(() => !!document.querySelector('.tabs') && !!window.WirdUnified);
  res.stubOffline = await p.evaluate(() => window.__PDFJS_STUB === 1);
  res.manhajiOfflineOpens = await (async () => { await p.click('.tab[data-view="view-lessons"]'); for (let i = 0; i < 40 && !(await p.evaluate(() => window.__WIRD_STUDY_APP__ && __WIRD_STUDY_APP__.isOpen)); i++) await sleep(150); return p.evaluate(() => !!(window.__WIRD_STUDY_APP__ && __WIRD_STUDY_APP__.isOpen)) })();
  console.log(JSON.stringify(res)); const okAll = res.controlled && /wird-v5/.test(res.cacheName) && res.cdnCached >= 1 && res.stubOnline && res.offlinePageLoaded && res.stubOffline && res.manhajiOfflineOpens && !errs.length;
  console.log(okAll ? '✔ offline: page + pdf.js (CDN) served from the service-worker cache, «منهجي» opens offline' : '✘ offline check failed ' + JSON.stringify(errs));
  await browser.close(); server.close(); process.exit(okAll ? 0 : 1);
})().catch(e => { console.error(e); process.exit(2) });
