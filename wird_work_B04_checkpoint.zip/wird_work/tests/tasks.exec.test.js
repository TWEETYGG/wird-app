/* tests/tasks.exec.test.js — B4 / TASK 1.3: focused execution screen (WirdTasks.exec) + the additive engine field `elapsedMs`.
   Part 1 (Node, no browser): the additive `elapsedMs` field of the engine.  Part 2 (real Chromium, Playwright): file:// pages,
   network aborted, service workers blocked, locale ar-EG, Africa/Cairo, FIXED clock (2026-11-06 10:00 +02:00).
   Reads the project, never modifies it. Screenshots go to WIRD_SHOTS_DIR (default docs/test-logs/B04/screens).
   WIRD_ONLY=A,B,...  runs only the named sections (the whole suite takes a few minutes; one tool command is limited to 300 s). */
'use strict';
const fs = require('fs'), path = require('path'), os = require('os');
const ROOT = path.resolve(__dirname, '..');
const SHOTS = process.env.WIRD_SHOTS_DIR || path.join(ROOT, 'docs', 'test-logs', 'B04', 'screens');
const T0 = new Date('2026-11-06T10:00:00+02:00'), TODAY = '2026-11-06', TOMORROW = '2026-11-07';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const ONLY = (process.env.WIRD_ONLY || '').split(',').map(s => s.trim()).filter(Boolean);
const want = s => !ONLY.length || ONLY.includes(s);
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'wird-exec-'));
process.on('exit', () => { try { fs.rmSync(TMP, { recursive: true, force: true }); } catch (e) { /* ignore */ } });

let passed = 0, failed = 0, assertions = 0; const failures = [];
setTimeout(() => { console.error('\n✘ WATCHDOG: the suite did not finish within 9 minutes'); process.exit(3); }, 9 * 60 * 1000).unref();
function assert(c, m) { assertions++; if (!c) throw new Error(m || 'assertion failed'); }
function eq(a, b, m) { assertions++; const x = JSON.stringify(a), y = JSON.stringify(b); if (x !== y) throw new Error((m || 'not equal') + '\n   got      ' + x.slice(0, 600) + '\n   expected ' + y.slice(0, 600)); }
async function step(name, fn) {
  const t = Date.now();
  try { await fn(); passed++; console.log('  ✔ ' + name + '  (' + (Date.now() - t) + ' ms)'); }
  catch (e) { failed++; failures.push(name); console.log('  ✘ ' + name + '\n     ' + String(e && e.message || e).split('\n').join('\n     ')); }
}

/* =============================================================================== part 1 — engine, additive field (Node) */
function part1() {
  const E = require(path.join(ROOT, 'tools', 'src', 'tasks-engine.js'));
  const mk = () => { let t = 1000000; const st = E.makeMemoryStorage(); let n = 0; return { st, tick: ms => { t += ms; }, eng: () => E.createEngine({ storage: st, clock: () => t, idGen: p => p + '_' + (++n) }) }; };
  const setup = (h, steps) => { const e = h.eng(); const t = e.createTask('2026-11-06', 'x', { steps: steps || ['a', 'b', 'c'] }); e.start(t.task.id); return { e, id: t.task.id, sid: i => e.getTask(t.task.id).steps[i].id }; };
  return [
    ['complete(stepId, {elapsedMs}) stores the field on the event; skip does too; it survives a reload', () => {
      const h = mk(), s = setup(h);
      const r = s.e.complete(s.sid(0), { elapsedMs: 4321 }); assert(r.ok && r.record.elapsedMs === 4321, 'result record carries elapsedMs');
      const r2 = s.e.skip(s.sid(1), { elapsedMs: 0 }); assert(r2.ok && r2.record.elapsedMs === 0, 'zero is a valid reading');
      const e2 = h.eng(); const ev = e2.getEvents({ taskId: s.id }).filter(e => e.type === 'complete' || e.type === 'skip');
      eq(ev.map(e => e.elapsedMs), [4321, 0], 'persisted and reloaded');
      eq(e2.status().repairs, 0, 'the new field is not a repair');
    }],
    ['invalid readings are ignored, never fail the action: negative, fractional, NaN, string, > 24 h, null, array', () => {
      const bad = [-1, 1.5, NaN, Infinity, '5', 86400001, null, [5], {}];
      bad.forEach((v, i) => {
        const h = mk(), s = setup(h, ['a', 'b']);
        const r = s.e.complete(s.sid(0), { elapsedMs: v });
        assert(r.ok && !r.noop, 'completes anyway for ' + String(v));
        assert(!('elapsedMs' in r.record), 'field absent for ' + String(v));
      });
      const h = mk(), s = setup(h, ['a', 'b']);
      assert(s.e.complete(s.sid(0), { elapsedMs: 86400000 }).record.elapsedMs === 86400000, '24 h exactly is accepted');
      assert(!('elapsedMs' in s.e.complete(s.sid(1), 'garbage').record), 'a non-object opts is ignored');
    }],
    ['complete without opts behaves exactly as before (no field), and a duplicate completion writes nothing', () => {
      const h = mk(), s = setup(h);
      const r = s.e.complete(s.sid(0)); assert(r.ok && !('elapsedMs' in r.record));
      const n = s.e.getEvents({ taskId: s.id }).length;
      const d = s.e.complete(s.sid(0), { elapsedMs: 999 }); assert(d.ok && d.noop && d.duplicate, 'duplicate');
      eq(s.e.getEvents({ taskId: s.id }).length, n, 'no new event');
      assert(!('elapsedMs' in s.e.getEvents({ taskId: s.id, type: 'complete' })[0]), 'the first record was not altered by the duplicate');
    }],
    ['undo voids a completion that carries elapsedMs; the history keeps both events; re-completing stores the new reading', () => {
      const h = mk(), s = setup(h);
      const c1 = s.e.complete(s.sid(0), { elapsedMs: 100 }); assert(s.e.undo(s.id, { key: c1.record.key }).ok);
      const c2 = s.e.complete(s.sid(0), { elapsedMs: 250 }); assert(c2.ok && c2.record.elapsedMs === 250);
      const all = s.e.getEvents({ taskId: s.id, type: 'complete' }).map(e => e.elapsedMs); eq(all, [100, 250]);
      eq(s.e.getCompletions({ taskId: s.id }).map(e => e.elapsedMs), [250], 'only the standing completion');
    }],
    ['old stored data without the field loads unchanged (backward compatible)', () => {
      const h = mk(), s = setup(h); s.e.complete(s.sid(0));
      const raw = h.st.getItem('wird_tasks_v1'); assert(raw && raw.indexOf('elapsedMs') < 0, 'old-format data has no field');
      const e2 = h.eng(); eq(e2.status().loadedFrom, 'storage'); eq(e2.getCompletions({ taskId: s.id }).length, 1);
    }],
    ['the field is a number on the event only: a non-primitive value planted in storage is dropped by the sanitizer, a valid one is kept', () => {
      const h = mk(), s = setup(h); s.e.complete(s.sid(0), { elapsedMs: 7 });
      const st = JSON.parse(h.st.getItem('wird_tasks_v1')); const ev = st.events.find(e => e.type === 'complete');
      ev.elapsedMs = { evil: 1 }; h.st.setItem('wird_tasks_v1', JSON.stringify(st));
      const e2 = h.eng(); assert(!('elapsedMs' in e2.getEvents({ type: 'complete' })[0]), 'object dropped');
      ev.elapsedMs = 55; h.st.setItem('wird_tasks_v1', JSON.stringify(st));
      eq(h.eng().getEvents({ type: 'complete' })[0].elapsedMs, 55, 'number kept');
    }]
  ];
}

/* ======================================================================================================== browser */
let browser;
const CTX = (o = {}) => ({ viewport: o.viewport || { width: 360, height: 640 }, locale: 'ar-EG', timezoneId: 'Africa/Cairo', serviceWorkers: 'block', reducedMotion: o.reducedMotion || 'no-preference' });
async function prep(ctx, o = {}) {
  await ctx.route(/^https?:\/\//, r => r.abort());
  const page = ctx.pages()[0] || await ctx.newPage(); page.errs = [];
  page.on('pageerror', e => page.errs.push('pageerror: ' + e));
  page.on('console', m => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) page.errs.push('console: ' + m.text()); });
  await page.clock.setFixedTime(o.time || T0);
  await page.addInitScript(() => {
    window.__vib = []; try { Object.defineProperty(navigator, 'vibrate', { value: p => { window.__vib.push(p); return true; }, configurable: true }); } catch (e) { /* ignore */ }
    window.__lst = {}; const add = EventTarget.prototype.addEventListener, rem = EventTarget.prototype.removeEventListener;
    const key = (t, ty) => (t === window ? 'window' : t === document ? 'document' : t === window.visualViewport ? 'vv' : 'other') + ':' + ty;
    EventTarget.prototype.addEventListener = function (ty, fn, op) { const k = key(this, ty); window.__lst[k] = (window.__lst[k] || 0) + 1; return add.call(this, ty, fn, op); };
    EventTarget.prototype.removeEventListener = function (ty, fn, op) { const k = key(this, ty); window.__lst[k] = (window.__lst[k] || 0) - 1; return rem.call(this, ty, fn, op); };
  });
  return page;
}
async function open(dir, o = {}) {
  const ctx = await browser.newContext(CTX(o)); const page = await prep(ctx, o);
  await page.goto('file://' + path.join(dir, 'index.html')); await sleep(o.settle || 800);
  page.ctx = ctx;
  if (o.habits !== false) { await page.click('.tab[data-view="view-habits"]'); await page.waitForSelector('#habitsRoot .hb-top'); await sleep(120); }
  return page;
}
const ls = (page, k) => page.evaluate(k => localStorage.getItem(k), k);
const E = (page, m, ...args) => page.evaluate(a => WirdTasks.getEngine()[a.m](...a.args), { m, args });
const tick = (page, secs) => page.clock.setFixedTime(new Date(T0.getTime() + secs * 1000));
const state = async page => JSON.parse(await ls(page, 'wird_tasks_v1'));
const nEv = async (page, taskId, type) => (await state(page)).events.filter(e => e.taskId === taskId && e.type === type).length;
const stepText = page => page.$eval('.wx-step', n => n.textContent);
const norm = s => String(s).replace(/[٠-٩]/g, d => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));
const view = page => page.evaluate(() => WirdTasks.exec.status().view);
const isOpen = page => page.evaluate(() => WirdTasks.exec.isOpen());
const STEPS4 = ['افتح الكتاب', 'اقرأ الفصل الأول', 'حل ٣ مسائل', 'راجع الأخطاء'];
/* prefs: applied as the session snapshot of a task that is started right away (engine start(id,{prefs})); the SAVED preferences stay untouched */
async function plan(page, title, steps, prefs, day) {
  return page.evaluate(a => {
    const e = WirdTasks.getEngine();
    const t = e.createTask(a.day || e.todayKey(), a.title, { steps: a.steps }); if (a.prefs) e.start(t.task.id, { prefs: a.prefs }); return t.task.id;
  }, { title, steps: steps || STEPS4, prefs: prefs || null, day: day || null });
}
const openRun = (page, id, o) => page.evaluate(a => { const r = WirdTasks.exec.open(a.id, a.o); return { ok: r.ok, reason: r.reason }; }, { id, o: o || { from: 'planner', fromView: 'task' } });
/* The UI lock after a resolving tap is behaviour under test elsewhere (section D). Everywhere else a test waits for it to release, instead of racing it with sleeps. */
const unlocked = page => page.waitForFunction(() => { const s = WirdTasks.exec.status(); return !s.open || !s.locked; }, null, { timeout: 4000 });
const clickAct = async (page, act, wait) => { await unlocked(page); await page.click('[data-act="' + act + '"]'); await sleep(wait === undefined ? 450 : wait); };
const clickDone = (page, wait) => clickAct(page, 'done', wait === undefined ? 700 : wait);
async function shot(page, name) { try { fs.mkdirSync(SHOTS, { recursive: true }); await page.screenshot({ path: path.join(SHOTS, name + '.png') }); } catch (e) { /* evidence only */ } }
const noErrors = (page, l) => eq(page.errs, [], (l || 'page') + ' had errors');
async function layout(page, tag, landscape) {
  const r = await page.evaluate(() => {
    const ov = document.querySelector('.wx-ov'); if (!ov) return { missing: true };
    const vis = el => { const b = el.getBoundingClientRect(); return b.width > 0 && b.height > 0 && getComputedStyle(el).visibility !== 'hidden'; };
    const small = [...ov.querySelectorAll('button, textarea, input')].filter(vis).map(b => { const r = b.getBoundingClientRect(); return { t: (b.getAttribute('data-act') || b.className), w: Math.round(r.width), h: Math.round(r.height) }; }).filter(b => b.w < 44 || b.h < 44);
    const st = ov.querySelector('.wx-step'), pr = ov.querySelector('.wx-primary'), pb = pr && pr.getBoundingClientRect(), o = ov.getBoundingClientRect();
    return { scrollW: document.documentElement.scrollWidth, innerW: innerWidth, innerH: innerHeight, dir: getComputedStyle(ov).direction, small,
      stepOverflow: st ? st.scrollWidth - st.clientWidth : 0, ovFull: Math.round(o.width) === innerWidth && Math.round(o.height) === innerHeight,
      pr: pb ? { cy: pb.top + pb.height / 2, h: pb.height, w: pb.width, bottom: pb.bottom, l: pb.left, r: pb.right } : null,
      cover: ['0.5,0.5', '0.1,0.1', '0.9,0.1', '0.1,0.9', '0.9,0.9'].map(s => { const [a, b] = s.split(',').map(Number); const e = document.elementFromPoint(innerWidth * a, innerHeight * b); return !!(e && e.closest('.wx-ov')); }) };
  });
  assert(!r.missing, tag + ': overlay present');
  assert(r.scrollW <= r.innerW, tag + ': horizontal overflow ' + r.scrollW + ' > ' + r.innerW);
  eq(r.dir, 'rtl', tag + ': direction'); assert(r.ovFull, tag + ': the overlay fills the viewport');
  eq(r.small, [], tag + ': controls under 44x44'); assert(r.stepOverflow <= 1, tag + ': step text overflows by ' + r.stepOverflow);
  assert(r.cover.every(Boolean), tag + ': app chrome shows through the overlay ' + JSON.stringify(r.cover));
  assert(r.pr && r.pr.h >= 52 && r.pr.l >= 0 && r.pr.r <= r.innerW && r.pr.bottom <= r.innerH, tag + ': primary action inside the viewport and large ' + JSON.stringify(r.pr));
  if (!landscape) assert(r.pr.cy > r.innerH * 0.6, tag + ': primary action is in the thumb zone (cy=' + r.pr.cy + ' of ' + r.innerH + ')');
  return r;
}

/* ===================================================================================================== main */
(async () => {
  console.log('B4 execution screen test — ' + new Date().toISOString());
  console.log('\n[1] engine: additive field elapsedMs (Node)');
  for (const [n, f] of part1()) await step(n, f);
  if (ONLY.length && !ONLY.some(s => /^[A-Z]$/.test(s))) { summary(); return; }

  const DIR = path.join(TMP, 'proj');
  fs.cpSync(ROOT, DIR, { recursive: true, filter: p => !/[\\/](node_modules|\.git)([\\/]|$)/.test(p) && !/test-logs/.test(p) });
  const { chromium } = require('playwright');
  browser = await chromium.launch({ args: ['--no-sandbox'] });
  console.log('Chromium ' + browser.version() + ', fixed clock ' + T0.toISOString());

  /* ------------------------------------------------------------------------------------------------- A */
  if (want('A')) {
    console.log('\n[A] default view: ONE step, ONE action, no list, no counters; never auto-opens');
    const p = await open(DIR); let id;
    await step('before any plan: WirdTasks.exec exists, nothing is open, no tasks key, no .wx element', async () => {
      eq(await p.evaluate(() => [typeof WirdTasks.exec.open, WirdTasks.exec.version, WirdTasks.exec.isOpen()]), ['function', 1, false]);
      eq(await ls(p, 'wird_tasks_v1'), null); eq(await p.$$eval('[class*="wx-"]', n => n.length), 0);
    });
    await step('open from the planner: «ابدأ» now appears, the planner closes, the immersive view opens on step 1 and the task starts', async () => {
      id = await plan(p, 'مذاكرة الكيمياء', STEPS4);
      await p.evaluate(i => WirdTasks.ui.openPlanner({ taskId: i }), id); await sleep(150);
      const lbl = await p.$eval('.wt-start', b => b.textContent); assert(lbl.includes('ابدأ'), 'label ' + lbl);
      await p.click('.wt-start'); await sleep(250);
      assert(await isOpen(p), 'exec open'); eq(await p.evaluate(() => WirdTasks.ui.isOpen()), false, 'planner closed');
      eq(await p.$$eval('.wt-ov, .wt-sheet', n => n.length), 0, 'no planner nodes in the DOM during the run');
      eq(await stepText(p), STEPS4[0]); eq((await E(p, 'getTask', id)).status, 'in_progress');
      eq(await p.evaluate(() => WirdTasks.exec.status().view), 'run');
    });
    await step('exactly ONE step node and ONE primary action; nothing else of the plan is in the overlay', async () => {
      eq(await p.$$eval('.wx-ov .wx-step', n => n.length), 1);
      eq(await p.$$eval('.wx-ov [data-act="done"]', n => n.length), 1);
      const txt = await p.$eval('.wx-ov', n => n.textContent);
      STEPS4.slice(1).forEach(s => assert(!txt.includes(s), 'another step is visible: ' + s));
      eq(await p.$$eval('.wx-ov .wt-task, .wx-ov .wt-step, .wx-ov ol, .wx-ov ul, .wx-ov li, .wx-ov table', n => n.length), 0, 'no lists');
    });
    await step('no "Step 2 of 8" style text, no counters, no progress node, no timer, no skip, no edit, no back (first step) by default', async () => {
      const txt = (await p.$eval('.wx-ov', n => n.textContent)).replace(/\s+/g, ' ');
      assert(!/Step/i.test(txt), 'Step'); assert(!/خطوة\s*[٠-٩0-9]/.test(txt), 'خطوة N'); assert(!/[٠-٩0-9]+\s*من\s*[٠-٩0-9]+/.test(txt), 'N من M');
      eq(await p.$$eval('.wx-prog, .wx-prog-slot > *, .wx-timer, [data-act="skip"], [data-act="edit"], [data-act="back"]', n => n.length), 0);
      const names = await p.$$eval('.wx-ov button', b => b.map(x => x.getAttribute('data-act')));
      eq(names.sort(), ['close', 'done', 'pause'], 'the only controls by default');
    });
    await step('the day list is never in the DOM: no planner, no task titles of other plans', async () => {
      const other = await plan(p, 'مهمة ثانية في اليوم', ['خطوة أخرى']); await sleep(100);
      const txt = await p.$eval('.wx-ov', n => n.textContent); assert(!txt.includes('مهمة ثانية'), 'other task visible');
      eq(await p.$$eval('.wx-ov .wt-task', n => n.length), 0);
      await E(p, 'deleteTask', other);
    });
    await step('the primary action is bigger than 44px and the dialog is announced (role, aria-modal, label)', async () => {
      const r = await p.$eval('.wx-ov', n => ({ role: n.getAttribute('role'), modal: n.getAttribute('aria-modal'), label: n.getAttribute('aria-label') }));
      eq(r, { role: 'dialog', modal: 'true', label: 'تنفيذ المهمة' });
    });
    await step('closing keeps the step; a reload does NOT auto-open the view; «متابعة» is offered and lands on the same step', async () => {
      await clickDone(p); eq(await stepText(p), STEPS4[1]);
      await p.click('.wx-x'); await sleep(200);
      eq(await isOpen(p), false); assert(await p.evaluate(() => WirdTasks.ui.isOpen()), 'back in the planner (came from the task editor)');
      await p.reload(); await sleep(900); await p.click('.tab[data-view="view-habits"]'); await sleep(200);
      eq(await p.$$eval('.wx-ov', n => n.length), 0, 'no auto-open after reload');
      await p.evaluate(i => WirdTasks.ui.openPlanner({ taskId: i }), id); await sleep(150);
      const lbl = await p.$eval('.wt-start', b => b.textContent); assert(lbl.includes('متابعة') && !lbl.includes('ابدأ'), 'label ' + lbl);
      await p.click('.wt-start'); await sleep(250); eq(await stepText(p), STEPS4[1], 'same step after reload');
      await shot(p, '360-1-run'); noErrors(p);
    });
    await p.ctx.close();
  }

  /* ------------------------------------------------------------------------------------------------- B */
  if (want('B')) {
    console.log('\n[B] flow: check → record → auto transition → undo / back / pause / finish');
    const p = await open(DIR); const id = await plan(p, 'مراجعة الفيزياء', STEPS4);
    await openRun(p, id, { from: 'planner', fromView: 'day' });
    await step('check records ONE completion with the step text, then step 2 appears automatically', async () => {
      await clickDone(p);
      eq(await stepText(p), STEPS4[1]); eq(await nEv(p, id, 'complete'), 1);
      const ev = (await state(p)).events.find(e => e.type === 'complete'); eq([ev.stepText, ev.taskTitle], [STEPS4[0], 'مراجعة الفيزياء']);
      assert(!('elapsedMs' in ev), 'no timer reading when the timer is off');
    });
    await step('the undo snackbar appears, is unobtrusive (not covering the primary action) and the step text is not repeated', async () => {
      const u = await p.$eval('.wx-undo', n => ({ hidden: n.hidden, t: n.textContent }));
      eq(u.hidden, false); assert(u.t.includes('اتسجّلت') && u.t.includes('تراجع'), u.t);
      const b = await p.evaluate(() => { const a = document.querySelector('.wx-undo').getBoundingClientRect(), c = document.querySelector('.wx-primary').getBoundingClientRect(); return { aBottom: a.bottom, cTop: c.top, h: a.height }; });
      assert(b.aBottom <= b.cTop + 1, 'snackbar overlaps the primary action'); assert(b.h <= 64, 'snackbar too tall ' + b.h);
    });
    await step('undo inside the window restores the previous step exactly, records an `undo` event, and the completion no longer stands', async () => {
      await p.click('[data-act="undo"]'); await sleep(500);
      eq(await stepText(p), STEPS4[0]); eq(await nEv(p, id, 'undo'), 1);
      eq((await E(p, 'getCompletions', { taskId: id })).length, 0, 'completion voided');
      eq((await E(p, 'getTask', id)).steps[0].state, 'in_progress');
      eq(await p.$eval('.wx-undo', n => n.hidden), true, 'snackbar gone'); eq(await nEv(p, id, 'complete'), 1, 'history keeps the original event');
    });
    await step('undo OUTSIDE the window is refused (engine clock), the step is unchanged, the user is told, the snackbar goes away', async () => {
      await clickDone(p); eq(await stepText(p), STEPS4[1]);
      await tick(p, 9); await p.click('[data-act="undo"]'); await sleep(300);
      eq(await stepText(p), STEPS4[1], 'unchanged'); eq(await nEv(p, id, 'undo'), 1, 'no second undo event');
      eq(await p.$eval('.wx-undo', n => n.hidden), true);
      assert((await p.$eval('.wx-msg', n => n.textContent)).includes('فات وقت التراجع'), 'message');
      await tick(p, 0);
    });
    await step('the snackbar also disappears on its own after the undo window (8 s, real time)', async () => {
      await clickDone(p, 300); eq(await p.$eval('.wx-undo', n => n.hidden), false);
      await sleep(8400); eq(await p.$eval('.wx-undo', n => n.hidden), true); eq(await stepText(p), STEPS4[2]);
    });
    await step('back returns to the previous step without a time limit (the completion is voided, not deleted)', async () => {
      const cur = await stepText(p); const before = await nEv(p, id, 'complete');
      await clickAct(p, 'back', 450);
      assert((await stepText(p)) !== cur, 'moved to the previous step');
      eq(await nEv(p, id, 'back'), 1); eq(await nEv(p, id, 'complete'), before, 'no event deleted');
    });
    await step('pause: a visible resume action, the engine is paused and refuses completion; resume returns to the same step', async () => {
      const cur = await stepText(p);
      await p.click('[data-act="pause"]'); await sleep(200);
      eq(await view(p), 'paused'); eq((await E(p, 'getTask', id)).status, 'paused');
      const b = await p.$eval('[data-act="resume"]', n => { const r = n.getBoundingClientRect(); return { h: r.height, t: n.textContent, v: n.offsetParent !== null }; });
      assert(b.v && b.h >= 44 && b.t.includes('متابعة'), JSON.stringify(b));
      assert(!(await p.$eval('.wx-ov', n => n.textContent)).includes(cur), 'the step is not shown while paused');
      const r = await E(p, 'complete', (await E(p, 'getCurrent', id)).step.id); eq([r.ok, r.reason], [false, 'paused']);
      await shot(p, '360-2-paused');
      await p.click('[data-act="resume"]'); await sleep(250);
      eq(await view(p), 'run'); eq(await stepText(p), cur); eq((await E(p, 'getTask', id)).status, 'in_progress');
      eq([await nEv(p, id, 'pause'), await nEv(p, id, 'resume')], [1, 1]);
    });
    await step('finishing the last step: a quiet completion state (no animation needed), undo still possible; «تمام» returns to the planner day', async () => {
      for (let i = 0; i < 6 && (await view(p)) === 'run'; i++) await clickDone(p, 600);
      eq(await view(p), 'done'); eq((await E(p, 'getTask', id)).status, 'completed');
      const txt = await p.$eval('.wx-ov', n => n.textContent); assert(txt.includes('خلصت المهمة') && txt.includes('مراجعة الفيزياء'), txt);
      eq(await p.$$eval('.wx-ov .wx-step', n => n.length), 0);
      await shot(p, '360-3-done');
      await p.click('[data-act="finish"]'); await sleep(250);
      eq(await isOpen(p), false); eq(await p.evaluate(() => WirdTasks.ui.status().view), 'day', 'planner day view');
      eq(await p.$eval('#wt-title', n => n.textContent), '🧩 خطوات المهام');
    });
    await step('every step was completed exactly once in the history (no duplicate completion records)', async () => {
      const ev = (await state(p)).events.filter(e => e.taskId === id && e.type === 'complete');
      const standing = await E(p, 'getCompletions', { taskId: id }); eq(standing.length, 4);
      eq(new Set(standing.map(e => e.stepText)).size, 4);
      eq(new Set(ev.map(e => e.key)).size, ev.length, 'unique event keys');
    });
    noErrors(p); await p.ctx.close();
  }

  /* ------------------------------------------------------------------------------------------------- C */
  if (want('C')) {
    console.log('\n[C] exact restore: reload, and a real browser restart (persistent profile)');
    const p = await open(DIR); const id = await plan(p, 'استرجاع', STEPS4);
    await step('reload mid-plan → «متابعة» → the same step; the in-progress step is derived, not stored in the UI', async () => {
      await openRun(p, id); await clickDone(p); await clickDone(p); eq(await stepText(p), STEPS4[2]);
      await p.reload(); await sleep(900);
      eq(await p.$$eval('.wx-ov', n => n.length), 0); eq((await E(p, 'getCurrent', id)).step.text, STEPS4[2]);
      await openRun(p, id); eq(await stepText(p), STEPS4[2], 'same step'); eq(await nEv(p, id, 'start'), 1, 'not restarted');
    });
    await step('paused then closed then reloaded: the task is still paused; opening resumes it at the same step; opening with resume:false shows the paused view', async () => {
      await p.click('[data-act="pause"]'); await p.click('.wx-x'); await sleep(150);
      await p.reload(); await sleep(900);
      eq((await E(p, 'getTask', id)).status, 'paused');
      await p.evaluate(i => WirdTasks.exec.open(i, { resume: false }), id); await sleep(150);
      eq(await view(p), 'paused'); await p.click('.wx-x'); await sleep(100);
      await openRun(p, id); eq(await view(p), 'run'); eq(await stepText(p), STEPS4[2]); eq((await E(p, 'getTask', id)).status, 'in_progress');
    });
    await p.ctx.close();
    await step('persistent browser profile: complete two steps, close the whole browser context, start a new one → same step', async () => {
      const ud = path.join(TMP, 'profile'); const o = { ...CTX(), args: ['--no-sandbox'] };
      let c1 = await chromium.launchPersistentContext(ud, o); let p1 = await prep(c1);
      await p1.goto('file://' + path.join(DIR, 'index.html')); await sleep(900);
      const tid = await plan(p1, 'إعادة تشغيل المتصفح', STEPS4); await openRun(p1, tid); await clickDone(p1); await clickDone(p1);
      eq(await stepText(p1), STEPS4[2]); await c1.close();
      const c2 = await chromium.launchPersistentContext(ud, o); const p2 = await prep(c2);
      await p2.goto('file://' + path.join(DIR, 'index.html')); await sleep(900);
      eq(await p2.$$eval('.wx-ov', n => n.length), 0, 'not auto-opened after a restart');
      assert((await E(p2, 'getTask', tid)).status === 'in_progress', 'still in progress');
      await openRun(p2, tid); eq(await stepText(p2), STEPS4[2], 'same step after a restart');
      eq(await nEv(p2, tid, 'complete'), 2); await c2.close();
    });
  }

  /* ------------------------------------------------------------------------------------------------- D */
  if (want('D')) {
    console.log('\n[D] double / triple tap protection');
    const p = await open(DIR); const id = await plan(p, 'نقرات سريعة', STEPS4);
    await openRun(p, id);
    await step('a real triple click (clickCount 3) records ONE completion and shows step 2, not step 3', async () => {
      await p.click('[data-act="done"]', { clickCount: 3, delay: 10 }); await sleep(700);
      eq(await nEv(p, id, 'complete'), 1); eq(await stepText(p), STEPS4[1]);
    });
    await step('five synchronous clicks on the same button → one completion', async () => {
      await sleep(300);
      await p.evaluate(() => { const b = document.querySelector('[data-act="done"]'); for (let i = 0; i < 5; i++) b.click(); }); await sleep(700);
      eq(await nEv(p, id, 'complete'), 2); eq(await stepText(p), STEPS4[2]);
    });
    await step('taps spaced 120 ms apart inside the transition (4 taps) → one completion', async () => {
      await sleep(300);
      for (let i = 0; i < 4; i++) { await p.evaluate(() => { const b = document.querySelector('[data-act="done"]'); if (b) b.click(); }); await sleep(120); }
      await sleep(500); eq(await nEv(p, id, 'complete'), 3); eq(await stepText(p), STEPS4[3]);
    });
    await step('the lock is short and not permanent: it releases within 800 ms (≥ 300 ms, so a double tap cannot slip through), then a normal tap completes the next step', async () => {
      await sleep(900); const id9 = await plan(p, 'قفل', ['أ', 'ب']); await openRun(p, id9, { from: 'x' });
      const t1 = Date.now(); await p.click('[data-act="done"]'); await unlocked(p); const lockMs = Date.now() - t1;
      assert(lockMs >= 250 && lockMs <= 800, 'lock lasted ' + lockMs + ' ms'); await p.click('.wx-x'); await sleep(100); await openRun(p, id, { from: 'x' });
      await clickDone(p, 700); eq(await nEv(p, id, 'complete'), 4); eq(await view(p), 'done');
    });
    await step('engine-level idempotency still holds when the UI is bypassed (same step id three times)', async () => {
      const id2 = await plan(p, 'مباشر', ['أ', 'ب']); await E(p, 'start', id2);
      const sid = (await E(p, 'getCurrent', id2)).step.id;
      const rs = await p.evaluate(s => [0, 1, 2].map(() => { const r = WirdTasks.getEngine().complete(s); return [r.ok, !!r.noop]; }), sid);
      eq(rs, [[true, false], [true, true], [true, true]]); eq(await nEv(p, id2, 'complete'), 1);
    });
    await step('double-tapping «تراجع» undoes once', async () => {
      await p.click('[data-act="finish"]').catch(() => {}); await sleep(100);
      const id3 = await plan(p, 'تراجع مزدوج', ['أ', 'ب', 'ج']); await openRun(p, id3, { from: 'x' }); await clickDone(p, 600);
      await p.evaluate(() => { const b = document.querySelector('[data-act="undo"]'); b.click(); b.click(); b.click(); }); await sleep(500);
      eq(await nEv(p, id3, 'undo'), 1); eq(await stepText(p), 'أ');
    });
    noErrors(p); await p.ctx.close();
  }

  /* ------------------------------------------------------------------------------------------------- E */
  if (want('E')) {
    console.log('\n[E] skip: disabled by default, enabled by a preference; a skipped step is never completed');
    const p = await open(DIR);
    await step('default (skipStep off): no skip control', async () => {
      const id = await plan(p, 'بدون تخطي', STEPS4); await openRun(p, id);
      eq(await p.$$eval('[data-act="skip"]', n => n.length), 0); await p.click('.wx-x');
    });
    await step('skipStep on (saved pref, snapshot taken at start): the control appears; skipping records `skip`, not `complete`; undo restores it', async () => {
      await E(p, 'setPrefs', { skipStep: true }); const id = await plan(p, 'مع تخطي', STEPS4); await openRun(p, id, { from: 'x' });
      eq(await p.$$eval('[data-act="skip"]', n => n.length), 1);
      await clickAct(p, 'skip', 450);
      eq(await stepText(p), STEPS4[1]); eq(await nEv(p, id, 'skip'), 1); eq(await nEv(p, id, 'complete'), 0);
      eq((await E(p, 'getCompletions', { taskId: id })).length, 0, 'a skipped step is never a completion');
      const t = await E(p, 'getTask', id); eq(t.steps[0].state, 'skipped'); eq(t.counts.completed, 0);
      assert((await p.$eval('.wx-undo', n => n.textContent)).includes('اتخطّت'), 'snackbar says skipped');
      await p.click('[data-act="undo"]'); await sleep(450); eq(await stepText(p), STEPS4[0]); eq((await E(p, 'getTask', id)).steps[0].state, 'in_progress');
      await E(p, 'resetPrefs'); await p.click('.wx-x');
    });
    await step('changing the saved prefs does not alter a running session; a session override applies after the next render', async () => {
      const id = await plan(p, 'لقطة', STEPS4); await openRun(p, id, { from: 'x' });
      await E(p, 'setPrefs', { skipStep: true }); await p.click('[data-act="pause"]'); await p.click('[data-act="resume"]'); await sleep(250);
      eq(await p.$$eval('[data-act="skip"]', n => n.length), 0, 'snapshot unchanged');
      await E(p, 'setSessionPrefs', id, { skipStep: true }); await p.click('[data-act="pause"]'); await p.click('[data-act="resume"]'); await sleep(250);
      eq(await p.$$eval('[data-act="skip"]', n => n.length), 1, 'session override visible'); await E(p, 'resetPrefs'); await p.click('.wx-x');
    });
    await step('skipping everything ends as «skipped»; skipping some and completing others ends as «partial» — never as completed', async () => {
      const a = await plan(p, 'كله تخطي', ['أ', 'ب'], { skipStep: true }); await openRun(p, a, { from: 'x' });
      await clickAct(p, 'skip', 450); await clickAct(p, 'skip', 450);
      eq(await view(p), 'done'); eq((await E(p, 'getTask', a)).status, 'skipped'); assert((await p.$eval('.wx-ov', n => n.textContent)).includes('اتخطّيت كل الخطوات'));
      await p.click('[data-act="finish"]'); await sleep(100);
      const b = await plan(p, 'جزئي', ['أ', 'ب'], { skipStep: true }); await openRun(p, b, { from: 'x' });
      await clickAct(p, 'skip', 450); await clickDone(p, 600);
      eq((await E(p, 'getTask', b)).status, 'partial'); assert((await p.$eval('.wx-ov', n => n.textContent)).includes('خطوات اتخطّت'));
      eq((await E(p, 'getCompletions', { taskId: b })).length, 1); await E(p, 'resetPrefs'); await p.click('[data-act="finish"]');
    });
    noErrors(p); await p.ctx.close();
  }

  /* ------------------------------------------------------------------------------------------------- F */
  if (want('F')) {
    console.log('\n[F] edit in the run');
    const p = await open(DIR);
    await step('default: no edit control', async () => {
      const id = await plan(p, 'بدون تعديل', STEPS4); await openRun(p, id, { from: 'x' }); eq(await p.$$eval('[data-act="edit"]', n => n.length), 0); await p.click('.wx-x');
    });
    const id = await plan(p, 'مع تعديل', STEPS4, { editDuringExecution: true });
    await step('editDuringExecution on: edit the current step inline → saved through the engine, same step stays current, nothing is completed', async () => {
      await openRun(p, id, { from: 'x' }); await p.click('[data-act="edit"]'); await sleep(100);
      eq(await p.$$eval('.wx-ov textarea', n => n.length), 1);
      eq(await p.$$eval('.wx-ov [data-act="done"]', n => n.length), 0, 'no completion button while editing');
      await p.fill('.wx-edit-in', 'افتح كتاب الكيمياء العضوية'); await p.click('[data-act="edit-save"]'); await sleep(200);
      eq(await stepText(p), 'افتح كتاب الكيمياء العضوية'); eq((await E(p, 'getTask', id)).steps[0].text, 'افتح كتاب الكيمياء العضوية');
      eq(await nEv(p, id, 'complete'), 0); eq(await nEv(p, id, 'step_edit'), 1);
    });
    await step('an empty or over-long text is refused with a message and the old text stays', async () => {
      await p.click('[data-act="edit"]'); await p.fill('.wx-edit-in', '   '); await p.click('[data-act="edit-save"]'); await sleep(150);
      assert((await p.$eval('.wx-msg', n => n.textContent)).includes('فاضي'), 'message'); eq(await p.$$eval('.wx-edit-in', n => n.length), 1, 'still editing');
      await p.keyboard.press('Escape'); await sleep(150);
      eq(await stepText(p), 'افتح كتاب الكيمياء العضوية'); eq(await isOpen(p), true, 'Esc cancelled the edit only');
      await p.click('[data-act="edit"]'); eq(await p.$eval('.wx-edit-in', n => +n.getAttribute('maxlength')), 300);
      await p.keyboard.press('Escape'); await sleep(100);
    });
    await step('Enter saves, Shift+Enter is a new line; closing while editing keeps a valid change; the dialog is not closed by Enter', async () => {
      await p.click('[data-act="edit"]'); await p.fill('.wx-edit-in', 'نص جديد'); await p.press('.wx-edit-in', 'Enter'); await sleep(200);
      eq(await stepText(p), 'نص جديد'); eq(await isOpen(p), true);
      await p.click('[data-act="edit"]'); await p.fill('.wx-edit-in', 'نص ثالث'); await p.click('.wx-x'); await sleep(150);
      eq((await E(p, 'getTask', id)).steps[0].text, 'نص ثالث', 'close committed the valid edit');
    });
    await step('the soft keyboard (viewport shrinks to 300 px high) keeps the field and its save button visible', async () => {
      await openRun(p, id, { from: 'x' }); await p.click('[data-act="edit"]'); await sleep(100);
      await p.setViewportSize({ width: 360, height: 300 }); await sleep(300);
      const r = await p.evaluate(() => { const t = document.querySelector('.wx-edit-in').getBoundingClientRect(), b = document.querySelector('[data-act="edit-save"]').getBoundingClientRect(); return { tt: t.top, tb: t.bottom, bb: b.bottom, bt: b.top, H: innerHeight }; });
      assert(r.tt >= 0 && r.tb <= r.H && r.bb <= r.H && r.bt >= 0, JSON.stringify(r));
      await shot(p, '360-4-keyboard'); await p.setViewportSize({ width: 360, height: 640 }); await p.click('[data-act="edit-cancel"]');
    });
    noErrors(p); await p.ctx.close();
  }

  /* ------------------------------------------------------------------------------------------------- G */
  if (want('G')) {
    console.log('\n[G] optional timer and progress indicator');
    const p = await open(DIR);
    await step('timer off by default: no element, no interval-created text', async () => {
      const id = await plan(p, 'بدون مؤقت', STEPS4); await openRun(p, id, { from: 'x' }); eq(await p.$$eval('.wx-timer', n => n.length), 0); await p.click('.wx-x');
    });
    await step('timer on: a subtle stopwatch counts the current step (fixed clock +65 s → ٠١:٠٥); pause stops it; the reading is stored with the completion', async () => {
      const id = await plan(p, 'مع مؤقت', STEPS4, { timer: true });
      await openRun(p, id, { from: 'x' }); assert(norm(await p.$eval('.wx-timer', n => n.textContent)) === '00:00', 'starts at zero');
      await tick(p, 10); await p.click('[data-act="pause"]'); await tick(p, 110); await sleep(200);
      await p.click('[data-act="resume"]'); await tick(p, 115); await sleep(1300);
      eq(norm(await p.$eval('.wx-timer', n => n.textContent)), '00:15', 'paused time is not counted (10 s + 5 s)');
      await clickDone(p, 300);
      const ev = (await state(p)).events.find(e => e.taskId === id && e.type === 'complete'); eq(ev.elapsedMs, 15000, 'stored additive field');
      eq(norm(await p.$eval('.wx-timer', n => n.textContent)), '00:00', 'the next step starts from zero');
      await tick(p, 0); await p.click('.wx-x');
    });
    await step('after closing there is no timer element left (the interval is cleared with the view)', async () => {
      eq(await p.$$eval('.wx-timer', n => n.length), 0);
    });
    await step('progress hidden (default): no node at all; subtle: a bar and NO numbers; detailed: «N من M»', async () => {
      const a = await plan(p, 'تقدم', STEPS4); await openRun(p, a, { from: 'x' }); eq(await p.$$eval('.wx-prog', n => n.length), 0, 'hidden'); await clickDone(p, 500);
      await E(p, 'setSessionPrefs', a, { progress: 'subtle' }); await p.click('[data-act="pause"]'); await p.click('[data-act="resume"]'); await sleep(200);
      eq(await p.$$eval('.wx-prog', n => n.length), 1); eq(await p.$$eval('.wx-prog-txt', n => n.length), 0, 'subtle has no text');
      eq(await p.$eval('.wx-prog', n => n.getAttribute('aria-valuenow')), '1');
      await E(p, 'setSessionPrefs', a, { progress: 'detailed' }); await p.click('[data-act="pause"]'); await p.click('[data-act="resume"]'); await sleep(200);
      eq(norm(await p.$eval('.wx-prog-txt', n => n.textContent)), '1 من 4');
      const w = await p.$eval('.wx-prog-fill', n => n.style.width); eq(w, '25%'); await shot(p, '360-5-progress'); await p.click('.wx-x');
    });
    noErrors(p); await p.ctx.close();
  }

  /* ------------------------------------------------------------------------------------------------- H */
  if (want('H')) {
    console.log('\n[H] automatic transition off, haptic / sound only when enabled');
    const p = await open(DIR);
    await step('autoTransition off: the checked step stays (marked done) with «التالية»; engine already recorded; next shows step 2; undo works in that state', async () => {
      const id = await plan(p, 'يدوي', STEPS4, { autoTransition: false }); await openRun(p, id, { from: 'x' });
      await clickDone(p, 400);
      eq(await view(p), 'hold'); eq(await stepText(p), STEPS4[0]); assert(await p.$eval('.wx-step', n => n.classList.contains('done')));
      eq(await nEv(p, id, 'complete'), 1); eq((await p.$eval('[data-act="next"]', n => n.textContent)), 'التالية');
      await p.click('[data-act="undo"]'); await sleep(450); eq(await view(p), 'run'); eq(await stepText(p), STEPS4[0]);
      await clickDone(p, 400); await sleep(300); await p.click('[data-act="next"]'); await sleep(500);
      eq(await stepText(p), STEPS4[1]); eq(await view(p), 'run'); await p.click('.wx-x');
    });
    await step('haptic and sound are OFF by default (no vibrate call, no blip); ON when the preference says so', async () => {
      await p.evaluate(() => { window.__blips = 0; WirdKit.audio.blip = () => { window.__blips++; return true; }; window.__vib.length = 0; });
      const a = await plan(p, 'بدون صوت', STEPS4); await openRun(p, a, { from: 'x' }); await clickDone(p, 500);
      eq(await p.evaluate(() => [window.__vib.length, window.__blips]), [0, 0]); await p.click('.wx-x');
      const b = await plan(p, 'مع صوت', STEPS4, { haptic: true, sound: true }); await openRun(p, b, { from: 'x' }); await clickDone(p, 500);
      eq(await p.evaluate(() => [window.__vib.length, window.__blips]), [1, 1], 'once per completion'); await p.click('.wx-x');
    });
    noErrors(p); await p.ctx.close();
  }

  /* ------------------------------------------------------------------------------------------------- I */
  if (want('I')) {
    console.log('\n[I] reduced motion and animation discipline');
    await step('tasks-exec.css: every transition / animation / keyframes lives inside @media (prefers-reduced-motion: no-preference), and only opacity/transform are animated', () => {
      const css = fs.readFileSync(path.join(ROOT, 'tools', 'src', 'tasks-exec.css'), 'utf8').replace(/\/\*[\s\S]*?\*\//g, '');
      const at = css.indexOf('@media (prefers-reduced-motion: no-preference)'); assert(at >= 0, 'media block');
      let depth = 0, end = -1; for (let i = css.indexOf('{', at); i < css.length; i++) { if (css[i] === '{') depth++; else if (css[i] === '}') { depth--; if (!depth) { end = i; break; } } }
      const outside = css.slice(0, at) + css.slice(end + 1); const inside = css.slice(at, end + 1);
      assert(!/transition|animation|@keyframes/.test(outside), 'motion outside the media block');
      const props = [...inside.matchAll(/transition:\s*([^;]+);/g)].map(m => m[1].split(',').map(x => x.trim().split(/\s+/)[0]));
      props.flat().forEach(pn => assert(pn === 'opacity' || pn === 'transform', 'transition on ' + pn));
      const frames = [...inside.matchAll(/@keyframes[^{]+\{([\s\S]*?\})\s*\}/g)].map(m => m[1]);
      frames.forEach(f => [...f.matchAll(/([a-z-]+)\s*:/g)].forEach(m => assert(['opacity', 'transform'].includes(m[1]), 'keyframe property ' + m[1])));
      assert(frames.length >= 3, 'keyframes found');
    });
    const run = async reduced => {
      const p = await open(DIR, { reducedMotion: reduced ? 'reduce' : 'no-preference' }); const id = await plan(p, 'حركة', STEPS4); await openRun(p, id, { from: 'x' });
      await p.evaluate(() => { window.__cls = []; const st = document.querySelector('.wx-stage'); new MutationObserver(() => window.__cls.push(st.className)).observe(st, { attributes: true, attributeFilter: ['class'] }); });
      const t0 = Date.now(); await p.click('[data-act="done"]');
      await p.waitForFunction(s => document.querySelector('.wx-step') && document.querySelector('.wx-step').textContent === s, STEPS4[1], { timeout: 3000 }); const dt = Date.now() - t0;
      await sleep(500);
      const cs = await p.evaluate(() => { const st = document.querySelector('.wx-stage'), bar = document.querySelector('.wx-undo-bar'); st.classList.add('wx-enter'); const a = getComputedStyle(st).animationName; st.classList.remove('wx-enter'); st.classList.add('wx-leave'); const tr = getComputedStyle(st).transitionDuration; st.classList.remove('wx-leave'); return { enter: a, leave: tr, drain: bar ? getComputedStyle(bar).animationName : 'no-bar', cls: window.__cls }; });
      return { p, dt, cs };
    };
    await step('reduced motion: the swap is immediate (no wx-leave / wx-enter ever applied, no animation or transition computed)', async () => {
      const { p, dt, cs } = await run(true);
      eq(cs.cls.filter(c => /wx-(leave|enter)/.test(c)), [], 'no motion classes'); eq(cs.enter, 'none'); assert(parseFloat(cs.leave) <= 0.001, 'transition ' + cs.leave + ' (the app itself clamps to 0.01 ms under reduced motion)'); eq(cs.drain, 'none');
      assert(dt < 160, 'step swapped in ' + dt + ' ms (no artificial delay under reduced motion)'); await p.ctx.close();
    });
    await step('no reduced-motion request: the leave/enter classes ARE used and the CSS defines the animation (so the check above is sensitive)', async () => {
      const { p, dt, cs } = await run(false);
      assert(cs.cls.some(c => /wx-leave/.test(c)) && cs.cls.some(c => /wx-enter/.test(c)), 'motion classes seen: ' + JSON.stringify(cs.cls));
      eq(cs.enter, 'wx-in'); assert(/0\.17s/.test(cs.leave), 'transition ' + cs.leave); eq(cs.drain, 'wx-drain'); assert(dt >= 150, 'the fade takes time: ' + dt); await p.ctx.close();
    });
    await step('completionAnimation "off": no motion even when the system allows it', async () => {
      const p = await open(DIR); const id = await plan(p, 'بدون حركة', STEPS4, { completionAnimation: 'off' }); await openRun(p, id, { from: 'x' });
      await p.evaluate(() => { window.__cls = []; const st = document.querySelector('.wx-stage'); new MutationObserver(() => window.__cls.push(st.className)).observe(st, { attributes: true, attributeFilter: ['class'] }); });
      await p.click('[data-act="done"]'); await sleep(500);
      eq((await p.evaluate(() => window.__cls)).filter(c => /wx-(leave|enter)/.test(c)), []); eq(await p.$eval('.wx-ov', n => n.getAttribute('data-anim')), 'off');
      eq(await p.$$eval('.wx-pop', n => n.length), 0); await p.ctx.close();
    });
  }

  /* ------------------------------------------------------------------------------------------------- J */
  if (want('J')) {
    console.log('\n[J] Android Back / history, listeners, entry points, return navigation');
    const p = await open(DIR);
    await step('Back (history) closes the view and keeps the state; the page is not left', async () => {
      const id = await plan(p, 'رجوع', STEPS4); const url = p.url(); await openRun(p, id, { from: 'planner', fromView: 'task' }); await clickDone(p, 400);
      assert(await p.evaluate(() => !!(history.state && history.state.wirdExec)), 'an entry was pushed');
      await p.goBack(); await sleep(350); eq(p.url(), url); eq(await isOpen(p), false);
      eq((await E(p, 'getCurrent', id)).step.text, STEPS4[1]); eq(await p.evaluate(() => WirdTasks.ui.status().view), 'task', 'returned to the task editor');
      await p.evaluate(() => WirdTasks.ui.closePlanner());
    });
    await step('closing with the ✕ pops the entry it pushed (no leftover state, page stays)', async () => {
      const id = await plan(p, 'إغلاق', STEPS4); const url = p.url(); await openRun(p, id, { from: 'x' });
      await p.click('.wx-x'); await sleep(400);
      eq(await p.evaluate(() => history.state), null); eq(p.url(), url); eq(await isOpen(p), false);
    });
    await step('open → close → open → close in quick succession never leaves the page and ends with no state', async () => {
      const id = await plan(p, 'تكرار', STEPS4); const url = p.url();
      for (let i = 0; i < 3; i++) { await openRun(p, id, { from: 'x' }); await p.click('.wx-x'); }
      await sleep(600); eq(p.url(), url); eq(await p.evaluate(() => history.state), null); eq(await isOpen(p), false);
      await openRun(p, id, { from: 'x' }); await p.goBack(); await sleep(350); eq(await isOpen(p), false, 'Back still closes after the sequence');
    });
    await step('Esc closes the view; Tab stays inside it (focus trap)', async () => {
      const id = await plan(p, 'مفاتيح', STEPS4); await openRun(p, id, { from: 'x' });
      for (let i = 0; i < 6; i++) { await p.keyboard.press('Tab'); assert(await p.evaluate(() => !!document.activeElement.closest('.wx-ov')), 'focus escaped on Tab ' + i); }
      await p.keyboard.press('Escape'); await sleep(250); eq(await isOpen(p), false);
    });
    await step('listeners are lazy and balanced: document keydown / window popstate / visualViewport added on open are removed on close', async () => {
      const base = await p.evaluate(() => ({ ...window.__lst }));
      const id = await plan(p, 'توازن', STEPS4, { timer: true }); await openRun(p, id, { from: 'x' });
      const during = await p.evaluate(() => ({ ...window.__lst }));
      assert((during['document:keydown'] || 0) > (base['document:keydown'] || 0), 'keydown added while open');
      await p.click('.wx-x'); await sleep(500);
      const after = await p.evaluate(() => ({ ...window.__lst }));
      ['document:keydown', 'window:popstate', 'vv:resize', 'vv:scroll'].forEach(k => eq(after[k] || 0, base[k] || 0, 'unbalanced ' + k));
      eq(await p.evaluate(() => WirdTasks.exec.status().open), false);
    });
    await step('open() refusals: unknown id, empty plan, finished plan → { ok:false, reason }, nothing opens, nothing is written', async () => {
      const empty = await p.evaluate(() => { const e = WirdTasks.getEngine(); return e.createTask(e.todayKey(), 'فاضية').task.id; });
      const fin = await plan(p, 'منتهية', ['أ']); await E(p, 'start', fin); await E(p, 'complete', (await E(p, 'getCurrent', fin)).step.id);
      const before = await ls(p, 'wird_tasks_v1');
      eq(await openRun(p, 'nope'), { ok: false, reason: 'not_found' }); eq(await openRun(p, empty), { ok: false, reason: 'no_steps' }); eq(await openRun(p, fin), { ok: false, reason: 'finished' });
      eq(await isOpen(p), false); eq(await ls(p, 'wird_tasks_v1'), before);
    });
    await step('open() replaces a run that is already open, and closes an open planner first', async () => {
      const a = await plan(p, 'أولى', ['أ1', 'أ2']), b = await plan(p, 'ثانية', ['ب1', 'ب2']);
      await openRun(p, a, { from: 'x' }); await openRun(p, b, { from: 'x' }); eq(await stepText(p), 'ب1'); eq(await p.$$eval('.wx-ov', n => n.length), 1);
      await p.evaluate(i => { WirdTasks.exec.close(); WirdTasks.ui.openPlanner({ taskId: i }); }, a); await sleep(100);
      await openRun(p, a, { from: 'x' }); eq(await p.evaluate(() => WirdTasks.ui.isOpen()), false); eq(await p.$$eval('.wt-ov', n => n.length), 0);
      await p.click('.wx-x'); await sleep(300); eq(await p.evaluate(() => history.state), null);
    });
    await step('the planner keeps the B3 contract exactly: exec.open(id, {from:"planner"}); the origin is handed over once through ui.takeOrigin(id)', async () => {
      const id = await plan(p, 'عقد', ['أ', 'ب']);
      await p.evaluate(() => { window.__real = WirdTasks.exec; WirdTasks.exec = { open: (i, o) => { window.__call = [i, o]; } }; });
      await p.evaluate(i => WirdTasks.ui.openPlanner({ taskId: i }), id); await sleep(120); await p.click('.wt-start'); await sleep(120);
      eq(await p.evaluate(() => window.__call), [id, { from: 'planner' }], 'exact arguments');
      eq(await p.evaluate(i => WirdTasks.ui.takeOrigin(i), id), { view: 'task', day: TODAY }, 'origin recorded');
      eq(await p.evaluate(i => WirdTasks.ui.takeOrigin(i), id), null, 'consumed once');
      eq(await p.evaluate(() => WirdTasks.ui.takeOrigin('zzz')), null, 'foreign id');
      await p.evaluate(() => { WirdTasks.exec = window.__real; });
    });
    await step('return navigation: from the day view → day view; from the task editor → editor; after finishing → day view', async () => {
      const id = await plan(p, 'عودة', ['أ', 'ب']);
      await p.evaluate(() => WirdTasks.ui.openPlanner({})); await sleep(120); await p.click('.wt-task[data-task="' + id + '"] .wt-start'); await sleep(250);
      await p.click('.wx-x'); await sleep(250); eq(await p.evaluate(() => WirdTasks.ui.status().view), 'day');
      await p.evaluate(() => WirdTasks.ui.closePlanner()); await sleep(80);
      await p.evaluate(i => WirdTasks.ui.openPlanner({ taskId: i }), id); await sleep(120); await p.click('.wt-start'); await sleep(250);
      eq(await stepText(p), 'أ');
      await p.click('.wx-x'); await sleep(250); eq(await p.evaluate(() => WirdTasks.ui.status().view), 'task');
      await p.click('.wt-start'); await sleep(250); await clickDone(p, 500); await clickDone(p, 500); eq(await view(p), 'done');
      await p.click('[data-act="finish"]'); await sleep(250); eq(await p.evaluate(() => WirdTasks.ui.status().view), 'day'); await p.evaluate(() => WirdTasks.ui.closePlanner());
    });
    noErrors(p); await p.ctx.close();
  }

  /* ------------------------------------------------------------------------------------------------- K */
  if (want('K')) {
    console.log('\n[K] quick-task rows: «متابعة» from a row, no data of the app is touched');
    const p = await open(DIR);
    let habitsRaw, keysBefore;
    await step('create a real quick task through the app, plan it, start it from the row sheet; the row sheet offers «متابعة» once started', async () => {
      await p.click('#hFab'); await p.waitForSelector('#qn'); await p.fill('#qn', 'مهمة سريعة'); await p.click('#hok'); await sleep(300);
      const oid = await p.evaluate(d => { const H0 = JSON.parse(localStorage.getItem('wird_habits_v1')); return (H0.oneoffs[d].find(o => o.name === 'مهمة سريعة') || {}).id; }, TODAY);
      assert(oid, 'quick task exists');
      habitsRaw = await ls(p, 'wird_habits_v1'); keysBefore = await p.evaluate(() => Object.keys(localStorage).sort());
      await p.evaluate(a => WirdTasks.getEngine().createTask(a.d, 'خطة سريعة', { steps: ['أ', 'ب', 'ج'], linkedOneoffId: a.o }), { d: TODAY, o: oid });
      await p.evaluate(() => WirdTasks.ui.refreshBadges()); await sleep(100);
      await p.click('.hb-task[data-id="' + oid + '"] .hb-n'); await sleep(200);
      assert((await p.$eval('.wt-start', b => b.textContent)).includes('ابدأ'), 'not started yet → ابدأ');
      await p.click('.wt-start'); await sleep(250); await clickDone(p, 500);
      eq(await stepText(p), 'ب');
      await p.click('.wx-x'); await sleep(250);
      eq(await p.evaluate(() => WirdTasks.ui.isOpen()), false, 'came from the row → back on the habits screen, planner not forced open');
      await p.click('.hb-task[data-id="' + oid + '"] .hb-n'); await sleep(200);
      assert((await p.$eval('.wt-start', b => b.textContent)).includes('متابعة'), 'row sheet says «متابعة»');
      await p.click('.wt-start'); await sleep(250); eq(await stepText(p), 'ب');
    });
    await step('finishing a linked plan never writes wird_habits_v1 (the habits adapter is still a no-op); only wird_tasks_v1 appears in storage; wird_quiz_db is not created', async () => {
      await clickDone(p, 500); await clickDone(p, 500); eq(await view(p), 'done'); await p.click('[data-act="finish"]'); await sleep(200);
      eq(await ls(p, 'wird_habits_v1'), habitsRaw, 'habits data byte-identical');
      const keys = await p.evaluate(() => Object.keys(localStorage).sort()); eq(keys.filter(k => !keysBefore.includes(k)), ['wird_tasks_v1']);
      assert(!(await p.evaluate(async () => (await indexedDB.databases()).map(d => d.name).includes('wird_quiz_db'))), 'no quiz database');
    });
    noErrors(p); await p.ctx.close();
  }

  /* ------------------------------------------------------------------------------------------------- L */
  if (want('L')) {
    console.log('\n[L] phones: RTL, no overflow, ≥ 44 px, thumb zone, long Arabic/English steps, landscape');
    const LONG = 'اقرأ الفصل الأول من كتاب الفيزياء كاملًا ثم لخّص قانون نيوتن الثاني F = m a مع شرح كل رمز وحدته بالإنجليزي (Newton) ' +
      'وحل المسائل الأربع الأولى من نهاية الفصل وراجع الإجابات النموذجية واكتب الأخطاء في ورقة مستقلة علشان تراجعها بكرة قبل النوم إن شاء الله، ويا رب تخلص بدري النهارده.';
    assert(LONG.length <= 300, 'long step must be valid: ' + LONG.length);
    const vps = [[360, 640, '360'], [390, 844, '390'], [412, 915, '412']];
    for (const [w, hgt, tag] of vps) {
      await step('viewport ' + w + 'x' + hgt + ': run view, long step, paused view, done view, undo snackbar, edit mode', async () => {
        const p = await open(DIR, { viewport: { width: w, height: hgt } }); const id = await plan(p, 'مهمة بعنوان طويل جدًا يتكرر فيه الكلام علشان نتأكد إن العنوان بيتقصّ ومش بيكسر الشاشة أبدًا', [LONG, 'خطوة قصيرة', 'Review Chapter 1 & 2 (EN)'], { editDuringExecution: true, skipStep: true, timer: true, progress: 'detailed' });
        await openRun(p, id, { from: 'x' }); await sleep(150);
        await layout(p, tag + ' run (long step)'); await shot(p, tag + '-1-run-long');
        await p.click('[data-act="done"]'); await sleep(250); await layout(p, tag + ' run + undo'); await shot(p, tag + '-2-undo');
        await sleep(500); await p.click('[data-act="pause"]'); await sleep(150); await layout(p, tag + ' paused'); await shot(p, tag + '-3-paused'); await p.click('[data-act="resume"]'); await sleep(150);
        await p.click('[data-act="edit"]'); await sleep(100); await layout(p, tag + ' edit'); await p.click('[data-act="edit-cancel"]');
        await clickDone(p, 600); await clickDone(p, 600); eq(await view(p), 'done'); await layout(p, tag + ' done'); await shot(p, tag + '-4-done');
        noErrors(p, tag); await p.ctx.close();
      });
    }
    await step('landscape 844x390: primary action reachable, nothing overflows, the step area scrolls instead of growing', async () => {
      const p = await open(DIR, { viewport: { width: 844, height: 390 } }); const id = await plan(p, 'أفقي', [LONG, 'تانية'], { skipStep: true }); await openRun(p, id, { from: 'x' }); await sleep(150);
      const r = await layout(p, 'landscape run', true); await shot(p, '844-1-landscape');
      const sc = await p.$eval('.wx-main', n => ({ ch: n.clientHeight, sh: n.scrollHeight })); assert(sc.ch > 40, 'step area still visible: ' + JSON.stringify(sc));
      await p.click('[data-act="done"]'); await sleep(250); await layout(p, 'landscape + undo', true); await shot(p, '844-2-landscape-undo');
      noErrors(p); await p.ctx.close();
    });
    await step('the overlay sits above the app chrome (tabs, floating button) but below the app confirm dialog (z-index 150 < 200)', async () => {
      const p = await open(DIR); const id = await plan(p, 'طبقات', STEPS4); await openRun(p, id, { from: 'x' });
      const z = await p.evaluate(() => ({ ov: +getComputedStyle(document.querySelector('.wx-ov')).zIndex, confirm: +getComputedStyle(document.getElementById('confirmOverlay')).zIndex, toast: +getComputedStyle(document.querySelector('.toast') || document.body).zIndex || 300 }));
      assert(z.ov > 100 && z.ov < z.confirm, JSON.stringify(z)); await p.ctx.close();
    });
  }

  /* ------------------------------------------------------------------------------------------------- M */
  if (want('M')) {
    console.log('\n[M] robustness');
    const p = await open(DIR);
    await step('a plan edited in another place while the view is open: the view re-derives the current step on the next action (no stale completion)', async () => {
      const id = await plan(p, 'تعديل خارجي', STEPS4); await openRun(p, id, { from: 'x' });
      const s0 = (await E(p, 'getCurrent', id)).step.id; await E(p, 'complete', s0);        // completed behind the view's back
      eq(await stepText(p), STEPS4[0], 'the view still shows step 1 (it was not told)');
      await clickDone(p, 600);                                                              // the tap targets the step on screen: already done → nothing is recorded, the view re-syncs
      eq((await E(p, 'getCompletions', { taskId: id })).length, 1, 'no second completion was recorded'); eq(await nEv(p, id, 'complete'), 1);
      eq(await stepText(p), STEPS4[1], 'the view now shows the real current step');
    });
    await step('storage that cannot be written: the step still advances in memory and the user is warned (persisted:false)', async () => {
      const id = await plan(p, 'مساحة ممتلئة', STEPS4); await openRun(p, id, { from: 'x' });
      await p.evaluate(() => { const o = Storage.prototype.setItem; window.__o = o; Storage.prototype.setItem = function (k, v) { if (/^wird_tasks/.test(k)) { const e = new Error('quota'); e.name = 'QuotaExceededError'; throw e; } return o.call(this, k, v); }; });
      await clickDone(p, 600); eq(await stepText(p), STEPS4[1]);
      assert((await p.$eval('.wx-msg', n => n.textContent)).includes('لسه ما اتحفظش'), 'warning shown');
      await p.evaluate(() => { Storage.prototype.setItem = window.__o; });
      await clickDone(p, 600); eq(await stepText(p), STEPS4[2]); eq(JSON.parse(await ls(p, 'wird_tasks_v1')).events.filter(e => e.taskId === id && e.type === 'complete').length, 2, 'the next successful save wrote everything');
    });
    await step('a plan deleted behind the view closes it without errors', async () => {
      const id = await plan(p, 'ستُحذف', STEPS4); await openRun(p, id, { from: 'x' }); await E(p, 'deleteTask', id);
      await p.click('[data-act="done"]').catch(() => {}); await sleep(600);
      eq(await isOpen(p), false); eq(await p.evaluate(() => history.state), null);
    });
    await step('back from the finished state reopens the last step (A2) and the undo snackbar can undo the final completion', async () => {
      const a = await plan(p, 'نهاية', ['أ', 'ب']); await openRun(p, a, { from: 'x' }); await clickDone(p, 500); await clickDone(p, 500); eq(await view(p), 'done');
      await p.click('[data-act="undo"]'); await sleep(500); eq(await view(p), 'run'); eq(await stepText(p), 'ب');
      await clickDone(p, 500); await clickAct(p, 'back', 500); eq(await view(p), 'run'); eq(await stepText(p), 'ب'); eq((await E(p, 'getTask', a)).status, 'in_progress');
    });
    noErrors(p); await p.ctx.close();
  }

  await browser.close();
  summary();
})().catch(e => { console.error('SUITE CRASHED', e); process.exit(2); });

function summary() {
  console.log('\n' + (failed ? '✘' : '✔') + ' execution screen: ' + passed + ' passed' + (failed ? ', ' + failed + ' FAILED' : ''));
  console.log('  tests: ' + (passed + failed) + ' | passed: ' + passed + ' | failed: ' + failed + ' | assertions: ' + assertions);
  if (failed) { console.log('  failures:\n   - ' + failures.join('\n   - ')); process.exit(1); }
}
