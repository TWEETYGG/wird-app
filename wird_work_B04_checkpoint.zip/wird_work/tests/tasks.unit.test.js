// Unit tests of the task engine (B2 / TASK 1.1). Pure Node, no browser, no framework, no network.
// Run:  node tests/tasks.unit.test.js            (exit 0 = all passed)
'use strict';
const assert = require('assert').strict;
const E = require('../tools/src/tasks-engine.js');

let passed = 0, asserts = 0; const failed = [];
function t(name, fn) { try { fn(); passed++; } catch (e) { failed.push(name + '\n      ' + String(e && e.message || e).split('\n').slice(0, 6).join('\n      ')); } }
const eq = (a, b, m) => { asserts++; assert.deepStrictEqual(a, b, m); };
const ok = (v, m) => { asserts++; assert.ok(v, m); };
const isOk = (r, m) => { asserts++; assert.ok(r && r.ok === true, (m || '') + ' expected ok, got ' + JSON.stringify(r)); return r; };
const isFail = (r, reason, m) => { asserts++; assert.ok(r && r.ok === false && r.reason === reason, (m || '') + ' expected fail ' + reason + ', got ' + JSON.stringify(r)); return r; };

// ---------------------------------------------------------------------------------------------------- harness
const NOON = new Date(2026, 10, 5, 12, 0, 0).getTime();          // local noon: the same calendar day in any time zone
const TODAY = E.dayKeyOf(NOON), TOMORROW = E.addDays(TODAY, 1), YESTERDAY = E.addDays(TODAY, -1);
function flaky(inner) {
  const s = { log: [], failGet: false, failSet: false, quota: false, inner,
    getItem(k) { s.log.push(['get', k]); if (s.failGet) throw new Error('getItem blocked'); return inner.getItem(k); },
    setItem(k, v) { s.log.push(['set', k]); if (s.quota) { const e = new Error('quota exceeded'); e.name = 'QuotaExceededError'; e.code = 22; throw e; } if (s.failSet) throw new Error('setItem failed'); inner.setItem(k, v); } };
  return s;
}
let idBase = 0;
function mk(o) {
  o = o || {};
  const clock = { t: NOON, adv(ms) { this.t += ms; return this.t; } };
  let n = idBase; idBase += 100000;
  const storage = o.storage || flaky(E.makeMemoryStorage());
  const deps = { storage, clock: () => clock.t, idGen: p => p + (++n), habits: o.habits, undoWindowMs: o.undoWindowMs };
  const eng = E.createEngine(deps);
  return { eng, clock, storage, reopen() { return E.createEngine(Object.assign({}, deps, { idGen: p => p + 'r' + (++n) })); } };
}
function task(eng, steps, day, title, opts) { const r = isOk(eng.createTask(day || TODAY, title || 'مهمة', Object.assign({ steps: steps }, opts || {}))); return r.task; }
const ids = (view) => view.steps.map(s => s.id);
const states = (view) => view.steps.map(s => s.state);
const stored = (storage, key) => storage.inner.getItem(key);

// ======================================================================================== day keys, text
t('day keys: validation, calendar arithmetic, local day', () => {
  ok(E.isDayKey('2026-11-05')); ok(E.isDayKey('2028-02-29'));
  ['2026-02-29', '2026-13-01', '2026-00-10', '2026-1-1', '26-11-05', '', null, undefined, 20261105, '2026-11-05 ', '2026-11-5'].forEach(x => ok(!E.isDayKey(x), String(x)));
  eq(E.addDays('2026-12-31', 1), '2027-01-01'); eq(E.addDays('2026-03-01', -1), '2026-02-28'); eq(E.addDays('2028-02-28', 1), '2028-02-29');
  eq(E.addDays('2026-11-05', 0), '2026-11-05'); eq(E.addDays('bad', 1), null); eq(E.addDays('2026-11-05', 1.5), null);
  eq(E.dayKeyOf(new Date(2026, 0, 2, 23, 59).getTime()), '2026-01-02'); eq(E.dayKeyOf(new Date(2026, 0, 3, 0, 0).getTime()), '2026-01-03');
  eq(mk().eng.todayKey(), TODAY);
});
t('createTask: validation of day, title, steps, limits and text cleaning', () => {
  const { eng } = mk();
  isFail(eng.createTask('2026-02-30', 'x'), 'bad_day'); isFail(eng.createTask(undefined, 'x'), 'bad_day');
  isFail(eng.createTask(TODAY, ''), 'empty_text'); isFail(eng.createTask(TODAY, '   \n\t '), 'empty_text'); isFail(eng.createTask(TODAY, 42), 'invalid_argument'); isFail(eng.createTask(TODAY, null), 'invalid_argument');
  isFail(eng.createTask(TODAY, 'x'.repeat(121)), 'too_long'); isOk(eng.createTask(TODAY, 'x'.repeat(120)));
  isFail(eng.createTask(TODAY, 'ok', { steps: 'nope' }), 'invalid_argument'); isFail(eng.createTask(TODAY, 'ok', { steps: ['a', ' '] }), 'empty_text');
  isFail(eng.createTask(TODAY, 'ok', { steps: ['a', 'y'.repeat(301)] }), 'too_long'); isOk(eng.createTask(TODAY, 'ok', { steps: ['y'.repeat(300)] }));
  isFail(eng.createTask(TODAY, 'ok', { steps: new Array(101).fill('s') }), 'limit_steps'); isOk(eng.createTask(TODAY, 'ok', { steps: new Array(100).fill('s') }));
  const r = isOk(eng.createTask(TODAY, '  شراء   \n الخبز\u0000  ', { steps: ['  أ\tب  '] }));
  eq(r.task.title, 'شراء الخبز'); eq(r.task.steps[0].text, 'أ ب');
  eq(r.task.status, 'not_started'); eq(r.task.steps[0].state, 'not_started'); eq(r.task.counts, { total: 1, completed: 0, skipped: 0, remaining: 1 });
  isOk(eng.createTask(TODAY, 'no steps yet')); eq(eng.getState().days[TODAY].taskOrder.length >= 3, true);
});
t('tasks per day limit', () => {
  const { eng } = mk();
  for (let i = 0; i < 100; i++) isOk(eng.createTask(TODAY, 'm' + i));
  isFail(eng.createTask(TODAY, 'one too many'), 'limit_tasks'); isOk(eng.createTask(TOMORROW, 'other day is fine'));
});

// ========================================================================================== lifecycle
t('lifecycle: not_started -> in_progress -> completed with exact counts and current step', () => {
  const { eng } = mk(); const v = task(eng, ['a', 'b', 'c']); const [a, b, c] = ids(v);
  eq(v.status, 'not_started'); eq(v.currentStepId, a);
  const s = isOk(eng.start(v.id)); eq(s.status, 'in_progress'); eq(s.current.id, a); eq(s.finished, false);
  eq(states(eng.getTask(v.id)), ['in_progress', 'not_started', 'not_started']);
  const r1 = isOk(eng.complete(a)); eq(r1.record.key, 'done:' + a + ':1'); eq(r1.current.id, b); eq(r1.status, 'in_progress'); eq(r1.finished, false);
  eq(eng.getTask(v.id).counts, { total: 3, completed: 1, skipped: 0, remaining: 2 });
  isOk(eng.complete(b)); const r3 = isOk(eng.complete(c));
  eq(r3.status, 'completed'); eq(r3.finished, true); eq(r3.current, null); eq(eng.getCurrent(v.id), null);
  eq(states(eng.getTask(v.id)), ['completed', 'completed', 'completed']); eq(eng.getCompletions().length, 3);
});
t('illegal transitions are refused with a reason and change nothing', () => {
  const { eng, storage } = mk(); const v = task(eng, ['a', 'b']); const [a, b] = ids(v);
  isFail(eng.complete(a), 'not_started'); isFail(eng.skip(a), 'not_started'); isFail(eng.back(v.id), 'not_started'); isFail(eng.pause(v.id), 'not_started'); isFail(eng.resume(v.id), 'not_started');
  isFail(eng.undo(v.id), 'nothing_to_undo');
  isFail(eng.start('nope'), 'not_found'); isFail(eng.start(''), 'invalid_argument'); isFail(eng.start(undefined), 'invalid_argument'); isFail(eng.complete('nope'), 'not_found'); isFail(eng.complete(null), 'invalid_argument');
  const empty = isOk(eng.createTask(TODAY, 'empty')).task; isFail(eng.start(empty.id), 'no_steps');
  isOk(eng.start(v.id)); const noop = isOk(eng.start(v.id)); eq(noop.noop, true);
  isFail(eng.complete(b), 'not_current'); eq(eng.complete(b).currentStepId, a); isFail(eng.skip(b), 'not_current');
  isOk(eng.pause(v.id)); isFail(eng.start(v.id), 'paused');
  isOk(eng.resume(v.id)); eq(isOk(eng.resume(v.id)).noop, true);
  isOk(eng.complete(a)); isOk(eng.complete(b));
  isFail(eng.start(v.id), 'finished'); isFail(eng.pause(v.id), 'finished'); isFail(eng.resume(v.id), 'finished');
  eq(eng.getEvents({ type: 'complete' }).length, 2);
  const sets = storage.log.filter(x => x[0] === 'set').length; isFail(eng.complete(a + 'x'), 'not_found'); eq(storage.log.filter(x => x[0] === 'set').length, sets, 'a refused action never writes');
});
t('complete twice (double tap) yields ONE record; complete->undo->complete yields one ACTIVE record with unique keys', () => {
  const { eng } = mk(); const v = task(eng, ['a', 'b', 'c']); const [a, b] = ids(v); isOk(eng.start(v.id));
  const r1 = isOk(eng.complete(a)), r2 = isOk(eng.complete(a));
  eq(r2.duplicate, true); eq(r2.record.key, r1.record.key); eq(eng.getEvents({ type: 'complete', stepId: a }).length, 1); eq(eng.getCompletions().length, 1);
  eq(eng.getCurrent(v.id).step.id, b, 'the duplicate tap must not complete the next step');
  const u = isOk(eng.undo(v.id, { key: r1.record.key })); eq(u.undone.key, r1.record.key);
  const r3 = isOk(eng.complete(a)); eq(r3.record.key, 'done:' + a + ':2');
  eq(eng.getEvents({ type: 'complete', stepId: a }).length, 2); eq(eng.getCompletions({ taskId: v.id }).length, 1); eq(eng.getCompletions()[0].key, 'done:' + a + ':2');
  const keys = eng.getEvents().map(e => e.key); eq(new Set(keys).size, keys.length);
  const seqs = eng.getEvents().map(e => e.seq); eq(seqs, seqs.slice().sort((x, y) => x - y)); eq(new Set(seqs).size, seqs.length);
});
t('skip never counts as completed: partial / skipped statuses, duplicate and cross-resolution rules', () => {
  const { eng } = mk(); const v = task(eng, ['a', 'b', 'c']); const [a, b, c] = ids(v); isOk(eng.start(v.id));
  isOk(eng.complete(a)); const sk = isOk(eng.skip(b)); eq(sk.record.type, 'skip'); eq(isOk(eng.skip(b)).duplicate, true);
  isFail(eng.complete(b), 'already_resolved'); isFail(eng.skip(a), 'already_resolved');
  const fin = isOk(eng.complete(c)); eq(fin.status, 'partial'); eq(fin.finished, true);
  eq(eng.getTask(v.id).counts, { total: 3, completed: 2, skipped: 1, remaining: 0 }); eq(states(eng.getTask(v.id)), ['completed', 'skipped', 'completed']);
  eq(eng.getCompletions().map(x => x.stepId), [a, c], 'the skipped step is not a completion');
  const w = task(eng, ['x', 'y']); isOk(eng.start(w.id)); isOk(eng.skip(ids(w)[0])); eq(isOk(eng.skip(ids(w)[1])).status, 'skipped'); eq(eng.getCompletions({ taskId: w.id }).length, 0);
  const z = task(eng, ['p', 'q']); isOk(eng.start(z.id)); isOk(eng.skip(ids(z)[0])); eq(isOk(eng.complete(ids(z)[1])).status, 'partial');
  isFail(eng.start(w.id), 'finished');
});
t('undo: inside the window, after expiry, with key guards, never twice, never after another action', () => {
  const { eng, clock } = mk(); const v = task(eng, ['a', 'b', 'c']); const [a, b, c] = ids(v); isOk(eng.start(v.id));
  const r = isOk(eng.complete(a)); eq(r.undoUntil, r.record.at + E.UNDO_WINDOW_MS); eq(E.UNDO_WINDOW_MS, 8000);
  clock.adv(8000); isOk(eng.undo(v.id), 'exactly at the window edge'); eq(eng.getCurrent(v.id).step.id, a);
  isFail(eng.undo(v.id), 'nothing_to_undo', 'second undo without key');
  isOk(eng.complete(a)); clock.adv(8001); isFail(eng.undo(v.id), 'window_expired'); eq(eng.getCurrent(v.id).step.id, b, 'expired undo changes nothing');
  const rb = isOk(eng.complete(b)); isFail(eng.undo(v.id, { key: 'done:' + a + ':2' }), 'not_latest'); isOk(eng.undo(v.id, { key: rb.record.key }));
  eq(isOk(eng.undo(v.id, { key: rb.record.key })).duplicate, true, 'double-tapped undo is a no-op');
  eq(eng.getTask(v.id).counts.completed, 1, 'the earlier completion survives a repeated undo');
  const rs = isOk(eng.skip(b)); isOk(eng.undo(v.id)); eq(eng.getCurrent(v.id).step.id, b); eq(eng.getEvents({ type: 'undo' }).pop().of, 'skip');
  isOk(eng.complete(b)); isOk(eng.pause(v.id)); isFail(eng.undo(v.id), 'paused'); isOk(eng.resume(v.id)); isFail(eng.undo(v.id), 'nothing_to_undo', 'resume is a later action');
  const x = task(eng, ['p']); isOk(eng.start(x.id)); const fx = isOk(eng.complete(ids(x)[0])); eq(fx.status, 'completed');
  const ux = isOk(eng.undo(x.id)); eq(ux.status, 'in_progress'); eq(ux.finished, false); eq(ux.current.id, ids(x)[0]);
});
t('back re-opens the previous step, keeps history, works from a finished task, stops at the first step', () => {
  const { eng } = mk(); const v = task(eng, ['a', 'b', 'c']); const [a, b, c] = ids(v); isOk(eng.start(v.id));
  isFail(eng.back(v.id), 'at_first_step'); isOk(eng.complete(a)); isOk(eng.complete(b)); eq(eng.getCurrent(v.id).step.id, c);
  const bk = isOk(eng.back(v.id)); eq(bk.reopened, b); eq(bk.current.id, b); eq(states(eng.getTask(v.id)), ['completed', 'in_progress', 'not_started']);
  eq(eng.getCompletions().map(x => x.stepId), [a], 'a reopened step is no longer an active completion'); eq(eng.getEvents({ type: 'complete', stepId: b }).length, 1, 'but its event is still in the history');
  eq(eng.getEvents({ type: 'back' })[0].voids, 'done:' + b + ':1');
  isFail(eng.undo(v.id), 'nothing_to_undo', 'undo after back is not offered');
  eq(isOk(eng.complete(b)).record.key, 'done:' + b + ':2'); isOk(eng.complete(c)); eq(eng.getTask(v.id).status, 'completed');
  const bk2 = isOk(eng.back(v.id)); eq(bk2.reopened, c); eq(bk2.status, 'in_progress');
  isOk(eng.back(v.id)); isOk(eng.back(v.id)); isFail(eng.back(v.id), 'at_first_step'); eq(states(eng.getTask(v.id)), ['in_progress', 'not_started', 'not_started']);
  const sk = task(eng, ['p', 'q']); isOk(eng.start(sk.id)); isOk(eng.skip(ids(sk)[0])); eq(isOk(eng.back(sk.id)).reopened, ids(sk)[0]); eq(eng.getTask(sk.id).counts.skipped, 0);
});
t('pause / resume: execution actions are refused while paused; position survives reload', () => {
  const m = mk(); const { eng } = m; const v = task(eng, ['a', 'b', 'c']); const [a, b, c] = ids(v); isOk(eng.start(v.id)); isOk(eng.complete(a));
  const p = isOk(eng.pause(v.id)); eq(p.status, 'paused'); eq(eng.getTask(v.id).steps[1].state, 'in_progress'); eq(isOk(eng.pause(v.id)).noop, true);
  isFail(eng.complete(b), 'paused'); isFail(eng.skip(b), 'paused'); isFail(eng.back(v.id), 'paused'); isFail(eng.undo(v.id), 'paused');
  const e2 = m.reopen(); eq(e2.getTask(v.id).status, 'paused'); eq(e2.getCurrent(v.id).step.id, b); eq(e2.getCurrent(v.id).step.index, 1);
  const rs = isOk(e2.resume(v.id)); eq(rs.status, 'in_progress'); eq(rs.current.id, b); isOk(e2.complete(b)); isOk(e2.complete(c)); eq(e2.getTask(v.id).status, 'completed');
  eq(e2.getEvents({ type: 'pause' }).length, 1); eq(e2.getEvents({ type: 'resume' }).length, 1);
});
t('closing and reopening (new engine on the same storage) resumes at the exact position with all states', () => {
  const m = mk(); const { eng } = m; const v = task(eng, ['a', 'b', 'c', 'd']); const [a, b, c, d] = ids(v);
  isOk(eng.start(v.id)); isOk(eng.complete(a)); isOk(eng.skip(b));
  const e2 = m.reopen(); const v2 = e2.getTask(v.id);
  eq(states(v2), ['completed', 'skipped', 'in_progress', 'not_started']); eq(v2.currentStepId, c); eq(v2.status, 'in_progress'); eq(e2.getActiveTask().id, v.id);
  eq(isOk(e2.complete(c)).record.key, 'done:' + c + ':1'); eq(e2.status().loadedFrom, 'storage');
  eq(isOk(e2.complete(c)).duplicate, true, 'duplicate protection survives a reload');
});

// ===================================================================================== step / task editing
t('steps: add, insert, edit, delete, reorder; the current step is the first unresolved step in plan order', () => {
  const { eng } = mk(); const v = task(eng, ['a', 'b', 'c']); const [a, b, c] = ids(v); isOk(eng.start(v.id)); isOk(eng.complete(a));
  const ins = isOk(eng.insertStep(v.id, 1, 'X')); const X = ins.step.id; eq(ins.step.index, 1); eq(ins.current.id, X, 'inserted before the current step -> becomes current');
  eq(eng.getTask(v.id).steps.map(s => s.text), ['a', 'X', 'b', 'c']);
  const aft = isOk(eng.addStep(v.id, 'Y', { afterStepId: X })); eq(aft.current.id, X); eq(eng.getTask(v.id).steps.map(s => s.text), ['a', 'X', 'Y', 'b', 'c']);
  const app = isOk(eng.addStep(v.id, 'Z')); eq(eng.getTask(v.id).steps.pop().id, app.step.id);
  isFail(eng.insertStep(v.id, 99, 'bad'), 'bad_index'); isFail(eng.insertStep(v.id, -1, 'bad'), 'bad_index'); isFail(eng.insertStep(v.id, 1.5, 'bad'), 'bad_index'); isFail(eng.addStep(v.id, 'bad', { afterStepId: 'nope' }), 'not_found'); isFail(eng.addStep(v.id, ' '), 'empty_text'); isFail(eng.addStep('nope', 'x'), 'not_found');
  eq(isOk(eng.editStep(X, '  X2 ')).step.text, 'X2'); eq(isOk(eng.editStep(X, 'X2')).noop, true); isFail(eng.editStep(X, ''), 'empty_text'); isFail(eng.editStep('nope', 'q'), 'not_found');
  const ev = eng.getEvents({ type: 'step_edit' }); eq(ev.length, 1); eq([ev[0].from, ev[0].to], ['X', 'X2']);
  const del = isOk(eng.deleteStep(X)); eq(del.wasCurrent, true); eq(del.current.id, Y(eng, v.id), 'deleting the current step lands on the next one');
  eq(isOk(eng.deleteStep(X)).duplicate, true); isFail(eng.editStep(X, 'still deleted'), 'deleted'); isFail(eng.complete(X), 'deleted');
  eq(eng.getState().steps[X].deletedAt > 0, true, 'tombstone, not physical removal'); eq(eng.getTask(v.id).steps.length, 5);
  const ids2 = ids(eng.getTask(v.id));
  isFail(eng.reorderSteps(v.id, ids2.slice(1)), 'bad_order'); isFail(eng.reorderSteps(v.id, ids2.slice(1).concat(['x'])), 'bad_order'); isFail(eng.reorderSteps(v.id, [ids2[0], ids2[0], ids2[2], ids2[3], ids2[4]]), 'bad_order');
  eq(isOk(eng.reorderSteps(v.id, ids2.slice())).noop, true);
  isOk(eng.reorderSteps(v.id, [ids2[0], ids2[4], ids2[3], ids2[2], ids2[1]])); eq(ids(eng.getTask(v.id)), [ids2[0], ids2[4], ids2[3], ids2[2], ids2[1]]);
  isOk(eng.moveStep(ids2[1], 0)); eq(ids(eng.getTask(v.id))[0], ids2[1]); isFail(eng.moveStep(ids2[1], 9), 'bad_index'); isFail(eng.moveStep(ids2[1], 5), 'bad_index'); isFail(eng.moveStep('nope', 0), 'not_found');
});
function Y(eng, taskId) { return eng.getTask(taskId).steps.find(s => s.text === 'Y').id; }
t('editing keeps completion history; deleting a completed step keeps its record; counts follow the live steps', () => {
  const { eng } = mk(); const v = task(eng, ['كتب', 'ب', 'ج'], TODAY, 'العنوان'); const [a, b, c] = ids(v); isOk(eng.start(v.id)); isOk(eng.complete(a));
  isOk(eng.editStep(a, 'نص جديد')); isOk(eng.editTask(v.id, { title: 'عنوان جديد' }));
  const rec = eng.getCompletions()[0]; eq(rec.stepText, 'كتب'); eq(rec.taskTitle, 'العنوان'); eq(eng.getTask(v.id).steps[0].text, 'نص جديد'); eq(eng.getTask(v.id).steps[0].state, 'completed');
  eq(eng.getEvents({ type: 'task_edit' })[0].from, 'العنوان');
  isFail(eng.editTask(v.id, { title: '' }), 'empty_text'); isFail(eng.editTask(v.id, {}), 'invalid_argument'); eq(isOk(eng.editTask(v.id, { title: 'عنوان جديد' })).noop, true);
  isOk(eng.deleteStep(a)); eq(eng.getCompletions().length, 1, 'the completion record of a deleted step is kept'); eq(eng.getTask(v.id).counts, { total: 2, completed: 0, skipped: 0, remaining: 2 });
  eq(eng.getEvents({ type: 'step_delete' })[0].state, 'completed');
  isOk(eng.complete(b)); const last = isOk(eng.deleteStep(c)); eq(last.status, 'completed', 'deleting the last unresolved step finishes the task');
  const e = task(eng, ['only']); isOk(eng.start(e.id)); isOk(eng.deleteStep(ids(e)[0])); eq(eng.getTask(e.id).status, 'not_started', 'no live steps -> back to not_started'); isFail(eng.start(e.id), 'no_steps');
});
t('adding a step to a finished task re-opens it', () => {
  const { eng } = mk(); const v = task(eng, ['a']); isOk(eng.start(v.id)); isOk(eng.complete(ids(v)[0])); eq(eng.getTask(v.id).status, 'completed');
  const r = isOk(eng.addStep(v.id, 'more')); eq(r.reopened, true); eq(r.status, 'in_progress'); eq(r.current.id, r.step.id); isOk(eng.complete(r.step.id)); eq(eng.getTask(v.id).status, 'completed');
});
t('reordering with progress: completed steps keep their state, current follows plan order', () => {
  const { eng } = mk(); const v = task(eng, ['a', 'b', 'c']); const [a, b, c] = ids(v); isOk(eng.start(v.id)); isOk(eng.complete(a));
  isOk(eng.moveStep(c, 0)); eq(eng.getCurrent(v.id).step.id, c); eq(states(eng.getTask(v.id)), ['in_progress', 'completed', 'not_started']);
  isOk(eng.complete(c)); isOk(eng.complete(b)); eq(eng.getTask(v.id).status, 'completed');
  const bk = isOk(eng.back(v.id)); eq(bk.reopened, b, 'back reopens the step right before the first unresolved position (the last step in plan order)');
});
t('tasks: edit title, delete (tombstone), move to another day, reorder within a day', () => {
  const { eng } = mk(); const a = task(eng, ['x'], TODAY, 'A'), b = task(eng, ['x'], TODAY, 'B'), c = task(eng, ['x'], TODAY, 'C');
  eq(eng.listTasks(TODAY).map(x => x.title), ['A', 'B', 'C']);
  isOk(eng.reorderTasks(TODAY, [c.id, a.id, b.id])); eq(eng.listTasks(TODAY).map(x => x.title), ['C', 'A', 'B']);
  isFail(eng.reorderTasks(TODAY, [c.id, a.id]), 'bad_order'); isFail(eng.reorderTasks(TODAY, [c.id, a.id, 'zz']), 'bad_order'); isFail(eng.reorderTasks('bad', []), 'bad_day'); eq(isOk(eng.reorderTasks(TODAY, [c.id, a.id, b.id])).noop, true);
  isOk(eng.moveTask(a.id, TOMORROW)); eq(eng.listTasks(TODAY).map(x => x.title), ['C', 'B']); eq(eng.listTasks(TOMORROW).map(x => x.title), ['A']); eq(eng.getTask(a.id).dayKey, TOMORROW);
  isOk(eng.moveTask(b.id, TOMORROW, 0)); eq(eng.listTasks(TOMORROW).map(x => x.title), ['B', 'A']);
  isOk(eng.moveTask(b.id, TOMORROW, 1)); eq(eng.listTasks(TOMORROW).map(x => x.title), ['A', 'B']); eq(isOk(eng.moveTask(b.id, TOMORROW, 1)).noop, true);
  isFail(eng.moveTask(b.id, TOMORROW, 5), 'bad_index'); isFail(eng.moveTask(b.id, 'x'), 'bad_day'); isFail(eng.moveTask('nope', TODAY), 'not_found');
  eq(eng.getEvents({ type: 'task_move' }).length, 2); eq(eng.getEvents({ type: 'task_move' })[0].from, TODAY);
  isOk(eng.start(c.id)); isOk(eng.complete(ids(c)[0])); isFail(eng.moveTask(c.id, YESTERDAY), 'task_finished');
  isOk(eng.moveTask(a.id, YESTERDAY)); eq(eng.getDay(YESTERDAY).tasks.length, 1);
  const d = isOk(eng.deleteTask(a.id)); eq(d.deleted, a.id); eq(eng.getTask(a.id), null); eq(eng.getTask(a.id, { includeDeleted: true }).deleted, true); eq(eng.listTasks(YESTERDAY).length, 0);
  eq(eng.getEvents({ type: 'task_delete' })[0].taskTitle, 'A'); eq(isOk(eng.deleteTask(a.id)).duplicate, true); isFail(eng.start(a.id), 'deleted'); isFail(eng.addStep(a.id, 'z'), 'deleted'); isFail(eng.deleteTask('nope'), 'not_found');
  eq(Object.keys(eng.getState().steps).length, 3, 'steps of a deleted task are kept');
});
t('a started task can be moved; its progress and status come along', () => {
  const { eng } = mk(); const v = task(eng, ['a', 'b']); isOk(eng.start(v.id)); isOk(eng.complete(ids(v)[0])); isOk(eng.pause(v.id));
  const r = isOk(eng.moveTask(v.id, TOMORROW)); eq(r.task.status, 'paused'); eq(states(r.task), ['completed', 'in_progress']);
});

// ====================================================================================== persistence
t('autosave after every mutating action; refused and no-op actions do not write', () => {
  const { eng, storage } = mk(); const sets = () => storage.log.filter(x => x[0] === 'set' && x[1] === 'wird_tasks_v1').length;
  eq(storage.log.filter(x => x[0] === 'set').length, 0, 'constructing an engine writes nothing');
  const v = task(eng, ['a', 'b']); eq(sets(), 1); let n = 1;
  [() => eng.start(v.id), () => eng.complete(ids(v)[0]), () => eng.pause(v.id), () => eng.resume(v.id), () => eng.skip(ids(v)[1]), () => eng.back(v.id), () => eng.editStep(ids(v)[0], 'q'), () => eng.addStep(v.id, 'n'), () => eng.editTask(v.id, { title: 'tt' })].forEach(f => { f(); n++; eq(sets(), n); });
  eng.start(v.id); eng.pause(v.id); n++; eq(sets(), n);
  eng.pause(v.id); eng.editTask(v.id, { title: 'tt' }); eng.editStep('nope', 'x'); eq(sets(), n);
  const raw = JSON.parse(stored(storage, 'wird_tasks_v1')); eq(raw.schemaVersion, 1); eq(Object.keys(raw).sort(), ['days', 'events', 'exec', 'savedAt', 'schemaVersion', 'seq', 'steps', 'tasks']);
  eq(eng.getTask(v.id).persisted, undefined);
});
t('state round-trips through storage unchanged (tasks incl. deleted, days, events, status)', () => {
  const m = mk(); const { eng } = m; const a = task(eng, ['a', 'b', 'c'], TODAY, 'A'), b = task(eng, ['p', 'q'], TOMORROW, 'B'); isOk(eng.start(a.id)); isOk(eng.complete(ids(a)[0])); isOk(eng.skip(ids(a)[1])); isOk(eng.deleteStep(ids(b)[0])); isOk(eng.deleteTask(b.id));
  const e2 = m.reopen();
  [a.id, b.id].forEach(id => eq(e2.getTask(id, { includeDeleted: true }), eng.getTask(id, { includeDeleted: true })));
  eq(e2.listDays(), eng.listDays()); eq(e2.getEvents(), eng.getEvents()); eq(e2.getCompletions(), eng.getCompletions());
  eq(e2.status().loadedFrom, 'storage'); eq(e2.status().repairs, 0); eq(e2.status().degraded, false);
});
t('missing storage key: empty start, no throw, no write', () => {
  const m = mk(); eq(m.eng.status().loadedFrom, 'empty'); eq(m.eng.listDays(), []); eq(m.eng.getActiveTask(), null); eq(m.storage.log.filter(x => x[0] === 'set').length, 0);
});
t('corrupt storage never throws: recovered empty state, raw text kept in memory, saving works again', () => {
  ['{not json', '', 'null', '[]', '"text"', '12', '{"foo":1}', '{"schemaVersion":"1"}', '{"schemaVersion":0}', '{"schemaVersion":1.5}', '{"schemaVersion":-3,"tasks":{}}'].forEach(raw => {
    const inner = E.makeMemoryStorage({ wird_tasks_v1: raw }); const s = flaky(inner);
    const eng = E.createEngine({ storage: s, clock: () => NOON, idGen: p => p + 'x' });
    if (raw === '') { eq(eng.status().loadedFrom, 'empty'); return; }
    const st = eng.status(); eq(st.loadedFrom, 'recovered', raw); ok(['corrupt_json', 'invalid_schema'].includes(st.recovered.code), raw); eq(st.recovered.rawLength, raw.length); eq(eng.getRecoveredRaw(), raw); eq(st.readOnly, false);
    eq(eng.listDays(), []); const r = isOk(eng.createTask(TODAY, 'works after recovery')); eq(r.persisted, true); eq(JSON.parse(inner.getItem('wird_tasks_v1')).schemaVersion, 1);
  });
});
t('valid JSON with broken contents is repaired, never thrown on', () => {
  const good = { schemaVersion: 1, seq: 5, savedAt: 1, days: { [TODAY]: { key: TODAY, taskOrder: ['t1', 'ghost', 't1', 't2'] }, 'bad-day': { taskOrder: [] } },
    tasks: { t1: { id: 't1', dayKey: TODAY, title: 'T1', stepOrder: ['s1', 's9', 's1', 'sx'], linkedOneoffId: 'o_abc', linkedDay: TODAY }, t2: { id: 't2', dayKey: TODAY, title: 'T2', stepOrder: [], deletedAt: 5 }, t3: { id: 'WRONG', dayKey: TODAY, title: 'x' }, t4: 'junk', t5: { id: 't5', dayKey: 'nope', title: 'x' }, t6: { id: 't6', dayKey: TODAY, title: '   ' } },
    steps: { s1: { id: 's1', taskId: 't1', text: 'one' }, s2: { id: 's2', taskId: 't1', text: 'two', createdAt: 9 }, s3: { id: 's3', taskId: 'nope', text: 'orphan' }, s4: { id: 's4', taskId: 't1', text: '' }, s5: 7, sx: { id: 'sx', taskId: 't2', text: 'foreign' }, s6: { id: 's6', taskId: 't1', text: 'dead', deletedAt: 3 } },
    exec: { t1: { started: true, paused: false, prefs: { progress: 'weird', sound: 'yes' } }, ghost: { started: true } },
    events: [{ key: 'done:s1:1', seq: 1, at: 100, type: 'complete', taskId: 't1', stepId: 's1', n: 1 }, { key: 'done:s1:1', seq: 2, at: 101, type: 'complete', taskId: 't1', stepId: 's1' }, { key: 'x', at: 1, type: 'evil', taskId: 't1' }, { key: 'y', at: 'now', type: 'start', taskId: 't1' }, { key: 'z', at: 1, type: 'start', taskId: 'ghost' }, 'junk', null, { key: 'k2', at: 5, type: 'start', taskId: 't1', secret: { nested: 1 }, stepText: 'ok' }, { key: 'k3', at: 6, type: 'step_edit', taskId: 't1', stepId: 's1', from: { a: 1 }, to: ['x'], taskTitle: 'kept' }] };
  const eng = E.createEngine({ storage: E.makeMemoryStorage({ wird_tasks_v1: JSON.stringify(good) }), clock: () => NOON, idGen: p => p + 'q' });
  const st = eng.status(); eq(st.loadedFrom, 'repaired'); ok(st.repairs > 5); eq(st.lastError.code, 'repaired');
  const t1 = eng.getTask('t1'); eq(t1.steps.map(s => s.id), ['s1', 's2']); eq(t1.steps[0].state, 'completed'); eq(t1.status, 'in_progress'); eq(t1.linkedOneoffId, 'o_abc');
  eq(eng.listTasks(TODAY).map(x => x.id), ['t1']); eq(eng.getTask('t2'), null); eq(eng.getEvents().map(e => e.key), ['done:s1:1', 'k2', 'k3']); eq(eng.getEvents()[1].secret, undefined); eq(eng.getEvents()[2].from, undefined, 'non-primitive values of whitelisted fields are dropped'); eq(eng.getEvents()[2].to, undefined); eq(eng.getEvents()[2].taskTitle, 'kept');
  eq(eng.getSessionPrefs('t1'), E.DEFAULT_PREFS, 'invalid snapshot values fall back to the defaults');
  isOk(eng.complete('s2')); eq(eng.getTask('t1').status, 'completed');
  ['tasks', 'steps', 'days', 'exec', 'events'].forEach(k => { const o = Object.assign({}, good); o[k] = k === 'events' ? 'nope' : 5; const e = E.createEngine({ storage: E.makeMemoryStorage({ wird_tasks_v1: JSON.stringify(o) }), clock: () => NOON }); ok(e.status().repairs > 0, k); isOk(e.createTask(TODAY, 'still usable')); });
});
let bn = 0; const gen = tag => p => p + tag + (++bn);
function selective(inner, blocked) {                              // storage that refuses writes to keys matching `blocked.rx` while blocked.on
  return { inner, getItem: k => inner.getItem(k), setItem(k, v) { if (blocked.on && blocked.rx.test(k)) { const e = new Error('quota exceeded'); e.name = 'QuotaExceededError'; throw e; } return inner.setItem(k, v); } };
}
t('unreadable or repaired data is copied byte for byte to a sibling key BEFORE it is overwritten (and only once)', () => {
  ['{not json', '[]', '{"schemaVersion":0}', '{"schemaVersion":"1"}'].forEach(raw => {
    const inner = E.makeMemoryStorage({ wird_tasks_v1: raw }); const eng = E.createEngine({ storage: inner, clock: () => NOON, idGen: gen('b') });
    eq(inner.getItem('wird_tasks_v1'), raw, 'loading alone never writes'); eq(eng.status().backups, []);
    const r = isOk(eng.createTask(TODAY, 'first save')); eq(r.persisted, true);
    const bk = 'wird_tasks_v1_recovered_' + NOON; eq(eng.status().backups, [bk]); eq(inner.getItem(bk), raw, 'exact original text'); eq(JSON.parse(inner.getItem('wird_tasks_v1')).schemaVersion, 1);
    isOk(eng.createTask(TODAY, 'second save')); isOk(eng.createTask(TODAY, 'third save')); eq(eng.status().backups, [bk], 'one backup per recovery, not one per save'); eq(inner.getItem(bk), raw);
    const e2 = E.createEngine({ storage: inner, clock: () => NOON + 5, idGen: gen('c') }); eq(e2.status().loadedFrom, 'storage'); isOk(e2.createTask(TODAY, 'after reload')); eq(e2.status().backups, [], 'a healthy reload makes no backup');
  });
  // repaired (valid JSON with broken parts): the original text is what the backup holds
  const broken = JSON.stringify({ schemaVersion: 1, seq: 2, savedAt: 1, days: {}, tasks: { t1: { id: 't1', dayKey: TODAY, title: 'T', stepOrder: [] }, junk: 7 }, steps: {}, exec: {}, events: [] });
  const inner = E.makeMemoryStorage({ wird_tasks_v1: broken }); const eng = E.createEngine({ storage: inner, clock: () => NOON, idGen: gen('r') }); eq(eng.status().loadedFrom, 'repaired');
  eq(inner.getItem('wird_tasks_v1'), broken); isOk(eng.createTask(TODAY, 'x')); eq(inner.getItem('wird_tasks_v1_recovered_' + NOON), broken); ok(inner.getItem('wird_tasks_v1') !== broken);
  // healthy data, empty storage and a newer schema never create a backup
  const m = mk(); task(m.eng, ['a']); eq(m.eng.status().backups, []); eq(Object.keys(m.storage.inner.dump()).filter(k => k.indexOf('_recovered_') >= 0), []);
  const inner2 = E.makeMemoryStorage({ wird_tasks_v1: JSON.stringify({ schemaVersion: 50 }) }); const e3 = E.createEngine({ storage: inner2, clock: () => NOON }); isFail(e3.createTask(TODAY, 'x'), 'read_only'); eq(Object.keys(inner2.dump()), ['wird_tasks_v1']);
});
t('if the backup cannot be written the original is NOT overwritten; the session continues in memory and recovers on the next save', () => {
  const raw = '{"schemaVersion":1,"tasks":{"t1":'; // truncated JSON: the only copy of whatever was there
  const inner = E.makeMemoryStorage({ wird_tasks_v1: raw }); const blocked = { on: true, rx: /_recovered_/ }; const eng = E.createEngine({ storage: selective(inner, blocked), clock: () => NOON, idGen: gen('k') });
  const r = isOk(eng.createTask(TODAY, 'kept in memory', { steps: ['a', 'b'] })); eq(r.persisted, false); eq(inner.getItem('wird_tasks_v1'), raw, 'original untouched');
  let st = eng.status(); eq(st.degraded, true); eq(st.lastError.code, 'backup_failed'); eq(st.lastError.quota, true); eq(st.backups, []);
  const id = r.task.id; isOk(eng.start(id)); eq(isOk(eng.complete(r.task.steps[0].id)).persisted, false); eq(eng.getTask(id).status, 'in_progress'); eq(inner.getItem('wird_tasks_v1'), raw, 'still untouched after more actions');
  blocked.on = false; const r2 = isOk(eng.complete(r.task.steps[1].id)); eq(r2.persisted, true, 'one successful save carries everything'); eq(inner.getItem('wird_tasks_v1_recovered_' + NOON), raw);
  const e2 = E.createEngine({ storage: inner, clock: () => NOON }); eq(e2.getTask(id).status, 'completed'); eq(e2.status().degraded, false);
});
t('corrupt preferences are backed up before the first prefs save; a failing backup leaves them untouched', () => {
  const raw = '{broken prefs';
  const inner = E.makeMemoryStorage({ wird_taskprefs_v1: raw }); const blocked = { on: true, rx: /_recovered_/ }; const eng = E.createEngine({ storage: selective(inner, blocked), clock: () => NOON });
  eq(eng.status().prefsLoadedFrom, 'recovered'); eq(inner.getItem('wird_taskprefs_v1'), raw);
  const a = isOk(eng.setPrefs({ sound: true })); eq(a.persisted, false); eq(eng.getPrefs().sound, true, 'applied in memory'); eq(inner.getItem('wird_taskprefs_v1'), raw); eq(eng.status().lastError.code, 'backup_failed');
  blocked.on = false; const b = isOk(eng.setPrefs({ haptic: true })); eq(b.persisted, true); eq(inner.getItem('wird_taskprefs_v1_recovered_' + NOON), raw); eq(JSON.parse(inner.getItem('wird_taskprefs_v1')).values.sound, true);
  eq(eng.status().backups, ['wird_taskprefs_v1_recovered_' + NOON]); isOk(eng.setPrefs({ timer: true })); eq(eng.status().backups.length, 1);
});
t('a NEWER schema opens read-only and is never overwritten', () => {
  const raw = JSON.stringify({ schemaVersion: 99, tasks: { future: { whatever: true } }, extra: 'from the future' });
  const inner = E.makeMemoryStorage({ wird_tasks_v1: raw, wird_taskprefs_v1: JSON.stringify({ schemaVersion: 7, values: { sound: true } }) }); const s = flaky(inner);
  const eng = E.createEngine({ storage: s, clock: () => NOON });
  const st = eng.status(); eq(st.readOnly, true); eq(st.readOnlyReason, 'newer_schema'); eq(st.foundSchemaVersion, 99); eq(st.loadedFrom, 'newer_schema'); eq(st.prefsReadOnly, true);
  isFail(eng.createTask(TODAY, 'x'), 'read_only'); isFail(eng.start('x'), 'read_only'); isFail(eng.deleteTask('x'), 'read_only'); isFail(eng.setPrefs({ sound: false }), 'read_only'); isFail(eng.resetPrefs(), 'read_only');
  eq(eng.listDays(), []); eq(eng.getPrefs(), E.DEFAULT_PREFS, 'unknown prefs are not applied');
  eq(s.log.filter(x => x[0] === 'set').length, 0, 'not a single write'); eq(inner.getItem('wird_tasks_v1'), raw); eq(JSON.parse(inner.getItem('wird_taskprefs_v1')).schemaVersion, 7);
});
t('quota exceeded / failing storage: no throw, degraded flag, in-memory state stays authoritative, recovery on the next save', () => {
  const m = mk(); const { eng, storage } = m; const v = task(eng, ['a', 'b', 'c']);
  storage.quota = true; const s1 = isOk(eng.start(v.id)); eq(s1.persisted, false); const c1 = isOk(eng.complete(ids(v)[0])); eq(c1.persisted, false);
  let st = eng.status(); eq(st.degraded, true); eq(st.lastError.code, 'save_failed'); eq(st.lastError.quota, true); eq(st.lastError.name, 'QuotaExceededError');
  eq(eng.getTask(v.id).counts.completed, 1, 'work continues in memory');
  storage.quota = false; storage.failSet = true; eq(isOk(eng.complete(ids(v)[1])).persisted, false); eq(eng.status().lastError.quota, false);
  storage.failSet = false; const ok3 = isOk(eng.complete(ids(v)[2])); eq(ok3.persisted, true); eq(eng.status().degraded, false);
  const e2 = m.reopen(); eq(e2.getTask(v.id).status, 'completed', 'everything done while degraded was written by the next successful save');
  const g = flaky(E.makeMemoryStorage()); g.failGet = true; let gc = 0; const e3 = E.createEngine({ storage: g, clock: () => NOON, idGen: p => p + 'g' + (++gc) });
  eq(e3.status().loadedFrom, 'unavailable'); eq(e3.status().degraded, true); ok(['storage_unavailable', 'prefs_unavailable'].includes(e3.status().lastError.code)); isOk(e3.createTask(TODAY, 'in memory'));
  g.failGet = false; eq(isOk(e3.createTask(TODAY, 'saved now')).persisted, true); eq(e3.status().degraded, false);
});
t('reload() re-reads storage (another tab) and resets transient state', () => {
  const m = mk(); const { eng } = m; const v = task(eng, ['a']); const other = m.reopen(); isOk(other.start(v.id)); isOk(other.complete(ids(v)[0]));
  eq(eng.getTask(v.id).status, 'not_started'); eng.reload(); eq(eng.getTask(v.id).status, 'completed');
});
t('subscribe: change notifications, unsubscribe, a throwing listener cannot break the engine', () => {
  const { eng } = mk(); const seen = []; const off = eng.subscribe(e => seen.push(e)); eng.subscribe(() => { throw new Error('bad listener'); });
  const v = task(eng, ['a']); isOk(eng.start(v.id)); eq(seen.map(e => e.action), ['createTask', 'start']); eq(seen[0], { type: 'change', action: 'createTask', taskId: v.id });
  off(); isOk(eng.complete(ids(v)[0])); eq(seen.length, 2); eq(eng.subscribe('x')(), undefined);
});
t('returned objects are copies: mutating them never changes the engine', () => {
  const { eng } = mk(); const v = task(eng, ['a', 'b']); const view = eng.getTask(v.id); view.title = 'HACK'; view.steps.length = 0; view.counts.total = 99;
  eq(eng.getTask(v.id).title, 'مهمة'); eq(eng.getTask(v.id).steps.length, 2); isOk(eng.start(v.id)); const r = isOk(eng.complete(ids(v)[0])); r.record.key = 'x'; eng.getEvents()[0].key = 'y'; eng.getState().tasks = null;
  eq(eng.getCompletions()[0].key, 'done:' + ids(v)[0] + ':1'); ok(eng.getState().tasks);
});

// ========================================================================================== preferences
t('preferences: Minimal defaults, validated patch, persisted separately, per-session snapshot', () => {
  const m = mk(); const { eng, storage } = m;
  eq(eng.getPrefs(), { displayMode: 'one', autoTransition: true, backNavigation: true, skipStep: false, editDuringExecution: false, timer: false, progress: 'hidden', completionAnimation: 'subtle', sound: false, haptic: false, microInteractions: false, endOfDayPrompt: true });
  eq(storage.log.filter(x => x[0] === 'set').length, 0, 'defaults are not written until something changes');
  const r = isOk(eng.setPrefs({ progress: 'detailed', sound: true, bogus: 1, timer: 'yes', displayMode: 'grid' })); eq(r.applied, { progress: 'detailed', sound: true }); eq(r.rejected.sort(), ['bogus', 'displayMode', 'timer']); eq(r.persisted, true);
  isFail(eng.setPrefs({ bogus: 1 }), 'invalid_argument'); isFail(eng.setPrefs(null), 'invalid_argument'); isFail(eng.setPrefs('x'), 'invalid_argument');
  eq(storage.log.filter(x => x[0] === 'set').map(x => x[1]), ['wird_taskprefs_v1']); eq(JSON.parse(stored(storage, 'wird_taskprefs_v1')), { schemaVersion: 1, values: eng.getPrefs() });
  const v = task(eng, ['a', 'b']); isOk(eng.start(v.id)); eq(eng.getSessionPrefs(v.id).progress, 'detailed');
  isOk(eng.setPrefs({ progress: 'subtle', sound: false })); eq(eng.getSessionPrefs(v.id).progress, 'detailed', 'a running session keeps its snapshot'); eq(eng.getSessionPrefs(v.id).sound, true);
  const w = task(eng, ['a']); eq(eng.getSessionPrefs(w.id).progress, 'subtle', 'before start the live defaults are reported'); isOk(eng.start(w.id)); eq(eng.getSessionPrefs(w.id).progress, 'subtle');
  const e2 = m.reopen(); eq(e2.getPrefs().progress, 'subtle'); eq(e2.getSessionPrefs(v.id).progress, 'detailed', 'the snapshot is persisted with the session'); eq(e2.status().prefsLoadedFrom, 'storage');
  isOk(eng.pause(v.id)); const sp = isOk(eng.setSessionPrefs(v.id, { timer: true, progress: 'hidden', nope: 1 })); eq(sp.applied, { timer: true, progress: 'hidden' }); eq(eng.getSessionPrefs(v.id).timer, true); eq(eng.getPrefs().timer, false, 'a session override never changes the saved defaults');
  isFail(eng.setSessionPrefs(v.id, { nope: 1 }), 'invalid_argument'); const z = task(eng, ['q']); isFail(eng.setSessionPrefs(z.id, { timer: true }), 'not_started');
  const y = task(eng, ['q']); isOk(eng.start(y.id, { prefs: { haptic: true, progress: 'junk' } })); eq(eng.getSessionPrefs(y.id).haptic, true); eq(eng.getSessionPrefs(y.id).progress, 'subtle');
  isOk(eng.resetPrefs()); eq(eng.getPrefs(), E.DEFAULT_PREFS); eq(eng.getSessionPrefs(v.id).progress, 'hidden', 'resetting the defaults leaves the session snapshot (with its own override) alone'); eq(eng.getSessionPrefs(v.id).timer, true);
});
t('corrupt or invalid preferences fall back to the defaults without throwing', () => {
  ['{x', 'null', '[]', '{"schemaVersion":"1","values":{}}', '{"schemaVersion":1}', '{"schemaVersion":1,"values":{"sound":"loud","progress":"detailed","unknown":1}}'].forEach(raw => {
    const eng = E.createEngine({ storage: E.makeMemoryStorage({ wird_taskprefs_v1: raw }), clock: () => NOON });
    const p = eng.getPrefs(); eq(Object.keys(p).sort(), Object.keys(E.DEFAULT_PREFS).sort(), raw); eq(p.sound, false, raw);
    if (raw.includes('detailed')) eq(p.progress, 'detailed'); else eq(p.progress, 'hidden');
    isOk(eng.setPrefs({ timer: true }));
  });
});

// ============================================================================== linked quick task, isolation
t('linked quick task: link rules and the single done-flag call', () => {
  const calls = []; const { eng } = mk({ habits: { markOneoffDone: (id, day) => calls.push([id, day]) } });
  isFail(eng.createTask(TODAY, 'x', { linkedOneoffId: 'bad id' }), 'bad_link'); isFail(eng.createTask(TODAY, 'x', { linkedOneoffId: 5 }), 'bad_link'); isFail(eng.createTask(TOMORROW, 'x', { linkedOneoffId: 'o_1' }), 'link_today_only'); isFail(eng.createTask(YESTERDAY, 'x', { linkedOneoffId: 'o_1' }), 'link_today_only');
  const v = task(eng, ['a', 'b'], TODAY, 'linked', { linkedOneoffId: 'o_17a9x' }); eq(v.linkedOneoffId, 'o_17a9x'); eq(v.linkedDay, TODAY); eq(eng.getTaskByLink('o_17a9x').id, v.id); eq(eng.getTaskByLink('o_nope'), null);
  isOk(eng.start(v.id)); isOk(eng.complete(ids(v)[0])); eq(calls.length, 0, 'nothing before the whole task is done');
  const fin = isOk(eng.complete(ids(v)[1])); eq(fin.status, 'completed'); eq(calls, [['o_17a9x', TODAY]]);
  isOk(eng.undo(v.id)); isOk(eng.complete(ids(v)[1])); eq(calls.length, 1, 'called once per task, not again after undo + redo');
  const none = task(eng, ['a']); isOk(eng.start(none.id)); isOk(eng.complete(ids(none)[0])); eq(calls.length, 1, 'no link, no call');
  const part = task(eng, ['a', 'b'], TODAY, 'p', { linkedOneoffId: 'o_part' }); isOk(eng.start(part.id)); isOk(eng.skip(ids(part)[0])); eq(isOk(eng.complete(ids(part)[1])).status, 'partial'); eq(calls.length, 1, 'partial does not mark the quick task done');
  const sk = task(eng, ['a'], TODAY, 's', { linkedOneoffId: 'o_skip' }); isOk(eng.start(sk.id)); eq(isOk(eng.skip(ids(sk)[0])).status, 'skipped'); eq(calls.length, 1);
  const del = task(eng, ['a', 'b'], TODAY, 'd', { linkedOneoffId: 'o_del' }); isOk(eng.start(del.id)); isOk(eng.complete(ids(del)[0])); isOk(eng.deleteStep(ids(del)[1])); eq(calls.length, 2, 'finishing by deleting the last open step also counts'); eq(calls[1][0], 'o_del');
});
t('linked quick task: moving away clears the link; setLink rules; a throwing adapter cannot break completion', () => {
  const { eng } = mk({ habits: { markOneoffDone: () => { throw new Error('habits exploded'); } } });
  const v = task(eng, ['a'], TODAY, 'x', { linkedOneoffId: 'o_1' }); const mv = isOk(eng.moveTask(v.id, TOMORROW)); eq(mv.linkCleared, true); eq(mv.task.linkedOneoffId, null); eq(eng.getEvents({ type: 'task_move' })[0].linkCleared, true);
  isFail(eng.setLink(v.id, 'o_2'), 'link_today_only'); isOk(eng.moveTask(v.id, TODAY)); isFail(eng.setLink(v.id, 'bad id'), 'bad_link'); eq(isOk(eng.setLink(v.id, 'o_2')).task.linkedOneoffId, 'o_2'); eq(isOk(eng.setLink(v.id, 'o_2')).noop, true);
  isOk(eng.start(v.id)); const r = isOk(eng.complete(ids(v)[0])); eq(r.status, 'completed'); eq(eng.status().lastError.code, 'link_failed'); eq(eng.getTask(v.id).status, 'completed');
  eq(isOk(eng.setLink(v.id, null)).task.linkedOneoffId, null); eq(isOk(eng.setLink(v.id, null)).noop, true);
});
t('isolation: the engine touches only wird_tasks_v1 and wird_taskprefs_v1 (never wird_habits_v1 or any other key)', () => {
  const inner = E.makeMemoryStorage({ wird_habits_v1: '{"habits":[]}', wird_quran_state_v1: 'q', other: 'o' }); const s = flaky(inner);
  let ic = 0; const eng = E.createEngine({ storage: s, clock: () => NOON, idGen: p => p + 'i' + (++ic) });
  const v = task(eng, ['a', 'b'], TODAY, 'x', { linkedOneoffId: 'o_9' }); isOk(eng.start(v.id)); isOk(eng.complete(ids(v)[0])); isOk(eng.skip(ids(v)[1])); isOk(eng.undo(v.id)); isOk(eng.setPrefs({ sound: true })); eng.reload();
  eq([...new Set(s.log.map(x => x[1]))].sort(), ['wird_taskprefs_v1', 'wird_tasks_v1']); eq(inner.getItem('wird_habits_v1'), '{"habits":[]}'); eq(inner.getItem('other'), 'o');
});

// ================================================================================== queries and views
t('queries: getDay, listDays, getCurrent, getActiveTask, getEvents / getCompletions filters', () => {
  const { eng, clock } = mk(); const a = task(eng, ['a1', 'a2'], TODAY, 'A'), b = task(eng, ['b1'], TODAY, 'B'), c = task(eng, ['c1'], TOMORROW, 'C');
  eq(eng.getDay(TODAY).counts, { tasks: 2, finished: 0, unfinished: 2 }); eq(eng.getDay(TODAY).allFinished, false); eq(eng.getDay('x'), null); eq(eng.getDay(YESTERDAY).tasks, []); eq(eng.getDay(YESTERDAY).allFinished, false);
  eq(eng.listDays().map(d => d.key), [TODAY, TOMORROW]); eq(eng.getActiveTask(), null);
  isOk(eng.start(a.id)); clock.adv(1000); isOk(eng.start(b.id)); eq(eng.getActiveTask().id, b.id); clock.adv(1000); isOk(eng.complete(ids(a)[0])); eq(eng.getActiveTask().id, a.id, 'the most recently touched unfinished task');
  eq(eng.getCurrent(a.id), { taskId: a.id, taskTitle: 'A', status: 'in_progress', step: { id: ids(a)[1], text: 'a2', index: 1 }, counts: { total: 2, completed: 1, skipped: 0, remaining: 1 } }); eq(eng.getCurrent('nope'), null);
  isOk(eng.complete(ids(a)[1])); isOk(eng.complete(ids(b)[0])); eq(eng.getDay(TODAY).allFinished, true); eq(eng.getDay(TODAY).counts, { tasks: 2, finished: 2, unfinished: 0 }); eq(eng.getActiveTask(), null);
  eq(eng.getCompletions({ taskId: a.id }).length, 2); eq(eng.getCompletions({ dayKey: TOMORROW }).length, 0); eq(eng.getCompletions({ since: NOON + 2000 }).length, 3); eq(eng.getCompletions({ since: NOON + 2001 }).length, 0); eq(eng.getCompletions({ until: NOON + 1500 }).length, 0); eq(eng.getCompletions({ until: NOON + 2000 }).length, 3);
  eq(eng.getEvents({ taskId: b.id }).map(e => e.type), ['start', 'complete']); eq(eng.getEvents({ dayKey: TODAY, type: 'complete' }).length, 3); eq(eng.getEvents({ stepId: ids(a)[0] }).length, 1);
});
t('text handling: Arabic, RTL marks and emoji are preserved; markup is plain text (the engine never interprets it)', () => {
  const { eng } = mk(); const v = isOk(eng.createTask(TODAY, 'مذاكرة الفيزياء ⚡', { steps: ['اقرأ الفصل \u200F(٣)', '<img src=x onerror=alert(1)>', '😀 ختام'] })).task;
  eq(v.steps.map(s => s.text), ['اقرأ الفصل \u200F(٣)', '<img src=x onerror=alert(1)>', '😀 ختام']); eq(v.title, 'مذاكرة الفيزياء ⚡');
});

// ===================================================================================== fuzz + scale
function rng(seed) { let s = seed >>> 0; return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; }
function invariants(m, label) {
  const { eng } = m; const st = eng.getState(); const days = new Set(); const evs = eng.getEvents();
  eq(new Set(evs.map(e => e.key)).size, evs.length, label + ': unique event keys'); eq(evs.map(e => e.seq), evs.map(e => e.seq).slice().sort((a, b) => a - b), label + ': seq order'); eq(new Set(evs.map(e => e.seq)).size, evs.length, label + ': unique seq');
  Object.keys(st.tasks).forEach(id => {
    const v = eng.getTask(id, { includeDeleted: true }); const c = v.counts;
    eq(c.total, v.steps.length, label + ': total'); eq(c.completed + c.skipped + c.remaining, c.total, label + ': counts add up');
    eq(v.steps.filter(s => s.state === 'completed').length, c.completed); eq(v.steps.filter(s => s.state === 'skipped').length, c.skipped);
    const firstOpen = v.steps.find(s => s.state === 'not_started' || s.state === 'in_progress'); eq(v.currentStepId, firstOpen ? firstOpen.id : null, label + ': current is the first unresolved step');
    const expect = c.total === 0 ? 'not_started' : c.remaining === 0 ? (c.skipped === 0 ? 'completed' : (c.completed === 0 ? 'skipped' : 'partial')) : (v.paused ? 'paused' : (v.started ? 'in_progress' : 'not_started'));
    eq(v.status, expect, label + ': status derivation');
    if (v.status === 'paused' || v.status === 'in_progress') eq(v.steps.filter(s => s.state === 'in_progress').length, 1, label + ': exactly one in-progress step'); else eq(v.steps.filter(s => s.state === 'in_progress').length, 0);
    v.steps.forEach(s => { const act = eng.getCompletions({ taskId: id }).filter(e => e.stepId === s.id); eq(act.length, s.state === 'completed' ? 1 : 0, label + ': one active completion per completed step'); });
    ok(!v.deleted || !(st.days[v.dayKey] && st.days[v.dayKey].taskOrder.includes(id)), label + ': deleted task not in day order');
    ok(!v.steps.some(s => st.steps[s.id].deletedAt), label + ': no tombstoned step in view'); ok(v.linkedOneoffId === null || v.dayKey === v.linkedDay, label + ': link only on its own day');
  });
  Object.keys(st.days).forEach(k => { const o = st.days[k].taskOrder; eq(new Set(o).size, o.length); o.forEach(id => { ok(st.tasks[id] && !st.tasks[id].deletedAt && st.tasks[id].dayKey === k, label + ': day order consistent'); }); });
  const e2 = m.reopen(); eq(e2.status().repairs, 0, label + ': reload needs no repair'); eq(e2.status().loadedFrom === 'storage' || e2.status().loadedFrom === 'empty', true);
  Object.keys(st.tasks).forEach(id => eq(e2.getTask(id, { includeDeleted: true }), eng.getTask(id, { includeDeleted: true }), label + ': reload equals live view'));
  eq(e2.listDays(), eng.listDays()); eq(e2.getCompletions(), eng.getCompletions()); eq(e2.getPrefs(), eng.getPrefs());
}
t('fuzz: 150 seeded random sessions keep every invariant and survive a reload at the end', () => {
  for (let seed = 1; seed <= 150; seed++) {
    const R = rng(seed * 7919), m = mk({ undoWindowMs: 5000 }), eng = m.eng, taskIds = [], stepIds = [], days = [TODAY, TOMORROW, YESTERDAY];
    const pick = a => a.length ? a[Math.floor(R() * a.length)] : 'none'; const maybe = (a, p) => R() < p ? 'ghost' : pick(a);
    for (let i = 0; i < 70; i++) {
      m.clock.adv(Math.floor(R() * 9000)); const x = Math.floor(R() * 21); let r;
      switch (x) {
        case 0: r = eng.createTask(pick(days), 'task ' + i, { steps: new Array(Math.floor(R() * 5)).fill(0).map((_, k) => 's' + k), linkedOneoffId: R() < 0.2 ? 'o_' + i : undefined }); if (r.ok) { taskIds.push(r.task.id); r.task.steps.forEach(s => stepIds.push(s.id)); } break;
        case 1: case 2: r = eng.start(maybe(taskIds, 0.05)); break;
        case 3: case 4: case 5: { const tv = eng.getTask(pick(taskIds)); r = eng.complete(tv && tv.currentStepId && R() < 0.85 ? tv.currentStepId : maybe(stepIds, 0.1)); break; }
        case 6: { const tv = eng.getTask(pick(taskIds)); r = eng.skip(tv && tv.currentStepId && R() < 0.85 ? tv.currentStepId : maybe(stepIds, 0.1)); break; }
        case 7: case 8: r = eng.undo(maybe(taskIds, 0.05)); break;
        case 9: r = eng.back(maybe(taskIds, 0.05)); break;
        case 10: r = eng.pause(maybe(taskIds, 0.05)); break;
        case 11: r = eng.resume(maybe(taskIds, 0.05)); break;
        case 12: r = eng.addStep(maybe(taskIds, 0.05), 'added ' + i, R() < 0.5 ? { index: Math.floor(R() * 4) } : (R() < 0.5 ? { afterStepId: pick(stepIds) } : undefined)); if (r.ok) stepIds.push(r.step.id); break;
        case 13: r = eng.deleteStep(maybe(stepIds, 0.05)); break;
        case 14: r = eng.editStep(maybe(stepIds, 0.05), 'edit ' + i); break;
        case 15: { const tv = eng.getTask(pick(taskIds)); r = eng.reorderSteps(tv ? tv.id : 'x', tv ? tv.steps.map(s => s.id).reverse() : []); break; }
        case 16: r = eng.moveStep(maybe(stepIds, 0.05), Math.floor(R() * 4)); break;
        case 17: r = eng.moveTask(maybe(taskIds, 0.05), pick(days), R() < 0.5 ? Math.floor(R() * 3) : undefined); break;
        case 18: if (R() < 0.3) r = eng.deleteTask(maybe(taskIds, 0.05)); else r = eng.editTask(maybe(taskIds, 0.05), { title: 'retitled ' + i }); break;
        case 19: r = eng.setPrefs({ progress: pick(['hidden', 'subtle', 'detailed', 'bad']), sound: R() < 0.5 }); break;
        default: r = eng.setLink(maybe(taskIds, 0.05), R() < 0.5 ? 'o_' + i : null);
      }
      ok(r && typeof r.ok === 'boolean', 'every action returns a result object'); if (!r.ok) ok(typeof r.reason === 'string' && r.reason !== 'internal_error', 'seed ' + seed + ' step ' + i + ': ' + JSON.stringify(r));
    }
    invariants(m, 'seed ' + seed);
  }
});
t('scale: 100 tasks x 10 steps in a day completes quickly; the saved state stays within a sane size', () => {
  const m = mk(); const { eng } = m; const t0 = Date.now(); const all = [];
  for (let i = 0; i < 100; i++) all.push(task(eng, new Array(10).fill(0).map((_, k) => 'خطوة رقم ' + (k + 1)), TODAY, 'مهمة رقم ' + i));
  const tCreate = Date.now() - t0; const t1 = Date.now(); let actions = 0;
  all.forEach(v => { isOk(eng.start(v.id)); v.steps.forEach(s => { isOk(eng.complete(s.id)); actions++; }); }); const tRun = Date.now() - t1;
  const bytes = stored(m.storage, 'wird_tasks_v1').length; const t2 = Date.now(); const e2 = m.reopen(); const tLoad = Date.now() - t2;
  console.log('    scale: create 100 tasks %d ms; %d completions %d ms (%s ms/action); saved state %s KB; reload %d ms', tCreate, actions, tRun, (tRun / actions).toFixed(2), (bytes / 1024).toFixed(0), tLoad);
  eq(eng.getDay(TODAY).allFinished, true); eq(e2.getDay(TODAY).allFinished, true); eq(e2.getCompletions().length, 1000);
  ok(tRun / actions < 40, 'average action time ' + (tRun / actions).toFixed(1) + ' ms'); ok(tLoad < 1500, 'reload ' + tLoad + ' ms'); ok(bytes < 2 * 1024 * 1024, 'state size ' + bytes);
});

// ----------------------------------------------------------------------------------------------- report
console.log(failed.length ? '\n✘ ' + failed.length + ' FAILED:\n  - ' + failed.join('\n  - ') : '\n✔ task engine: ' + passed + ' tests passed (' + asserts + ' assertions)');
console.log('  tests: ' + (passed + failed.length) + ' | passed: ' + passed + ' | failed: ' + failed.length + ' | assertions: ' + asserts);
process.exit(failed.length ? 1 : 0);
