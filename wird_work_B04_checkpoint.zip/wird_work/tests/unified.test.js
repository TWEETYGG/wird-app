// اختبارات «الشجرة الموحّدة» والترحيل — Playwright، بدون أي اتصال حقيقي.
// بيانات قديمة حقيقية بتتكتب بنسخة ما قبل التوحيد (tools/phase2/index.html) وبتتفتح بالنسخة الموحّدة على نفس الأصل (نفس IndexedDB/localStorage).
// التشغيل:  NODE_PATH=$(npm root -g) node tests/unified.test.js [مسار index.html]     (ONLY=MIG-U1 لتشغيل اختبار واحد، DEBUG=1 لتفاصيل الأخطاء)
const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
const ROOT = path.resolve(__dirname, '..');
const INDEX = path.resolve(process.argv[2] || path.join(ROOT, 'index.html'));
const OLD = path.join(ROOT, 'tools/phase2/index.html');
const UNC = 'غير مصنّف';
let current = INDEX, BASE, browser;
const server = http.createServer((req, res) => {
  const u = decodeURIComponent(req.url.split('?')[0]);
  if (u === '/blank.html') { res.writeHead(200, { 'content-type': 'text/html' }); return res.end('<!doctype html><title>x</title>'); }
  const f = u === '/' || u === '/index.html' ? current : path.join(ROOT, u);
  fs.readFile(f, (e, d) => { if (e) { res.writeHead(404); return res.end(); } const ext = path.extname(f); res.writeHead(200, { 'content-type': ext === '.html' ? 'text/html; charset=utf-8' : ext === '.js' ? 'text/javascript' : ext === '.png' ? 'image/png' : 'application/json' }); res.end(d); });
});
const results = [];
const eq = (a, b, m) => { if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error((m || 'eq') + ': expected ' + JSON.stringify(b) + ' got ' + JSON.stringify(a)); };
const ok = (c, m) => { if (!c) throw new Error(m || 'assertion failed'); };
const W = (p, fn, arg) => p.evaluate(fn, arg);
const sleep = ms => new Promise(r => setTimeout(r, ms));
const newCtx = (vp) => browser.newContext({ viewport: vp || { width: 390, height: 844 }, locale: 'ar-EG', timezoneId: 'Africa/Cairo', serviceWorkers: 'block' });
async function open(ctx) {
  const p = await ctx.newPage(); p.__errs = [];
  p.on('pageerror', e => p.__errs.push('pageerror: ' + e));
  p.on('console', m => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) p.__errs.push('console: ' + m.text()) });
  p.on('requestfailed', r => { if (r.url().startsWith(BASE)) p.__errs.push('local request failed: ' + r.url()) });
  await p.route(/^https?:\/\/(?!127\.0\.0\.1)/, r => r.abort());
  p.setDefaultTimeout(8000); await p.goto(BASE + '/index.html'); await sleep(500); return p;
}
async function T(name, fn) {
  if (process.env.ONLY && !name.includes(process.env.ONLY)) return;
  try { await fn(); results.push([name, true]); } catch (e) { results.push([name, false, process.env.DEBUG ? e.stack.split("\n").slice(0, 18).join('\n      ') : e.message.split('\n')[0]]); }
}
const openWs = async p => { await p.click('.tab[data-view="view-lessons"]'); await p.waitForFunction(() => window.__WIRD_STUDY_APP__ && __WIRD_STUDY_APP__.isOpen, null, { timeout: 15000 }); };
const state = p => W(p, () => WirdUnified.state());
const waitMigrated = p => p.waitForFunction(() => { try { const s = JSON.parse(localStorage.getItem('wird_mig_v3')); return !!(s && s.after) } catch (e) { return false } }, null, { timeout: 20000 });
const resources = p => W(p, async () => (await __WIRD_STUDY_APP__.repo.listAllResources()).filter(r => !r.deletedAt));
const treeInfo = p => W(p, async () => { const a = __WIRD_STUDY_APP__, T = a.tree, res = (await a.repo.listAllResources()).filter(r => !r.deletedAt), L = id => (T.lessons.find(l => l.id === id) || {}).title; const unc = T.subjects.find(s => s.name === 'غير مصنّف');
  return { subjects: T.subjects.map(s => s.name).sort(), uncUnits: unc ? T.units.filter(u => u.subjectId === unc.id).map(u => u.name).sort() : null, lessons: T.lessons.length, items: res.map(r => [r.type, L(r.lessonId), r.status]).sort() } });
const expandAll = (p) => W(p, () => { const a = __WIRD_STUDY_APP__; a.tree.subjects.forEach(s => a.sidebar.setExpanded(s.id, true)); a.tree.units.forEach(u => a.sidebar.setExpanded(u.id, true)); a.sidebar.render(); a.root.classList.add('side-open') });

(async () => {
  await new Promise(r => server.listen(0, '127.0.0.1', r)); BASE = 'http://127.0.0.1:' + server.address().port;
  browser = await chromium.launch(process.env.CHROME ? { executablePath: process.env.CHROME, args: ['--no-sandbox'] } : { args: ['--no-sandbox'] });
  let mig = null; // سياق الترحيل بيتشارك بين MIG-U1 و MIG-U2

  await T('MIG-U1. ترحيل بيانات قديمة حقيقية: أعداد قبل=بعد، المصادر ما اتمسّتش، «غير مصنّف» بوحداته، نسخة احتياطية، تقرير مرة واحدة، idempotent', async () => {
    const ctx = await newCtx(); current = OLD; const old = await open(ctx);
    const seeded = await W(old, async () => {
      const iso = todayISO(), mkB = (id, title, cur) => ({ id, title, reason: '', dailyTarget: 10, totalPages: 200, currentPage: cur, addedDate: iso, todayDate: iso, todayStartPage: cur, streak: 0 });
      for (const b of [mkB('b1', 'كتاب التوحيد', 50), mkB('b2', 'كتاب جديد', 1)]) { await dbPut('books', b); booksState.list.push(b) }
      const WC = WirdCourses, c = WC.createCourse({ title: 'أساسيات الكيمياء' }), v = WC.upsertVideo({ id: 'dQw4w9WgXcQ', title: 'الذرة', duration: 600 });
      c.lessons.push(WC.mkLesson({ vid: v.id, title: 'التفاعلات' })); WC.save();
      const sid = stCreate('رياضيات', 'المشتقة هي معدل التغير. التكامل عكس التفاضل. النهاية أساس التفاضل.', 'sent'); ST.sessions[sid].items[0].status = 'red'; stSave();
      const a = __WIRD_STUDY_APP__; await a.init(); const r = a.repo, s = await r.createSubject('فيزياء'), u = await r.createUnit(s.id, 'الحركة'), l = await r.createLesson({ subjectId: s.id, unitId: u.id, title: 'قوانين نيوتن' });
      return { s: s.id, u: u.id, l: l.id };
    });
    await sleep(600);
    const snap = await W(old, async () => ({ books: await dbGetAll('books'), courses: localStorage.getItem('wird_courses_v1'), study: localStorage.getItem('wird_study_v1') }));
    ok(snap.courses && snap.study, 'legacy localStorage seeded'); await old.close();
    const blank = await ctx.newPage(); await blank.goto(BASE + '/blank.html');   // دفتر نوت قديم: مفتاح L<lessonId> + النوت العام G
    await W(blank, async lid => { const it = [{ k: 'txt', x: 1, y: 1, s: 'نص قديم' }], pg = { t: 'ورقة', bg: '#14191c', mode: 'free', lay: 'free', pt: 0, pc: 0, it, v: { x: 0, y: 0, z: 1 } };
      const db = await new Promise((res, rej) => { const q = indexedDB.open('wird_fnb_m', 1); q.onupgradeneeded = () => { if (!q.result.objectStoreNames.contains('m')) q.result.createObjectStore('m') }; q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error) });
      await new Promise((res, rej) => { const t = db.transaction('m', 'readwrite'); t.objectStore('m').put({ g: { bg: '#14191c', mode: 'free', lay: 'free' }, glob: null, mode: {}, books: { ['L' + lid]: { cur: 0, n: [pg] }, G: { cur: 0, n: [pg] } } }, '__S'); t.oncomplete = res; t.onerror = () => rej(t.error) }); db.close() }, seeded.l);
    await blank.close();
    current = INDEX; const p = await open(ctx); await openWs(p); await waitMigrated(p);
    const st = await state(p);
    eq(st.before, { books: 2, courses: 1, notebooks: 2, texts: 1, resources: 0 }, 'before');
    eq(st.after, { books: 2, courses: 1, notebooks: 2, texts: 1, resources: 6 }, 'after'); eq(st.created.items.length, 6);
    const ti = await treeInfo(p);
    eq(ti.subjects, [UNC, 'فيزياء'].sort(), 'subjects'); eq(ti.uncUnits, ['كتب', 'كورسات', 'المذاكرة', 'دفاتر'].sort(), 'orphans grouped by type');
    eq(ti.items, [['book', 'كتاب التوحيد', 'doing'], ['book', 'كتاب جديد', 'todo'], ['course', 'أساسيات الكيمياء', 'todo'], ['text', 'رياضيات', 'todo'], ['notebook', 'النوت العام', 'todo'], ['notebook', 'قوانين نيوتن', 'todo']].sort(), 'items');
    eq(await W(p, ids => __WIRD_STUDY_APP__.tree.lessons.filter(l => l.unitId === ids.u).map(l => l.id), seeded), [seeded.l], 'existing lesson untouched, nothing added under it except its own notebook item');
    eq(await W(p, async () => ({ books: await dbGetAll('books'), courses: localStorage.getItem('wird_courses_v1'), study: localStorage.getItem('wird_study_v1') })), snap, 'original sources byte-identical after migration');
    const bk = await W(p, () => new Promise(r => { const q = indexedDB.open('wird_mig_db'); q.onsuccess = () => { const g = q.result.transaction('b').objectStore('b').get('pre-v3'); g.onsuccess = () => { q.result.close(); r(g.result && JSON.parse(g.result.json)) } } }));
    ok(bk && bk.kind === 'pre-v3-backup', 'backup exists'); eq(bk.books.map(b => b.id).sort(), ['b1', 'b2']); eq(bk.resources, [], 'backup taken before any link'); ok(bk.note.includes('بيانات وصفية'));
    await p.waitForSelector('.wu-sheet', { timeout: 8000 }); eq(await p.locator('.wu-hd h3').innerText(), 'تقرير الترحيل');
    eq(await p.locator('.wu-tbl td[aria-label="مطابق"]').count(), 4, 'four ✓ rows (books/courses/notebooks/texts)'); ok(!(await p.locator('.wu-tbl td[aria-label="اختلاف"]').count()), 'no mismatch');
    await p.click('.wu-act .ls-btn-primary'); eq(await p.locator('.wu-sheet').count(), 0);
    const before2 = await treeInfo(p); await W(p, async () => { await WirdUnified.reconcile(); await WirdUnified.reconcile(); await WirdUnified.reconcile() });
    eq(await treeInfo(p), before2, 'idempotent: three more passes change nothing'); eq((await state(p)).created.items.length, 6);
    await W(p, async () => { const db = await openBooksDB(); await new Promise(r => { const tx = db.transaction('books', 'readwrite'); tx.objectStore('books').delete('b2'); tx.oncomplete = r }); await WirdUnified.reconcile() });
    eq((await state(p)).after, { books: 2, courses: 1, notebooks: 2, texts: 1, resources: 6 }, 'report is a frozen snapshot of the migration: later deleting a source does not fake a mismatch');
    await W(p, async () => { const b = { id: 'b2', title: 'كتاب جديد', reason: '', dailyTarget: 10, totalPages: 200, currentPage: 1, addedDate: todayISO(), todayDate: todayISO(), todayStartPage: 1, streak: 0 }; await dbPut('books', b) });   // نرجّعه عشان باقي الاختبار والمقارنة بالنسخة الأصلية
    await p.reload(); await sleep(500); await openWs(p); await sleep(1800); eq(await p.locator('.wu-sheet').count(), 0, 'report shown only once');
    eq(p.__errs, [], 'no console/page errors');
    mig = { ctx, p, seeded, snap };
  });

  await T('MIG-U2. رجوع للوضع السابق (بتأكيد) ثم إعادة الربط: المصادر والشجرة الأصلية سليمة في الاتجاهين', async () => {
    ok(mig, 'needs MIG-U1'); const { p, seeded, snap } = mig;
    await W(p, () => { const a = __WIRD_STUDY_APP__; a.go({ kind: 'home' }) }); await sleep(400);
    eq(await p.locator('.ls-home .wu-rep').innerText(), '📋 تقرير الترحيل', 'report entry on the home screen');
    await p.click('.ls-home .wu-rep'); await p.waitForSelector('.wu-sheet'); await p.click('.wu-act .ls-btn-danger');
    eq(await p.locator('.wu-hd h3').innerText(), 'تأكيد الرجوع', 'rollback asks for confirmation'); await p.click('.wu-act button:has-text("إلغاء")');
    eq((await resources(p)).length, 6, 'cancel keeps everything');
    await p.click('.ls-home .wu-rep'); await p.waitForSelector('.wu-sheet'); await p.click('.wu-act .ls-btn-danger'); await p.waitForSelector('.wu-sheet'); await p.click('.wu-act .ls-btn-danger');
    await p.waitForFunction(() => WirdUnified.state().rolledBack, null, { timeout: 10000 }); await sleep(500);
    let ti = await treeInfo(p); eq(ti.subjects, ['فيزياء'], 'auto-created subject gone, user subject intact'); eq(ti.items, [], 'no linked items'); eq(ti.lessons, 1);
    eq(await W(p, async () => ({ books: await dbGetAll('books'), courses: localStorage.getItem('wird_courses_v1'), study: localStorage.getItem('wird_study_v1') })), snap, 'sources identical after rollback');
    eq(await p.locator('.ls-home .wu-rep').innerText(), '↻ إعادة ربط البيانات القديمة', 'entry switches to re-link');
    await p.click('.ls-home .wu-rep'); await p.waitForFunction(() => { const s = WirdUnified.state(); return s.after && s.after.resources === 6 && !s.off }, null, { timeout: 20000 });
    ti = await treeInfo(p); eq(ti.subjects, [UNC, 'فيزياء'].sort()); eq(ti.items.length, 6, 'all six items back'); eq((await state(p)).after, { books: 2, courses: 1, notebooks: 2, texts: 1, resources: 6 });
    await p.waitForSelector('.wu-sheet', { timeout: 6000 }); await p.click('.wu-act .ls-btn-primary'); eq(mig.p.__errs, [], 'no errors');
    await mig.ctx.close();
  });

  await T('UNI-A1. الإضافة من السياق: ⋯ على الدرس ← ＋ نص (لمستين) بيتربط بالدرس نفسه ومفيش «غير مصنّف»', async () => {
    const ctx = await newCtx(); current = INDEX; const p = await open(ctx);
    const ids = await W(p, async () => { const a = __WIRD_STUDY_APP__; await a.init(); const r = a.repo, s = await r.createSubject('كيمياء'), u = await r.createUnit(s.id, 'الروابط'), l = await r.createLesson({ subjectId: s.id, unitId: u.id, title: 'الروابط التساهمية' }), l2 = await r.createLesson({ subjectId: s.id, unitId: u.id, title: 'الروابط الأيونية' }); await a.reloadTree(); return { s: s.id, u: u.id, l: l.id, l2: l2.id } });
    await openWs(p); await sleep(900); await expandAll(p); await sleep(300);
    let taps = 0;
    await p.click(`.ls-row[data-id="${ids.l}"] [data-act="menu"]`); taps++; await p.click('.ls-ctx-item:has-text("＋ نص مذاكرة")'); taps++; eq(taps, 2, 'two taps to reach the form');
    await p.waitForSelector('#wuTx'); await p.fill('#wuTx', 'الرابطة التساهمية تنشأ بمشاركة الإلكترونات. الرابطة الأيونية تنشأ بانتقالها.'); await p.click('.wr-form button[type="submit"]');
    await p.waitForSelector('.ls-row-item', { timeout: 8000 }); await sleep(1500);
    const res = await resources(p); eq(res.map(r => [r.type, r.lessonId]), [['text', ids.l]], 'attached to the selected lesson');
    eq((await treeInfo(p)).subjects, ['كيمياء'], 'no «غير مصنّف» created for in-context add');
    eq(await p.locator(`.ls-row-item .ls-row-icon`).first().innerText(), '📓'); await expandAll(p);
    mig = { ctx, p, ids }; eq(p.__errs, [], 'no errors');
  });

  await T('UNI-A2. بحث بالكيبورد (Ctrl+K ثم Enter) بيلاقي العنصر ويفتحه، وقائمة ⋯ + إعادة تسمية بـ Enter + نقل لدرس تاني', async () => {
    const { p, ids } = mig;
    await p.keyboard.press('Control+k'); await p.waitForSelector('.ls-palette-input'); await p.keyboard.type('مشاركة'); await sleep(500);
    ok((await p.locator('.ls-palette-item', { hasText: '📓' }).count()) === 1, 'item found by its text'); await p.keyboard.press('Enter'); await sleep(900);
    eq(await W(p, () => __WIRD_STUDY_APP__.route.id), ids.l, 'search opened the lesson'); eq(await p.locator('#wrt-text').getAttribute('aria-selected'), 'true', 'text tab selected');
    await expandAll(p); await sleep(300);
    await p.click('.ls-row-item [data-act="menu"]'); const labels = await p.locator('.ls-ctx-item').allInnerTexts(); eq(labels.map(x => x.trim().replace(/^\S+\s*/, '')).filter(Boolean), ['فتح', 'إعادة تسمية', 'نقل لدرس تاني', 'إعدادات', 'إزالة من الدرس'], 'item menu');
    await p.click('.ls-ctx-item:has-text("إعادة تسمية")'); await p.waitForSelector('#wuNm'); eq(await W(p, () => document.activeElement.id), 'wuNm', 'rename input focused'); await p.fill('#wuNm', 'نص الروابط'); await p.keyboard.press('Enter');
    await p.waitForFunction(() => [...document.querySelectorAll('.ls-row-item .ls-row-name')].some(e => e.textContent === 'نص الروابط'), null, { timeout: 6000 });
    await p.click('.ls-row-item [data-act="menu"]'); await p.click('.ls-ctx-item:has-text("نقل لدرس تاني")'); await p.waitForSelector('#wuLes'); await p.selectOption('#wuLes', ids.l2); await p.click('.wu-act .ls-btn-primary'); await sleep(700);
    eq((await resources(p)).map(r => r.lessonId), [ids.l2], 'moved to the other lesson'); eq(p.__errs, [], 'no errors');
  });

  await T('UNI-A3. حذف نص = فك ربط فقط: تراجع بيرجّعه ولا يتكرّر، وبدون تراجع المصدر يظهر تحت «غير مصنّف»؛ حذف رابط حقيقي بتراجع', async () => {
    const { p, ids } = mig; const sid = await W(p, () => Object.keys(ST.sessions)[0]); ok(sid, 'text source exists');
    await p.click('.ls-row-item [data-act="menu"]'); await p.click('.ls-ctx-item:has-text("إزالة من الدرس")'); await p.waitForSelector('.wu-toast button'); eq((await resources(p)).length, 0, 'unlinked'); await p.click('.wu-toast button:has-text("تراجع")'); await sleep(900);
    eq((await resources(p)).length, 1, 'undo restores'); await sleep(8200); eq((await resources(p)).map(r => r.type + ':' + r.lessonId), ['text:' + ids.l2], 'no duplicate adoption after undo');
    await p.click('.ls-row-item [data-act="menu"]'); await p.click('.ls-ctx-item:has-text("إزالة من الدرس")'); await sleep(8300);
    const left = await resources(p); eq(left.length, 1); const ti = await treeInfo(p); ok(ti.subjects.includes(UNC), 'orphan goes under «غير مصنّف»'); eq(ti.items.map(i => i[0] + ':' + i[1]), ['text:' + (await W(p, sid => ST.sessions[sid].subject, sid))], 'adopted by source subject');
    ok(await W(p, sid => !!ST.sessions[sid], sid), 'source text itself never deleted');
    const lid = await W(p, async ids => { const r = __WIRD_STUDY_APP__.repo, L = __WIRD_STUDY_APP__.tree.lessons.find(l => l.id === ids.l); await r.putResourceRaw({ id: 'res_lnk', lessonId: L.id, subjectId: L.subjectId, type: 'link', title: 'مرجع', order: 0, status: 'todo', completedAt: null, createdAt: 1, updatedAt: 1, rev: 1, deletedAt: null, deleteBatch: null, link: { url: 'https://example.com/x' } }); await WirdResources.reloadCache(); __WIRD_STUDY_APP__.sidebar.render(); return L.id }, ids); await sleep(500);
    await p.click('.ls-row-item:has-text("مرجع") [data-act="menu"]'); await p.click('.ls-ctx-item:has-text("حذف")'); await sleep(400); ok(!(await resources(p)).some(r => r.id === 'res_lnk'), 'link truly deleted');
    await p.click('.wu-toast button:has-text("تراجع")'); await sleep(600); ok((await resources(p)).some(r => r.id === 'res_lnk'), 'link restored by undo'); eq(p.__errs, [], 'no errors');
  });

  await T('UNI-A4. نوت من السياق + رفع كتاب من السياق بيتربط بالدرس (مش «غير مصنّف») + لوحة رفع PDF فوق مساحة العمل', async () => {
    const { p, ids } = mig;
    await p.click(`.ls-row[data-id="${ids.l}"] [data-act="menu"]`); await p.click('.ls-ctx-item:has-text("＋ نوت")'); await sleep(900);
    ok((await resources(p)).some(r => r.type === 'notebook' && r.lessonId === ids.l), 'notebook item created under the lesson'); eq(await W(p, () => __WIRD_STUDY_APP__.route.id), ids.l);
    await expandAll(p); await sleep(300);   // فتح درس بيقفل الدرج على الموبايل (مقصود) ⇒ نفتحه تاني
    await p.click(`.ls-row[data-id="${ids.l}"] [data-act="menu"]`); await p.click('.ls-ctx-item:has-text("＋ كتاب")'); await p.waitForSelector('#wrt-book'); await sleep(400);
    await p.click('[data-wu="upload"]'); await p.waitForSelector('#addBookOverlay.open');
    const z = await W(p, () => ({ o: +getComputedStyle(document.getElementById('addBookOverlay')).zIndex, w: +getComputedStyle(document.querySelector('.ls-ws')).zIndex })); ok(z.o > z.w, 'upload panel above the workspace ' + JSON.stringify(z));
    await W(p, async () => { const iso = todayISO(), b = { id: 'b_ctx', title: 'كتاب من السياق', reason: '', dailyTarget: 5, totalPages: 90, currentPage: 1, addedDate: iso, todayDate: iso, todayStartPage: 1, streak: 0 }; await dbPut('books', b); booksState.list.unshift(b); globalThis.__wirdDirty() });   // نفس اللي بيعمله معالج «إضافة كتاب» بعد نجاح الـPDF
    let b; for (let i = 0; i < 40 && !b; i++) { await sleep(200); b = (await resources(p)).find(r => r.type === 'book') }
    ok(b, 'book item created from the legacy add-book handler hook'); eq(b.lessonId, ids.l, 'new book attached to the context lesson');
    eq(p.__errs, [], 'no errors'); await mig.ctx.close();
  });

  await T('UNI-A5. كورس جديد من السياق: ⋯ على الدرس ← ＋ كورس ← إنشاء ← رجوع ⇒ عنصر 🎓 تحت الدرس نفسه؛ فتحه من الكارت ثم Esc بيقفل اللوحة', async () => {
    const ctx = await newCtx(); current = INDEX; const p = await open(ctx);
    const ids = await W(p, async () => { const a = __WIRD_STUDY_APP__; await a.init(); const r = a.repo, s = await r.createSubject('كيمياء'), u = await r.createUnit(s.id, 'التفاعلات'), l = await r.createLesson({ subjectId: s.id, unitId: u.id, title: 'الأحماض والقواعد' }); await a.reloadTree(); return { l: l.id } });
    await openWs(p); await sleep(900); await expandAll(p); await sleep(300);
    await p.click(`.ls-row[data-id="${ids.l}"] [data-act="menu"]`); await p.click('.ls-ctx-item:has-text("＋ كورس")'); await p.waitForSelector('[data-wu="newcourse"]'); await p.click('[data-wu="newcourse"]');
    await p.waitForSelector('.wu-host:not([hidden])'); await p.waitForSelector('#cfT'); await p.fill('#cfT', 'كورس الكيمياء العضوية'); await p.click('#cfOk'); await sleep(500);
    ok(await p.locator('.wu-host:not([hidden])').count() === 1, 'course screen shown inside the panel'); await p.click('.wu-back'); await sleep(900);
    const res = await resources(p); eq(res.map(r => [r.type, r.lessonId]), [['course', ids.l]], 'attached to the lesson it was created from');
    eq((await treeInfo(p)).subjects, ['كيمياء'], 'no «غير مصنّف»'); eq(await p.locator('.wu-host:not([hidden])').count(), 0, 'panel closed');
    await W(p, () => { const a = __WIRD_STUDY_APP__; a.root.classList.add('side-open') }); await expandAll(p); await sleep(300); eq(await p.locator('.ls-row-item .ls-row-icon').first().innerText(), '🎓');
    await W(p, id => __wirdOpen(id), res[0].id); await p.waitForSelector('.wr-card [data-wu="open"]'); await p.click('.wr-card [data-wu="open"]'); await p.waitForSelector('.wu-host:not([hidden])');
    eq(await W(p, () => document.activeElement.className.includes('wu-back')), true, 'focus moves into the panel'); await p.keyboard.press('Escape'); await sleep(400); eq(await p.locator('.wu-host:not([hidden])').count(), 0, 'Esc closes the panel');
    eq(await W(p, () => WirdCourses.C.courses.length), 1, 'no duplicate course'); eq(p.__errs, [], 'no errors'); await ctx.close();
  });

  await T('UNI-C3. «مناهجي الدراسية» (خطط الكتب) لسه متاحة من «منهجي»: الزر بيفتح الشاشة الأصلية فوق مساحة العمل، وبانر «مهام مناهجك اليوم» بيظهر وبيفضل بعد إعادة رسم الرئيسية، وبياناتها ما اتمسّتش', async () => {
    const ctx = await newCtx(); current = INDEX; const p = await open(ctx);
    const raw = await W(p, async () => { const iso = todayISO(), b = { id: 'bk1', title: 'كتاب الفقه', reason: '', dailyTarget: 5, totalPages: 200, currentPage: 20, addedDate: iso, todayDate: iso, todayStartPage: 20, streak: 0 }; await dbPut('books', b); booksState.list.push(b);
      const d = new Date(Date.now() + 30 * 864e5), dl = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
      CU.list.push({ id: 'cur1', name: 'منهج الفقه', deadline: dl, books: [{ bookId: 'bk1', days: [0, 1, 2, 3, 4, 5, 6] }], milestones: [] }); cuSave(); return localStorage.getItem('wird_curricula_v1') });
    await openWs(p); await p.waitForSelector('.wu-sheet', { timeout: 8000 }); await p.click('.wu-act .ls-btn-primary');   // الكتاب القديم اتربط ⇒ تقرير الترحيل بيظهر مرة
    await W(p, () => __WIRD_STUDY_APP__.go({ kind: 'home' })); await sleep(500);
    ok(/مهام مناهجك اليوم/.test(await p.locator('.ls-home .wu-cu').innerText()), 'today\'s curricula banner shown on the home screen'); ok(/كتاب الفقه/.test(await p.locator('.ls-home .wu-cu').innerText()));
    await W(p, () => __WIRD_STUDY_APP__.go({ kind: 'home' })); await sleep(300); await W(p, async () => { const a = __WIRD_STUDY_APP__, s = await a.repo.createSubject('م'); await a.reloadTree(); a.go({ kind: 'home' }) }); await sleep(500);
    ok(/مهام مناهجك اليوم/.test(await p.locator('.ls-home .wu-cu').innerText()), 'banner survives home re-render'); eq(await p.locator('.ls-home .wu-cu').count(), 1, 'single mount');
    await p.click('.ls-home [data-wu="curricula"]'); await p.waitForSelector('.book-reader-overlay.open'); eq(await p.locator('.book-reader-overlay.open .book-reader-title').innerText(), 'مناهجي الدراسية');
    const top = await W(p, () => { const o = document.querySelector('.book-reader-overlay.open'), r = o.getBoundingClientRect(), e = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2); return !!(e && o.contains(e)) }); ok(top, 'curricula screen is above the workspace');
    await p.click('#cuX'); await sleep(300); eq(await W(p, () => localStorage.getItem('wird_curricula_v1')), raw, 'curricula data untouched'); eq(p.__errs, [], 'no errors'); await ctx.close();
  });

  await T('UNI-A6. حذف كتاب نهائيًا من العنصر (كان على شاشة «مكتبتي» المشالة): تأكيد ثم حذف الكتاب وملفه من التخزين؛ و«إزالة من الدرس» لا تلمس الكتاب', async () => {
    const ctx = await newCtx(); current = INDEX; const p = await open(ctx);
    const ids = await W(p, async () => { const a = __WIRD_STUDY_APP__; await a.init(); const r = a.repo, s = await r.createSubject('كتب'), u = await r.createUnit(s.id, 'و'), l = await r.createLesson({ subjectId: s.id, unitId: u.id, title: 'درس الكتاب' });
      const iso = todayISO(), b = { id: 'bk_del', title: 'كتاب للحذف', reason: '', dailyTarget: 5, totalPages: 50, currentPage: 3, addedDate: iso, todayDate: iso, todayStartPage: 1, streak: 0 }; await dbPut('books', b); await dbPut('files', { id: 'bk_del', blob: new Blob(['pdf']) }); booksState.list.push(b);
      await r.putResourceRaw({ id: 'res_bk', lessonId: l.id, subjectId: s.id, type: 'book', title: '', order: 0, status: 'todo', completedAt: null, createdAt: 1, updatedAt: 1, rev: 1, deletedAt: null, deleteBatch: null, book: { bookId: 'bk_del' } }); await a.reloadTree(); await WirdResources.reloadCache(); return { l: l.id } });
    await openWs(p); await sleep(700); const rep = p.locator('.wu-sheet'); if (await rep.count()) await p.click('.wu-act .ls-btn-primary'); await expandAll(p); await sleep(300);
    await p.click('.ls-row-item [data-act="menu"]'); const labels = (await p.locator('.ls-ctx-item').allInnerTexts()).map(x => x.replace(/^\S+\s*/, '').trim()).filter(Boolean); eq(labels, ['فتح', 'إعادة تسمية', 'نقل لدرس تاني', 'إعدادات', 'إزالة من الدرس', 'حذف الكتاب نهائيًا'], 'book item menu');
    await p.click('.ls-ctx-item:has-text("حذف الكتاب نهائيًا")'); await p.waitForSelector('#confirmOverlay.open'); await p.click('#confirmCancelBtn'); await sleep(300);
    eq(await W(p, async () => (await dbGetAll('books')).length), 1, 'cancel keeps the book');
    await p.click('.ls-row-item [data-act="menu"]'); await p.click('.ls-ctx-item:has-text("حذف الكتاب نهائيًا")'); await p.waitForSelector('#confirmOverlay.open'); await p.click('#confirmOkBtn'); await sleep(900);
    eq(await W(p, async () => ({ books: (await dbGetAll('books')).length, files: (await dbGetAll('files')).length, mem: booksState.list.length })), { books: 0, files: 0, mem: 0 }, 'book + its file deleted');
    eq((await resources(p)).length, 0, 'item removed with it'); eq(p.__errs, [], 'no errors'); await ctx.close();
  });

  const seedLinks = (p, n) => W(p, async n => { const a = __WIRD_STUDY_APP__; await a.init(); const r = a.repo, s = await r.createSubject('أحياء'), u = await r.createUnit(s.id, 'الخلية'), L = [];
    for (let i = 0; i < n; i++) { const l = await r.createLesson({ subjectId: s.id, unitId: u.id, title: 'درس ' + (i + 1) }); L.push(l.id);
      await r.putResourceRaw({ id: 'res_l' + i, lessonId: l.id, subjectId: s.id, type: 'link', title: 'رابط ' + (i + 1), order: 0, status: 'todo', completedAt: null, createdAt: 1, updatedAt: 1, rev: 1, deletedAt: null, deleteBatch: null, link: { url: 'https://example.com/' + i } }) }
    await a.reloadTree(); await WirdResources.reloadCache(); return { s: s.id, u: u.id, L } }, n);

  await T('UNI-K1. كيبورد وقارئ الشاشة: ⋯ الكارت ← قائمة تاخد الفوكس + أسهم/Home/End + Esc يرجّع الفوكس؛ نافذة الاسم محبوسة الفوكس وEsc يرجّعه؛ صفوف الشجرة aria-level ١..٤', async () => {
    const ctx = await newCtx(); current = INDEX; const p = await open(ctx); const ids = await seedLinks(p, 1);
    await openWs(p); await sleep(700); await W(p, id => __WIRD_STUDY_APP__.go({ kind: 'lesson', id }), ids.L[0]); await sleep(500); await p.click('#wrt-link'); await p.waitForSelector('.wr-card .wu-more');
    const more = p.locator('.wr-card .wu-more'); await more.focus(); await p.keyboard.press('Enter'); await p.waitForSelector('.wu-menu');
    const act = () => W(p, () => { const e = document.activeElement; return e && e.getAttribute('role') === 'menuitem' ? e.textContent.trim().replace(/^\S+\s+/, '') : (e && (e.id || e.tagName + '.' + e.className)) });
    eq(await act(), 'فتح', 'menu takes focus on its first item'); await p.keyboard.press('ArrowDown'); eq(await act(), 'إعادة تسمية'); await p.keyboard.press('ArrowUp'); eq(await act(), 'فتح'); await p.keyboard.press('ArrowUp'); eq(await act(), 'حذف', 'wraps around'); await p.keyboard.press('Home'); eq(await act(), 'فتح'); await p.keyboard.press('End'); eq(await act(), 'حذف');
    await p.keyboard.press('Escape'); eq(await p.locator('.wu-menu').count(), 0, 'Esc closes the menu'); eq(await W(p, () => document.activeElement.className.includes('wu-more')), true, 'focus returns to the ⋯ button');
    await p.keyboard.press('Enter'); await p.waitForSelector('.wu-menu'); await p.keyboard.press('ArrowDown'); await p.keyboard.press('Enter'); await p.waitForSelector('.wu-sheet');
    eq(await W(p, () => document.activeElement.id), 'wuNm', 'dialog focuses its field');
    for (let i = 0; i < 9; i++) { await p.keyboard.press('Tab'); ok(await W(p, () => !!document.activeElement.closest('.wu-sheet')), 'Tab stays inside the dialog (' + i + ')') }
    for (let i = 0; i < 9; i++) { await p.keyboard.press('Shift+Tab'); ok(await W(p, () => !!document.activeElement.closest('.wu-sheet')), 'Shift+Tab stays inside the dialog (' + i + ')') }
    eq(await p.locator('.wu-sheet').getAttribute('role'), 'dialog'); eq(await p.locator('.wu-sheet').getAttribute('aria-modal'), 'true');
    await p.keyboard.press('Escape'); eq(await p.locator('.wu-sheet').count(), 0); eq(await W(p, () => document.activeElement.className.includes('wu-more')), true, 'focus returns to the ⋯ button after the dialog');
    await W(p, () => __WIRD_STUDY_APP__.go({ kind: 'home' })); await sleep(400); await expandAll(p); await sleep(300);
    await p.click('.ls-row-item'); await sleep(800);   // لمسة واحدة على صف العنصر (الدرج مفتوح) ⇒ يفتح درسه على تبويب نوعه
    eq(await W(p, () => __WIRD_STUDY_APP__.route.id), ids.L[0], 'one tap on an item row opens its lesson'); eq(await p.locator('#wrt-link').getAttribute('aria-selected'), 'true', 'on the item type tab');
    await expandAll(p); await sleep(300);
    const lv = await W(p, () => [...document.querySelectorAll('.ls-tree .ls-row')].map(r => [r.dataset.kind, r.getAttribute('aria-level'), r.getAttribute('role')]));
    eq([...new Set(lv.map(x => x.join(':')))].sort(), ['item:4:treeitem', 'lesson:3:treeitem', 'subject:1:treeitem', 'unit:2:treeitem'], 'tree levels 1..4'); eq(p.__errs, [], 'no errors'); await ctx.close();
  });

  await T('UNI-P1. حالة الواجهة بتفضل بعد إعادة التحميل: التوسيع + مكان تمرير الشريط الجانبي، وآخر عنصر اتفتح (والشريط بيكشفه)', async () => {
    const ctx = await newCtx(); current = INDEX; const p = await open(ctx); const ids = await seedLinks(p, 40);
    await openWs(p); await sleep(900); await expandAll(p); await sleep(300);
    await W(p, () => { __WIRD_STUDY_APP__.sidebar.scroller.scrollTop = 900 }); await sleep(600);
    eq(await W(p, () => ({ s: +localStorage.getItem('wird_wu_scroll'), l: localStorage.getItem('wird_wu_last') })), { s: 900, l: null }, 'scroll persisted, no item yet');
    await p.reload(); await sleep(600); await openWs(p); await sleep(1800);
    const st1 = await W(p, ids => { const a = __WIRD_STUDY_APP__; return { sub: a.sidebar.expanded(ids.s), unit: a.sidebar.expanded(ids.u), top: a.sidebar.scroller.scrollTop, route: a.route.kind } }, ids);
    if (process.env.DEBUG) console.log('P1 after reload (scroll only):', JSON.stringify(st1));
    eq([st1.sub, st1.unit], [true, true], 'expanded state survives reload'); ok(Math.abs(st1.top - 900) <= 60, 'sidebar scroll restored (' + st1.top + ')');
    const target = ids.L[25]; await W(p, () => __wirdOpen('res_l25')); await sleep(900);
    const live = await W(p, () => ({ s: +localStorage.getItem('wird_wu_scroll'), top: __WIRD_STUDY_APP__.sidebar.scroller.scrollTop, l: JSON.parse(localStorage.getItem('wird_wu_last')) }));
    eq(live.l, { lessonId: target, resId: 'res_l25' }, 'last item persisted'); ok(Math.abs(live.s - live.top) <= 2, 'persisted scroll follows the real scroll (' + live.s + ' vs ' + live.top + ')');
    await p.reload(); await sleep(600); await openWs(p); await sleep(2200);
    eq(await W(p, () => __WIRD_STUDY_APP__.route.id), target, 'last opened item reopened (its lesson)'); eq(await p.locator('#wrt-link').getAttribute('aria-selected'), 'true', "on the item's own tab");
    await W(p, () => __WIRD_STUDY_APP__.root.classList.add('side-open')); await sleep(400);
    const vis = await W(p, () => { const r = document.querySelector('.ls-row-item[data-id="res_l25"]'); if (!r) return null; const b = r.getBoundingClientRect(), c = __WIRD_STUDY_APP__.sidebar.scroller.getBoundingClientRect(); return b.top >= c.top - 1 && b.bottom <= c.bottom + 1 });
    eq(vis, true, 'the reopened item is visible in the sidebar'); eq(p.__errs, [], 'no errors'); await ctx.close();
  });

  await T('UNI-L1. مفيش مستمعين مكرّرة: فتح/إغلاق مساحة العمل ٧ مرات ما بيزوّدش مستمعي document/window/body ولا مراقبات', async () => {
    const ctx = await newCtx(); current = INDEX; const p = await ctx.newPage(); p.__errs = []; p.on('pageerror', e => p.__errs.push(String(e)));
    await p.route(/^https?:\/\/(?!127\.0\.0\.1)/, r => r.abort()); p.setDefaultTimeout(8000);
    await p.addInitScript(() => { const ad = EventTarget.prototype.addEventListener, rm = EventTarget.prototype.removeEventListener; window.__L = new Map(); window.__MO = 0;
      const key = (t, ty) => (t === document ? 'document' : t === window ? 'window' : t === document.body ? 'body' : null) && ((t === document ? 'document' : t === window ? 'window' : 'body') + ':' + ty);
      EventTarget.prototype.addEventListener = function (ty, fn, o) { const k = key(this, ty); if (k) __L.set(k, (__L.get(k) || 0) + 1); return ad.call(this, ty, fn, o) };
      EventTarget.prototype.removeEventListener = function (ty, fn, o) { const k = key(this, ty); if (k) __L.set(k, (__L.get(k) || 0) - 1); return rm.call(this, ty, fn, o) };
      const MO = window.MutationObserver; window.MutationObserver = class extends MO { constructor(f) { super(f); __MO++ } } });
    await p.goto(BASE + '/index.html'); await sleep(500);
    const snap = () => W(p, () => ({ L: Object.fromEntries([...__L].filter(([, v]) => v).sort()), MO: __MO }));
    const cycle = async () => { await p.click('.tab[data-view="view-lessons"]'); await p.waitForFunction(() => window.__WIRD_STUDY_APP__ && __WIRD_STUDY_APP__.isOpen, null, { timeout: 15000 }); await sleep(900); await p.click('.ls-exit'); await sleep(300); await p.click('.tab[data-view="view-habits"]'); await sleep(150) };
    await cycle(); await cycle(); const s2 = await snap(); for (let i = 0; i < 5; i++) await cycle(); const s7 = await snap();
    eq(s7, s2, 'listener/observer counts identical after 5 more open/close cycles'); eq(p.__errs, [], 'no errors'); await ctx.close();
  });

  await browser.close(); server.close();
  let pass = 0; for (const [n, okk, m] of results) { console.log((okk ? '✔ ' : '✘ ') + n + (okk ? '' : '\n      → ' + m)); if (okk) pass++ }
  console.log('\n' + pass + '/' + results.length + ' passed'); process.exit(pass === results.length ? 0 : 1);
})().catch(e => { console.error(e); process.exit(2) });
