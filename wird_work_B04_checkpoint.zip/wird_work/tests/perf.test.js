// فحص أداء الشجرة الموحّدة على بيانات كبيرة (≈٢١٠٠ عنصر / ٣٦٠ درس / ٢٠٠ كتاب). بيطبع أرقام وبيفشل بس لو الأرقام خرجت عن ميزانية واسعة.
// التشغيل:  NODE_PATH=$(npm root -g) node tests/perf.test.js [مسار index.html]
const { chromium } = require('playwright');
const path = require('path');
const INDEX = path.resolve(process.argv[2] || path.join(__dirname, '..', 'index.html'));
const SUBJ = 6, UNITS = 5, LESS = 12, PER = 6, BOOKS = 200;      // 6×5×12 = 360 درس × 6 عناصر = 2160
const BUDGET = { rowsInDom: 80, renderMs: 250, scrollStepMs: 60, searchMs: 120, openMs: 800 };   // ميزانية واسعة (مع تقليل ٤× للمعالج)
const sleep = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  const browser = await chromium.launch({ args: ['--no-sandbox'] }), out = [], fails = [];
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, locale: 'ar-EG', timezoneId: 'Africa/Cairo', serviceWorkers: 'block' });
  const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(String(e))); p.on('console', m => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push(m.text()) });
  await p.route(/^https?:\/\//, r => r.abort());
  await p.addInitScript(() => { localStorage.setItem('wird_mig_v3', JSON.stringify({ v: 3, ts: 1, reported: true, created: { subject: null, units: [], lessons: [], items: [] } })); });
  await p.goto('file://' + INDEX); await sleep(600);
  const t0 = Date.now();
  const made = await p.evaluate(async ([S, U, L, PER, BOOKS]) => {
    const a = __WIRD_STUDY_APP__; await a.init(); const r = a.repo, lessons = [];
    for (let i = 0; i < S; i++) { const s = await r.createSubject('مادة ' + (i + 1)); for (let j = 0; j < U; j++) { const u = await r.createUnit(s.id, 'وحدة ' + (j + 1)); for (let k = 0; k < L; k++) lessons.push(await r.createLesson({ subjectId: s.id, unitId: u.id, title: `درس ${i + 1}.${j + 1}.${k + 1}` })) } }
    const iso = todayISO(), books = []; for (let b = 0; b < BOOKS; b++) books.push({ id: 'bk' + b, title: 'كتاب ' + b, reason: '', dailyTarget: 5, totalPages: 100, currentPage: 1 + (b % 90), addedDate: iso, todayDate: iso, todayStartPage: 1, streak: 0 });
    for (const b of books) await dbPut('books', b); booksState.list.push(...books);
    const recs = []; let n = 0;
    for (const l of lessons) { const mk = (type, extra) => ({ id: 'res_' + (n++), lessonId: l.id, subjectId: l.subjectId, type, title: type + ' ' + n, order: n, status: n % 5 ? 'todo' : 'done', completedAt: null, createdAt: n, updatedAt: n, rev: 1, deletedAt: null, deleteBatch: null, ...extra });
      recs.push(mk('link', { link: { url: 'https://example.com/' + n } }), mk('video', { video: { youtubeVideoId: 'dQw4w9WgXcQ', metadataStatus: 'manual' } }), mk('book', { book: { bookId: 'bk' + (n % BOOKS) } }), mk('course', { course: { courseId: 'missing' + n } }), mk('text', { text: { sessionId: 'nos' + n, subject: 's' } }), mk('notebook', { notebook: { key: 'L' + l.id } })) }
    const db = await new Promise((res, rej) => { const q = indexedDB.open('wird_study_db'); q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error) });
    await new Promise((res, rej) => { const tx = db.transaction('resources', 'readwrite'), st = tx.objectStore('resources'); recs.forEach(x => st.put(x)); tx.oncomplete = res; tx.onerror = () => rej(tx.error) }); db.close();
    await a.reloadTree(); await WirdResources.reloadCache(); return { lessons: lessons.length, items: recs.length } }, [SUBJ, UNITS, LESS, PER, BOOKS]);
  out.push(`seeded ${made.lessons} lessons / ${made.items} items / ${BOOKS} books in ${((Date.now() - t0) / 1000).toFixed(1)}s`);
  await p.click('.tab[data-view="view-lessons"]'); await p.waitForFunction(() => window.__WIRD_STUDY_APP__ && __WIRD_STUDY_APP__.isOpen, null, { timeout: 20000 }); await sleep(800);
  await p.evaluate(() => { const a = __WIRD_STUDY_APP__; a.tree.subjects.forEach(s => a.sidebar.setExpanded(s.id, true)); a.tree.units.forEach(u => a.sidebar.setExpanded(u.id, true)); a.sidebar.render(); a.root.classList.add('side-open') }); await sleep(500);
  const cdp = await ctx.newCDPSession(p);
  for (const rate of [1, 4]) {
    await cdp.send('Emulation.setCPUThrottlingRate', { rate });
    const m = await p.evaluate(async () => {
      const a = __WIRD_STUDY_APP__, sc = a.sidebar.scroller, raf = () => new Promise(r => requestAnimationFrame(() => r())), T = () => performance.now(), res = {};
      res.totalRows = a.sidebar.computeRows ? a.sidebar.computeRows().length : null;
      let t = T(); for (let i = 0; i < 5; i++) a.sidebar.render(); res.renderMs = (T() - t) / 5; await raf();
      res.rowsInDom = document.querySelectorAll('.ls-tree .ls-row').length; res.domNodes = document.getElementsByTagName('*').length; res.treeHeightPx = Math.round(sc.scrollHeight);
      t = T(); const steps = 40; for (let i = 0; i < steps; i++) { sc.scrollTop = (i + 1) * (sc.scrollHeight - sc.clientHeight) / steps; await raf() } res.scrollStepMs = (T() - t) / steps;
      t = T(); let hits = 0; for (let i = 0; i < 20; i++) hits = __wirdSearch('link 1').length; res.searchMs = (T() - t) / 20; res.searchHits = hits;
      t = T(); let hb = 0; for (let i = 0; i < 20; i++) hb = __wirdSearch('كتاب 1').length; res.searchBookNamesMs = (T() - t) / 20; res.searchBookHits = hb; res.searchMiss = (() => { const x = T(); __wirdSearch('zzzz'); return T() - x })();
      t = T(); await WirdResources.reloadCache(); a.sidebar.render(); res.reloadCacheMs = T() - t;
      t = T(); await __wirdOpen('res_1000'); await raf(); await raf(); res.openMs = T() - t; res.openedTab = (document.querySelector('#wrTabs [aria-selected="true"]') || {}).id;
      if (performance.memory) res.heapMB = Math.round(performance.memory.usedJSHeapSize / 1048576);
      return res });
    out.push(`CPU×${rate}: ` + JSON.stringify(m));
    const g = (k, v, lim) => { if (!(v <= lim)) fails.push(`CPU×${rate} ${k}=${typeof v === 'number' ? v.toFixed(1) : v} > ${lim}`) };
    g('rowsInDom', m.rowsInDom, BUDGET.rowsInDom); g('renderMs', m.renderMs, BUDGET.renderMs); g('scrollStepMs', m.scrollStepMs, BUDGET.scrollStepMs); g('searchMs', m.searchMs, BUDGET.searchMs); g('searchBookNamesMs', m.searchBookNamesMs, BUDGET.searchMs); if (!m.searchHits || !m.searchBookHits) fails.push('search returned no hits (test data/term problem)'); g('openMs', m.openMs, BUDGET.openMs);
    if (m.openedTab !== 'wrt-link' && m.openedTab !== 'wrt-video' && m.openedTab !== 'wrt-book' && m.openedTab !== 'wrt-course' && m.openedTab !== 'wrt-text') fails.push('item did not open on its own tab: ' + m.openedTab);
  }
  await cdp.send('Emulation.setCPUThrottlingRate', { rate: 1 });
  if (errs.length) fails.push('errors: ' + errs.slice(0, 3).join(' | '));
  console.log(out.join('\n')); console.log(fails.length ? '✘ over budget:\n  ' + fails.join('\n  ') : '✔ within budget (' + JSON.stringify(BUDGET) + ')');
  await browser.close(); process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2) });
