/* tests/tasks.planning.test.js — B3 / TASK 1.2: planning UI & entry points.
   Real Chromium (Playwright), file:// pages, network aborted, service workers blocked, locale ar-EG, Africa/Cairo,
   FIXED clock (2026-11-06 10:00 +02:00) so that a pristine page and the injected page can be compared byte for byte.
   Reads the project, never modifies it. Screenshots go to WIRD_SHOTS_DIR (default docs/test-logs/B03/screens).
   Optional: WIRD_ORIGINAL_INDEX=<path of the very first index.html> proves the pristine copy equals the original. */
'use strict';
const fs = require('fs'), path = require('path'), os = require('os'), crypto = require('crypto');
const ROOT = path.resolve(__dirname, '..');
const SHOTS = process.env.WIRD_SHOTS_DIR || path.join(ROOT, 'docs', 'test-logs', 'B03', 'screens');
const ANCHOR = '<script id="wird-offline">';
const T0 = new Date('2026-11-06T10:00:00+02:00'), TODAY = '2026-11-06', TOMORROW = '2026-11-07', YESTERDAY = '2026-11-05', LATER = '2026-11-20';
const sleep = ms => new Promise(r => setTimeout(r, ms));
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'wird-planning-'));
process.on('exit', () => { try { fs.rmSync(TMP, { recursive: true, force: true }); } catch (e) { /* ignore */ } });

let passed = 0, failed = 0, assertions = 0; const failures = [];
/* watchdog: a frozen page (e.g. an observer feedback loop) must end the run as a failure, never as a hang */
setTimeout(() => { console.error('\n✘ WATCHDOG: the suite did not finish within 8 minutes (a page is probably frozen)'); process.exit(3); }, 8 * 60 * 1000).unref();
function assert(c, m) { assertions++; if (!c) throw new Error(m || 'assertion failed'); }
function eq(a, b, m) { assertions++; const x = JSON.stringify(a), y = JSON.stringify(b); if (x !== y) throw new Error((m || 'not equal') + '\n   got      ' + x.slice(0, 600) + '\n   expected ' + y.slice(0, 600)); }
async function step(name, fn) {
  const t = Date.now();
  try { await fn(); passed++; console.log('  ✔ ' + name + '  (' + (Date.now() - t) + ' ms)'); }
  catch (e) { failed++; failures.push(name); console.log('  ✘ ' + name + '\n     ' + String(e && e.message || e).split('\n').join('\n     ')); }
}

/* ------------------------------------------------------------------------------------------ project copies */
function pristineOf(text) {
  const s = text.indexOf('<style id="wird-tasks-css">'), e = text.indexOf(ANCHOR);
  if (s < 0 || e < 0 || e < s) throw new Error('cannot locate the injected region');
  return text.slice(0, s) + text.slice(e);
}
function copyProject(dest, indexText) {
  fs.cpSync(ROOT, dest, { recursive: true, filter: p => !/[\\/](node_modules|\.git)([\\/]|$)/.test(p) && !/test-logs/.test(p) });
  fs.writeFileSync(path.join(dest, 'index.html'), indexText);
}

/* ------------------------------------------------------------------------------------------------ browser */
let browser;
async function open(dir, o = {}) {
  const ctx = await browser.newContext({ viewport: o.viewport || { width: 360, height: 640 }, locale: 'ar-EG', timezoneId: 'Africa/Cairo', serviceWorkers: 'block', reducedMotion: o.reducedMotion || 'no-preference' });
  await ctx.route(/^https?:\/\//, r => r.abort());
  const page = await ctx.newPage(); page.errs = [];
  page.on('pageerror', e => page.errs.push('pageerror: ' + e));
  page.on('console', m => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) page.errs.push('console: ' + m.text()); });
  await page.clock.setFixedTime(o.time || T0);
  await page.addInitScript(() => {                                   // record every MutationObserver.observe() call
    window.__obs = []; const MO = window.MutationObserver, orig = MO.prototype.observe;
    MO.prototype.observe = function (t, opt) { window.__obs.push({ id: t && t.id || '', tag: t && t.tagName || '', o: opt ? JSON.parse(JSON.stringify(opt)) : null }); return orig.call(this, t, opt); };
  });
  if (o.seed) await page.addInitScript(s => { if (sessionStorage.getItem('__seeded')) return; sessionStorage.setItem('__seeded', '1'); Object.keys(s).forEach(k => localStorage.setItem(k, s[k])); }, o.seed);
  await page.goto('file://' + path.join(dir, 'index.html')); await sleep(o.settle || 900);
  page.ctx = ctx;
  if (o.habits !== false) await habitsTab(page);
  return page;
}
async function habitsTab(page) { await page.click('.tab[data-view="view-habits"]'); await page.waitForSelector('#habitsRoot .hb-top'); await sleep(150); }
const ls = (page, k) => page.evaluate(k => localStorage.getItem(k), k);
const habitsJson = async page => JSON.parse(await ls(page, 'wird_habits_v1'));
const E = (page, m, ...args) => page.evaluate(a => WirdTasks.getEngine()[a.m](...a.args), { m, args });
const tick = (page, n) => page.clock.setFixedTime(new Date(T0.getTime() + n * 1000));
const root = page => page.$eval('#habitsRoot', n => n.innerHTML);
async function rootNoBadge(page) { return page.$eval('#habitsRoot', n => { const c = n.cloneNode(true); c.querySelectorAll('.wt-badge').forEach(b => b.remove()); return c.innerHTML; }); }
const modalHtml = page => page.$eval('.modal-overlay.open .modal', m => { const c = m.cloneNode(true); c.querySelectorAll('[data-wt]').forEach(n => n.remove()); return c.innerHTML; });
const sheetOpen = page => page.evaluate(() => WirdTasks.ui.isOpen());
const titleOf = page => page.$eval('#wt-title', n => n.textContent);
const texts = (page, sel) => page.$$eval(sel, els => els.map(e => e.value !== undefined && e.tagName !== 'BUTTON' ? e.value : e.textContent));
async function addQuick(page, name, after) {                         // the app's own quick-task flow
  await page.click('#hFab'); await page.waitForSelector('#qn');
  await page.fill('#qn', name);
  if (after) await page.click('.wt-chip >> nth=0');
  await page.click('#hok'); await sleep(250);
}
async function oneoffId(page, name) { const H = await habitsJson(page); const l = H.oneoffs[TODAY] || []; const o = l.find(x => x.name === name); return o && o.id; }
async function closeSheet(page) { await page.click('.wt-sheet .wt-x'); await sleep(120); }
async function addSteps(page, list) { for (const s of list) { await page.fill('.wt-add-in', s); await page.keyboard.press('Enter'); await sleep(60); } }
async function shot(page, name) { try { fs.mkdirSync(SHOTS, { recursive: true }); await page.screenshot({ path: path.join(SHOTS, name + '.png') }); } catch (e) { /* screenshots are evidence, never a failure */ } }
const noErrors = (page, label) => eq(page.errs, [], (label || 'page') + ' had errors');

/* ================================================================================================== main */
(async () => {
  const idx = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
  const pristine = pristineOf(idx);
  const NEWDIR = path.join(TMP, 'new'), PRIDIR = path.join(TMP, 'pri');
  copyProject(NEWDIR, idx); copyProject(PRIDIR, pristine);
  const { chromium } = require('playwright');
  browser = await chromium.launch({ args: ['--no-sandbox'] });
  console.log('B3 planning UI test — Chromium ' + browser.version() + ', fixed clock ' + T0.toISOString());

  /* ------------------------------------------------------------------------------------------------ 0 */
  console.log('\n[0] harness');
  await step('the pristine copy is the page without the injected region (and equals the original when WIRD_ORIGINAL_INDEX is given)', async () => {
    assert(!pristine.includes('id="wird-tasks"') && !pristine.includes('wird-tasks-css'), 'pristine still has the tasks blocks');
    assert(idx.includes('WirdTasks.ui') || idx.includes('T.ui = {'), 'the injected page has the planner');
    if (process.env.WIRD_ORIGINAL_INDEX) eq(sha(Buffer.from(pristine)), sha(fs.readFileSync(process.env.WIRD_ORIGINAL_INDEX)), 'pristine != original index.html');
  });

  /* seed: habits created through the REAL wizard in the pristine page */
  let SEED;
  await step('seed realistic habits through the real wizard of the pristine page (the same state then feeds both pages)', async () => {
    const p = await open(PRIDIR);
    await p.click('.hb-top [data-v="new"]'); await p.waitForSelector('#wn');
    await p.fill('#wn', 'قراءة الورد'); await p.click('#wx'); await p.click('#wx');          // step 1 -> 2 -> (4) plain habit
    for (let i = 0; i < 6 && (await p.$('#wx')); i++) { const lbl = await p.$eval('#wx', b => b.textContent); await p.click('#wx'); await sleep(120); if (lbl.includes('حفظ')) break; }
    await sleep(250);
    await p.click('.hb-top [data-v="new"]'); await p.waitForSelector('#wn');
    await p.fill('#wn', 'مذاكرة'); await p.click('#wx'); await p.click('#wt button[data-t="qty"]'); await p.click('#wx');
    await p.fill('#wtg', '5'); await p.fill('#wu', 'صفحة');
    for (let i = 0; i < 6 && (await p.$('#wx')); i++) { const lbl = await p.$eval('#wx', b => b.textContent); await p.click('#wx'); await sleep(120); if (lbl.includes('حفظ')) break; }
    await sleep(250);
    const H = await habitsJson(p); assert(H.habits.length === 2, 'two habits expected, got ' + H.habits.length);
    await addQuick(p, 'مهمة سريعة للتجربة');
    SEED = { wird_habits_v1: await ls(p, 'wird_habits_v1') };
    assert(JSON.parse(SEED.wird_habits_v1).oneoffs[TODAY].length === 1, 'quick task seeded');
    await p.ctx.close();
  });
  await step('the harness is deterministic: the same seed renders the same #habitsRoot twice (otherwise no pristine/new comparison would mean anything)', async () => {
    const a = await open(PRIDIR, { seed: SEED }), b = await open(PRIDIR, { seed: SEED });
    eq(await root(a), await root(b), 'pristine page is not deterministic'); await a.ctx.close(); await b.ctx.close();
  });

  /* --------------------------------------------------------------------------------------------- A */
  console.log('\n[A] entry points, and the existing app stays exactly as it was');
  const P = await open(PRIDIR, { seed: SEED }), N = await open(NEWDIR, { seed: SEED });
  await step('load footprint: two element hooks, no observer, no interval-created work, no tasks key, no engine instance, habits row HTML identical to the pristine page', async () => {
    const st = await N.evaluate(() => WirdTasks.ui.status());
    eq(st, { rootHook: true, fabHook: true, observer: false, open: false, view: null });
    assert((await ls(N, 'wird_tasks_v1')) === null, 'wird_tasks_v1 must not exist before the first plan');
    eq(await N.evaluate(() => (window.__obs || []).filter(o => o.id === 'habitsRoot').length), 0, 'no observer on #habitsRoot before the first plan');
    eq(await root(N), await root(P), '#habitsRoot differs from the pristine page');
  });
  await step('every view of the habits screen is byte-identical to the pristine page when no plan exists (3 list modes, calendar, table, stats, today)', async () => {
    const views = async page => {
      const out = {};
      for (const m of ['sched', 'list', 'cat']) { await page.click('#habitsRoot [data-mode="' + m + '"]'); await sleep(80); out['mode:' + m] = await root(page); }
      for (const v of ['cal', 'table', 'stats', 'today']) { await page.click('#habitsRoot .hb-top [data-v="' + v + '"]'); await sleep(120); out['view:' + v] = await root(page); }
      return out;
    };
    const a = await views(P), b = await views(N);
    Object.keys(a).forEach(k => assert(a[k] === b[k], 'view ' + k + ' differs from the pristine page'));
  });
  await step('name tap on a quick-task row opens the sheet with «🧩 قسّمها لخطوات» and «إغلاق»; nothing is written', async () => {
    const before = await ls(N, 'wird_habits_v1');
    await N.click('.hb-task[data-id^="o_"] .hb-n'); await sleep(150);
    assert(await sheetOpen(N), 'sheet should be open');
    eq(await N.evaluate(() => WirdTasks.ui.status().view), 'row');
    eq(await texts(N, '.wt-actions .btn'), ['🧩 قسّمها لخطوات', 'إغلاق']);
    assert(/مهمة سريعة للتجربة/.test(await titleOf(N)), 'title shows the quick-task name');
    assert((await ls(N, 'wird_tasks_v1')) === null, 'opening the sheet must not create the tasks key');
    eq(await ls(N, 'wird_habits_v1'), before, 'habits data changed');
    await N.click('[data-act="close"]'); await sleep(100); assert(!(await sheetOpen(N)), 'closes');
    assert((await ls(N, 'wird_tasks_v1')) === null, 'closing without a change leaves no trace');
  });
  await step('name tap on a HABIT row still opens the app\'s own habit detail (no planner), identical to the pristine page', async () => {
    await P.click('.hb-task:not([data-id^="o_"]) .hb-n >> nth=0'); await N.click('.hb-task:not([data-id^="o_"]) .hb-n >> nth=0'); await sleep(250);
    assert(!(await sheetOpen(N)), 'planner must not open for habits');
    eq(await N.$$eval('.modal-overlay.open [data-wt]', e => e.length), 0, 'no planner nodes');
    eq(await N.$eval('.modal-overlay.open .modal', m => m.innerHTML), await P.$eval('.modal-overlay.open .modal', m => m.innerHTML), 'habit detail differs');
    await P.keyboard.press('Escape'); await N.keyboard.press('Escape'); await sleep(150);
    await P.evaluate(() => document.querySelectorAll('.modal-overlay.open').forEach(m => m.remove())); await N.evaluate(() => document.querySelectorAll('.modal-overlay.open').forEach(m => m.remove()));
  });
  await step('quick-task modal: only two chips are added (exact labels), everything else equals the pristine modal', async () => {
    await P.click('#hFab'); await N.click('#hFab'); await sleep(150);
    eq(await texts(N, '.modal-overlay.open .wt-chips button'), ['🧩 قسّمها لخطوات بعد الحفظ', '🧩 خطّة بخطوات (بدون مهمة سريعة)']);
    eq(await modalHtml(N), await P.$eval('.modal-overlay.open .modal', m => m.innerHTML), 'modal markup differs outside the chips');
    eq(await N.$$eval('.modal-overlay.open .wt-chips button', b => b.map(x => x.getAttribute('aria-pressed'))), ['false', null]);
    await P.evaluate(() => document.querySelector('.modal-overlay.open').remove()); await N.evaluate(() => document.querySelector('.modal-overlay.open').remove());
  });
  await step('creating a quick task with the chips untouched behaves exactly like the pristine page (same habits JSON), no planner', async () => {
    await tick(P, 5); await tick(N, 5);
    await addQuick(P, 'مهمة ثانية'); await addQuick(N, 'مهمة ثانية');
    eq(await habitsJson(N), await habitsJson(P), 'habits data differs from the pristine page');
    assert(!(await sheetOpen(N)), 'planner must stay closed'); assert((await ls(N, 'wird_tasks_v1')) === null, 'no tasks key');
    eq(await root(N), await root(P), 'rows differ after creation');
  });
  await step('check-off flow of a quick task is unchanged (same sheet, same result as the pristine page)', async () => {
    await P.click('.hb-task[data-id^="o_"] .hb-c >> nth=0'); await N.click('.hb-task[data-id^="o_"] .hb-c >> nth=0'); await sleep(150);
    eq(await N.$eval('.modal-overlay.open .modal', m => m.innerHTML), await P.$eval('.modal-overlay.open .modal', m => m.innerHTML), 'check-off sheet differs');
    await P.click('.tier-btn[data-t="2"]'); await N.click('.tier-btn[data-t="2"]'); await sleep(200);
    eq(await habitsJson(N), await habitsJson(P), 'habits data differs after check-off'); eq(await root(N), await root(P), 'rows differ after check-off');
  });
  await step('wizard is unchanged: step titles, the 3 chips and their labels, markup identical to the pristine page at every step', async () => {
    const run = async page => {
      const out = []; await page.click('.hb-top [data-v="new"]'); await page.waitForSelector('#wn');
      out.push(await page.$eval('.modal-overlay.open .modal', m => m.innerHTML));
      await page.fill('#wn', 'عادة اختبار'); await page.click('#wx'); out.push(await page.$eval('.modal-overlay.open .modal', m => m.innerHTML));
      out.push(await page.$$eval('#wt button', b => b.map(x => x.textContent)).then(JSON.stringify));
      await page.click('#wt button[data-t="qty"]'); await page.click('#wx'); out.push(await page.$eval('.modal-overlay.open .modal', m => m.innerHTML));
      await page.fill('#wtg', '3'); await page.click('#wx'); out.push(await page.$eval('.modal-overlay.open .modal', m => m.innerHTML));
      await page.click('#wx'); out.push(await page.$eval('.modal-overlay.open .modal', m => m.innerHTML));
      await page.evaluate(() => document.querySelectorAll('.modal-overlay.open').forEach(m => m.remove())); return out;
    };
    const a = await run(P), b = await run(N);
    a.forEach((x, i) => assert(x === b[i], 'wizard screen ' + (i + 1) + ' differs'));
    assert(/خطوة ١ من ٥/.test(b[0]) || /٥/.test(b[0]), 'five-step wizard');
    eq(JSON.parse(b[2]), ['✅ عادية (بمستويات)', '⏱ بالوقت (دقائق)', '🔢 بالكمية (عدّات/صفحات…)']);
    eq(await N.$$eval('.modal-overlay.open', e => e.length), 0);
  });
  await P.ctx.close(); await N.ctx.close();

  /* --------------------------------------------------------------------------------------------- B */
  console.log('\n[B] saving a quick task with «قسّمها لخطوات بعد الحفظ», the linked plan, and the habits data staying untouched');
  const PB = await open(PRIDIR, { seed: SEED }), NB = await open(NEWDIR, { seed: SEED });
  await tick(PB, 9); await tick(NB, 9);
  let linkedPlan;
  await step('toggle chip, save: the quick task is saved exactly like the pristine page, then the planner opens linked to it (title pre-filled), still nothing in wird_tasks_v1', async () => {
    await addQuick(PB, 'مراجعة الفيزياء'); await NB.click('#hFab'); await NB.fill('#qn', 'مراجعة الفيزياء');
    await NB.click('.wt-chip >> nth=0'); eq(await NB.$eval('.wt-chip >> nth=0', b => b.getAttribute('aria-pressed')), 'true');
    await NB.click('#hok'); await sleep(300);
    eq(await habitsJson(NB), await habitsJson(PB), 'quick task differs from the pristine page');
    assert(await sheetOpen(NB), 'planner should open'); eq(await NB.evaluate(() => WirdTasks.ui.status().view), 'task');
    eq(await NB.inputValue('.wt-title-in'), 'مراجعة الفيزياء'); assert(/مربوطة بمهمة سريعة/.test(await NB.$eval('.wt-sheet', s => s.textContent)), 'link hint');
    assert((await ls(NB, 'wird_tasks_v1')) === null, 'opening the editor must not create anything');
  });
  await step('closing the draft without any change writes nothing and leaves no badge; reopening from the row offers «قسّمها» again', async () => {
    await closeSheet(NB);
    assert((await ls(NB, 'wird_tasks_v1')) === null, 'nothing written'); eq(await NB.$$eval('.wt-badge', e => e.length), 0);
    eq(await NB.evaluate(() => WirdTasks.ui.status().observer), false, 'still no observer');
  });
  await step('adding the first step creates the plan linked to the quick task (engine oracle), persists, shows the badge; wird_habits_v1 is still byte-identical to the pristine page', async () => {
    const id = await oneoffId(NB, 'مراجعة الفيزياء');
    await NB.click('.hb-task[data-id="' + id + '"] .hb-n'); await NB.click('[data-act="split"]'); await sleep(100);
    await addSteps(NB, ['اقرأ الدرس', 'حل ٥ مسائل', 'راجع الأخطاء']);
    const tasks = await E(NB, 'listTasks', TODAY); eq(tasks.length, 1); linkedPlan = tasks[0];
    eq(tasks[0].linkedOneoffId, id); eq(tasks[0].title, 'مراجعة الفيزياء'); eq(tasks[0].steps.map(s => s.text), ['اقرأ الدرس', 'حل ٥ مسائل', 'راجع الأخطاء']);
    assert((await ls(NB, 'wird_tasks_v1')).length > 10, 'persisted');
    eq(await habitsJson(NB), await habitsJson(PB), 'wird_habits_v1 must stay identical (D8: nothing is written there)');
    eq(await NB.evaluate(() => WirdTasks.ui.status().observer), true, 'observer installed lazily after the first plan');
    eq(await NB.evaluate(() => window.__obs.filter(o => o.id === 'habitsRoot').map(o => o.o)), [{ childList: true }], 'one observer, #habitsRoot, childList only (no subtree)');
  });
  await step('badge appears ONLY on the row that has a plan; the rest of the habits screen equals the pristine page', async () => {
    await closeSheet(NB);
    eq(await NB.$$eval('.wt-badge', b => b.map(x => x.textContent)), ['🧩 ٣']);
    const id = await oneoffId(NB, 'مراجعة الفيزياء');
    eq(await NB.$$eval('.hb-task[data-id^="o_"]', rows => rows.filter(r => r.querySelector('.wt-badge')).map(r => r.getAttribute('data-id'))), [id], 'only the planned row carries a badge');
    eq(await NB.$$eval('.hb-task:not([data-id^="o_"]) .wt-badge', e => e.length), 0, 'habit rows never get a badge');
    eq(await rootNoBadge(NB), await root(PB), 'apart from the badge the rows are identical');
  });
  await step('survives hRender(): the badge is redrawn exactly once, never duplicated; reload keeps plan, badge and observer', async () => {
    await NB.evaluate(() => { for (let i = 0; i < 5; i++) hRender(); }); await sleep(150);
    eq(await NB.$$eval('.wt-badge', b => b.length), 1);
    await NB.reload(); await sleep(900); await habitsTab(NB); await sleep(200);
    eq(await NB.$$eval('.wt-badge', b => b.map(x => x.textContent)), ['🧩 ٣']);
    eq(await NB.evaluate(() => WirdTasks.ui.status().observer), true);
    eq((await E(NB, 'listTasks', TODAY))[0].steps.length, 3);
  });
  await step('tapping the named row again shows «تعديل الخطوات», the status, and the three steps in the editor (same order)', async () => {
    const id = await oneoffId(NB, 'مراجعة الفيزياء');
    await NB.click('.hb-task[data-id="' + id + '"] .hb-n'); await sleep(120);
    eq(await texts(NB, '.wt-actions .btn'), ['تعديل الخطوات', 'إغلاق']); assert(/٣ خطوات · لسه ما بدأتش/.test(await NB.$eval('.wt-sheet .desc', n => n.textContent)), 'status line');
    await NB.click('[data-act="edit"]'); await sleep(100);
    eq(await texts(NB, '.wt-step-in'), ['اقرأ الدرس', 'حل ٥ مسائل', 'راجع الأخطاء']);
    await closeSheet(NB);
  });
  await step('toggle ON but empty name: nothing is created, planner does not open, the modal stays open with both chips', async () => {
    const before = await ls(NB, 'wird_habits_v1');
    await NB.click('#hFab'); await NB.click('.wt-chip >> nth=0'); await NB.click('#hok'); await sleep(250);
    assert(!(await sheetOpen(NB)), 'planner must not open'); eq(await ls(NB, 'wird_habits_v1'), before);
    eq(await NB.$$eval('.modal-overlay.open .wt-chip', c => c.length), 2);
    await NB.evaluate(() => document.querySelector('.modal-overlay.open').remove());
  });
  await step('standalone chip: closes the quick-task modal, opens the day view with the typed name pre-filled; no quick task is created', async () => {
    const before = await ls(NB, 'wird_habits_v1');
    await NB.click('#hFab'); await NB.fill('#qn', 'خطة الأسبوع'); await NB.click('.wt-chip >> nth=1'); await sleep(200);
    eq(await NB.evaluate(() => WirdTasks.ui.status().view), 'day'); eq(await NB.inputValue('.wt-newtask'), 'خطة الأسبوع');
    eq(await NB.$$eval('#qn', e => e.length), 0, 'quick modal closed'); eq(await ls(NB, 'wird_habits_v1'), before, 'no quick task created');
    await closeSheet(NB);
  });
  await step('no page errors in section B (pageerror / console.error)', async () => noErrors(NB, 'section B'));
  await PB.ctx.close(); await NB.ctx.close();

  /* --------------------------------------------------------------------------------------------- C */
  console.log('\n[C] planning operations (engine is the oracle; every step is also checked after reload)');
  const C = await open(NEWDIR, { seed: SEED });
  let planId;
  await step('create a task for today from the day view, then add steps with Enter (focus stays in the field for the next one)', async () => {
    await C.evaluate(() => WirdTasks.ui.openPlanner({})); await sleep(100);
    eq(await C.evaluate(() => WirdTasks.ui.status().view), 'day'); eq(await texts(C, '.wt-chips button'), ['اليوم', 'غدًا', 'يوم آخر']);
    await C.fill('.wt-newtask', 'مذاكرة الأحياء'); await C.press('.wt-newtask', 'Enter'); await sleep(150);
    eq(await C.evaluate(() => WirdTasks.ui.status().view), 'task'); eq(await C.evaluate(() => document.activeElement.className.includes('wt-add-in')), true, 'focus goes to the add-step field');
    await addSteps(C, ['افتح الكتاب', 'اقرأ الفصل', 'لخّص في ٣ نقاط']);
    eq(await C.evaluate(() => document.activeElement.className.includes('wt-add-in')), true, 'focus stays in the add field');
    const t = (await E(C, 'listTasks', TODAY))[0]; planId = t.id; eq(t.steps.map(s => s.text), ['افتح الكتاب', 'اقرأ الفصل', 'لخّص في ٣ نقاط']);
    eq(t.linkedOneoffId, null);
  });
  await step('edit a step inline (blur saves), the step id stays the same; an empty edit is refused and reverted with a message', async () => {
    const before = (await E(C, 'getTask', planId)).steps[1];
    await C.fill('.wt-step[data-step] >> nth=1 >> .wt-step-in', 'اقرأ الفصل الأول بتركيز'); await C.locator('.wt-step-in').nth(1).blur(); await sleep(120);
    const after = (await E(C, 'getTask', planId)).steps[1]; eq(after.id, before.id); eq(after.text, 'اقرأ الفصل الأول بتركيز');
    await C.locator('.wt-step-in').nth(1).fill(''); await C.locator('.wt-step-in').nth(1).blur(); await sleep(120);
    eq((await E(C, 'getTask', planId)).steps[1].text, 'اقرأ الفصل الأول بتركيز', 'engine text untouched'); eq(await C.locator('.wt-step-in').nth(1).inputValue(), 'اقرأ الفصل الأول بتركيز', 'field reverted');
    assert(/نص الخطوة/.test(await C.$eval('.wt-msg', n => n.textContent)), 'message shown');
  });
  await step('autosave without blur: typing and waiting is enough (debounced), caret and text untouched', async () => {
    await C.locator('.wt-step-in').nth(2).fill('لخّص في ٤ نقاط'); await sleep(1700);
    eq((await E(C, 'getTask', planId)).steps[2].text, 'لخّص في ٤ نقاط'); eq(await C.locator('.wt-step-in').nth(2).inputValue(), 'لخّص في ٤ نقاط');
  });
  await step('insert a step BETWEEN two steps (＋ on step 1); chained inserts keep going after the new one; «تم» closes the row', async () => {
    await C.click('.wt-step >> nth=0 >> [data-act="ins"]'); await sleep(100);
    eq(await C.evaluate(() => document.activeElement.className.includes('wt-insert-in')), true);
    await C.fill('.wt-insert-in', 'ضع الجوال بعيد'); await C.keyboard.press('Enter'); await sleep(100);
    await C.fill('.wt-insert-in', 'اشرب مياه'); await C.keyboard.press('Enter'); await sleep(100);
    eq((await E(C, 'getTask', planId)).steps.map(s => s.text), ['افتح الكتاب', 'ضع الجوال بعيد', 'اشرب مياه', 'اقرأ الفصل الأول بتركيز', 'لخّص في ٤ نقاط']);
    await C.click('[data-act="insert-done"]'); eq(await C.$$eval('.wt-insert', e => e.length), 0);
  });
  await step('reorder steps with ▲/▼: engine order equals DOM order, arrows disabled at the ends, focus stays on the arrow that was pressed', async () => {
    eq(await C.$eval('.wt-step >> nth=0 >> [data-act="up"]', b => b.disabled), true); eq(await C.$eval('.wt-step >> nth=4 >> [data-act="down"]', b => b.disabled), true);
    await C.click('.wt-step >> nth=2 >> [data-act="down"]'); await sleep(80);
    eq(await C.evaluate(() => document.activeElement.getAttribute('data-act')), 'down', 'focus on ▼ again');
    await C.click('.wt-step >> nth=4 >> [data-act="up"]'); await sleep(80);
    const dom = await texts(C, '.wt-step-in'), eng = (await E(C, 'getTask', planId)).steps.map(s => s.text); eq(dom, eng);
    eq(eng, ['افتح الكتاب', 'ضع الجوال بعيد', 'اقرأ الفصل الأول بتركيز', 'لخّص في ٤ نقاط', 'اشرب مياه']);
  });
  await step('delete a step: no confirmation dialog, engine updated, order kept', async () => {
    const before = (await E(C, 'getTask', planId)).steps.map(s => s.text), victim = before[1];
    await C.click('.wt-step >> nth=1 >> [data-act="del"]'); await sleep(100);
    assert(!(await C.$eval('#confirmOverlay', n => n.classList.contains('open'))), 'no confirm for a step');
    eq((await E(C, 'getTask', planId)).steps.map(s => s.text), before.filter(x => x !== victim)); eq(await texts(C, '.wt-step-in'), before.filter(x => x !== victim));
  });
  await step('title edit saves on blur; everything persists across a reload and the editor shows it again', async () => {
    await C.fill('.wt-title-in', 'مذاكرة الأحياء — الفصل ١'); await C.locator('.wt-title-in').blur(); await sleep(120);
    eq((await E(C, 'getTask', planId)).title, 'مذاكرة الأحياء — الفصل ١'); eq(await titleOf(C), 'مذاكرة الأحياء — الفصل ١');
    const want = (await E(C, 'getTask', planId)).steps.map(s => s.text);
    await C.reload(); await sleep(900); await habitsTab(C);
    await C.evaluate(id => WirdTasks.ui.openPlanner({ taskId: id }), planId); await sleep(120);
    eq(await texts(C, '.wt-step-in'), want); eq(await C.inputValue('.wt-title-in'), 'مذاكرة الأحياء — الفصل ١');
  });
  await step('editing keeps the completion history: a completed step shows ✓, its record survives edit and delete of the step', async () => {
    const t0 = await E(C, 'getTask', planId); await E(C, 'start', planId); await E(C, 'complete', t0.steps[0].id);
    await C.evaluate(() => WirdTasks.ui.closePlanner()); await C.evaluate(id => WirdTasks.ui.openPlanner({ taskId: id }), planId); await sleep(120);
    eq(await C.$eval('.wt-step.done .wt-num', n => n.textContent), '✓');
    const recs = () => E(C, 'getCompletions', { taskId: planId });
    const r0 = await recs(); assert(r0.length >= 1, 'completion recorded'); const orig = r0[0].stepText;
    await C.fill('.wt-step-in >> nth=0', 'نص جديد للخطوة الأولى'); await C.locator('.wt-step-in').nth(0).blur(); await sleep(100);
    eq((await recs())[0].stepText, orig, 'the record keeps the text the user saw when completing');
    await C.click('.wt-step >> nth=0 >> [data-act="del"]'); await sleep(100); eq((await recs()).length, r0.length, 'record survives deleting the step');
    await C.fill('.wt-title-in', 'عنوان معدّل'); await C.locator('.wt-title-in').blur(); await sleep(100); eq((await recs()).length, r0.length);
  });
  await step('step limits are explained in Arabic (100 steps per task), not silently ignored', async () => {
    const id = await C.evaluate(() => { const e = WirdTasks.getEngine(), r = e.createTask(e.todayKey(), 'مهمة طويلة', { steps: Array.from({ length: 100 }, (_, i) => 'خطوة ' + (i + 1)) }); return r.task.id; });
    await C.evaluate(i => WirdTasks.ui.openPlanner({ taskId: i }), id); await sleep(150);
    await C.fill('.wt-add-in', 'خطوة زيادة'); await C.press('.wt-add-in', 'Enter'); await sleep(120);
    const lim = await C.$eval('.wt-msg', n => n.textContent); assert(/للحد الأقصى: ١٠٠ خطوة/.test(lim), 'limit message; the message region says: ' + JSON.stringify(lim) + ', view=' + await C.evaluate(() => WirdTasks.ui.status().view) + ', title=' + await titleOf(C)); eq((await E(C, 'getTask', id)).steps.length, 100);
    await E(C, 'deleteTask', id); await C.evaluate(() => WirdTasks.ui.closePlanner());
  });
  await step('no page errors in section C (pageerror / console.error)', async () => noErrors(C, 'section C'));
  await C.ctx.close();

  /* --------------------------------------------------------------------------------------------- D */
  console.log('\n[D] days: today, tomorrow, any future day, several tasks per day, reorder, move, overdue, delete');
  const D = await open(NEWDIR, { seed: SEED });
  let tm1, tm2, fut;
  await step('Tomorrow: two tasks are created for tomorrow and today stays empty; the day line names the date', async () => {
    await D.evaluate(() => WirdTasks.ui.openPlanner({})); await sleep(100); await D.click('.wt-chips button >> nth=1'); await sleep(80);
    assert(/غدًا — .*٧ نوفمبر/.test(await D.$eval('.wt-dayline', n => n.textContent)), 'day line: ' + await D.$eval('.wt-dayline', n => n.textContent));
    await D.fill('.wt-newtask', 'تجهيز الشنطة'); await D.press('.wt-newtask', 'Enter'); await sleep(120); await D.click('[data-act="back"]'); await sleep(100);
    await D.fill('.wt-newtask', 'مراجعة الدرس'); await D.press('.wt-newtask', 'Enter'); await sleep(120); await D.click('[data-act="back"]'); await sleep(100);
    const t = await E(D, 'listTasks', TOMORROW); eq(t.map(x => x.title), ['تجهيز الشنطة', 'مراجعة الدرس']); tm1 = t[0].id; tm2 = t[1].id;
    eq(await E(D, 'listTasks', TODAY), []);
    eq(await texts(D, '.wt-task-title'), ['تجهيز الشنطة', 'مراجعة الدرس']);
  });
  await step('any future day through the date picker; the day label and the task land on that day', async () => {
    await D.click('.wt-chips button >> nth=2'); await sleep(80); await D.fill('.wt-date', LATER); await sleep(100);
    assert(/٢٠ نوفمبر/.test(await D.$eval('.wt-dayline', n => n.textContent)), 'future day label');
    await D.fill('.wt-newtask', 'اختبار نصف الفصل'); await D.press('.wt-newtask', 'Enter'); await sleep(120);
    const t = await E(D, 'listTasks', LATER); eq(t.map(x => x.title), ['اختبار نصف الفصل']); fut = t[0].id; await D.click('[data-act="back"]'); await sleep(100);
    eq(await D.evaluate(() => WirdTasks.ui.status().view), 'day'); assert(/٢٠ نوفمبر/.test(await D.$eval('.wt-dayline', n => n.textContent)), 'still on the picked day');
  });
  await step('reorder several tasks of a day with ▲/▼ (engine order equals screen order, persists after reload)', async () => {
    await D.click('.wt-chips button >> nth=1'); await sleep(80);
    eq(await D.$eval('.wt-task >> nth=0 >> [data-act="up"]', b => b.disabled), true);
    await D.click('.wt-task >> nth=0 >> [data-act="down"]'); await sleep(100);
    eq((await E(D, 'listTasks', TOMORROW)).map(x => x.id), [tm2, tm1]); eq(await texts(D, '.wt-task-title'), ['مراجعة الدرس', 'تجهيز الشنطة']);
    await D.reload(); await sleep(900); await habitsTab(D); eq((await E(D, 'listTasks', TOMORROW)).map(x => x.id), [tm2, tm1]);
  });
  await step('move a task: Tomorrow -> a future day; the destination day is shown; moving to the same day is refused with a message', async () => {
    await D.evaluate(() => WirdTasks.ui.openPlanner({ day: '2026-11-07' })); await sleep(120);
    await D.click('.wt-task >> nth=1 >> [data-act="move"]'); await sleep(100);
    eq(await D.evaluate(() => WirdTasks.ui.status().view), 'move'); assert(/تجهيز الشنطة/.test(await D.$eval('.wt-move-name', n => n.textContent)));
    await D.click('.wt-chips button >> nth=1'); await D.click('[data-act="move-do"]'); await sleep(100);
    assert(/أصلاً في اليوم ده/.test(await D.$eval('.wt-msg', n => n.textContent)), 'same-day message'); eq((await E(D, 'getTask', tm1)).dayKey, TOMORROW);
    await D.click('.wt-chips button >> nth=2'); await D.fill('.wt-date', '2026-11-25'); await D.click('[data-act="move-do"]'); await sleep(150);
    eq((await E(D, 'getTask', tm1)).dayKey, '2026-11-25'); eq(await D.evaluate(() => WirdTasks.ui.status().view), 'day'); assert(/٢٥ نوفمبر/.test(await D.$eval('.wt-dayline', n => n.textContent)));
    eq(await texts(D, '.wt-task-title'), ['تجهيز الشنطة']);
  });
  await step('a past date is refused for a move; Esc inside the move view goes back, it does not close the sheet', async () => {
    await D.click('.wt-task >> nth=0 >> [data-act="move"]'); await sleep(80); await D.click('.wt-chips button >> nth=2'); await D.fill('.wt-date', YESTERDAY); await D.click('[data-act="move-do"]'); await sleep(80);
    assert(/النهارده أو يوم جاي/.test(await D.$eval('.wt-msg', n => n.textContent)), 'past refused'); eq((await E(D, 'getTask', tm1)).dayKey, '2026-11-25');
    await D.keyboard.press('Escape'); await sleep(80); assert(await sheetOpen(D), 'sheet still open'); eq(await D.evaluate(() => WirdTasks.ui.status().view), 'day');
  });
  await step('a finished task cannot be moved (no «نقل» button), a linked plan loses its link when moved and its badge disappears', async () => {
    const t = await E(D, 'createTask', TOMORROW, 'مهمة منتهية', { steps: ['واحدة'] }); await E(D, 'start', t.task.id); await E(D, 'complete', t.task.steps[0].id);
    await D.evaluate(() => WirdTasks.ui.openPlanner({ day: '2026-11-07' })); await sleep(120);
    const card = D.locator('.wt-task', { hasText: 'مهمة منتهية' }); eq(await card.locator('[data-act="move"]').count(), 0); assert(/خلصت/.test(await card.textContent()), 'status shows finished');
    await D.evaluate(() => WirdTasks.ui.closePlanner());
    await tick(D, 30); await addQuick(D, 'مهمة للربط'); const id = await oneoffId(D, 'مهمة للربط');
    await D.click('.hb-task[data-id="' + id + '"] .hb-n'); await D.click('[data-act="split"]'); await addSteps(D, ['أ', 'ب']); await closeSheet(D);
    eq(await D.$$eval('.wt-badge', b => b.length), 1);
    const pid = (await E(D, 'getTaskByLink', id)).id;
    await D.evaluate(i => WirdTasks.ui.openPlanner({ taskId: i }), pid); await sleep(100); await D.click('[data-act="move"]'); await sleep(80); await D.click('[data-act="move-do"]'); await sleep(150);
    eq((await E(D, 'getTask', pid)).linkedOneoffId, null, 'link cleared'); await closeSheet(D); eq(await D.$$eval('.wt-badge', b => b.length), 0, 'badge gone');
  });
  await step('overdue block: unfinished plans of earlier days are listed in Today and can be pulled to today in one tap; finished ones are not listed', async () => {
    await E(D, 'createTask', YESTERDAY, 'متأخرة غير منتهية', { steps: ['س'] });
    const f = await E(D, 'createTask', YESTERDAY, 'متأخرة منتهية', { steps: ['ص'] }); await E(D, 'start', f.task.id); await E(D, 'complete', f.task.steps[0].id);
    await D.evaluate(() => WirdTasks.ui.openPlanner({})); await sleep(120);
    eq(await D.$$eval('.wt-od .wt-task-title', e => e.map(x => x.textContent)), ['متأخرة غير منتهية']);
    await D.click('.wt-od [data-act="to-today"]'); await sleep(120);
    eq((await E(D, 'listTasks', TODAY)).map(t => t.title), ['متأخرة غير منتهية']); eq(await D.$$eval('.wt-od', e => e.length), 0);
    await D.evaluate(() => WirdTasks.ui.closePlanner());
  });
  await step('delete: the app\'s own confirm dialog (above the sheet) names the task; Cancel keeps it; OK removes it from the day, the engine and the next reload', async () => {
    await D.evaluate(() => WirdTasks.ui.openPlanner({ day: '2026-11-25' })); await sleep(120);
    await D.click('[data-act="del-task"]'); await sleep(120);
    assert(await D.$eval('#confirmOverlay', n => n.classList.contains('open')), 'confirm open'); assert(/تجهيز الشنطة/.test(await D.$eval('#confirmMessage', n => n.textContent)), 'names the task');
    const top = await D.evaluate(() => { const b = document.getElementById('confirmOkBtn').getBoundingClientRect(); const el = document.elementFromPoint(b.x + b.width / 2, b.y + b.height / 2); return !!el.closest('#confirmOverlay'); });
    assert(top, 'confirm dialog is on top of the sheet');
    await D.keyboard.press('Escape'); await sleep(60); assert(await sheetOpen(D), 'Esc does not close the sheet while the confirm is open');
    await D.click('#confirmCancelBtn'); await sleep(100); eq((await E(D, 'listTasks', '2026-11-25')).length, 1, 'cancel keeps the task');
    await D.click('[data-act="del-task"]'); await sleep(100); await D.click('#confirmOkBtn'); await sleep(150);
    eq(await E(D, 'listTasks', '2026-11-25'), []); eq(await E(D, 'getTask', tm1), null); eq(await D.$$eval('.wt-task', e => e.length), 0);
    await D.reload(); await sleep(900); await habitsTab(D); eq(await E(D, 'getTask', tm1), null, 'stays deleted after reload');
  });
  await step('no page errors in section D (pageerror / console.error)', async () => noErrors(D, 'section D'));
  await D.ctx.close();

  /* --------------------------------------------------------------------------------------------- E */
  console.log('\n[E] «ابدأ» is feature-detected; XSS; read-only data; storage discipline');
  const F = await open(NEWDIR, { seed: SEED });
  await step('without WirdTasks.exec there is no «ابدأ» anywhere; with it, it shows only for unfinished plans that have steps and calls exec.open(id,{from:"planner"})', async () => {
    const a = (await E(F, 'createTask', TODAY, 'قابلة للبدء', { steps: ['١', '٢'] })).task, b = (await E(F, 'createTask', TODAY, 'بلا خطوات')).task, c = (await E(F, 'createTask', TODAY, 'منتهية', { steps: ['x'] })).task;
    await E(F, 'start', c.id); await E(F, 'complete', c.steps[0].id);
    await F.evaluate(() => WirdTasks.ui.openPlanner({})); await sleep(120); eq(await F.$$eval('[data-act="start"]', e => e.length), 0, 'no start without exec');
    await F.evaluate(() => { WirdTasks.exec = { open: (id, o) => { window.__exec = [id, o]; } }; WirdTasks.ui.closePlanner(); WirdTasks.ui.openPlanner({}); }); await sleep(120);
    eq(await F.$$eval('.wt-task', ts => ts.map(t => [t.querySelector('.wt-task-title').textContent, !!t.querySelector('[data-act="start"]')])), [['قابلة للبدء', true], ['بلا خطوات', false], ['منتهية', false]]);
    await F.click('.wt-task >> nth=0 >> [data-act="start"]'); await sleep(100); assert(!(await sheetOpen(F)), 'planner closed before exec opens');
    eq(await F.evaluate(() => window.__exec), [a.id, { from: 'planner' }]);
    await F.evaluate(() => { delete WirdTasks.exec; });
  });
  await step('user text is only ever text: <img onerror> in a task title, a step and a quick-task name never becomes an element (planner, row sheet, confirm dialog)', async () => {
    const evil = '<img src=x onerror="window.__xss=1">';
    await F.evaluate(() => WirdTasks.ui.openPlanner({})); await F.fill('.wt-newtask', evil); await F.press('.wt-newtask', 'Enter'); await sleep(120); await addSteps(F, [evil]);
    eq(await F.$$eval('.wt-sheet img', e => e.length), 0); eq(await F.inputValue('.wt-add-in'), ''); eq(await texts(F, '.wt-step-in'), [evil]);
    await F.click('[data-act="back"]'); await sleep(80); eq(await F.$$eval('.wt-task-title', (e, ev) => e.map(x => x.textContent).includes(ev), evil), true); eq(await F.$$eval('.wt-sheet img', e => e.length), 0);
    await F.locator('.wt-task', { hasText: 'img' }).locator('[data-act="del-task"]').click(); await sleep(120);
    eq(await F.$$eval('#confirmMessage img', e => e.length), 0); await F.click('#confirmCancelBtn'); await closeSheet(F);
    await tick(F, 60); await addQuick(F, evil); await F.click('.hb-task[data-id^="o_"]:has-text("img") .hb-n'); await sleep(120);
    eq(await F.$$eval('.wt-sheet img', e => e.length), 0); eq(await titleOf(F), '🧩 ' + evil); await closeSheet(F);
    eq(await F.evaluate(() => window.__xss), undefined, 'script injection executed'); noErrors(F, 'page F');
  });
  await step('only wird_tasks_v1 is ever written by the planner (no habit data, no new keys, no IndexedDB)', async () => {
    const keys = await F.evaluate(() => Object.keys(localStorage).sort()); assert(keys.includes('wird_tasks_v1'), 'tasks key present');
    const baseline = await open(PRIDIR, { seed: SEED }); const bk = await baseline.evaluate(() => Object.keys(localStorage).sort()); await baseline.ctx.close();
    eq(keys.filter(k => !bk.includes(k)), ['wird_tasks_v1'], 'the only extra key');
    eq(await F.evaluate(async () => (await indexedDB.databases()).map(d => d.name).sort()), await (async () => { const p2 = await open(PRIDIR, { seed: SEED }); const r = await p2.evaluate(async () => (await indexedDB.databases()).map(d => d.name).sort()); await p2.ctx.close(); return r; })(), 'no new database');
  });
  await F.ctx.close();
  await step('data written by a NEWER app version is read-only: banner shown, edits refused, the stored bytes never change', async () => {
    const fut2 = JSON.stringify({ schemaVersion: 99, tasks: { x: 1 }, days: {}, events: [], note: 'from the future' });
    const R = await open(NEWDIR, { seed: Object.assign({}, SEED, { wird_tasks_v1: fut2 }) });
    await R.evaluate(() => WirdTasks.ui.openPlanner({})); await sleep(150);
    assert(/نسخة أحدث/.test(await R.$eval('.wt-sheet', s => s.textContent)), 'read-only banner'); eq(await R.$eval('.wt-sheet', s => s.getAttribute('data-ro')), '1');
    await R.fill('.wt-newtask', 'x', { force: true }); await R.evaluate(() => document.querySelector('.wt-add-btn').click()); await sleep(120);
    assert(/نسخة أحدث/.test(await R.$eval('.wt-msg', n => n.textContent)), 'edit refused with the reason'); eq(await ls(R, 'wird_tasks_v1'), fut2, 'bytes unchanged'); noErrors(R, 'read-only page'); await R.ctx.close();
  });

  /* --------------------------------------------------------------------------------------------- F */
  console.log('\n[F] robustness: fault injection and observer discipline');
  await step('FAULT: the planner code throws while the quick-task modal opens -> modal still works, task is created exactly like the pristine page', async () => {
    const A = await open(PRIDIR, { seed: SEED }), B = await open(NEWDIR, { seed: SEED }); await tick(A, 3); await tick(B, 3);
    await B.evaluate(() => { WirdKit.h = () => { throw new Error('boom'); }; });
    await addQuick(A, 'بعد العطل'); await B.click('#hFab'); await sleep(100);
    eq(await B.$$eval('.modal-overlay.open .wt-chip', e => e.length), 0, 'no chips when the planner cannot build them'); await B.fill('#qn', 'بعد العطل'); await B.click('#hok'); await sleep(250);
    eq(await habitsJson(B), await habitsJson(A), 'quick task identical despite the fault'); assert(await B.evaluate(() => !!WirdTasks.ui.lastError()), 'error is recorded, not swallowed silently');
    const id = await oneoffId(B, 'بعد العطل'); await B.click('.hb-task[data-id="' + id + '"] .hb-n'); await sleep(100); assert(!(await sheetOpen(B)), 'no sheet'); noErrors(B, 'fault page (a)'); await A.ctx.close(); await B.ctx.close();
  });
  await step('FAULT: the planner throws AFTER «بعد الحفظ» was toggled -> the quick task is already saved, no error escapes, the app keeps working', async () => {
    const A = await open(PRIDIR, { seed: SEED }), B = await open(NEWDIR, { seed: SEED }); await tick(A, 3); await tick(B, 3);
    await addQuick(A, 'مهمة قبل العطل'); await B.click('#hFab'); await B.fill('#qn', 'مهمة قبل العطل'); await B.click('.wt-chip >> nth=0');
    await B.evaluate(() => { WirdKit.h = () => { throw new Error('boom'); }; }); await B.click('#hok'); await sleep(300);
    eq(await habitsJson(B), await habitsJson(A)); assert(!(await sheetOpen(B)), 'no half-open sheet'); eq(await B.$$eval('.wt-ov', e => e.length), 0, 'no stray overlay');
    noErrors(B, 'fault page (b)'); await A.ctx.close(); await B.ctx.close();
  });
  await step('FAULT: the engine cannot be created -> openPlanner reports {ok:false} instead of throwing, quick tasks still work', async () => {
    const B = await open(NEWDIR, { seed: SEED });
    const r = await B.evaluate(() => { WirdTasks.getEngine = () => { throw new Error('no engine'); }; return WirdTasks.ui.openPlanner({}); });
    eq(r.ok, false); eq(r.reason, 'internal_error'); eq(await B.$$eval('.wt-ov', e => e.length), 0);
    await addQuick(B, 'تعمل برضه'); eq((await habitsJson(B)).oneoffs[TODAY].map(o => o.name).includes('تعمل برضه'), true); noErrors(B, 'fault page (c)'); await B.ctx.close();
  });
  await step('observer discipline: one observer on #habitsRoot (childList, no subtree); 50 hRender() calls neither loop nor slow the render; badges never duplicate', async () => {
    const B = await open(NEWDIR, { seed: SEED });
    const bare = await B.evaluate(() => { const t = performance.now(); for (let i = 0; i < 50; i++) hRender(); return performance.now() - t; });
    const id = await (async () => { const h = await habitsJson(B); return h.oneoffs[TODAY][0].id; })();
    await B.click('.hb-task[data-id="' + id + '"] .hb-n'); await B.click('[data-act="split"]'); await addSteps(B, ['١', '٢']); await closeSheet(B);
    eq(await B.evaluate(() => window.__obs.filter(o => o.id === 'habitsRoot')).then(a => a.length), 1, 'exactly one observer on #habitsRoot');
    await B.evaluate(() => { window.__recs = 0; new MutationObserver(r => { window.__recs += r.length; }).observe(document.getElementById('habitsRoot'), { childList: true }); });
    const withPlan = await B.evaluate(() => { const t = performance.now(); for (let i = 0; i < 50; i++) hRender(); return performance.now() - t; });
    await sleep(400); const c1 = await B.evaluate(() => window.__recs); await sleep(500); const c2 = await B.evaluate(() => window.__recs);
    eq(c1, c2, 'no feedback loop: mutation count is stable'); eq(await B.$$eval('.wt-badge', b => b.length), 1);
    console.log('       50 hRender(): ' + bare.toFixed(0) + ' ms without plans, ' + withPlan.toFixed(0) + ' ms with a plan + badge');
    assert(withPlan < bare * 2 + 150, 'the badge pass must not slow rendering noticeably (' + withPlan + ' vs ' + bare + ')');
    eq(await B.evaluate(() => WirdTasks.ui.status().observer), true); await B.evaluate(() => WirdTasks.ui.destroy());
    eq(await B.evaluate(() => WirdTasks.ui.status()), { rootHook: false, fabHook: false, observer: false, open: false, view: null }); eq(await B.$$eval('.wt-badge', b => b.length), 0, 'destroy cleans up');
    noErrors(B, 'observer page'); await B.ctx.close();
  });
  await step('keyboard: focus moves into the sheet, Tab is trapped inside, Esc closes and returns focus to the opener', async () => {
    const B = await open(NEWDIR, { seed: SEED });
    await B.focus('#hFab'); await B.evaluate(() => WirdTasks.ui.openPlanner({})); await sleep(100);
    assert(await B.evaluate(() => !!document.activeElement.closest('.wt-sheet')), 'focus inside the sheet');
    for (let i = 0; i < 14; i++) { await B.keyboard.press('Tab'); assert(await B.evaluate(() => !!document.activeElement.closest('.wt-sheet')), 'focus escaped the sheet at Tab ' + (i + 1)); }
    for (let i = 0; i < 6; i++) { await B.keyboard.press('Shift+Tab'); assert(await B.evaluate(() => !!document.activeElement.closest('.wt-sheet')), 'focus escaped at Shift+Tab ' + (i + 1)); }
    await B.keyboard.press('Escape'); await sleep(100); assert(!(await sheetOpen(B)), 'Esc closes'); eq(await B.evaluate(() => document.activeElement.id), 'hFab', 'focus returns to the opener');
    eq(await B.evaluate(() => WirdTasks.ui.status().open), false); noErrors(B, 'keyboard page'); await B.ctx.close();
  });
  await step('static hygiene of tasks-ui.js: no innerHTML/outerHTML/insertAdjacentHTML/document.write, no direct storage access, no timers at load, no forbidden API strings', async () => {
    const src = fs.readFileSync(path.join(ROOT, 'tools', 'src', 'tasks-ui.js'), 'utf8').replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
    ['.innerHTML', '.outerHTML', 'insertAdjacentHTML', 'document.write', 'localStorage', 'sessionStorage', 'indexedDB', 'serviceWorker', 'eval(', 'new Function', 'fetch('].forEach(w => assert(!src.includes(w), 'tasks-ui.js must not use ' + w));
    assert(!/wird_habits_v1/.test(src), 'must not mention the habits key at all'); assert(!/setInterval/.test(src), 'no interval');
    const css = fs.readFileSync(path.join(ROOT, 'tools', 'src', 'tasks.css'), 'utf8').replace(/\/\*[\s\S]*?\*\//g, '');
    css.split('}').forEach(r => { const sel = r.split('{')[0].trim(); if (!sel) return; sel.split(',').forEach(s => assert(/\.wt-|wt-sheet/.test(s), 'tasks.css restyles a non-module selector: ' + s.trim())); });
  });

  /* --------------------------------------------------------------------------------------------- G */
  console.log('\n[G] phones (360x640, 390x844, 412x915): RTL, no overflow, every control >= 44x44, keyboard, screenshots');
  const VPS = [{ w: 360, h: 640, n: '360' }, { w: 390, h: 844, n: '390' }, { w: 412, h: 915, n: '412' }];
  for (const vp of VPS) {
    await step('viewport ' + vp.n + ': quick modal + chips, row sheet, day view (+overdue), editor with 8 steps and an open insert row, move view', async () => {
      const G = await open(NEWDIR, { seed: SEED, viewport: { width: vp.w, height: vp.h } });
      const sweep = async label => {
        const r = await G.evaluate(() => {
          const out = { overflowX: document.documentElement.scrollWidth - window.innerWidth, small: [], sheet: null };
          const sh = document.querySelector('.wt-sheet'), scope = sh || document.querySelector('.modal-overlay.open .modal');
          if (sh) out.sheet = { sw: sh.scrollWidth - sh.clientWidth, bw: sh.querySelector('.wt-body').scrollWidth - sh.querySelector('.wt-body').clientWidth, dir: getComputedStyle(sh).direction, h: sh.getBoundingClientRect().height, vh: window.innerHeight };
          scope.querySelectorAll('button, input, textarea, select').forEach(e => { if (e.offsetParent === null) return; if (!sh && !e.closest('[data-wt]') && !e.classList.contains('wt-chip')) return; const b = e.getBoundingClientRect(); if (b.width < 43.5 || b.height < 43.5) out.small.push((e.getAttribute('data-act') || e.className || e.tagName) + ' ' + Math.round(b.width) + 'x' + Math.round(b.height)); });
          out.anim = [...document.querySelectorAll('.wt-sheet, .wt-sheet *')].filter(e => getComputedStyle(e).animationName !== 'none').length;
          return out;
        });
        assert(r.overflowX <= 0, label + ': page scrolls sideways by ' + r.overflowX + 'px'); eq(r.small, [], label + ': controls under 44px');
        if (r.sheet) { assert(r.sheet.sw <= 0 && r.sheet.bw <= 0, label + ': sheet overflows horizontally'); eq(r.sheet.dir, 'rtl'); assert(r.sheet.h <= r.sheet.vh + 0.5, label + ': sheet taller than the screen'); eq(r.anim, 0, 'no animations defined by the module'); }
      };
      await tick(G, 100); await G.click('#hFab'); await sleep(150); await sweep('quick modal'); await shot(G, vp.n + '-1-quick-modal');
      eq(await G.$$eval('.wt-chips button', b => b.map(x => Math.round(x.getBoundingClientRect().left))).then(a => a[0] >= 0), true);
      await G.fill('#qn', 'مراجعة الفيزياء'); await G.click('.wt-chip >> nth=0'); await G.click('#hok'); await sleep(250); await sweep('draft editor'); await shot(G, vp.n + '-2-editor-draft');
      await addSteps(G, ['اقرأ الدرس', 'حل ٥ مسائل', 'Solve Q1 ثم راجع (x²)', 'راجع الأخطاء', 'لخّص', 'اشرب مياه', 'ريّح ٥ دقائق', 'خطوة أخيرة طويلة نسبيًا عشان نشوف الالتفاف في السطر بشكل سليم']);
      await G.click('.wt-step >> nth=1 >> [data-act="ins"]'); await sleep(100); await sweep('editor + insert row'); await shot(G, vp.n + '-3-editor-steps-insert');
      const order = await G.$$eval('.wt-step >> nth=0 >> .wt-step-tools button', b => b.map(x => [x.getAttribute('data-act'), Math.round(x.getBoundingClientRect().left)])); eq(order.map(o => o[0]), ['up', 'down', 'ins', 'del']);
      assert(order[0][1] > order[1][1] && order[1][1] > order[2][1] && order[2][1] > order[3][1], 'RTL order: ▲ is the right-most button, ✕ the left-most');
      eq(await G.$eval('.wt-step-in >> nth=2', t => [t.value, t.getAttribute('dir')]), ['Solve Q1 ثم راجع (x²)', 'auto'], 'mixed Arabic/English text kept and bidi-auto');
      await G.click('[data-act="insert-done"]');
      await G.click('[data-act="back"]'); await sleep(100); await E(G, 'createTask', YESTERDAY, 'متأخرة', { steps: ['س'] }); await G.evaluate(() => WirdTasks.ui.closePlanner()); await G.evaluate(() => WirdTasks.ui.openPlanner({})); await sleep(120);
      await sweep('day view'); await shot(G, vp.n + '-4-day-overdue'); eq(await texts(G, '.wt-chips button'), ['اليوم', 'غدًا', 'يوم آخر']);
      const cx = await G.$$eval('.wt-chips button', b => b.map(x => Math.round(x.getBoundingClientRect().left))); assert(cx[0] > cx[1] && cx[1] > cx[2], 'RTL chips: اليوم is right-most');
      await G.click('.wt-task >> nth=0 >> [data-act="move"]'); await sleep(100); await sweep('move view'); await shot(G, vp.n + '-5-move'); await G.click('[data-act="move-cancel"]'); await sleep(80);
      await G.click('.wt-task >> nth=0 >> .wt-task-main'); await sleep(100);
      const last = G.locator('.wt-step-in').last(); await last.focus();                                          // soft keyboard: the visual viewport shrinks to ~45%
      await G.setViewportSize({ width: vp.w, height: Math.round(vp.h * 0.45) }); await sleep(250);
      const vis = await G.evaluate(() => { const b = document.activeElement.getBoundingClientRect(); return { top: b.top, bottom: b.bottom, vh: window.innerHeight, sh: document.querySelector('.wt-sheet').getBoundingClientRect().height }; });
      assert(vis.top >= -0.5 && vis.bottom <= vis.vh + 0.5, 'focused input hidden behind the keyboard: ' + JSON.stringify(vis)); assert(vis.sh <= vis.vh + 0.5, 'sheet taller than the visible area');
      await shot(G, vp.n + '-6-keyboard'); await G.setViewportSize({ width: vp.w, height: vp.h }); noErrors(G, 'mobile ' + vp.n); await G.ctx.close();
    });
  }
  await step('reduced motion: the planner opens, works, and defines no animation or transition of its own', async () => {
    const G = await open(NEWDIR, { seed: SEED, reducedMotion: 'reduce' }); await G.evaluate(() => WirdTasks.ui.openPlanner({})); await sleep(150);
    eq(await G.$$eval('.wt-sheet, .wt-sheet *', els => els.filter(e => getComputedStyle(e).animationName !== 'none').length), 0);
    await G.fill('.wt-newtask', 'حركة أقل'); await G.press('.wt-newtask', 'Enter'); await sleep(120); eq((await E(G, 'listTasks', TODAY)).length, 1); noErrors(G, 'reduced-motion page'); await G.ctx.close();
  });

  await browser.close();
  console.log('\n' + (failed ? '✘ ' + failed + ' FAILED: ' + failures.join(' | ') : '✔ planning UI: ' + passed + ' tests passed (' + assertions + ' assertions)'));
  console.log('  tests: ' + (passed + failed) + ' | passed: ' + passed + ' | failed: ' + failed + ' | assertions: ' + assertions);
  process.exit(failed ? 1 : 0);
})().catch(e => { console.error('HARNESS ERROR', e); process.exit(2); });
