# MASTER-PLAN — Wird: Dynamic Task Atomization + Focus Quiz & Self-Grading

**Authoritative project specification.** Package: prompt-package v1 (generated after B1; project vision frozen at the B1 approval). Prepared on 2026-11-03 (container clock). Generated sections (§6 requirements, §8 decisions, §10 roadmap index) come from `tools/prompt-package/*` — edit the data files and re-run `python3 -I tools/prompt-package/build_package.py`, or record changes in §12 by hand when a session is told to.

**Order of authority when documents disagree:** (1) the user’s latest explicit instruction; (2) the actual project files — for *what exists*; (3) this MASTER-PLAN — for *what must be built and why*; (4) `docs/ROADMAP.md` — the normative task cards; (5) the batch prompts in `prompts/`; (6) `PROJECT-STATUS.md`/`HANDOFF.md` — for state, always verified against the files. A session that finds a contradiction must STOP and report it; it never resolves it silently.

**Companion documents:** `docs/ROADMAP.md` (24 task cards + amendments A1–A8) · `BATCH-DEPENDENCY-MAP.md` · `TRACEABILITY-MATRIX.md` · `PROMPT-USAGE-GUIDE.md` · `PROJECT-STATUS.md` · `HANDOFF.md` · `CHANGELOG.md` · `docs/INTEGRATION-SPIKES.md` (evidence) · `docs/BASELINE-TEST-RESULTS.md` (baseline).

## 1. Vision

Wird (وِرد) is a production, Arabic-first, RTL, mobile-first, offline-first PWA (Quran/worship tracking, habits and quick tasks, Pomodoro, and the study workspace «منهجي»). This project extends it with two **optional, additive** systems without redesigning anything:

1. **Dynamic Task Atomization** — divide a task into steps, organize them by day (DAY → TASKS → STEPS) and execute them through a focused view that shows ONE current step at a time. *ONE TASK → ONE CURRENT STEP → ONE ACTION.*
2. **Focus Quiz & Self-Grading** — MATERIAL → AI PROMPT → JSON IMPORT → FOCUSED SOLVING → REVIEW → SELF-GRADING → SESSION REPORT, using a reusable prompt with an external AI (no API keys, no paid calls), an immersive one-question-at-a-time solving view, review with or without an answer key, a fair session report and simple local mistake tracking.

**Final product principle (the user’s words):** for tasks — "I know what I need to do. Show me the next step."; for studying — "I know what I need to solve. Show me the next question."; for evaluation — "Let me finish first. I will evaluate afterward." Wird should remove unnecessary decisions from the user’s path. *Preserve the existing product; improve how the user interacts with it; do not turn the application into something else.*

Priorities in order: correctness · preservation · data safety · maintainability · faithful implementation of the approved design · speed (last).

## 2. Scope

**First release (mandatory):** everything in §6 whose kind is MANDATORY/PRESERVATION/PROCESS, plus the OPTIONAL items implemented as optional (configurable, off or non-intrusive by default). **Optional features:** the atomization feature itself, end-of-day prompt, skip step, edit during execution, timer, progress indicator, sound, haptic, micro-interactions, Mark for Review, Skip and Return, Previous Question, answer editing, «اطلب تصحيح AI», mistake categories, automatic revision suggestions. **Conditional:** if the user does not want automatic suggestions the feature stays disabled (MT-03); if no answer key exists the app must not invent one (G-04). **Deferred (must not be built):** the eight items DF-01…DF-08 (automatic AI recognition of task names, AI task decomposition, keyword-triggered templates, automatic AI coaching, per-step math scoring, continuous AI analysis, complicated reward systems, unnecessary new top-level navigation). **Not built:** manual question creation (Q-05), a `quiz` lesson resource type (D3), server submission (D10), changes to the habit wizard (T-02) unless D1(b) is approved.

## 3. Preservation constraints (summary — the full text is embedded in every prompt, §8)

* Existing UI/UX/theme/navigation/features/data are preserved; new work is additive, isolated, reversible.
* **Never touched:** `sw.js` (no `SHELL_VERSION` bump before D6 at B17), the SW registration and `wird-update`, `wird-update-css`, `wird-offline`, `wird-quran-font(-js)`; every other existing block of `index.html`; manifest; icons; existing tests/tools/docs (docs append-only in 5.3). **Guarded:** `script:#2`, `style:#0`, markup — only by user-approved exact-match hooks.
* **Never run:** `tools/patch/build.py`, `unify.py`, `bundle_patches.py`.
* **Data:** never clear/recreate/migrate existing localStorage/IndexedDB; new namespaces only (§7.2).
* **Tooling that enforces it:** `tools/audit/verify_preservation.py` + `docs/PRESERVATION-BASELINE.json` (frozen "before" state; never regenerated) + `tools/audit/test_verify_preservation.py` (27 mutation cases).

## 4. Existing application — verified architecture

**Project objective.** Add two OPTIONAL, ADDITIVE features to the existing app without redesigning or breaking anything:
(1) **Dynamic Task Atomization** — plan DAY → TASKS → STEPS and execute one current step at a time (ONE TASK → ONE CURRENT STEP → ONE ACTION);
(2) **Focus Quiz & Self-Grading** — MATERIAL → AI PROMPT → JSON IMPORT → FOCUSED SOLVING → REVIEW → SELF-GRADING → SESSION REPORT, with simple local
mistake tracking. The app is Arabic-first, RTL, mobile-first (small Android phones), offline-first. Full requirements: `MASTER-PLAN.md`.

**Existing application (verified by reading the code and probing it live in B1; details in `docs/INTEGRATION-SPIKES.md`).**
* One 1.8 MB `index.html` plus `sw.js`, `manifest.webmanifest`, two icons. No bundler. Features were added as self-contained blocks `<script id="wird-…">` /
  `<style id="wird-…-css">` plus a few exact-match patches. 26 `<script>/<style>` blocks (listed with hashes in `docs/PRESERVATION-BASELINE.json`).
  Main app = the anonymous 336 KB inline script (verifier key `script:#2`: habits, Pomodoro, Quran, books) and the main stylesheet (`style:#0`).
  The lesson workspace «منهجي» = minified bundle `ls-main` (no source) + `courses-module`, `wird-v33-*`, `wird-resources`, `wird-unified`; KaTeX/mhchem/JSZip are
  embedded as `ls-asset-*` blocks. Readable sources only for `tools/src/resources.*` and `tools/src/unified.*`.
  **`tools/patch/build.py`, `unify.py`, `bundle_patches.py` regenerate the OLD `sw.js`/`index.html` — never run them.**
* Storage: localStorage `wird_habits_v1` (global lexical object `H`; quick tasks = `H.oneoffs[date]` items `{id:'o_…',name,s,cat,done}`; `window.H` is undefined, use bare `H`),
  `wird_quran_state_v1`, `wird_mig_v3`, study/course keys; IndexedDB `wird_study_db@v2` (lessons, resources, mistakes…), `wird_books_db@v3`, `wird_fnb_m@v1`, `wird_mig_db@v1`.
  New namespaces reserved for this project: localStorage `wird_tasks_v1`, `wird_taskprefs_v1`, `wird_quizprefs_v1`; IndexedDB `wird_quiz_db` (created lazily, only on first quiz use).
* PWA update system: `sw.js` (`SHELL_VERSION = 5`) + blocks `wird-update` (contains the SW registration), `wird-update-css`, `wird-offline`, `wird-quran-font(-js)`.
* UI facts: tabs switch `.tab[data-view="view-habits"|"view-lessons"|…]`; habits root `#habitsRoot` is **re-rendered completely by `hRender()`**; quick-task rows
  `.hb-task[data-id^="o_"] > button.hb-c + span.hb-n[data-a=open]` (tapping the name currently does nothing); quick-task modal opened by `#hFab` (fields `#qn`, `#hok`);
  habit wizard `hWizard()` has 5 steps, step 2 = chips `#wt.hb-chips` (✅ عادية / ⏱ بالوقت / 🔢 بالكمية). Helpers callable from a new classic script: `hModal(html)`
  (overlay `.modal-overlay.open>.modal`, closes on backdrop tap only, no Esc/focus-trap), `showConfirm(title,msg,onConfirm)`, `showToast(msg)` (no action button),
  `hUid(prefix)`, `escapeHtml`, `toArabicNum`, `todayISO()`, `hSave()`, `hRender()`. Design tokens: `--gold --gold-soft --gold-bright --line --panel-raised --ink-dim --ink-faint --sage`;
  classes `.field-input .field-label .field-hint .hb-chips .btn .btn-primary .btn-ghost .btn-danger .panel-card .desc`.
* Lesson screen: `.ls-lesson-main > … + section.wr[data-lesson] + .ls-editor-wrap`; `section.wr` children `#wrHead` (rewritten by `renderHead()` — never append inside it or inside
  `.wr-foot`), `#wrTabs`, `#wrPanel`; anything inserted as a **sibling after `#wrHead` or `#wrTabs` survives** re-renders. Sidebar rows call `window.__wirdRow(row, el)` (wrappable).
  `__WIRD_STUDY_APP__.repo` is the public lesson-data API (`saveMistake`, `reseeMistake`, `setMistakeStatus`, `listMistakes`, `saveResource`…). `wirdResNorm` rejects unknown
  resource types. KaTeX is lazy (`typeof katex === 'undefined'` until a lesson editor loads it); an independent loader mirroring `ls-main` works in ~37 ms (assets
  `#ls-asset-katex`, `#ls-asset-mhchem`, `#ls-asset-katex-css`, style id `ls-katex-style`).
* Tests: Playwright 1.56 is installed globally (`NODE_PATH=$(npm root -g)`), Chromium 141 works; existing suites `tests/{update,offline,unified,resources,courses,perf}.test.js`.
* Preservation tooling (created in B1): `tools/audit/verify_preservation.py` (tiers FROZEN / GUARDED / APPEND-ONLY / NEW), `tools/audit/test_verify_preservation.py` (27 mutation cases),
  `tools/audit/probe_anchors.js` (live evidence probe), `docs/PRESERVATION-BASELINE.json` (frozen "before" state — never regenerate).
* Approved amendments A1–A8 (see `docs/ROADMAP.md`): module-owned settings sheets (A1); patch-free hooks by default via MutationObserver/delegation/`__wirdRow` wrapper (A2);
  no `quiz` resource type (A3); D7 (A4); O(1) observers because lesson `openMs` has only 33 ms of headroom (A5); Web Share fallback + `storage.persist()` (A6); bare `H`, IIFE modules (A7);
  verifier whitelist for new blocks `wird-tasks*`/`wird-quiz*` with forbidden-API scan (A8).

## 5. Roadmap shape

6 phases, 24 tasks, 17 batches; task cards in `docs/ROADMAP.md`; batch graph in `BATCH-DEPENDENCY-MAP.md`; the generated index is in §10.

## 6. Requirement register

Kinds: MANDATORY, OPTIONAL (must stay optional), CONDITIONAL, PRESERVATION, PROCESS, DEFERRED / EXCLUDED (must NOT be built). `impl` = implementing tasks; `verify` = verifying tasks. Traceability to batches: `TRACEABILITY-MATRIX.md`.


### Part 0 — Preservation

* **PRES-01** [PRESERVATION] Preserve the existing UI/UX, theme, colors, typography, icons, spacing, layouts, navigation and tab structure; the app stays visually and functionally identical outside the new features; never replace existing screens with invented layouts. _(impl: ALL · verify: 0.3, 1.2, 1.5, 2.4, 5.2, 5.4)_
* **PRES-02** [PRESERVATION] Preserve existing task and habit functionality, study materials/lessons/notes/summaries, Quran and Wird functionality and user workflows; do not modify unrelated features. _(impl: ALL · verify: 1.5, 5.1, 5.4)_
* **PRES-03** [PRESERVATION] No change to existing database structures unless an additive migration is genuinely necessary (then explain and get approval). _(impl: ALL · verify: 0.3, 5.4)_
* **PRES-04** [PRESERVATION] Do not rewrite, remove or modify sw.js, the Service Worker registration, the wird-update functionality, cache ownership/versioning, offline Quran/Tafsir storage or existing localStorage/IndexedDB data; never regenerate the old SW from legacy build scripts; modify only if absolutely required, after explanation and approval. _(impl: ALL · verify: 0.1, 0.3, 1.5, 5.4)_
* **PRES-05** [PRESERVATION] Preserve every existing record: all new storage is additive and backward compatible; never clear or recreate existing databases; existing tasks, habit history, notes, course progress and user content stay intact. _(impl: ALL · verify: 1.5, 5.1, 5.4)_
* **PRES-06** [PRESERVATION] No unnecessary external services, API dependencies or paid AI; prioritize local processing and locally stored preferences; the user never has to re-configure the same settings. _(impl: ALL · verify: 5.4)_
* **PRES-07** [PRESERVATION] Changes are additive, isolated and reversible; protected files are never modified without explicit authorization. _(impl: ALL · verify: 0.1, 5.4)_

### Protocol (global development rules + batch workflow)

* **PROC-01** [PROCESS] Read MASTER-PLAN.md, PROJECT-STATUS.md and HANDOFF.md before each batch; never rely on conversation memory; never repeat completed tasks; never skip dependencies. _(impl: ALL · verify: 5.4)_
* **PROC-02** [PROCESS] Execute only the explicitly authorized batch; respect dependencies and acceptance criteria; stop at the batch boundary; never start the next batch without approval; document (do not fix) bugs outside the scope. _(impl: ALL · verify: 5.4)_
* **PROC-03** [PROCESS] Verify all changes before declaring completion; never claim a test passed unless it was executed; clearly separate executed from untested. _(impl: ALL · verify: 5.4)_
* **PROC-04** [PROCESS] At the end of every batch: update MASTER-PLAN.md if necessary, PROJECT-STATUS.md, HANDOFF.md and CHANGELOG.md; produce the next-batch prompt and a checkpoint ZIP; report exact modified files; no undocumented changes. _(impl: ALL · verify: 5.4)_
* **PROC-05** [PROCESS] IMPLEMENTED ≠ TESTED ≠ VERIFIED; a task is COMPLETED only after its acceptance criteria are satisfied; PROJECT-STATUS.md and HANDOFF.md always describe the same actual state. _(impl: ALL · verify: 5.4)_

### Part 1 — Dynamic Task Atomization

* **T-01** [OPTIONAL] Task atomization is an OPTIONAL feature integrated into the existing task/habit system (no separate app, no unnecessary top-level tab), reachable from an appropriate existing task-management entry point, task-card action or an optional step after creating a complex task; regular creation of simple habits stays just as easy. _(impl: 1.2 · verify: 1.5)_
* **T-02** [PRESERVATION] The existing five-step habit creation wizard stays intact: steps, order and tracking methods are not reordered or removed. _(impl: 1.2 · verify: 1.5, 5.4)_
* **T-03** [MANDATORY] Planning operations: create a task, name it, add multiple steps, edit any step, delete any step, insert steps between existing steps, reorder steps, select which task to work on, edit a task without losing completion history, delete a task with confirmation, pause and resume an unfinished task, save state automatically. _(impl: 1.1, 1.2 · verify: 1.5)_
* **T-04** [MANDATORY] The planning interface may show the full editable list of steps; the execution interface shows only ONE current step by default (never the whole checklist). _(impl: 1.3 · verify: 1.5)_
* **T-05** [DEFERRED] Automatic AI keyword recognition, smart keyword templates and AI-generated task decomposition (typing "Chemistry Lecture" triggers nothing) are deferred to a future release. _(impl: — · verify: 5.4)_
* **T-06** [MANDATORY] Day-based organization DAY → TASKS → STEPS: today, tomorrow and future days; multiple tasks per day; multiple steps per task; reorder tasks within a day; move an unfinished task to another day; edit or delete planned tasks. _(impl: 1.1, 1.2 · verify: 1.5)_
* **T-07** [MANDATORY] The focused interface executes the selected task and its steps without displaying the full daily task list. _(impl: 1.3 · verify: 1.5)_
* **T-08** [OPTIONAL] End-of-day prompt when all of the day’s tasks are complete: «خلصت مهام النهارده. تحب تدخل على مهام اليوم التالي؟» with actions «الانتقال لليوم التالي» and «ليس الآن»; configurable and disableable; never forces navigation; if the next day is empty allow opening it or returning to the normal task list. _(impl: 1.4 · verify: 1.5)_
* **T-09** [MANDATORY] One-at-a-time execution: current task/context where useful, ONE current step, ONE primary completion action; flow: see step → complete → check → recorded → next step appears automatically with a pleasant transition; no "Step 2 of 8" by default; current step visually dominant; no lists, statistics or settings clutter. _(impl: 1.3 · verify: 1.5)_
* **T-10** [MANDATORY] Satisfying but restrained feedback: smooth fade/transition, brief completion animation, pleasant state change, optional haptic, optional subtle sound, optional micro-interaction — all configurable; no points, coins, artificial rewards or competitive streaks. _(impl: 1.3, 1.4 · verify: 1.5, 5.2)_
* **T-11** [MANDATORY] Execution controls (persistent): display mode (one step by default), automatic transition, back navigation, skip step (optional, configurable), edit during execution (optional, configurable), pause/resume, timer (optional), progress indicator (optional), completion animation (configurable), sound (optional), haptic (optional), end-of-day prompt (optional). _(impl: 1.3, 1.4 · verify: 1.5)_
* **T-12** [MANDATORY] Undo protection: a brief, unobtrusive undo action after completion; a skipped step never automatically counts as completed. _(impl: 1.1, 1.3 · verify: 1.5)_
* **T-13** [MANDATORY] Progress visibility setting: completely hidden / subtle indicator / detailed indicator; the default minimizes visual pressure. _(impl: 1.3, 1.4 · verify: 1.5)_
* **T-14** [MANDATORY] Preferences are saved locally and persist across sessions; a default profile exists for new task sessions; session-specific overrides are possible; changing a setting never affects an active session. _(impl: 1.1, 1.4 · verify: 1.5)_
* **T-15** [MANDATORY] State management: not started, in progress, paused, completed, skipped, partially completed; autosave after every action; current step preserved after closing; resume from the exact position; history preserved; the same completion is never recorded twice; completed vs skipped stays distinct; editing/deleting steps never corrupts progress. _(impl: 1.1 · verify: 1.5)_

### Part 2 — Focus Quiz: workflow, integration, AI prompt

* **Q-01** [MANDATORY] Workflow chain: MATERIAL → AI PROMPT → JSON IMPORT → FOCUSED SOLVING → REVIEW → SELF-GRADING → SESSION REPORT. _(impl: 2.4, 3.3, 4.1, 4.3 · verify: 5.1)_
* **Q-02** [MANDATORY] Focus Quiz lives inside the existing lesson/study environment without replacing or redesigning it; accessible in the context of the lesson/material/sheet; no independent app or top-level navigation; the solving screen may be an immersive dedicated view; on exit the user returns to the original lesson context. _(impl: 2.4, 3.3 · verify: 5.1, 5.4)_
* **Q-03** [MANDATORY] A persistent, easily accessible button for the fixed AI Prompt is placed next to the existing "Add New Sheet" action (anchor per decision D2). _(impl: 2.4 · verify: 5.1)_
* **Q-04** [MANDATORY] The fixed AI Prompt is reusable, reachable with one tap, easy to copy, stored persistently, versioned for future improvements and consistent across sessions. _(impl: 2.4 · verify: 5.1, 5.3)_
* **Q-05** [EXCLUDED] Manual question creation is NOT a priority for this release (not built). _(impl: — · verify: 5.4)_
* **Q-06** [MANDATORY] Import supports pasting JSON, importing a JSON file, validation, a preview of the generated session, malformed-JSON detection, useful validation errors, and prevents invalid data from entering an active session. _(impl: 2.1, 2.4 · verify: 5.1)_
* **Q-07** [PRESERVATION] No API keys, paid AI calls or automatic AI requests inside Wird; the workflow uses a reusable prompt with an external AI. _(impl: 2.4, 4.2 · verify: 5.4)_
* **Q-08** [MANDATORY] The prompt instructs the external AI to extract questions accurately, preserve original wording and source language, identify the correct question type, preserve numbering when useful, extract options, figures/diagrams where possible, math notation, physics symbols and units, tables and structured content. _(impl: 2.4 · verify: 5.3)_
* **Q-09** [MANDATORY] The prompt instructs the AI to extract official answers only when they exist, explanations/solutions only when present or explicitly requested, never invent an answer key, mark missing answers null/unavailable, assign stable question IDs, follow the actual Wird JSON schema and output valid JSON without surrounding prose. _(impl: 2.4 · verify: 5.3)_
* **Q-10** [MANDATORY] Imported content follows the existing Wird content framework (heading hierarchy, math, tables, media) rather than an invented formatting language (decision D4). _(impl: 2.1, 2.3, 2.4 · verify: 5.1)_
* **Q-11** [MANDATORY] Source material may be any format the external AI supports (PDF, images, screenshots, scanned worksheets, Word, plain text, existing question banks): the prompt is format-agnostic. _(impl: 2.4 · verify: 5.3)_

### Part 3 — Question types and content

* **QT-01** [MANDATORY] Question type 1 must be supported in the first release: Single-choice MCQ (schema in 2.1, rendering in 2.3, answer widget in 3.1). _(impl: 2.1, 3.1 · verify: 5.1)_
* **QT-02** [MANDATORY] Question type 2 must be supported in the first release: Multiple-select MCQ (schema in 2.1, rendering in 2.3, answer widget in 3.1). _(impl: 2.1, 3.1 · verify: 5.1)_
* **QT-03** [MANDATORY] Question type 3 must be supported in the first release: True/False (schema in 2.1, rendering in 2.3, answer widget in 3.1). _(impl: 2.1, 3.1 · verify: 5.1)_
* **QT-04** [MANDATORY] Question type 4 must be supported in the first release: Short text answers (schema in 2.1, rendering in 2.3, answer widget in 3.2). _(impl: 2.1, 3.2 · verify: 5.1)_
* **QT-05** [MANDATORY] Question type 5 must be supported in the first release: Long written/essay answers (schema in 2.1, rendering in 2.3, answer widget in 3.2). _(impl: 2.1, 3.2 · verify: 5.1)_
* **QT-06** [MANDATORY] Question type 6 must be supported in the first release: Numerical answers (schema in 2.1, rendering in 2.3, answer widget in 3.2). _(impl: 2.1, 3.2 · verify: 5.1)_
* **QT-07** [MANDATORY] Question type 7 must be supported in the first release: Mathematical expressions and equations (schema in 2.1, rendering in 2.3, answer widget in 3.2). _(impl: 2.1, 3.2 · verify: 5.1)_
* **QT-08** [MANDATORY] Question type 8 must be supported in the first release: Physics and chemistry problems (schema in 2.1, rendering in 2.3, answer widget in 3.2). _(impl: 2.1, 3.2 · verify: 5.1)_
* **QT-09** [MANDATORY] Question type 9 must be supported in the first release: Fill in the blanks (schema in 2.1, rendering in 2.3, answer widget in 3.1). _(impl: 2.1, 3.1 · verify: 5.1)_
* **QT-10** [MANDATORY] Question type 10 must be supported in the first release: Matching (schema in 2.1, rendering in 2.3, answer widget in 3.1). _(impl: 2.1, 3.1 · verify: 5.1)_
* **QT-11** [MANDATORY] Question type 11 must be supported in the first release: Ordering and sequencing (schema in 2.1, rendering in 2.3, answer widget in 3.1). _(impl: 2.1, 3.1 · verify: 5.1)_
* **QT-12** [MANDATORY] Question type 12 must be supported in the first release: Multi-part questions (schema in 2.1, rendering in 2.3, answer widget in 3.2). _(impl: 2.1, 3.2 · verify: 5.1)_
* **QT-13** [MANDATORY] Question type 13 must be supported in the first release: Step-based problem statements (schema in 2.1, rendering in 2.3, answer widget in 3.2). _(impl: 2.1, 3.2 · verify: 5.1)_
* **QT-14** [MANDATORY] Question type 14 must be supported in the first release: Questions containing images, diagrams or tables (schema in 2.1, rendering in 2.3, answer widget in 2.3/3.2). _(impl: 2.1, 2.3, 3.2 · verify: 5.1)_
* **QT-15** [MANDATORY] Each question is rendered according to its type; the application is not limited to multiple choice. _(impl: 2.3, 3.1, 3.2 · verify: 5.1)_
* **QM-01** [MANDATORY] Math/science content: fractions, exponents, square roots, Greek symbols, operators, equations, subscripts/superscripts, physics units, chemical notation, multiple equations in one question, tables, diagrams, image attachments. _(impl: 2.3 · verify: 5.1)_
* **QM-02** [PRESERVATION] Use the existing math renderer (embedded KaTeX/mhchem); introduce a new rendering dependency only if absolutely necessary. _(impl: 2.3 · verify: 5.4)_
* **QM-03** [MANDATORY] Equations never overflow the mobile screen. _(impl: 2.3 · verify: 5.2)_
* **QA-01** [MANDATORY] Answer inputs: selecting options, numerical values, text, mathematical expressions, multiple fields where necessary. _(impl: 3.1, 3.2 · verify: 5.1)_
* **QA-02** [MANDATORY] A student can attach an image of handwritten work (photo of a paper solution). _(impl: 3.2 · verify: 5.1)_
* **QA-03** [MANDATORY] A complete solution can be written or attached. _(impl: 3.2 · verify: 5.1)_
* **QA-04** [MANDATORY] Image attachments persist reliably across application reloads. _(impl: 2.2, 3.2 · verify: 5.1)_

### Part 4 — Focus Tunnel

* **FT-01** [MANDATORY] ONE QUESTION AT A TIME: during solving show only the current question — no side question list by default, no correct answers, explanations, scores, mastery percentages, distracting statistics or unnecessary navigation. _(impl: 3.3 · verify: 5.1)_
* **FT-02** [MANDATORY] Default flow: display a single question with its answer interface, allow answering, save, and on pressing «تثبيت الإجابة والانتقال للسؤال التالي» save the answer and show the next question. _(impl: 3.3 · verify: 5.1)_
* **FT-03** [MANDATORY] The interface never reveals whether a submitted answer is correct; answers are recorded privately and correctness appears only in the review stage. _(impl: 3.1, 3.2, 3.3 · verify: 5.1)_
* **FT-04** [MANDATORY] Persistent solving settings: focus mode (Minimal/Balanced/Advanced), question display (one by default), progress display (Hidden/Subtle/Detailed), question counter (Hidden/Visible), timer (Disabled/Visible/Hidden background), previous question, Mark for Review, Skip and Return, answer editing, navigation animation, input font size, question font size, keyboard behaviour optimized per input type, media display (Fit/Expand/Full-screen). _(impl: 3.4 · verify: 5.1)_
* **FT-05** [MANDATORY] A session-specific override is possible without replacing the saved defaults. _(impl: 3.4 · verify: 5.1)_
* **FT-06** [MANDATORY] Default configuration: minimal interface, one question, no visible score, no correctness feedback, no total-question counter, progress hidden, no unnecessary side navigation, automatic saving, explicit submit-and-continue action. _(impl: 3.3, 3.4 · verify: 5.1)_
* **FT-07** [OPTIONAL] Mark for Review: mark a question for later review without revealing the answer (configurable, remembered). _(impl: 3.3 · verify: 5.1)_
* **FT-08** [OPTIONAL] Skip and Return: skip a question and return before final submission (configurable, remembered). _(impl: 3.3 · verify: 5.1)_
* **FT-09** [OPTIONAL] Previous Question: return to a previously answered question when enabled (configurable, remembered). _(impl: 3.3 · verify: 5.1)_
* **FT-10** [MANDATORY] An unanswered question never disappears silently; all answers are preserved when navigating backward or forward. _(impl: 3.3 · verify: 5.1)_

### Part 5 — Session management

* **S-01** [MANDATORY] Sessions survive interruptions: automatic saving, pause and resume, closing and reopening the application, returning after the phone is restarted. _(impl: 2.2, 3.3 · verify: 5.1)_
* **S-02** [MANDATORY] Preserve the current question, previously submitted answers, unfinished input and attached images. _(impl: 2.2, 3.3 · verify: 5.1)_
* **S-03** [MANDATORY] A session completes only once; duplicate reports are prevented. _(impl: 2.2, 4.3 · verify: 5.1)_
* **S-04** [MANDATORY] Session states: Prepared, In Progress, Paused, Ready for Review, Completed; an unfinished session can be resumed without losing work. _(impl: 2.2 · verify: 5.1)_

### Part 6 — Review and self-grading

* **G-01** [MANDATORY] Scenario A (answer key available): after the final question enter review showing the question, the user’s answer, the official model answer and the explanation if available; the user grades their own answer. _(impl: 4.1 · verify: 5.1)_
* **G-02** [MANDATORY] Never automatically mark an answer correct because its text matches; the user remains responsible for the final assessment. _(impl: 4.1 · verify: 5.1)_
* **G-03** [MANDATORY] Grades: Correct, Partially Correct, Incorrect, Unanswered, Needs Review; the grading interface is fast and easy. _(impl: 4.1 · verify: 5.1)_
* **G-04** [MANDATORY] Scenario B (no answer key): do not treat every question as incorrect and do not invent model answers; preserve all submitted answers; show the original questions and responses; mark questions Awaiting Grading. _(impl: 4.1 · verify: 5.1)_
* **G-05** [MANDATORY] Answer sheet export: export all questions and submitted answers, copy the sheet, share it with a teacher (decision D10), generate a printable report/PDF where supported; preserve numbering and formatting; works even when nothing is graded. _(impl: 4.2 · verify: 5.1)_
* **G-06** [OPTIONAL] Optional «اطلب تصحيح AI» workflow: the app prepares a grading prompt (original questions, student answers, available marking criteria, any supplied official answer key); the user sends it to an external AI and imports the structured grading result. _(impl: 4.2 · verify: 5.1)_
* **G-07** [PRESERVATION] No automatic AI requests and no mandatory AI API usage or recurring credit consumption. _(impl: 4.2 · verify: 5.4)_
* **G-08** [MANDATORY] If there is no reliable answer key or marking basis, the system communicates that limitation instead of fabricating certainty. _(impl: 4.2 · verify: 5.1)_

### Part 7 — Mathematical review

* **M-01** [MANDATORY] Full rendering of mathematical expressions and complete written solutions (also in review). _(impl: 2.3, 4.1 · verify: 5.1)_
* **M-02** [DEFERRED] Per-step scoring of mathematical solutions is NOT required in this release; the student assesses the overall answer with the normal grading states. _(impl: — · verify: 5.4)_
* **M-03** [MANDATORY] The architecture stays extensible so detailed step-by-step marking can be added later (reserved `stepMarks`, not built). _(impl: 2.1, 4.1 · verify: 5.4)_

### Part 8 — Session report

* **R-01** [MANDATORY] After review generate a report with: number of questions, number graded, correct, partially correct, incorrect, unanswered, awaiting grading, mastery percentage when grading data is complete enough, questions requiring revision, weak topics when topic data exists, session duration when timing is enabled. _(impl: 4.3 · verify: 5.1)_
* **R-02** [MANDATORY] Accuracy rules: never a misleading mastery percentage; graded and awaiting questions are clearly separated; the score follows supplied marks; partial credit is supported; equal marks are never assumed when the data provides different marks (decision D9). _(impl: 4.3 · verify: 5.1)_
* **R-03** [MANDATORY] Provide an option to return directly to weak questions. _(impl: 4.3 · verify: 5.1)_

### Part 9 — Long-term mistake tracking

* **MT-01** [MANDATORY] A simple local mistake-tracking system using deterministic IF rules; no continuous AI analysis and no recurring AI API calls. _(impl: 4.4 · verify: 5.1)_
* **MT-02** [MANDATORY] Rules: Incorrect → mistake pool; Partially Correct → weak question; repeated errors in a topic → optionally suggest a revision session; a mistake successfully reviewed again → status update. _(impl: 4.4 · verify: 5.1)_
* **MT-03** [CONDITIONAL] If the user does not want automatic suggestions, the suggestion feature stays disabled (decision D5). _(impl: 4.4 · verify: 5.1)_
* **MT-04** [OPTIONAL] Optional mistake categories: Conceptual error, Wrong formula, Calculation error, Memorization error, Careless mistake, Other; users are never forced to classify. _(impl: 4.4 · verify: 5.1)_
* **MT-05** [MANDATORY] No new complicated planning system; mistake data is accessible from the existing study/lesson context. _(impl: 4.4 · verify: 5.1)_

### Part 10 — Global settings and UX

* **GS-01** [MANDATORY] Remember task execution/transition/feedback/animation/progress/edit-skip/end-of-day settings and Focus Quiz mode/navigation/progress/timer/text sizes/review preferences/mistake-tracking behaviour; apply them automatically to new sessions. _(impl: 1.4, 3.4 · verify: 1.5, 5.1)_
* **GS-02** [MANDATORY] Provide an appropriate settings location within the existing app (decision D11: module-owned sheets). _(impl: 1.4, 3.4 · verify: 5.2)_
* **GS-03** [MANDATORY] Three saved display modes — Minimal, Balanced, Advanced — with Minimal as the default. _(impl: 1.4, 3.4 · verify: 1.5, 5.1)_
* **GS-04** [MANDATORY] Subtle visual transitions only; optional haptic and sound only when supported and enabled; no animations that harm performance. _(impl: 1.3, 1.4, 3.3 · verify: 5.2)_
* **GS-05** [MANDATORY] Arabic-first: correct RTL, Arabic typography, mixed Arabic/English rendering, proper mathematical equation direction and layout. _(impl: 1.2, 1.3, 1.4, 2.3, 3.1, 3.2, 3.3, 4.1 · verify: 5.2)_
* **GS-06** [MANDATORY] Mobile-first portrait design usable on small Android screens, proper keyboard behaviour, no horizontal overflow, accessible touch targets. _(impl: 1.2, 1.3, 1.4, 2.3, 3.1, 3.2, 3.3, 4.1 · verify: 5.2)_
* **GS-07** [MANDATORY] The features feel like a native part of Wird (existing design system), not an embedded third-party page. _(impl: 1.2, 1.3, 2.4, 3.3 · verify: 5.2, 5.4)_

### Part 11 — Data architecture and JSON import

* **D-01** [MANDATORY] Inspect the current persistence architecture before designing schemas and use it where appropriate. _(impl: 0.2 · verify: 0.2)_
* **D-02** [MANDATORY] Separate clearly named structures for task plans, day groups, task steps, task execution state, persistent preferences, imported quiz sessions, questions, submitted answers, attached answer images, grading records, session reports and mistake records. _(impl: 1.1, 2.2, 3.4 · verify: 5.1)_
* **D-03** [MANDATORY] Stable IDs; historical sessions are preserved when a task or imported question set is edited or deleted; no destructive updates. _(impl: 1.1, 2.2 · verify: 1.5, 5.1)_
* **D-04** [MANDATORY] A versioned, validated JSON import format supporting at least: session title, subject, lesson, source material info, instructions, questions, question IDs/types, rich content, media attachments, answer input type, options, optional answer key, explanation, solution, marks, topic, difficulty and grading criteria. _(impl: 2.1 · verify: 2.1)_
* **D-05** [MANDATORY] The format supports different question structures without forcing empty irrelevant fields. _(impl: 2.1 · verify: 2.1)_
* **D-06** [MANDATORY] Unknown fields never corrupt an import; invalid question types produce clear validation errors. _(impl: 2.1 · verify: 2.1)_
* **D-07** [MANDATORY] The application never silently discards media or mathematical notation. _(impl: 2.1, 2.3 · verify: 5.1)_
* **D-08** [MANDATORY] The reusable fixed AI prompt generates exactly the JSON format the application accepts. _(impl: 2.4 · verify: 5.3)_

### Part 12 — Explicitly deferred (must NOT be implemented in this release)

* **DF-01** [DEFERRED] Automatic AI recognition of task names — deferred to a future release. _(impl: — · verify: 5.4)_
* **DF-02** [DEFERRED] AI-generated task decomposition — deferred to a future release. _(impl: — · verify: 5.4)_
* **DF-03** [DEFERRED] Keyword-triggered study templates — deferred to a future release. _(impl: — · verify: 5.4)_
* **DF-04** [DEFERRED] Automatic AI coaching — deferred to a future release. _(impl: — · verify: 5.4)_
* **DF-05** [DEFERRED] Per-step mathematical scoring — deferred to a future release. _(impl: — · verify: 5.4)_
* **DF-06** [DEFERRED] Continuous AI analysis — deferred to a future release. _(impl: — · verify: 5.4)_
* **DF-07** [DEFERRED] Complicated reward systems — deferred to a future release. _(impl: — · verify: 5.4)_
* **DF-08** [DEFERRED] Unnecessary new top-level navigation — deferred to a future release. _(impl: — · verify: 5.4)_

### Part 13 — Testing and acceptance

* **TS-01** [MANDATORY] Execute the 15 Task Atomization tests: create a task with multiple steps; edit a step; delete a step; reorder steps; execute one step; confirm automatic transition; return to the previous step; skip a step when skipping is enabled; pause and resume; close and reopen the app; confirm exact state restoration; finish all tasks scheduled for one day; confirm the optional next-day prompt; verify no duplicate completion records; verify all preferences persist. _(impl: 1.5 · verify: 1.5)_
* **TS-02** [MANDATORY] Execute the 22 Focus Quiz tests: copy the saved AI Prompt; import valid JSON; import invalid JSON with clear errors; import all question types; render mathematical notation; display diagrams and images; attach a handwritten answer image; navigate questions; Mark for Review; skip and return; confirm answers preserved; close and reopen; resume an unfinished session; finish with an answer key; finish without an answer key; manually grade; leave answers awaiting grading; export the complete answer sheet; generate optional AI grading material; verify report calculations; verify mistake tracking; verify settings persist. _(impl: 5.1 · verify: 5.1)_
* **TS-03** [MANDATORY] Regression: existing task management, habit tracking, lesson pages, Notes and Summary, study materials, Quran and Wird functionality, offline functionality all still work; no existing data deleted; the PWA update system is not broken; the app works on mobile. _(impl: 1.5, 5.1, 5.4 · verify: 5.4)_
* **TS-04** [PROCESS] Never claim a test passed unless it was actually executed; clearly distinguish executed tests from untested scenarios. _(impl: ALL · verify: 5.4)_

### Part 14 — Final deliverables

* **DL-01** [MANDATORY] Final deliverable 1: The complete modified project as a ZIP. _(impl: 5.4 · verify: 5.4)_
* **DL-02** [MANDATORY] Final deliverable 2: A list of every modified, created and deleted file. _(impl: 5.4 · verify: 5.4)_
* **DL-03** [MANDATORY] Final deliverable 3: A precise explanation of every modification. _(impl: 5.4 · verify: 5.4)_
* **DL-04** [MANDATORY] Final deliverable 4: Confirmation that existing application features were preserved. _(impl: 5.4 · verify: 5.4)_
* **DL-05** [MANDATORY] Final deliverable 5: Confirmation that existing user data was preserved. _(impl: 5.4 · verify: 5.4)_
* **DL-06** [MANDATORY] Final deliverable 6: The final JSON schema. _(impl: 5.3, 5.4 · verify: 5.4)_
* **DL-07** [MANDATORY] Final deliverable 7: The reusable fixed AI prompt. _(impl: 5.3, 5.4 · verify: 5.4)_
* **DL-08** [MANDATORY] Final deliverable 8: The implementation and testing report. _(impl: 5.4 · verify: 5.4)_
* **DL-09** [MANDATORY] Final deliverable 9: Instructions for importing questions. _(impl: 5.3 · verify: 5.4)_
* **DL-10** [MANDATORY] Final deliverable 10: Instructions for using task atomization. _(impl: 5.3 · verify: 5.4)_
* **DL-11** [MANDATORY] Final deliverable 11: A list of deferred features. _(impl: 5.3, 5.4 · verify: 5.4)_


## 7. Technical contracts (normative for all batches)

### 7.1 Modules and injection
New code lives in four blocks inserted by `tools/patch/inject_wird_modules.py` immediately before `<script id="wird-offline">`: `style#wird-tasks-css`, `script#wird-tasks`, `style#wird-quiz-css`, `script#wird-quiz`. Sources are `tools/src/wird-kit.js` (prepended to both blocks, single guarded instance `window.WirdKit`), `<module>-shell.js`, `<module>-core*.js`, then all other `<module>-*.js` in lexicographic order; CSS: `<module>.css` then `<module>-*.css`. Load-time code may depend only on files earlier in that order. Modules are IIFEs exposing only `window.WirdTasks` / `window.WirdQuiz`; habits state is read by bare `H`. **`index.html` is regenerated by the injector from `tools/src/`; it is never hand-merged.**

### 7.2 Storage namespaces
localStorage: `wird_tasks_v1` (plans, days, steps, execution, history, schemaVersion), `wird_taskprefs_v1`, `wird_quizprefs_v1`. IndexedDB: `wird_quiz_db` v1, created lazily on first quiz use, stores `sessions`, `answers`, `images`, `gradings`, `reports`, `mistakes`. Nothing else may be written; existing databases/keys/versions never change.

### 7.3 Hooks into existing screens (patch-free by default)
* Habits: capture-phase delegation + MutationObserver on `#habitsRoot` / `.modal-overlay.open` (quick-task modal `#qn`/`#hok`), owner B3.
* Lessons: MutationObserver for `section.wr[data-lesson]`; inject a sibling after `#wrHead` (never inside `#wrHead`/`.wr-foot`); optional `window.__wirdRow` wrapper; owner B8.
* Every observer is O(1) per mutation (lesson `openMs` headroom is 33 ms). A guarded patch of `script:#2` needs the user’s approval and `--allow-guarded script:#2`.

### 7.4 Task engine
Defined by TASK 1.1 and documented in `docs/TASKS-ENGINE.md` (model, events, storage format). Pure logic, injected dependencies, idempotent completion, append-only events, tombstones, schemaVersion, degraded mode instead of throwing. Undo window constant `UNDO_WINDOW_MS` (I3).

### 7.5 Quiz schema
`wird.quiz/1`, defined by TASK 2.1 and documented in `docs/QUIZ-SCHEMA.md`: canonical type keys for the 14 types, answer-value shapes (== answerKey shapes), rich-text spec (D4), validator error format `{path, code, severity, message_ar}`, media placeholders (`src:null`, `alt` mandatory).

### 7.6 Widget contract v1
**Widget Contract v1 (normative; shared by B9 = TASK 3.1, B10 = TASK 3.2, consumed by B11/B12).**
* File `tools/src/quiz-core-widgets.js` holds ONLY the registry below. The first batch that needs it creates it with exactly this content; if it already exists and is identical, leave it alone;
  if it exists and differs, STOP and report (do not merge silently). It sorts before the other widget files (`<module>-core*` rule of the injector).
```js
// tools/src/quiz-core-widgets.js — Widget Contract v1 (BYTE-IDENTICAL in every batch that creates it; never edit it except by approved REPLAN)
(function () {
  'use strict';
  var Q = window.WirdQuiz; if (!Q) return;
  if (Q.widgets && Q.widgets.contract === 1) return;
  var reg = Object.create(null);
  Q.widgets = {
    contract: 1,
    register: function (typeKey, impl) {
      if (!typeKey || !impl || typeof impl.mount !== 'function') throw new Error('widget needs mount(host, ctx)');
      reg[typeKey] = impl;
    },
    get: function (typeKey) { return reg[typeKey] || null; },
    has: function (typeKey) { return !!reg[typeKey]; },
    types: function () { return Object.keys(reg); }
  };
})();
```
* A widget implementation: `Q.widgets.register(typeKey, { version: 1, mount(host, ctx) { … return instance; } })` where `typeKey` is one of the canonical keys defined by TASK 2.1 in
  `docs/QUIZ-SCHEMA.md`, `host` is an empty DOM element owned by the widget, and
  `ctx = { question, value, readOnly, prefs, onChange(value), rich }`.
  * `ctx.question` is the **solving projection** of the question: id, type, number, stem, media, parts/steps, options, input kind, marks — and **never** `answerKey`, `explanation`, `solution`
    or `gradingCriteria` (no correctness cue can leak; the widget could not display it even by bug).
  * `ctx.value` is the saved answer value (shape per type in `docs/QUIZ-SCHEMA.md`, identical to the answerKey shape) or `undefined`; `ctx.readOnly` is true in review.
  * `ctx.rich(el, text)` renders rich text through the TASK 2.3 renderer (math, tables, media) into `el`.
  * `instance = { getValue(), setValue(v), isAnswered(), focus(), destroy() }`; `onChange(value)` is called after every user edit (the runner debounces and saves).
* Widgets never persist anything themselves except through `ctx.onChange` (attachments use the store API documented by TASK 2.2) and never show colours/icons that depend on correctness.
* Selected/active visual states must be identical for right and wrong choices. Touch targets ≥ 44×44 px. RTL aware. No horizontal overflow at 360 px.

### 7.7 Solving projection
The runner and widgets receive only the **solving projection** of a question — never `answerKey`, `explanation`, `solution`, `gradingCriteria`. Answers/explanations exist in memory only in review (B12+).

### 7.8 Conventions
Files `tools/src/<module>-<area>.js|css`; tests `tests/<area>.<kind>.test.js` (new files only); docs under `docs/`; logs under `docs/test-logs/<batch>/`; checkpoint ZIP `wird_work_<Bxx>_checkpoint.zip` with top-level folder `wird_work/`; Arabic UI strings in the app’s Egyptian tone; design tokens and classes of the existing app; DOM built with `textContent` (no unescaped `innerHTML`).

### 7.9 Verification contract
Each batch starts and ends with the verifier (PASS) and its self-test (27/27), runs the six existing suites on a scratch copy in the foreground against the baseline (update 64/64, offline 1/1, unified 12/12, resources 34/34, courses 32/32 with flaky test 18, perf within budget), reports executed vs not executed honestly, and lists real-device checks as NOT TESTED.

### 7.10 Release contract
No `sw.js` change until D6 (HARD gate at B17). A bump, if approved, changes only the single `SHELL_VERSION` number and is recorded as an approved exception — the baseline is never regenerated.

## 8. Decision register

Status of every decision at package time: **UNCONFIRMED — the default is in force**. The user answered none of D1–D11 explicitly; B1 did not depend on them. Gate HARD = stop and ask before the dependent batch; SOFT = proceed with the default, label it ASSUMED DEFAULT, ask for confirmation.

### D1 — Entry point of Task Atomization
* **Needed by:** B3 · **Gate:** SOFT · **Status:** UNCONFIRMED (default in force)
* **Options:** (a) action on quick-task rows + chip in the quick-task modal (no wizard change); (b) additionally a 4th tracking chip in habit-wizard step 2 (the user circled the free slot beside «بالكمية» in a screenshot, but the brief also says the wizard must stay intact).
* **Default:** (a). No 4th wizard chip: it would edit `hWizard` type logic in the guarded main script (`w.type` = b|time|qty drives routing, `meas()` and saving).
* **Evidence/why:** Docs/INTEGRATION-SPIKES.md §h; brief Part 1.2 (wizard intact) vs the circled screenshot.

### D2 — Meaning/location of "Add New Sheet" = anchor of the saved-prompt button
* **Needed by:** B8 · **Gate:** HARD · **Status:** UNCONFIRMED (default in force)
* **Options:** A = unit-row `＋` aria «ملخص جديد» in the sidebar (via `window.__wirdRow` wrapper); B = lesson header, sibling directly after `#wrHead` (beside «📅 جدولة»); C = sidebar-top `＋` «مادة جديدة».
* **Default:** B. NOT confirmed by the user; no literal "Add New Sheet" control exists in the app.
* **Evidence/why:** Docs/INTEGRATION-SPIKES.md §a (probe c1–c4). Wrong anchor = rework of B8, hence a HARD gate.

### D3 — How quizzes appear inside a lesson
* **Needed by:** B8 · **Gate:** SOFT · **Status:** UNCONFIRMED (default in force)
* **Options:** (a) lesson-linked panel owned by the new module; (b) a new `quiz` lesson resource type/tab (requires patching frozen blocks).
* **Default:** (a). Proven: `repo.saveResource({type:"quiz"})` is rejected ("Invalid resource").
* **Evidence/why:** Docs/INTEGRATION-SPIKES.md §b.

### D4 — Rich-text format of quiz content
* **Needed by:** B6 · **Gate:** SOFT · **Status:** UNCONFIRMED (default in force)
* **Options:** (a) small Markdown-style subset mapped to the existing lesson node types (heading 1–3, lists, `$…$`, `$$…$$`, `\ce{}`, pipe tables, images via media); (b) raw lesson-node JSON.
* **Default:** (a), obeying the `wMathTok` tokenizer rules. The brief assumed Markdown headings; the real lesson content is a JSON node tree.
* **Evidence/why:** Docs/INTEGRATION-SPIKES.md §c.

### D5 — Mistake tracking: pool, notebook integration, defaults
* **Needed by:** B14 · **Gate:** SOFT · **Status:** UNCONFIRMED (default in force)
* **Options:** Separate pool in `wird_quiz_db` + optional one-tap push to «دفتر الأخطاء»; or write only into the notebook; defaults for the on/off toggles.
* **Default:** Separate pool + optional push through `repo.saveMistake` (needs a `lessonId`). Recording ON (passive, no popups); automatic revision suggestions OFF until enabled (threshold default 3 incorrect in one topic); status rule: correct once → improving, correct in two separate sessions → mastered; incorrect again → open and recurrence +1.
* **Evidence/why:** Docs/INTEGRATION-SPIKES.md §d; brief Part 9 does not state defaults.

### D6 — `sw.js` SHELL_VERSION bump at release
* **Needed by:** B17 · **Gate:** HARD · **Status:** UNCONFIRMED (default in force)
* **Options:** (a) never touch sw.js; (b) bump `SHELL_VERSION` once at the end (single number) with explicit approval.
* **Default:** (a) until B17. The brief forbids modifying sw.js; the update guide says users still get updates through index.html change detection when the number is not bumped.
* **Evidence/why:** Brief Part 0.B vs docs/UPDATE-GUIDE.md release procedure.

### D7 — Future-day plans storage
* **Needed by:** B2 · **Gate:** SOFT · **Status:** UNCONFIRMED (default in force)
* **Options:** (a) standalone in `wird_tasks_v1`, optional link to a TODAY quick task; (b) also materialise quick tasks in `H.oneoffs[date]` for future days.
* **Default:** (a). No writes to `wird_habits_v1` for other days.
* **Evidence/why:** Docs/INTEGRATION-SPIKES.md §9.2 (quick tasks can only be created for today).

### D8 — Link targets of a step plan
* **Needed by:** B3 · **Gate:** SOFT · **Status:** UNCONFIRMED (default in force)
* **Options:** (a) standalone plans and quick tasks only; (b) also habit rows.
* **Default:** (a). Habits are recurring; atomizing them is not requested explicitly.
* **Evidence/why:** Brief Part 1.2 says "task and habit management" but the plan model is DAY → TASKS → STEPS.

### D9 — Scoring rules of the session report
* **Needed by:** B13 · **Gate:** SOFT · **Status:** UNCONFIRMED (default in force)
* **Options:** Partial-credit weight when no awarded marks are typed; handling of questions without marks when others have marks; when a mastery % may be shown.
* **Default:** Partial = 50 % of the question marks unless the user types awarded marks. If some questions have marks and others do not: the weighted score covers only the questions that have marks and the rest are listed separately ("بدون درجات"); with no marks at all every question weighs 1. Mastery % is shown only when no question is Awaiting Grading or Needs Review; otherwise show the graded-only score with its denominator, never labelled mastery. Unanswered counts as 0 once graded Unanswered.
* **Evidence/why:** Brief Part 8 requires partial credit and unequal marks but gives no numbers.

### D10 — Meaning of "submit the answers to a teacher"
* **Needed by:** B13 · **Gate:** SOFT · **Status:** UNCONFIRMED (default in force)
* **Options:** (a) export/share (copy, Web Share, print/PDF) — no backend; (b) any in-app submission to a server.
* **Default:** (a). No backend exists and external services are excluded by the brief.
* **Evidence/why:** Brief Part 6 Scenario B and Part 0.D.

### D11 — Location of settings (no global settings screen exists)
* **Needed by:** B5 · **Gate:** SOFT · **Status:** UNCONFIRMED (default in force)
* **Options:** (a) module-owned settings sheets (⚙ in the planner/execution screens and the quiz start sheet); (b) rows added inside existing settings screens (frozen/guarded code).
* **Default:** (a).
* **Evidence/why:** Docs/INTEGRATION-SPIKES.md §e.

### Interpretations (not decisions; recorded so they are not mistaken for requirements)
* **I1** The saved prompt is built into the app as a versioned constant (one-tap viewer + copy). It is not user-editable (editing was not requested).
* **I2** The brief lists three screenshots in a different order than the files received; they were identified by content: wizard step 1, wizard step 2, lesson page. Annotation marks (arrow on the lesson screenshot, circle in wizard step 2) are interpreted as in D1/D2 and are not treated as requirements.
* **I3** Undo window default is an implementation constant (suggested 8 s, adjustable) because the brief only says "brief".
* **I4** No automatic opening of the execution screen at app start; resume is offered through the planner/row actions (the brief requires exact resume but not auto-open).
* **I5** Real-device behaviour (Android Brave, camera capture, on-screen keyboard, installed PWA) cannot be tested in the container; it must be reported as NOT TESTED and listed for the user to try on a phone.

## 9. Unresolved items and contradictions (identified; none resolved silently)

| # | Item | Where | Treatment |
|---|---|---|---|
| U1 | The user circled the free slot beside «بالكمية» in the wizard screenshot, but the brief says the wizard must stay intact and atomization may live on a task card. | D1 | Default: no wizard change; ask. |
| U2 | "Add New Sheet" does not exist as a control; three candidates. | D2 | HARD gate before B8. |
| U3 | The brief assumes Markdown heading semantics; the lesson renderer is a JSON node tree. | D4 | Default: Markdown-style subset mapped to node types. |
| U4 | The brief forbids modifying `sw.js`; releasing normally bumps `SHELL_VERSION`. | D6 | HARD gate at B17; default no change. |
| U5 | The brief asks for "an appropriate settings location within the existing app"; no global settings screen exists. | D11 | Default: module-owned sheets; ask. |
| U6 | "Task and habit management": atomization targets quick tasks/standalone plans; habits are recurring and are not link targets. | D8 | Default: quick tasks + standalone plans only. |
| U7 | Partial-credit value, mixed marks and the mastery threshold are not specified. | D9 | Defaults documented; ask before trusting numbers. |
| U8 | "Submit the answers to a teacher" has no backend. | D10 | Export/share only. |
| U9 | Defaults of the mistake-tracking toggles are not specified. | D5 | Recording ON, suggestions OFF. |
| U10 | The brief’s screenshot order differs from the files received. | I2 | Identified by content. |
| U11 | The amendments A1–A8 and the decision defaults were presented after B1 and the user proceeded without objection; not explicit approval. | MASTER-PLAN | Treated as adopted-but-unconfirmed; the user may override at any batch. |
| U12 | The container clock (2026-11-03 UTC) is one day behind the chat date. | docs | Cosmetic. |
| U13 | Real devices cannot be tested here. | I5 | Always reported as NOT TESTED with a manual checklist. |

Checked and found consistent (no action): default "no total-question counter" vs the settable "Question counter Hidden/Visible"; "no correctness until review" vs Scenario A review; manual question creation not a priority vs the import format; optional Mark for Review/Skip and Return vs the first-release list; Phase-1/Phase-2–4 independence vs the join points listed in `BATCH-DEPENDENCY-MAP.md`.

## 10. Roadmap and batch index (generated)

| Task | Title | Size | Depends | Batch |
|---|---|---|---|---|
| 0.1 | Baseline, preservation verifier, tracking files | S | — | B01 |
| 0.2 | Integration-point spikes (read-only) | M | 0.1 | B01 |
| 0.3 | Module scaffold, injector, storage namespaces | M | 0.1, 0.2 | B02 |
| 1.1 | Task engine & persistence | M | 0.3 | B02 |
| 1.2 | Planning UI & entry points | L | 1.1, 0.2 | B03 |
| 1.3 | Focused execution screen | L | 1.1, 1.2 | B04 |
| 1.4 | Preferences, feedback, end-of-day | M | 1.3 | B05 |
| 1.5 | Verification & regression | M | 1.1, 1.2, 1.3, 1.4 | B05 |
| 2.1 | JSON schema, content spec, validator | M | 0.3, 0.2 | B06 |
| 2.2 | Storage & session state machine | M | 2.1 | B06 |
| 2.3 | Rich question renderer | L | 2.1, 0.2 | B07 |
| 2.4 | AI prompt, import UI, lesson placement | M | 2.1, 2.2, 2.3 | B08 |
| 3.1 | Choice-family widgets | M | 2.1, 2.3 | B09 |
| 3.2 | Free-form widgets & attachments | L | 2.2, 2.3 | B10 |
| 3.3 | Focus Tunnel flow | L | 3.1, 3.2, 2.2 | B11 |
| 3.4 | Quiz preferences & modes | M | 3.3, 1.4 | B11 |
| 4.1 | Review & self-grading | L | 3.3, 2.2 | B12 |
| 4.2 | Export & external-AI grading workflow | M | 4.1 | B13 |
| 4.3 | Session report | M | 4.1 | B13 |
| 4.4 | Mistake tracking | M | 4.1, 4.3, 0.2 | B14 |
| 5.1 | Quiz end-to-end suite | L | 4.1, 4.2, 4.3, 4.4 | B15 |
| 5.2 | Mobile / RTL / accessibility / performance pass | M | 5.1 | B16 |
| 5.3 | Documentation | S | 5.2 | B16 |
| 5.4 | FINAL AUDIT & packaging | M | ALL | B17 |

| Batch | Tasks | Phase | Requires | Prompt |
|---|---|---|---|---|
| B01 | 0.1 + 0.2 | Phase 0 | — | `prompts/B01-EXECUTION-PROMPT.md` |
| B02 | 0.3 + 1.1 | Phase 0 / Phase 1 | B01 | `prompts/B02-EXECUTION-PROMPT.md` |
| B03 | 1.2 | Phase 1 | B02 | `prompts/B03-EXECUTION-PROMPT.md` |
| B04 | 1.3 | Phase 1 | B03 | `prompts/B04-EXECUTION-PROMPT.md` |
| B05 | 1.4 + 1.5 | Phase 1 | B04 | `prompts/B05-EXECUTION-PROMPT.md` |
| B06 | 2.1 + 2.2 | Phase 2 | B02 | `prompts/B06-EXECUTION-PROMPT.md` |
| B07 | 2.3 | Phase 2 | B06 | `prompts/B07-EXECUTION-PROMPT.md` |
| B08 | 2.4 | Phase 2 | B07 | `prompts/B08-EXECUTION-PROMPT.md` |
| B09 | 3.1 | Phase 3 | B07 | `prompts/B09-EXECUTION-PROMPT.md` |
| B10 | 3.2 | Phase 3 | B07, B06 | `prompts/B10-EXECUTION-PROMPT.md` |
| B11 | 3.3 + 3.4 | Phase 3 | B05, B06, B08, B09, B10 | `prompts/B11-EXECUTION-PROMPT.md` |
| B12 | 4.1 | Phase 4 | B11 | `prompts/B12-EXECUTION-PROMPT.md` |
| B13 | 4.2 + 4.3 | Phase 4 | B12 | `prompts/B13-EXECUTION-PROMPT.md` |
| B14 | 4.4 | Phase 4 | B13 | `prompts/B14-EXECUTION-PROMPT.md` |
| B15 | 5.1 | Phase 5 | B14 | `prompts/B15-EXECUTION-PROMPT.md` |
| B16 | 5.2 + 5.3 | Phase 5 | B15 | `prompts/B16-EXECUTION-PROMPT.md` |
| B17 | 5.4 | Phase 5 | B16 | `prompts/B17-EXECUTION-PROMPT.md` |


## 11. Governance and workflow

* **Status vocabulary:** NOT STARTED · IN PROGRESS · COMPLETED · BLOCKED · NEEDS VERIFICATION. **IMPLEMENTED ≠ TESTED ≠ VERIFIED.** A task is COMPLETED only when its acceptance criteria are met by executed checks.
* **Commands the user may use:** `CREATE ROADMAP`, `EXECUTE: TASK X [+ TASK Y]`, `STATUS`, `HANDOFF`, `VERIFY`, `RESUME`, `REPLAN`, `FINAL AUDIT`. A batch prompt is the standing form of `EXECUTE` for its tasks; `VERIFY` = run the checks without changing anything; `REPLAN` = reassess remaining tasks without discarding completed work (output is a proposal; the user approves before prompts/roadmap change).
* **One batch per conversation; one approval per batch.** No batch starts another batch. Bugs outside the scope are documented, not fixed. Missing prerequisites stop the session.
* **End-of-batch handoff:** update MASTER-PLAN (if necessary), PROJECT-STATUS, HANDOFF, CHANGELOG; checkpoint ZIP verified by re-extraction; exact modified-file list; honest test report.
* **Change control:** requirements change only on the user’s explicit instruction, recorded in §12 and in the register; amendments to task cards go through `REPLAN` and are noted in `docs/ROADMAP.md`.

## 12. Change log

| Date | Entry |
|---|---|
| 2026-11-03 | **B1 executed** (TASK 0.1 + 0.2): baseline, preservation verifier, integration spikes; no application code changed. Amendments A1–A8 and decisions D1–D7 proposed in the B1 report. |
| 2026-11-03 | **PKG-1 (planning package, docs only):** this MASTER-PLAN, 17 batch prompts, BATCH-DEPENDENCY-MAP, TRACEABILITY-MATRIX, PROMPT-USAGE-GUIDE; ROADMAP.md restored to the full approved card text; new decisions D8–D11 and interpretations I1–I5 added (all UNCONFIRMED defaults); no application code changed. |
| 2026-11-06 | **B2 executed** (TASK 0.3 + 1.1): injector, shared kit, module shells, task engine, tests; first change to `index.html` (four-block insertion only). Assumptions recorded, not decisions: `endOfDayPrompt` default on, undo window 8 s, engine backups before overwrite. D1–D11 unchanged (still UNCONFIRMED); D7 default (a) implemented. Storage compaction policy flagged for the user before B17. |
